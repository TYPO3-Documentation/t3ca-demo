-- MariaDB dump 10.20-11.8.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.9-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1795336957,1795336957,0,0,'Edit pages, content and news of the Mto Safi site. Images upload to fileadmin/user_upload/news/','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','Editors','1','1','readFolder,addFolder,renameFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',0,'1,4,254','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','pages:doktype,pages:php_tree_stop,pages:categories,pages:layout,pages:extendToSubpages,pages:nav_title,pages:nav_hide,pages:subtitle,pages:target,pages:lastUpdated,pages:newUntil,pages:cache_timeout,pages:cache_tags,pages:no_search,pages:shortcut_mode,pages:content_from_pid,pages:keywords,pages:description,pages:abstract,pages:author,pages:author_email,pages:media,pages:is_siteroot,pages:mount_pid_ol,pages:module,pages:l18n_cfg,pages:backend_layout,pages:backend_layout_next_level,pages:hidden,pages:starttime,pages:endtime,pages:fe_group,pages:rowDescription,pages:seo_title,pages:no_index,pages:no_follow,pages:sitemap_changefreq,pages:sitemap_priority,pages:canonical_link,pages:og_title,pages:og_description,pages:og_image,pages:twitter_title,pages:twitter_description,pages:twitter_image,pages:twitter_card,tt_content:categories,tt_content:layout,tt_content:frame_class,tt_content:space_before_class,tt_content:space_after_class,tt_content:date,tt_content:header_layout,tt_content:header_position,tt_content:header_link,tt_content:subheader,tt_content:imagewidth,tt_content:imageheight,tt_content:imageorient,tt_content:imageborder,tt_content:image_zoom,tt_content:imagecols,tt_content:pages,tt_content:recursive,tt_content:sectionIndex,tt_content:linkToTop,tt_content:hidden,tt_content:starttime,tt_content:endtime,tt_content:fe_group,tt_content:rowDescription,tt_content:sys_language_uid,tt_content:bullets_type,tt_content:table_class,tt_content:table_caption,tt_content:table_delimiter,tt_content:table_enclosure,tt_content:table_header_position,tt_content:table_tfoot,tt_content:file_collections,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:uploads_description,tt_content:uploads_type,sys_category:hidden,sys_category:starttime,sys_category:endtime,sys_category:description,sys_category:sys_language_uid,sys_category:images,sys_category:single_pid,sys_category:shortcut,sys_category:seo_headline,sys_category:seo_title,sys_category:seo_description,sys_category:seo_text,sys_category:slug,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:title,sys_file_reference:link,sys_file_reference:description,sys_file_reference:alternative,sys_file_reference:crop,sys_file_reference:autoplay,sys_file_reference:showinpreview,tx_news_domain_model_news:sys_language_uid,tx_news_domain_model_news:hidden,tx_news_domain_model_news:starttime,tx_news_domain_model_news:endtime,tx_news_domain_model_news:fe_group,tx_news_domain_model_news:alternative_title,tx_news_domain_model_news:teaser,tx_news_domain_model_news:archive,tx_news_domain_model_news:author,tx_news_domain_model_news:author_email,tx_news_domain_model_news:categories,tx_news_domain_model_news:related,tx_news_domain_model_news:related_from,tx_news_domain_model_news:related_links,tx_news_domain_model_news:keywords,tx_news_domain_model_news:description,tx_news_domain_model_news:istopnews,tx_news_domain_model_news:content_elements,tx_news_domain_model_news:tags,tx_news_domain_model_news:fal_media,tx_news_domain_model_news:fal_related_files,tx_news_domain_model_news:sitemap_changefreq,tx_news_domain_model_news:sitemap_priority,tx_news_domain_model_link:sys_language_uid,tx_news_domain_model_link:hidden,tx_news_domain_model_link:description,tx_news_domain_model_tag:sys_language_uid,tx_news_domain_model_tag:hidden,tx_news_domain_model_tag:slug,tx_news_domain_model_tag:seo_headline,tx_news_domain_model_tag:seo_title,tx_news_domain_model_tag:seo_description,tx_news_domain_model_tag:seo_text','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:div,tt_content:CType:form_formframework,tt_content:CType:felogin_login,tt_content:CType:news_pi1,tt_content:CType:news_newsliststicky,tt_content:CType:news_newsdetail,tt_content:CType:news_newsselectedlist,tt_content:CType:news_newsdatemenu,tt_content:CType:news_categorylist,tt_content:CType:news_newssearchform,tt_content:CType:news_newssearchresult,tt_content:CType:news_taglist,tt_content:CType:mtosafi_tiles','0',NULL,'web_layout,records,media_management',NULL,'options.defaultUploadFolder = 1:/user_upload/news/','','',NULL,NULL);
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1794119204,1794119204,0,0,0,0,NULL,'a:7:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";i:0;}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\",\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":0}',0,NULL,'','_cli_','$argon2id$v=19$m=65536,t=16,p=1$SC5jQVhyTVMwZmIuZi9lVQ$my26zjcmtB0GZl+0EIiotj27ERAFI4Epms3l9llGZqM','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1794119204,1794119204,0,0,0,0,NULL,NULL,NULL,0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$NTQwSlBTTVJPdDBTeTNPaA$tH9SFkLNfU1mfU5cvq+Ot4SY54Kw5EpathLn0W0x2EY','',0,NULL,'','admin@mtosafi-demo.example','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'1_88ef5c556644a5cb',1826879810,'x��ێ�Ƶ��WLش��IݭU�lv�M,{�� ����H\Z/o�iWq����(�>���K�~J����3CR��k�;A\rdE��9��\'t丣�r�Y]�9�|�<А MK�o�v�3��|����g�d��hro�?$����b����B�����)J���Ck��\0f�`���/V\\�+�K���,�b�������#6�̸�ɒd,�\"FTJ$�c�r=�Q���4c	��Z��ɔ& U��\'���*���+N�hK��2?�2c��.)���IH\"�D��:	a����[�ΞTHi�|�R���v{$]�#; �����i�\nVY�ՊqA�%���*aB��d���*X��A{�\r@�T&G���f�w��e�m�~#�\\�����\"+��VkN%B���0��t\\��;�p0�>H�h��C[�1hM��t����gN��<w�8b���}tGhu�U�&�Ә�[���1j?��d�*ɽ��2Z<�j����pv��BU�^�P�C�����~aF[4b�:VUr���+�ԛ�$e+�<9�,��]��,��������I4I��,NB`�\0}��c�e�d��V�����%�l�Z���bMf\0�\0ȵ2nQ̓8�b5P�\r���0�bT��O���AD�\0��6��$a��z��h2��AR��\\xV�i���wߜN�v�>����|�v;��m�߸�QԱ&t���Q�9c��G��\0h *0�3��Y,m�#���ʵ�Ƹ��eM���]�4#~%`��T,�S�5�7��3�q\0�8�E�c���Rƾ�y�$R�*e�B�\"&��n�2�~����jL����<F|,c���q�Ұ}�2�i�-f�Z�HFE���H!�X�X�-(\"��Ʊ��Ն�5�{�!�!��:��L�b�/�߸�q4��I�V��{<�<��\"�,�[�X�G�)��>I��E�e�PVT�S�~+	������qˌ�Y���w���Q�c��ZA�c ��V�r��j���\n�\ZL2�ĂF��P]����ۀ�%�:��p�<�\n-|�\0�44݋��h���u�)�jǤ�\\\n��B貇-��U��.x-�;�l�bvF���O��	������&B��\"~�X�~kt,�p�&ț}�h�xʙ�ߚ��D�)ׂ�ؚ\\�kN ~k�ڇ.� �Ng�m�ə��\Z�[�j�\\w@8nU�V�t�2�eG��T�Xf�ʹ-Q����3�ʹ����\\D��?�U\ZWC�..G��^����ق�#��a��c�J�g�8���@N�}���V�mz������)b����9�u�mW�x�j�����lQQ�P�[Y�.��^�\'jC�k�=pk�iI��/�\Z��.�	�/U�\r\Z.W{�}jP\n�O0 ր����y[0�DIA��ͬch��K�Nt��І�h�����\\�\'��Ԅ�w�!�]�5�{_R������׹�g�\ZAjߵ�7��{��e�i�11��{7u�g�=Z�/��E�jJD��.���\\��\"�7�E<g�y%�d\"�#�)w�����yc��;�׭�����S�TVu�UwAs�q�$�W��ﷶ�}宏ʧ�9�>D�?<?z<gPI�J�U���s@E䍁״)�4]9���ҍy�Q����M�k5���х���(қ�Fo�T�U�F��dR6m�������Σ��8�˪��A������!�t|8��x�v��Z�<M7,�!�#]cV�q�?�<�=Yp�\"&�Sr���x���)�c{;�$]�m�C�C�BxI�C�	t� o�B�\'	D�c�z���;�.\\�DS[��+_l��΋��Ѧ�m�#nNiH�T�Z꼱������v�q�D�!��n�����}�,P�kM�1������(��Z,h�mS�6�b�/Rq)�X\'ڈ�_�+�.��RE�ZE/�VsǆS��ؙ������,�X�+,چ�70�kD�?�/��}7���W.s�B\Zgv�_\01�Ռ{��1(n�Ɇ�}|`bT�#U�7��`�\r\r�آ9�����_�l×�|�<�^W����l�W	�.�yKI�������k�ϖ ���}܉��k*�c�U��:^����ld@\r����:k��n�|Uc\'��sܨwhn=�i��4�Ue���3��i�Қܫ�\'�<; ���q�����`o~�*4��n�<�t��U���=��4	��Dpx��~:�AGQ�ߠ!��B@�\nY��+�ll�n��&�/η7l��۷���;�����>G�cP�[=�z�R��������3Pi\0]ƙy\'����3��*�Y*��}�W����+�� ,/��[��;��X�i��$��O�P�\\��:#C�ǕLq@�/�P��uo��1���p!x@u�=��N5E�W,d\05Œg�M?�~J7t�W��8_jc���/��1�ot����z���2 ���\r޽q��*�la�vF�b�JOzP^�17lp�;�N�^�$0�X�=z����>��	���}�+}��1�+\\��jg�=�,\\�ú��1�}����p�{�0N\r{����6�-Bfcج|*OD\Z?��ǋ��Ԛ��\r+z#+J�\"����ȃ�pϏ���G�=<���K�L�¬Q�G�~��b1PY�Q w]3B��\Z�<Jý�~m�P�S�� ]\'Jl�J\ro���X1w``��4��r=ݱ�5��I�J߮z!O��zi�p�܁ܟ����D ���(0��-s�kA7�x��Jt��>�z���3��I�I\ZΉR���r��������X���5���7Y�rq/�R���7�~[\\?��G��Y�kV9h��$��S��M�#/c\\��T�r�\n�U���\0c�;J���R��O��v�����H����h���eA(��h�@�g�=\Z�{b� �v\015:g涜l鲧X�\"_�JX�δ��O�y�gI;���{���\"���Kt8��tTH��)�k���b@�[�\'b������#��U�X�R�d��m��m�#��#�ԍx\0;B5���$��e��4z��2��h��-��u�N��Zװr�11��`wJ3;\Z=�!+o\r^�O������\n�\'E�r�[�ay��\\�N�,8�d����c��{����!>Bw�M�,�>M��=��&��1p!p$��-%\Zn(,����^�ќ��Ϗ�%˟�uN�S�F&`\'�BVUiǽ�c����ܜ���E3���]�U�5�&@�r���Ҥ���k�z�ѻ܂|5I��nU73������#A����ʋ+� {�N�����\n���\Z<x3�_�G׿�4�`��l�70�=X�	��e�삯\Z��?0���W��ݽ�3���^_�\r��i�iF�5՝�E��K^vkN��͚�Ω�*[�\"g7ʅï\n�b�;����4R��H;�v^`�?�\r?+M�4ZR�|~Π��;�ǆ㧌j˄JλZ����{^@\0I+���xl�:��i�ᆹ;�\\�y{����N�H��ч�Z�.6����-�կ�ߍ����(*��ѧ\r��E,�F��ƃ�ݞ݇�1M�g����|���U���ˇѢ���F.����4A��o�E�����t�����8~4}��嵠�\'�\'�;�}����6������pKO�\'oYPw�vP�KS�r�ʹS�����tA�=ɫ�\\uj A�\Z���^\r���k�>�5�\0A�\Zh�9mWan[Ü\Z�HT��a^ѕ�y���f�ss@�t���l:�*�,�WA�sgP·���GO��v�e9l��p�iͺ5�<-��2�;�0�C�y���@����y�F��ܚM=C�b����=g������7�1X�\Z:�]F}��X��������t�l��~\'lY��znwЦ�\r��z�p�^�a���v?lwzu]���n�������`R_');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_88ef5c556644a5cb','pages_1'),
(2,'1_88ef5c556644a5cb','pages_5'),
(3,'1_88ef5c556644a5cb','pages_11'),
(4,'1_88ef5c556644a5cb','pages_12'),
(5,'1_88ef5c556644a5cb','pages_13'),
(6,'1_88ef5c556644a5cb','pages_14'),
(7,'1_88ef5c556644a5cb','pages_15'),
(8,'1_88ef5c556644a5cb','pages_17'),
(9,'1_88ef5c556644a5cb','pages_18'),
(10,'1_88ef5c556644a5cb','pages_19'),
(11,'1_88ef5c556644a5cb','pages_20'),
(12,'1_88ef5c556644a5cb','pages_21'),
(13,'1_88ef5c556644a5cb','pages_16'),
(14,'1_88ef5c556644a5cb','tt_content_6'),
(15,'1_88ef5c556644a5cb','tt_content_3'),
(16,'1_88ef5c556644a5cb','pages_7'),
(17,'1_88ef5c556644a5cb','pages_6'),
(18,'1_88ef5c556644a5cb','pages_8'),
(19,'1_88ef5c556644a5cb','pages_9'),
(20,'1_88ef5c556644a5cb','tx_news'),
(21,'1_88ef5c556644a5cb','tx_news_pid_32'),
(22,'1_88ef5c556644a5cb','pages_30'),
(23,'1_88ef5c556644a5cb','tx_news_domain_model_news_1'),
(24,'1_88ef5c556644a5cb','tx_news_domain_model_news_2'),
(25,'1_88ef5c556644a5cb','tx_news_domain_model_news_3'),
(26,'1_88ef5c556644a5cb','pages_31'),
(27,'1_88ef5c556644a5cb','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_0_0',1797935810,'x�uUKo�6��W,xRQ�R�C���hsq��\'�\"G2aITI*��w��;���7��/h���M�f�� ���A�a<��)�Ӧ �:��#�ͳ$I�<�a$w03)�ym��DBB/%%t��\Z�T�נ�!�+H�6z��-�M\"2Zm���Ő�1��\r�0�wJ�CO���5ZWS�Ş-kxW�6\\���BC����@�n`�#��h��n���f3&UU-��₼���#f�O���HA���:xu��h<�N�R���A������\'t�����S��l�`.��ɂ���(��ф����-8�cΥ���R�_{������ǧ?�[�&�l�=`�����	�9l\r��nY�S�R�$��P�+Sm�=�F�a�������7\nYw&����l���Gw�a��v�������]>m3ԳD\'S��{��R#�c���~���{_e-j�����������b%Nw^�s���]��i��ҷCϜ�N�>�@=Ԙ#Xo�\0��r�bP ��YG�ؠ�ak�����t�Sk����/njp��kTw�qԸu?{�Yd����9լ�&>+q\0�7F�D����hf�q�,2c�����\'m��\'���v�_xi���M\0f��Ü�d�6��J��Zl%�����K�h�֑��3��a�a9\\�������Â�Z?�\n�&;��\"�8���R�.;I��N4���j[П�E����PY�U�i�i�ww�Nq�U\r����S��NwJ��]�/���i�Ϛ��j��x�Fe��r؆[O���q^�q\Z_8��\\������﨤�6�;^�\\$ �HJ��BR��*eZ�yB!��4��M�U��U<�l\"����1�<�*Z\n	ɦL�&h��ɂ�'),
(2,'5__0_0_0_0',1797935810,'x��UMo�6��W:�亢>V+=I�H}�:������J�JRY/����]9\r�E�&�g��,ȞD�nI�l�\'����	�݊,�������&�6�n{ I�0��4\Z,T1b�ʒd�7����{�o& �<���5�08��\"��+8.���z�����QKeDSZ� �X[�yJ�pM�h��p���3a*IST���iʎ����6��B~�[�xcV����s~ȟ`���^��c�(&w���7�m\\a���O�Q�g2�c��r�`��Z�Ns�Ї�	��|��EC4�w�<�pw�r�N��`������v��������J���e�3.T6��%k�.�C�jف���n��[��b�D��f)�פŭ`5\'oв��a�`N-�:\0iF����ʚ�_��jɩ������tՕޘ�/j������;�����}���x��K56KȐkG�EN�=�����[�Z;�i�G<g?��0�;@��/�LUr�`Pg%�����\'�|h�3\'dÏ\Z#�9��VE���u��g)��4kNݻQ&��Z�qৣTL��E��Y:ɵQ���*Ig �[S0��b+�M �\Z^\nr�����Ҹ�6�˹\r�\nmL�r>��	=\0�x�Ph�%�h�w�`N�{^�� �<���@����S�mb�Ъc����R�����+:�YU�8��]Ǝ��9�����\0\Z�J*|!08,�����/����Go�ј�0��:R��V�܃���b�D���l�^oMt�5��ښBi�\'��֜��-��xx���������ᢝL�[�Q��Ӄ�-/ZP�;YO��f�źZ�������?�~���=Z�F����_��O���:q��J�￯a{]�6= ?V��������e�Nb�⎞������}��H�	*x�Dq\Z$�<�A@�8)�\r	�$��F1	i�7��Q��%	�i�q���A(dAR�\0\\��-8�4O�\'���'),
(3,'11__0_0_0_0',1797935810,'x��UM��6��W:/6�dْ=,��[�݋7���Ʉ%Q%�x�����e���m�&�!���<�_dN�X�Y�/&��\"�C��\r����<�Ʋ��M���*�V��k�,\\Y6y ���p<��B@;Y�Wm�l`��\Z��G�<(�VZ���$�`<h�������Dζ���p-;+�z]���V|?{%��9\ZZ���Yt�~�a���-혆�^�F��/��p����$&dY��M�\'��nM�3���9�dD\'�o��	��5Ѝ��}���3>t�3����dr�?�Ɍ�>J��h������o�><�?����\"��C�xo}�j-v��Z5�;Վ]jT�#Ⱥ}���๣J�ʧ�Q*-4����h��`�rx�L�jo����-\nc`�?\0������L�Wӭ��ŀU<m1�RV׮���Z\r�|�Χ�#kf������\0���}�!��kC˾�%��G:�8P�����<�f��\n��aq�l�2h���s�,<�->�V�K����!���̹�[E\r0�w��Y�QgE��xPZ����=$��\nc5�v�J�[t��� EM�\n�����.: \ru�JY�R��a�`�_rR����������=RKgΗ�Qri�-ʀ�8^~���ͨ9*[^�.\Zl@�)��<�bR�Tu�K��il��C(5��_9b[�J�jz!������\n�o�l�G�t\Z�`�b�=e\'ە;����d�L�����~c�m��m�!Yn��7+�[�y	��r9����Hͯ�ᢜM_[��x�����(Qq��?�5��x� 1;��ӇO����x�z\"�A��۩��~~G~���؉ÍS�T��}�[�f�������L��<<H�5��b�����}�Z�Y�iJxɓ\r���5_��(^sV��(�d���*��)�eA�NS����!��L!��4�V�&�Y��ڱ�'),
(4,'12__0_0_0_0',1797935810,'x��UKo�6��W:�亢^��у�M�֗u99�+�*Iy�0��;z.w�)�C� �M���p�pXd/2#�,[%ً�����nn��v�ſ$󬱬n`��ai42\\f�Ye��\n,^��v+��f��C��ZYÌ�1h���3�\0Zj���&#��{��Q�ʦ�\rWɺ���j�ײ�R�U��V��f��1C+֔+�N��Q��-���بN�%>�ϰ��_H�	�(fs���7�m�\'�T9w�3�7������\r�<�v\rtmhg@�G����{�GC2�w�x<�wr%��Hm>o�w����~��p���b�xg�.p�X�2-��i{��T�	#�u�Le��sK���۶���B�Z�j��=x����xҌP;{ha�\0�mQCw�x�<I��\Z�zw�ǚ�B]��++L�8���!��l\nYN*��m��\0�)պ��x���8��*vP��g��xT�.o���)PÞ���c=�8j��.?7짚���a��lv2������\\8.�j���X�>+�ڏ�����4���(j�i�u��2��:Ib����L�%�s9�,7V3nG\0�d�E�nN�RTK��B� j|+�Y�����R֝�E�T-eHzXt�=�Ⱥ��(��X�����=_����\rʀV8xn��<�QsT6���؀zS\"\n�<�bR�PU��K���@�->�Ph�˽>�ۨFrV�3��aU^\\�A���!,��9;Z��^Z������]�s^8\r�gZ,�k���d�_�#B��_���pVط�\rc����`��A�H�~�+t���B�p����BQqU=.+7�ł��֏������᦯�45jn�\n_�zE~�\"�,Vb�+yJ��ƭt=����X���\n&��\n�\0l�5��b�����}�JbA�D0����a���g�\'!\n��<�c���(Q��u�ֱ����5�Q\n���E��A��\"�SH��I ,�G�oV���'),
(5,'13__0_0_0_0',1797935810,'x��UK��6��W,t�i����I�h�b�A��LXU���X��P/�֦@m� 7��g�o8$�g��{�\'��Y�a���y�����o7���&��6�� ��0��,\Z-T1b�ʒ��57|�⏾{�og �=���\r�18�[�\"i�WJ��^�(�|ot�R�VCj?�IQ�{J�qM�茐��q���0���9,����5i��TO�6HR#��Q�5+X�^��ȟa34�&D�1Q������7�g��tr�3xԗ7�)�+pu����F�^su��3>��1����h\n����x�9�>����`�~��?���{�n%	`A�3��*[]ƥ�\r�εC�\Zك���n��h:��a�D��f)�7�Ý`5\'o�O�a�`N�;\0�6 ��[�N�o���L�� )]��7��c]~v����(E5�o���Q�C�sI��cw��Qܼ&\'y��}a;��X�NcZ�/��b�#3�Ύ�kG;�DU�8V��� �ډ6;;��	����ֈz�kh��{��ܺE���T�r\0Z�5\'���(�<p#/�8��Q*���\"���G�\Z��f�J���� ��\np��A�: 4��RR\Zw�ab��aca�_sR��Ŵ������P�g�� �6�d�k8����QsX����j���U�H�g���ĥ�ky\\����������#Kl+[AI����e�Jm�\0�\Zo\0�fx��� s:����m�p��U��l�D���b�~e^,B��a�P���g�}�[0��g\0x�����;\\���K�3\n�x~ȿ��	�� ��sY��-Wn�޽}����w�\'BkШ��:|��\r��v�B\'��V�S���-l��q����\n�W0��V��\0�Fc<���>�_��Kf	Eq��E��\"McG�&��8I���A�Q�(��iVDi�A�bi��2-�2���3�f��*y������g���'),
(6,'14__0_0_0_0',1797935810,'x��UMo�6��W:��(i�e�`$AS 1\n�sȉ�HJK�$�$�����P_�]9zH��Io�3�yo8$�\'��[�\'q���0�z��[���ᷛ~�/�=�\ri�H�MFA��1|eIr��>D�Gߝ`��3��DUƈ���-s�4�J�+%{H�s�{�7:j��h�!u�Z_垒��\\S%:#$�cp&L-�~��:��qMڪ\'�S��\r���oqGo�\nֲWt� �g���	�f(��]��鍅��WX:9�<�����:���U�q��:����|��EC4�w�O�f�9�>���`�~��wۇ7���{�v%	`A�3��*[]ƥ�\r�N�C�\Zك���n�h:��a�D��f)�7�Ý`5Go���D���;>w\0�m@;t㏾��⍠�#��t��u_\rnН������j|�BE��&%���:l����\\�)pZ�=�v�U��(ϛ��G�An��ƵӤ�|�K\rS�t�a��9�}q�hG����Zk��dP>��Sgg�9![~��\ZQ/w\rmUtǱ�a�1�J�C+��Dѝe�\nn�Y{~<H���^dߙ���BE�����53�A1����h� \Z[y))�;q�H�\\�[�����(m1-��8�� t����?�\\\Zq2�5�{�a&��9,ZZ��_4Xs��D$�3��I�Rֵ<,WLOCEw�X�R�?���%������òZ��G\0~�7�E3<i\'o�9�_G�N�U8��*hp�Q��bz�e��ϖ����b�P��w_������.g\0x�����\\���kk4\n�������((�l��ykڥ�Z�p;��Ûw�~���=Z�F����_�Ы���\n�8\\[%O��װ���A���+�G\\��[���	\0���x��}�����4�S����$\r�,	7MY�0�a�5β���QR�\"�dGQ��Y��8Jˢ,\"\ZG�K��$I9�����|�n'),
(7,'15__0_0_0_0',1797935810,'x��UKo�6��W:���JF�4Z_�9�Dpɑ�XITI*����ћ���m�&~C������ �9�cy��/&s��»C,���t�S�{�XV��fqFA���peIsO@/�xw/��f��C��ZYÌ�o���^�Ԫ��&\'��{�E���M9&&�1�=���p-[+�z}���R�0�%��9Z���X	t*�a���\rm���^�Fu�/	��Ј> �\'LȢ���ozc�6��*\'�?�Gs�ɈN�߀��6е����G���|��\r��޹����>�8-�Ѵ�cK��>=|����+I f���κ,p�X�2-��i�֎]�U�#H�}��nṥJ�ҥ��TZ�YK[-�jO�(f�6�D#���Z�;�i[L�̅q۟PJ��JoL�=_-x|�⹐��v��}K�@FT�ʑ�s�(\03��I�7���Im�]��\Z�\r�B�<\'�ƙrg�t�ˋ��2]�u0�����Au3c?��<�e�ύ�Ւk�W��@�9u��+͹�E\r0����Y�VgE�tTZ����K�G���\'�c����Э)�A���+XLH|�o��4���VʺS����\rI��l\Zʋr�[�c���ҙ��~_\Zi�2�����{3j�ʆW���PoJD�}Ϯ�-TU���f��\n\r�ᣞ�F5���^V�U�����\raY��z�`��b�=e��ʝ���`�q��bz��~c�->�-���,���|��\n���^�<�\\�\0�p�7�G��w�*g��Ve����˫�I���\'��$f��~z�������}O�1�Qs;u�����O_��;q��<�?|��V�m~@~���q�kO\0�l\r������e�&����#2��(<�d�%�0K�iQ�\"&\r��$(�\"J�� Y�t�i��i�}�!�v$�� �6\nױk'),
(8,'17__0_0_0_0',1797935810,'x��UKo�6��W:;�^��у�M��;���i��D���^�����S�@��En�7���|�phϢ�i�&ų.����K���~�ſ���6��\'{���8������,i�qh��ş|��s� /<���-,���HVx�Z���EPx�79j���j��qf�q�)��\0�)�!�)pa\Z�vK�\0��M\Z������6��	���TAg�`-�����{a��1.�jq�zzS�&zE�s���{�:�	����G8D�@��\Zԑ� Z𱍎�wX4\n�����,8�݇R��z5���\'���?��xs���3I z�����,0��2��lI����\r �扈����H%j�6K�0�Ҟ�J���I���f\r�;s�a�\0�mP#;6��;lģ`�/zL�6ր���P�>Xď�:�;:���k�D=k�v}��\0�\'ٻT3d��A;���z���O�� G��Ӟ�>�5�9F6�8ik���Cy�h���\Z��a���v2j�j�SΝ��`��3�Ys�lUl�N�[��\Zh�_�A\'���֍��������{������|�i����L\0VI�ݚ�$��8&�C�/=���\nKIi�Y[�I�چ��|8�	����^�c�K�vH-Y8�PK�ф�Q�O�E�ͩ/�P��)t��CO$�c����\Z䛊�����Ֆ$�l\Z���qv�.��W*��ǖ�Nv�ц�����j{�hDX���v�Fm��0H�y��h;�<\Zm�*��^l�o��W���[�1�<�ӯ����W�yx>	���/�����>]L�ۧq�n���>E�}���nP\\�g���^?����旻+��5jT_����\"��v�b\'��V�s���%.��iЖ�o䅹��������q#/b�����>~a�d�`&Iy\'YZƐs\n!�0d	�� ��M�ƴJJ\Z�yE�,K�\'�$�J�L!YX2�Ye^�e�\'�W�r'),
(9,'18__0_0_0_0',1797935810,'x��UM��6��W,t�nD}X�=,��)��e7���Ʉ%Q%�x�����e��(�$m���7�μ7�G����-˳U�l�8z)�[�ַ��n���Vy`�eM7\0�&��$�$��k�,\\X�<P��!J8�n����&0��V60cxZ�#�<(�VZ����$�`t4J[�V�1�C��$y����eg��\\�c�֊���c�֬�zV��l��&aK;����Q���I8�vh�KH�	�,gw��g0n�O���r�3�7�7�)�+pu�#�\rtcho@�#�m����1��{�G<�q�܇B�Ò\ZM�?�_��~������I f�����,p�Z�2-�jhw��Ԩ\rF�v�De��SG���O��TZhXG;-�j�(��&�D#��:�;�׶(����8cd!k<|54�$`rԖ��j���7�w���+}|��JYMzpl;j5\0r�:�v�\'+�-O#XK��U�����/:��x�j�\'�T2�X�0N�R��/�݀3]��0,����C�3c?vn�7�-�?�V��]cW�u��.V�ӑh5�4��Qf��F	�I��a��0S{�{m.���j��`���Я)�A��q,&�F��;�4ԉL+e��[�J�҆��E�IM�-�e��V��Z:s��G鹑�(Z���&Ì����u/��ԫQ�/������k�_��>���	��?��#�U�䬦g��ê�H� �\Zo�fx؎�(��;is�]��^��6δXL/��Wv��j��jL�Da��W㬰�^L����@��B�h~�.����e��Y\Z��)*�j��yqb/�\\,H��������~��q=��WUkn�_�tE~���؉��S�T��}�[�z����+xf��\n�W0�R+xx�dk(���}�}���$�²H���H�o�JˤX�C��d�J�)�G��8Ol�\"�!+#Ú��4M!$��D�A�!���,#��	��9'),
(10,'19__0_0_0_0',1797935810,'x��UMo�6��W:�����d�`$AS�5\n�s艠HJK�$�$�����P���)P�m�\"�Vo�Ùyo8$�g��[���Y�a���y��e��g7}�W�{F�t���0��,\Z-T1b�Ʋ�=�kn��}�1��@�{U#\Z>cp���E��+9����z�����QKeD[Y� N�/�rO��{����cp&L-�q� }ָ&mՓ�������oqGo�ֲWtI�3l�F�Q<aL���s����M���Ν����LFt\n�\\�p\0�q�h�k�V�P8�C���h�������3���s!�y�\ZL�������û�w�?}x����������.�R�wk�ХF�`p0��\',��?uX*Q��YJ��\r�p�X�����ēh�<�s��@��1�c������:Y:�P�}�ME�Ѝ߯P���(E5�o�}�Q�C�sI��c�q�(2��Y�n�����X�NcZ򈗼��Ì-�َ�ť�g�*n��E{t�A�D�O��o�c�O�Z#�%��VE۹u�����h%֜(zp�����d�p��TLO�E�mَ8)�Q���*Io �[S0�Tb+XL@mo����JJIi�)[���҆�¬��Fi�iY-ǡ��G�Ϝ/�A|i�-�\0�0pn���QsX����h���M�H�g���ĥ�kyZRL�A�x y�����%������ò�\\m�\0�o\0�fx�Vo�9	��F�V�&�{p4Xm�(��^l�ol�W���[�0B(�����-ϗ3\0<\\������?\\���s�3\nw���NP�G���}	�r� !;��û���|c{\"��ꛩ�W?^��>k+t�tm�<�?����t=���|�<3�m��+�[+xx�d�1���m�}��E�Ѭ���e��LB�F	c��a\\Ƒ]�>�YZT��GQ�S��H�!H�\r�pǓ2��e�.H�\0��'),
(11,'20__0_0_0_0',1797935810,'x��UMo�6��W:;)i%���$h\n���sȉ����XITI*�������+�@��i�ܤ7��̛7���L�-O�(}2i�z�̽[���v�m�_�Q�Ycy�@��A�o��\"t�-�,q��P��!\n}�2ϡ��m�aTm��a��4��$�W\0+���z���#��h���)��\Z��0��:�#�l�Tx��ri+%sX�阓aoʎ����^RQҰ�kh�\n6��bI�����t3a�,��ݤ�鍅��h��;���LFt\n�\n\\�a��6�3������4:��рN��3��q��O��O��h�}ޱ_�v�>������J��Ǟ�κ]���2+��Y{�Y�U���v��d��c˔��۶���B�[�j�V{�F1���$�\\쩅�Lۢ0���X��`̕UW�)���(\"���LՕ�����o�zs�U>찦B��z��-�\Z\0��Z���Zb�`}`?��4�#��?�]���s����/l�b���0N�Rk��]:���u	����J6�ύ���Ӟ;����Sce��\Z�U�=�~��\"�b�y9�b�{7�,V��}p:*���^ڿ4�癱�;X%�,tk�g��f�\nʢ��_0 \r������-2ej�!�Ἳ�IE����\\�#�l-�{����K#kP���s���c�U���ԫQ�ã+&�\nUU긤���J��B�o��a��F5R��]�ruu�������G��b�Gi��u��ٶ\n�\\��6�u������{��X��O�ŐҭO�|-�\n�7��\r���r�� }4?��l��\"\r�xC���Q���6������!��>�z���Mω45jn&��~��?|ՎVd�x�+y*��ƭt=���|�<w��\n�W0��V��`��al��}�M��sp�,���0��&I .D�PBB���a��l��\0?�$�C��\"Ʉ�}?�s~(x!�Ը �a̽.'),
(12,'21__0_0_0_0',1797935810,'x��UM��6��W:/6�>--zX$AS�݋�CN%�d��T��b�{��2��(�6m���f8������ 9�cy��O:soܻy@���~��I�mXۏ@��aY4YJř�+K�{\Z00F�\'߽���r�*cD�Ǡ�.�ɽ\nh������M�Z*#��:�~\ZXc�{J߃.�荐x���0�,KX��蓦\r���@��G^���=SЙ+X�A�k��_`36�^H�㢪w���7n�/��t���_f2�s�W��H�V�A�:�G���|���H2�w��x���w�\n�O��h�~��_w�~���JȂ�#g�`\\J��2��li����\rF�v�HE��cO��K��ThYO{%�jN�$f�6�E����zX:�i�����(%��7%�֜-���b֕�g�m�=5\n\0��Kj��՘hG�i�N�e#��^��ۡ�U�4�c_��c3�8Sk5��Cq�hǗ�\Z��au��2��i��̝�����3�Ys\rmU���S�5�Z�|\'��ʽe�m%w�\0��T\\��%�-�iVh�Xi&\0�d���nM�RT��`5!�-�	�BS+!%�q�j\"�k�ᒓ�l:ZV�z[]���҅��?�/��C���vԽ�4GEW6��k��JD�?�GWL�V�i�qMqs�r�\"T\n~s��,���D�\Zz!<,뫫��_�\raю����`��`�#eg�U8��U��l+���ٖ}��^.>�O-���,��|�-\n�7o�yx�����������\\L_[�Q���`U��>�v�\\�$���Ղ��׻w~������Dh�\Zշs�������U;Z����������4h���W������`�w���	@���t��}�M��sM��&�,,�$M�$��2�>I�\n� �4��\"��rC/��X̪,N\0�>�\'�\"��\"\n!�4N�*-!�Yٱ'),
(13,'16__0_0_0_0',1797935810,'x��UMo�6��W:��o���H��@�C�9�DP$�%,�*Ie�0��;�D-��(�6m��􆜯��C��z�!U�UO���`,�,������*0ڐ~���L�8��d�Pň���\n�᳗p9����e�We����\Z��U�p�*9Ax]�*�堖ʈ�]CG֘T����\\S%F#$ĺ[|p&L\'�s� }Ը#C;�����A:x$���rRtK�6s#l@��M��\nNK�&���^�Ё�2�]���\'8ڸ�5�4W\'�P�𹍞!�/X4F�{��	O�!���츅�����vw������_HX�{��N�g���@�q�d��S�Х^N`�0��G,��?�X*���YJ��=�X�1X�^��h�|0Ǒ�@��1��w�(��?�$�M�z��P��rnD�rm���Q�r�)��Z�p���:r�/����^�zN�׆�|�[���b�a��Zl����^�Zn<�����!���6�F;����>\rFt[�����9�S�n��r$v<yqb��d��?��A*���\"��\\4��Q���*�d��_S�@��l&�����u@hl��4�Lm2�rkCfa6�sҡb��i������;�uٹ���x�D�\"��bK�o���;�9��y�\"D,�M��u]s��n$�g��W�č�:y��.N�D��F�F�����e{�����gj�˲�m�\0�\Z�\0�~~�N�A!� �q�<�.��/�F\'%�m�g[�+���.��.L*�0��w��ݿy�����`\0W }0?���3}i{&q�����	��({��v\'����ք����>�|��ݵ��\Z4������\r��v�B\'WV�k������e������c��^��2������{ى��>�*���i�RZ�4�i�\"^3V�1k(I��49C(k��,�7�4+Ҕ�e\nM���iXg$�IJk²�r��uQFi��9��6'),
(14,'7__0_0_0_0',1797935810,'x��WM��6��W:���%˒��a�M�t���A��LXU���X��P_��MТi��Yo8��x��4L�D\Zܒ4^�O\Z>�V0�V��m���_|�R�hC��(^Ga����B#��,q�1^rû(~v+���S�*cD�G�x�\\$I���B���)J=��j����.KX�2��ܿ�*�!��>g��ƨ���KR-)8��lpG��\Z7D���`-[E���?¦냽E�D���u\n\'��n~�\nK�N��4���\0G8��qUi�j��(���w]t��`�\r��G<\Zqw2���`������6�������͌0����ָS��6�e�+Y��X;t��-���#U�,�(ّܱ\n�+��F	����sٿ��0�3�����\r��N\0��\0�J��Z-j��+���t��Oh�+=�[~ݐC��W�s�]���P����E1��d�`�8���e�A�<�e����i��#4�=�M�5@�t�&�T�#�a�Aw�t����NT���A���wҭ��Cc��9!k��PQN���*����[�?H�O7��Xs��֍2�W�?�bzh/�o��\r �6�P�P%i\rtk\nF�l�	�R�#B�: 4��SR\Zw\r\'�b9�aea֞ϤDI�i^L������3��ѹ�@\\�l�E�=簨i�2~�`���p��G�L�,�~J19n\Z���s��p�_��ֲ����8�,����������w�x\Z�`��@���G�,��8\Zm�(6���c1��D(��B(�huʋP�-����[/��\0����`&�5����PC���!��&�����O)�|/���U�A5щj�I5��?��Usdⷬ����|W`W_X0?�B;�>\'��0���[Z`�;Y�?\'ea�	)d�~x��׻_�o���ZG�����O��g�`�N�,����W�^W����E��G�F��TG��|�����s\'A�0�� �9�����<_%�OP�\"IN�q��k		���I���1�ѐ�h���,ɲ����2���刲O��p'),
(15,'6__0_0_0_0',1797935810,'x��WM��6��W:��و�e�Z��H���v���A��LXU���X��P_��M�\0i��Yo���x��4L�D\Zܐ4^�O\Z>�V0�F�����\"�Z��цT�P���p����*F�Y��c��wQ��w+���S�*cD�G��H�z9ǅ�-\\�S�z��;j����D6k�L=%�o��J4FH����0���1*�l�A��EK\n���;�Q\"��\rQ�63X�V�)?䏰��`/Dр1�磻N����6�G��t��Gp�O3��!�pq��\ZW�ƭ檏�,�x�E��,\Z�!��ģ�p�!��0]\r�͟|w�yx�����wog��)�-���Ɲ���.�\\�\n7�ڡK�l��`�n��\Z��`�D�͎T^�7J������u4p�ɝ94|�\0�m��tl7�H�\nZ�-t�e[؟d�ZA�u�_5�PA��5�������a��h`�m�Q�èd�N�±���ԀJr���� � 7m����ӡ�|�SC���a���mv�hך����KQ���=��Cc��9!k��PQN���*����[�?H�O7��Xs��֍2�W�?�bzh/�o�|�I��\"��\0TIZݚ��@[�dFT�X���-����]���XNmXY���3)QRc��qhuF�F�ǙO�Atn�5�\0��@7�n!t�9,jZ���5Xs�\"E$�3��I�\\���O)&Ǎ�[x)y��_��K;�Zւ���bv�=�KsXT�{v�2��0��y���6��\r�6J�L��Q�bt\"��\"�A�\"$�G/y����	��`&�5���PC���!��&�u�s�E\n�����ƪ鿠��D5��R�%B����u���=kfsx:����g���?�Ў�O	�2��������^V��IYAXgB\n�A�޼�����k��5pT_^��@?}�V����2y(��}�u�/���\\��G�j�Iup�ۑ̗���?�y�q��	Z��%E1BI��0DQ̲<r��e/WI��aQ�\r1�DYHs?�r�P\"?	I��K�@Vԧ�oƊ�'),
(16,'8__0_0_0_0',1797935810,'x��WK��6��W:�وzز=,��)�.�zs艠��LXU���X��P/��&HѴM���f8��7��,��G{7,^-�G��N�3���M���_!~-cG+ͪ�\0d�}?��AoIe�4�,��ɠ\r]����,�zֱ�Q�ּ��cPg6�N�����ULb�uzG%��uaWK�5	bG��P������C@�u)���`6�h��eС�Άw�ĭi�$�z+��tʏ�#��>�I8`���]����uk�#H*�;�ܫ�Lzt�\\a��R�U �(����w]��}��>�[�G<q������h�����o7��������͌8�ő������Zc�i.EE�c�إJ�h�0�S��W\r<4TH^�c3#�\Z*��Fr���sٽ�db�\r���5���i߯L�R�@	�ʶ��`�^I��n�e�&�^5����,�~�%��`��m��\08.��Oq�&ڟ�e�� N�ؤ�^lڤ��+�K5�H�\"�Q��{����Ѭ6�hâK^�,��>S�Ccv=�Bְ�Pk^N����t��]�;X�N��T��֎2r�V⤈�Bfjh/1��|�Y��d�����\Z�5y#H�2��Ʉ����`g��\Z~I!��rK��ڰ4p֞Ϥ$QMӼ��c���p�t�����FZ#\rh����B����N�6��+�RD�6��EY���btܪt��%�����`kQ��8xX������¼�޴�7�A����#���Y8��,�w��Lf���<sQOD��/D��Q����EL�^�/��I��`&�5����PC�ě!kE�\'�0�r�E\n�����ʪ�>���D5ݿ��!k�]��92�[����x�+8��Ϭ���C�M���_���--2Ɵ����΄��^߿~����wצ\'\\)䨺:��qA~���؉��a�P~��\n��_���H��(���j�(�#�/���\'z��z��	[zQ�\\p3��U��U�����3`���0r`kߏ\"7@[�y�dA�K�����ϗ�$����I��\'�e`'),
(17,'9__0_0_0_0',1797935810,'x��Wˎ�6��+Zt5��zZ\Zt1H��@�E=YtE�$%�D���1���˴5	Z4m��;�\\�>��I�\"nI�&���O�̻yv���W_I�mH�Z\0�Y�Q�E��*F_X��c���^���V0ƛ	�r�*cD�\'���*�\n�K%;�s�{�7�Rє}h?�AQ�{J�_sM�h������3a*Iw�[���iʎ����6R!��-Q�1X�N�9A�O��a�xĘ(����7n�O\\a���\'p�O3���3py�W�Ɲ�j��,Nx�F��,\Z�ѽs����!�a#�a\r��ok��n}���݇�߼^P���03�w\nT6��%k�k�.ղ��!�y��n�C���;6;RaxMZ�*Vs�2�7�H\Z&w�����b�ӱe�\'j��U����IW]i��K�7ђC\r9�u��tJ�_CA�(G\"��o[l�0,ٺ�0����\"*r��=��\"v/�ݦ��k�G\r���F��us�Hw��v��*�q0����Az�m>�vՙ�����՜kh��[��\n�E�����t\Z�5\'�n]/Sp-O����^*���\"��,��l�Q���*Ig��[S0�c+�M��\Z�r���e��Ҹ7s˹\r��Yw>�\n�\ZL�r�������i��� >7�h�+���m�z�\r�:��\Z��|�\"�3���I�BV���)��;E��V�B����l#AI�ψ�e�m�\0���\0u��O�^���Sv�-ܹN����fӓ}���h\"�_hb\'I�H�ߓDH��A�~��T�Lme���E\r��\Z�\'��h��0�\rQ�xa��B~��E5��j�Ϩ&:QM�/�f�P�鿮��e͌a��s���:���;���9���4��oYh�qoe=����u!�����՛�w�|��=ZG���᫟�����:���L��_�z]�6= ���\Z�cR�v\"��_���O1\ri\'�_d	��e��Q�H���O����*܄IH�$)B�\"V��Ĩ	�l�_�)	�\"i�>E,&4��\0���'),
(18,'30__0_0_0_0',1797935810,'x��UMo�6��W:�o���H��@��:��J���J�JRY/�����jS�R�&�!�3�=rh���\"�w4O��Y�A�\r�yw\"����O����3�ж�$�� ΢x���Q�7�$�o��c4���x�\0Y�AVe�h���6�1Is��Vr��u�sy�B-�]=�#������=ץ��z�rp&L#�ÒC9��IC�z�5\'s�ci0�HO���rP�Z FlF\"�8�1&�jY�sX�M���WD:g�<�וL��\n\\�ad��d�\\������4:�n��szg����٧B��z4�v�w���㻏�?}x������Y9W�RvX&��-�ϽK� �`d7OD�=�T�ve��\n�[ړ^	���7��F�i�<�S��l���<�?u3�޴�m7�����D=�l����(�Aٻr��X\rUp�h56�$_S����(wCу�ڡ��_�Z�#�`�Mk�ۡ�\\h/.U57�5�;8��k�ͧ��d�\\<��SgD��\Zخ�=\'���M�5@k���$�SU��,�H+�{��t���^l_��e��6��f�K:H���/ ?����k@/�X�()�{�V��[�\r��48�HY��v�����%���z?��l@\Z�Zn�����9\"���ٱ�\'�W�!a)�O��$�d���Z]z�-�^A^)��{rh5�d\'Jڐ��fYo��[\0�&��ߪ�j��9\n�o3e��&��q��?�J��\Zz�mo�~5���i�Yxeڅg>J��i�-��tx��?�p������p>.����0H\"�m�Ǐ�]>��\\���F��~|�����n-\'Bk𨾝~����W�&�7��s���\r���-�>}�O߿q��j��O\0�l4!����(v��>���<~�\n�0��*K���,�8CU��)���A���Y�(�X�$�\r�\n�E�qY!�\"VD	Ӡ�RV�%b<�c?�a�]'),
(19,'31__0_0_0_0',1797935810,'x��WKo�6��W:���JFF4Z_�9�DP$�%VU��za��w��r.�6M�bo�9���~ ���Y����$�����yw\"����M�>�&�g�!Mg-(��0L�8=T1b��\'�=�kn�f����v6d�Q�1��\r�񖹖U�WJ�p��Q��޸PKeD[م�p&�rO��G����zCp&L-�v�� �׸&mՓ����g��oqGo͙Y�^�%?��f3������DY��u+��n~�\nK�L6��q&�u\n~�\\���U�q��\Z�X4Q8ۇ.:�ݰ�o�;��x�s8{_H�_����5��~������O�>�1P�����E���@�q�d��C�ХF��plP7OX4�T�ra��\n���N	�7�ٿ�\'�0�5�����\r�O�{ ��J��+o������{r�C5�kȽՄ����Fq��΅�zdĵ�ȷ&{y���`�r�`��v��+^��b�F3�R��s_�.�3LTōc�\Zk�n��q�͗�5sf���\ZQ/���*����[��8H��i�J�9Qt�F�I��ܩ���N*���\"{��6)�Q���\0U��@@��`6b���`q�\r��BcK$%�qgk�#�Kkf�)&5Z���ղZ]�h��4P\0��;���ŸZ�\Z���~�=r���=�S�����E�HX����+�KY�r�d�:L��\r�K�wO�,ƭl%5>�l����v�/Af���a5����#e�Y8w�Y���D���b��GR�ބ��?�*�W)�{R�y\0�;��x����]��[�ߴ�*w�_��rw��{��YtA�\"���O��ڽ����S�7�zp���qv���Q������ϲ9{\'�>�i#d�~������nmO���Q};u�ݏ��������X&O��7 H7�����3rW�����-�����9��J�����u=~�wA��(�Wi��8�Wa��*	\Z�(�XHP�2�UI���tUr�AI�8I��Ӣ�I�E)�XrT��FQ�|������');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_0_0','pageId_1'),
(2,'5__0_0_0_0','pageId_1'),
(3,'5__0_0_0_0','pageId_5'),
(4,'11__0_0_0_0','pageId_1'),
(5,'11__0_0_0_0','pageId_11'),
(6,'12__0_0_0_0','pageId_1'),
(7,'12__0_0_0_0','pageId_12'),
(8,'13__0_0_0_0','pageId_1'),
(9,'13__0_0_0_0','pageId_13'),
(10,'14__0_0_0_0','pageId_1'),
(11,'14__0_0_0_0','pageId_14'),
(12,'15__0_0_0_0','pageId_1'),
(13,'15__0_0_0_0','pageId_15'),
(14,'17__0_0_0_0','pageId_1'),
(15,'17__0_0_0_0','pageId_17'),
(16,'18__0_0_0_0','pageId_1'),
(17,'18__0_0_0_0','pageId_18'),
(18,'19__0_0_0_0','pageId_1'),
(19,'19__0_0_0_0','pageId_19'),
(20,'20__0_0_0_0','pageId_1'),
(21,'20__0_0_0_0','pageId_20'),
(22,'21__0_0_0_0','pageId_1'),
(23,'21__0_0_0_0','pageId_21'),
(24,'16__0_0_0_0','pageId_1'),
(25,'16__0_0_0_0','pageId_16'),
(26,'7__0_0_0_0','pageId_1'),
(27,'7__0_0_0_0','pageId_5'),
(28,'7__0_0_0_0','pageId_7'),
(29,'6__0_0_0_0','pageId_1'),
(30,'6__0_0_0_0','pageId_5'),
(31,'6__0_0_0_0','pageId_6'),
(32,'8__0_0_0_0','pageId_1'),
(33,'8__0_0_0_0','pageId_5'),
(34,'8__0_0_0_0','pageId_8'),
(35,'9__0_0_0_0','pageId_1'),
(36,'9__0_0_0_0','pageId_5'),
(37,'9__0_0_0_0','pageId_9'),
(38,'30__0_0_0_0','pageId_1'),
(39,'30__0_0_0_0','pageId_30'),
(40,'31__0_0_0_0','pageId_1'),
(41,'31__0_0_0_0','pageId_30'),
(42,'31__0_0_0_0','pageId_31');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1795334294,1794119207,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"}',0,0,0,0,1,1,31,31,1,1795343750,0,0,0,0,0.5,1,'Home','/','TCEMAIN.permissions.groupid = 1\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete',0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__Home','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,1,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(3,2,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,1795333022,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(4,2,1795333042,1795333022,1,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(5,1,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','pagets__SidebarLeft','','',0,0,'','','',NULL,0,'',NULL,0,''),
(6,5,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(7,5,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(8,5,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Parking fees','/revenue-payments/parking-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(9,5,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Market fees','/revenue-payments/market-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(10,5,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Waiver of interest','/revenue-payments/waiver-of-interest',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(11,1,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Health','/health',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(12,1,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Environment & water','/environment-water',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(13,1,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Trade & tourism','/trade-tourism',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(14,1,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Public participation','/public-participation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(15,1,1795334294,1795334294,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Contact','/contact',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(16,1,1795334294,1795334294,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Search','/search',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(17,1,1795334294,1795334294,0,0,0,0,'0',2048,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'E-services portal','/e-services-portal',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(18,1,1795334294,1795334294,0,0,0,0,'0',2304,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Accessibility statement','/accessibility-statement',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(19,1,1795334294,1795334294,0,0,0,0,'0',2560,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Privacy policy','/privacy-policy',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(20,1,1795334294,1795334294,0,0,0,0,'0',2816,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Access to information','/access-to-information',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(21,1,1795334294,1795334294,0,0,0,0,'0',3072,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Tenders','/tenders',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(22,1,1795334294,1795334294,0,0,0,0,'0',3328,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Service navigation','/service-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(23,1,1795334294,1795334294,0,0,0,0,'0',3584,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Footer navigation','/footer-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(24,22,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,17,0,0,0,0.5,4,'E-services portal','/e-services-portal-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(25,22,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,15,0,0,0,0.5,4,'Contact','/contact-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(26,23,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,18,0,0,0,0.5,4,'Accessibility statement','/accessibility-statement-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(27,23,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,19,0,0,0,0.5,4,'Privacy policy','/privacy-policy-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(28,23,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,20,0,0,0,0.5,4,'Access to information','/access-to-information-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(29,23,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,21,0,0,0,0.5,4,'Tenders','/tenders-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(30,1,1795336956,1795336956,0,0,0,0,'0',3200,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795336956,0,0,0,0,0.5,1,'News','/news',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(31,30,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795336956,0,0,0,0,0.5,1,'Article','/news/article',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(32,1,1795336956,1795336956,0,0,0,0,'0',3840,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'News records','/news-records',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,32,1795336956,1795336956,0,0,0,0,256,NULL,0,0,NULL,'',0,0,0,0,0,'Trade & markets',0,0,0,0,'','','',NULL,'',NULL,'trade-markets'),
(2,32,1795336956,1795336956,0,0,0,0,512,NULL,0,0,NULL,'',0,0,0,0,0,'Roads & transport',0,0,0,0,'','','',NULL,'',NULL,'roads-transport'),
(3,32,1795336956,1795336956,0,0,0,0,768,NULL,0,0,NULL,'',0,0,0,0,0,'Health',0,0,0,0,'','','',NULL,'',NULL,'health'),
(4,32,1795336956,1795336956,0,0,0,0,1024,NULL,0,0,NULL,'',0,0,0,0,0,'Revenue & payments',0,0,0,0,'','','',NULL,'',NULL,'revenue-payments'),
(5,32,1795336956,1795336956,0,0,0,0,1280,NULL,0,0,NULL,'',0,0,0,0,0,'Public participation',0,0,0,0,'','','',NULL,'',NULL,'public-participation'),
(6,32,1795336956,1795336956,0,0,0,0,1536,NULL,0,0,NULL,'',0,0,0,0,0,'Environment',0,0,0,0,'','','',NULL,'',NULL,'environment'),
(7,32,1795336956,1795336956,0,0,0,0,1792,NULL,0,0,NULL,'',0,0,0,0,0,'Water',0,0,0,0,'','','',NULL,'',NULL,'water'),
(8,32,1795336956,1795336956,0,0,0,0,2048,NULL,0,0,NULL,'',0,0,0,0,0,'Education',0,0,0,0,'','','',NULL,'',NULL,'education');
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,1,0,1,'tx_news_domain_model_news','categories'),
(2,2,0,1,'tx_news_domain_model_news','categories'),
(3,3,0,1,'tx_news_domain_model_news','categories'),
(4,4,0,1,'tx_news_domain_model_news','categories'),
(5,5,0,1,'tx_news_domain_model_news','categories'),
(6,6,0,1,'tx_news_domain_model_news','categories'),
(7,7,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1795334316,1795334316,'/user_upload/_temp_/importexport/data.xml','165cd81b05433cbd58fd78992daf226ea111f5bf','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','data.xml','ebf3036b95d3c9c905f56c226d5364a9aefa6554',1795334316,1795334316,33933,1,1,'text/xml',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1795334315,1795334315,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1795334315,1795334315,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1795336957,0,0,0,NULL,'News images','1:/user_upload/news/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1795332992,1,'BE',1,0,2,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"Sidebar probe\",\"bodytext\":\"<p>Rendered from the area sidebar.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795332992,\"t3ver_stage\":0,\"tstamp\":1795332992,\"uid\":2}',0,'0400$Ab_ebDixmlobc09ZW_wpQOm13MVZdCpf:01dbc21fdb1263685b9147b3b1596ea8'),
(2,1795332999,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":null},\"newRecord\":{\"backend_layout\":\"pagets__Default\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$xqYtF2Yzjz8vs6EvJQvzLj3QUpVEEGdA:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1795333001,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Default\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\"}}',0,'0400$dxU1W8i-7n0ls8Dxve2BCaS2_U6etDoY:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1795333004,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Home\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"}}',0,'0400$12o7r9be8NdlTq7M72UstYxByrD_Sh_g:e175f7045d7ccbfb26ffcf279422c2e5'),
(5,1795333006,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\"}}',0,'0400$s0fUPA88SDA-I6r3a2F12T6-HMxysVUK:e175f7045d7ccbfb26ffcf279422c2e5'),
(6,1795333009,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarRight\"},\"newRecord\":{\"backend_layout\":\"pagets__Narrow\"}}',0,'0400$rWk3qQFI-05fLi5WkRdZtrLMsXXEvAU3:e175f7045d7ccbfb26ffcf279422c2e5'),
(7,1795333011,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Narrow\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$Xfdponrx3mLaIVs0SAIfgknY-Uy1U1cn:e175f7045d7ccbfb26ffcf279422c2e5'),
(8,1795333022,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":2}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:f11830df10b4b0bca2db34810c2241b3'),
(9,1795333022,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"backend_layout\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":3}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(10,1795333022,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":4}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:412add0b3eb6ec8f1cb6710aea92e21e'),
(11,1795333042,4,'BE',1,0,2,'tt_content',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:01dbc21fdb1263685b9147b3b1596ea8'),
(12,1795333042,4,'BE',1,0,4,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:412add0b3eb6ec8f1cb6710aea92e21e'),
(13,1795333042,4,'BE',1,0,3,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(14,1795333042,4,'BE',1,0,2,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:f11830df10b4b0bca2db34810c2241b3'),
(15,1795334294,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"backend_layout\":\"pagets__SidebarLeft\",\"backend_layout_next_level\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":5}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7ef5a4e3e11db8ac3fea4d7a75468161'),
(16,1795334294,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":6}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c75354c439a48dbde16b03ac553a080d'),
(17,1795334294,1,'BE',1,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":7}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:df50bb24cbce671cf0d61f42fbbef601'),
(18,1795334294,1,'BE',1,0,8,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/parking-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Parking fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":8}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:595375f2fb9f014e091eb08fbc51ec88'),
(19,1795334294,1,'BE',1,0,9,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/market-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Market fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":9}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(20,1795334294,1,'BE',1,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/waiver-of-interest\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Waiver of interest\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":10}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e904af5a60392ab3165f5849f5877e45'),
(21,1795334294,1,'BE',1,0,11,'pages','{\"doktype\":\"1\",\"slug\":\"\\/health\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":11}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:51bca2bcf14079cc366c99de31802400'),
(22,1795334294,1,'BE',1,0,12,'pages','{\"doktype\":\"1\",\"slug\":\"\\/environment-water\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Environment & water\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":12}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:d6f57183d4ec29f4a568a174f36b861b'),
(23,1795334294,1,'BE',1,0,13,'pages','{\"doktype\":\"1\",\"slug\":\"\\/trade-tourism\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Trade & tourism\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":13}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:8a89606121863fe3a2ec2ea63ba83d69'),
(24,1795334294,1,'BE',1,0,14,'pages','{\"doktype\":\"1\",\"slug\":\"\\/public-participation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":14}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aaa274fb7a5f76c9749f1b2c8fba84a4'),
(25,1795334294,1,'BE',1,0,15,'pages','{\"doktype\":\"1\",\"slug\":\"\\/contact\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1536,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":15}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c97934f122918253f51c81fbe45fd105'),
(26,1795334294,1,'BE',1,0,16,'pages','{\"doktype\":\"1\",\"slug\":\"\\/search\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1792,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Search\",\"nav_hide\":1,\"backend_layout\":\"pagets__SidebarRight\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":16}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:878fab4218e507eb25dda6ac21dd7ff1'),
(27,1795334294,1,'BE',1,0,17,'pages','{\"doktype\":\"1\",\"slug\":\"\\/e-services-portal\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2048,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":17}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:dd30e16e220c1cff5911b320aa60dbce'),
(28,1795334294,1,'BE',1,0,18,'pages','{\"doktype\":\"1\",\"slug\":\"\\/accessibility-statement\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2304,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":18}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:9e9e8c5ba4be654320a3cd25d73d01a4'),
(29,1795334294,1,'BE',1,0,19,'pages','{\"doktype\":\"1\",\"slug\":\"\\/privacy-policy\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2560,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":19}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:25dbd94d40a6ff54757b6e36bf898997'),
(30,1795334294,1,'BE',1,0,20,'pages','{\"doktype\":\"1\",\"slug\":\"\\/access-to-information\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2816,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":20}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:1d0206225cc3f30f7ba150ff3aae8ab7'),
(31,1795334294,1,'BE',1,0,21,'pages','{\"doktype\":\"1\",\"slug\":\"\\/tenders\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3072,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":21}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:bb4ab293ec9d3ccfe43678d078f6cea0'),
(32,1795334294,1,'BE',1,0,22,'pages','{\"doktype\":\"254\",\"slug\":\"\\/service-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3328,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Service navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":22}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e5087395befe41329009e7b123017494'),
(33,1795334294,1,'BE',1,0,23,'pages','{\"doktype\":\"254\",\"slug\":\"\\/footer-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3584,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Footer navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":23}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7e88f7aa7664c6f494370160b60358a1'),
(34,1795334294,1,'BE',1,0,24,'pages','{\"doktype\":\"4\",\"slug\":\"\\/e-services-portal-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":24}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:219ad4d34a3e23c6ccf2ca87da6bc52b'),
(35,1795334294,1,'BE',1,0,25,'pages','{\"doktype\":\"4\",\"slug\":\"\\/contact-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":25}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:464961a1483e7dda27d23c882ff696bb'),
(36,1795334294,1,'BE',1,0,26,'pages','{\"doktype\":\"4\",\"slug\":\"\\/accessibility-statement-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":26}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:544939248209022b223d317bc97b7099'),
(37,1795334294,1,'BE',1,0,27,'pages','{\"doktype\":\"4\",\"slug\":\"\\/privacy-policy-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":27}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:97019c60b3ac7f8b98007c072afa2f0f'),
(38,1795334294,1,'BE',1,0,28,'pages','{\"doktype\":\"4\",\"slug\":\"\\/access-to-information-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":28}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aa68f552fa168869c47f8dbefb43cba0'),
(39,1795334294,1,'BE',1,0,29,'pages','{\"doktype\":\"4\",\"slug\":\"\\/tenders-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":29}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:2d7ab27da714dae3c89a6e0cb79b80cd'),
(40,1795334294,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\"}\"}}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e175f7045d7ccbfb26ffcf279422c2e5'),
(41,1795334294,4,'BE',1,0,1,'tt_content',NULL,0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7fa2c035f26826fe83eeecaaeddc4d40'),
(42,1795336956,1,'BE',1,0,30,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3200,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":30}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:e3e225390eee037c1380949b378763b1'),
(43,1795336956,1,'BE',1,0,31,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\\/article\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":30,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Article\",\"nav_hide\":1,\"backend_layout\":\"pagets__Article\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":31}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:9cb7b2b3fac90492135e3538aed4605a'),
(44,1795336956,1,'BE',1,0,32,'pages','{\"doktype\":\"254\",\"slug\":\"\\/news-records\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3840,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News records\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":32}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:302984e7412d7a45766e1d6304831138'),
(45,1795336956,1,'BE',1,0,1,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"trade-markets\",\"pid\":32,\"sorting\":256,\"title\":\"Trade & markets\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c6c8e24453121a7d668fe4b1031ebf88'),
(46,1795336956,1,'BE',1,0,2,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"roads-transport\",\"pid\":32,\"sorting\":512,\"title\":\"Roads & transport\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:497028e4af2a2cda8419e90cde34f71b'),
(47,1795336956,1,'BE',1,0,3,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"health\",\"pid\":32,\"sorting\":768,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:265912e2a2dda6b4b6be4e7069754d09'),
(48,1795336956,1,'BE',1,0,4,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"revenue-payments\",\"pid\":32,\"sorting\":1024,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:a832991055f9726888b6b83414d05630'),
(49,1795336956,1,'BE',1,0,5,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"public-participation\",\"pid\":32,\"sorting\":1280,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:55bc761d39a2d7a8b56679774f51dfe6'),
(50,1795336956,1,'BE',1,0,6,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"environment\",\"pid\":32,\"sorting\":1536,\"title\":\"Environment\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:0580043665451ed803b9e5d021b149fe'),
(51,1795336956,1,'BE',1,0,7,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"water\",\"pid\":32,\"sorting\":1792,\"title\":\"Water\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:e6068a768abec7500a6d253c29088f52'),
(52,1795336956,1,'BE',1,0,8,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"education\",\"pid\":32,\"sorting\":2048,\"title\":\"Education\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":8}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f564fff7cae82b30644518a57bd7a8a6'),
(53,1795336956,1,'BE',1,0,1,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-fish-market-opens-at-the-jetty\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New fish market opens at the jetty\",\"datetime\":1793595600,\"teaser\":\"Sixty stalls, cold storage and clean water for traders and buyers.\",\"bodytext\":\"<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night\\u2019s catch and running water at every stall.<\\/p>\\r\\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Trade &amp; Markets Office, +254 700 000 010<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:fccd16ea3664ec003726b2a72ea38f4b'),
(54,1795336956,1,'BE',1,0,2,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"beach-road-resurfacing-starts\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Beach Road resurfacing starts\",\"datetime\":1793077200,\"teaser\":\"Works run for six weeks. Matatus take the diversion via Market Street.\",\"bodytext\":\"<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.<\\/p>\\r\\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Roads Department, +254 700 000 020<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:640f28e5c1a5ec2efb19c26699b464a5'),
(55,1795336956,1,'BE',1,0,3,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"free-health-camp-in-ward-3\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Free health camp in Ward 3\",\"datetime\":1792472400,\"teaser\":\"Eye tests, vaccinations and screening, open to every resident.\",\"bodytext\":\"<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.<\\/p>\\r\\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Health Department, +254 700 000 030<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:1152fda277b2623b0152b5765fcb6b28'),
(56,1795336956,1,'BE',1,0,4,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"pay-land-rates-by-mobile-money-from-january\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Pay land rates by mobile money from January\",\"datetime\":1791781200,\"teaser\":\"Residents can now pay land rates and business permits with their phone.\",\"bodytext\":\"<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.<\\/p>\\r\\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Revenue Department, +254 700 000 040<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f3f39c24ca39d00c02ecd29ec2ad4225'),
(57,1795336956,1,'BE',1,0,5,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"have-your-say-on-the-budget-2027-28\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Have your say on the budget 2027\\/28\",\"datetime\":1790830800,\"teaser\":\"Public participation forums in every ward in November.\",\"bodytext\":\"<p>The municipality prepares its budget for 2027\\/28 and asks residents what matters most to them: roads, water, markets, health or schools.<\\/p>\\r\\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Planning Office, +254 700 000 050<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:bc83755a03cca2ca5c8daa03e9d6e32e'),
(58,1795336956,1,'BE',1,0,6,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"mto-safi-named-cleanest-town-on-the-coast\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Mto Safi named cleanest town on the coast\",\"datetime\":1789707600,\"teaser\":\"The monthly beach clean-ups and the new waste collection paid off.\",\"bodytext\":\"<p>Mto Safi has won this year\\u2019s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.<\\/p>\\r\\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Environment Department, +254 700 000 060<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:7e4fc5d3ec5edd1f76b0a3820eb3fb47'),
(59,1795336956,1,'BE',1,0,7,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-boreholes-bring-clean-water-to-ward-5\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New boreholes bring clean water to Ward 5\",\"datetime\":1788584400,\"teaser\":\"Three boreholes and twelve water kiosks serve 4,000 residents.\",\"bodytext\":\"<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.<\\/p>\\r\\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Water &amp; Sanitation Department, +254 700 000 070<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:31860b4bf14b13d2dc895987af663784'),
(60,1795336956,1,'BE',1,0,3,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"News\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">home<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:b92300cfb5d1d3645c9cb212a7f56c1f'),
(61,1795336956,1,'BE',1,0,4,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":30,\"sorting\":256,\"header\":\"All news\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:4d391f5ef79b8d5d10dffa8a07ca167d'),
(62,1795336956,1,'BE',1,0,5,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":31,\"sorting\":256,\"header\":\"News article\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c7626fc9bcba6f70beb6ebc085a400db'),
(63,1795343750,1,'BE',1,0,6,'tt_content','{\"CType\":\"mtosafi_tiles\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":128,\"header\":\"Popular services\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c0db6803ab1ec5f70c36e2a72187867b'),
(64,1795343750,1,'BE',1,0,1,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"icon\":\"\\ud83c\\udfea\",\"label\":\"Single business permit\",\"link\":\"t3:\\/\\/page?uid=7\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":1}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:55820ddffac9b29987f66a48c05c3e01'),
(65,1795343750,1,'BE',1,0,2,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"icon\":\"\\ud83c\\udfe1\",\"label\":\"Land rates\",\"link\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":2}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:b6549a503cf1dd498f3571f7d5d85d54'),
(66,1795343750,1,'BE',1,0,3,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"icon\":\"\\ud83c\\udd7f\\ufe0f\",\"label\":\"Parking fees\",\"link\":\"t3:\\/\\/page?uid=8\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":3}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:518760b21a46e7982878ebf568972b86'),
(67,1795343750,1,'BE',1,0,4,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":32,\"icon\":\"\\ud83d\\udca7\",\"label\":\"Water connection\",\"link\":\"t3:\\/\\/page?uid=12\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":4}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:ba2135e3eae99237605541429e1c8913'),
(68,1795343750,1,'BE',1,0,5,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":16,\"icon\":\"\\ud83e\\uddfa\",\"label\":\"Market stalls\",\"link\":\"t3:\\/\\/page?uid=9\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":5}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c65d007d6e8748b9615f1c9e01a28b86'),
(69,1795343750,1,'BE',1,0,6,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":8,\"icon\":\"\\ud83d\\udce3\",\"label\":\"Report a problem\",\"link\":\"t3:\\/\\/page?uid=15\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:632dfe70d9c02f2a21151ad96efaec1c');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1795330974,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lina.wolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1795330980,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lwolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(3,1795332992,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(4,1795332999,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1795333001,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(6,1795333004,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"4\"}',0,0,'',0,'','info',NULL,NULL),
(7,1795333006,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"5\"}',0,0,'',0,'','info',NULL,NULL),
(8,1795333009,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"6\"}',0,0,'',0,'','info',NULL,NULL),
(9,1795333011,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"7\"}',0,0,'',0,'','info',NULL,NULL),
(10,1795333022,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(11,1795333022,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(12,1795333022,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(13,1795333042,1,3,2,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(14,1795333042,1,3,4,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":4}',2,0,'',0,'','info',NULL,NULL),
(15,1795333042,1,3,3,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":3}',2,0,'',0,'','info',NULL,NULL),
(16,1795333042,1,3,2,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":2}',1,0,'',0,'','info',NULL,NULL),
(17,1795334294,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1795334294,1,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":6,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(19,1795334294,1,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":7,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(20,1795334294,1,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":8,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(21,1795334294,1,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":9,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(22,1795334294,1,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":10,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(23,1795334294,1,1,11,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(24,1795334294,1,1,12,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(25,1795334294,1,1,13,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":13,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1795334294,1,1,14,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":14,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(27,1795334294,1,1,15,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":15,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(28,1795334294,1,1,16,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(29,1795334294,1,1,17,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":17,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(30,1795334294,1,1,18,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":18,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(31,1795334294,1,1,19,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":19,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(32,1795334294,1,1,20,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(33,1795334294,1,1,21,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(34,1795334294,1,1,22,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(35,1795334294,1,1,23,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(36,1795334294,1,1,24,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":24,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(37,1795334294,1,1,25,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":25,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(38,1795334294,1,1,26,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":26,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(39,1795334294,1,1,27,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":27,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(40,1795334294,1,1,28,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":28,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(41,1795334294,1,1,29,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":29,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(42,1795334294,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"40\"}',0,0,'',0,'','info',NULL,NULL),
(43,1795334294,1,2,24,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":24,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(44,1795334294,1,2,25,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":25,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(45,1795334294,1,2,26,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":26,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(46,1795334294,1,2,27,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":27,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(47,1795334294,1,2,28,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":28,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(48,1795334294,1,2,29,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":29,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(49,1795334294,1,3,1,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(51,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(52,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(53,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(54,1795336956,1,1,30,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":30,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(55,1795336956,1,1,31,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":31,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(56,1795336956,1,1,32,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":32,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(57,1795336956,1,1,1,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(58,1795336956,1,1,2,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(59,1795336956,1,1,3,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(60,1795336956,1,1,4,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(61,1795336956,1,1,5,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(62,1795336956,1,1,6,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(63,1795336956,1,1,7,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(64,1795336956,1,1,8,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":8,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(65,1795336956,1,1,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(66,1795336956,1,1,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(67,1795336956,1,1,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(68,1795336956,1,1,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(69,1795336956,1,1,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(70,1795336956,1,1,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(71,1795336956,1,1,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(72,1795336956,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(73,1795336956,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":4,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(74,1795336956,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":5,\"pid\":31}',31,0,'',0,'','info',NULL,NULL),
(75,1795336956,1,2,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(76,1795336956,1,2,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(77,1795336956,1,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(78,1795336956,1,2,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(79,1795336956,1,2,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(80,1795336956,1,2,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(81,1795336956,1,2,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(82,1795343750,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1795343750,1,1,1,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(84,1795343750,1,1,2,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(85,1795343750,1,1,3,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(86,1795343750,1,1,4,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(87,1795343750,1,1,5,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(88,1795343750,1,1,6,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(89,1795343750,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('029d857185cc6f0a9a8ab7e9d2ef95f3','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',3,0,'tx_mtosafisitepackage_tile',4,'',0,0,2147483647,0,0,''),
('08d2716299a7edd920edfd9427d93525','tx_mtosafisitepackage_tile',1,'link',0,0,2147483647,0,'','typolink','7f69a1aa54e9db8a5ae0d952977b4cd9:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('1fde6c7fd92bd9d8eafb8e741be22840','tt_content',4,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('20f5efef03fe691570c3d2cd2fc393cf','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('222baf9b25427e410e9c39f6ec6f2b7f','sys_category',5,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',5,'categories',0,0,2147483647,0,1,''),
('313e461a539f46cf2465487a128c051c','tx_mtosafisitepackage_tile',4,'link',0,0,2147483647,0,'','typolink','e34f7e18c8dc8d47f12cbbc9ec0587df:0',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('37aaef61fe9da71c3d2158c1cc012f0c','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('39f11610b54678a8af0feb57210bb43f','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',5,0,'tx_mtosafisitepackage_tile',6,'',0,0,2147483647,0,0,''),
('3d2896994c41d754a6409b530412c846','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('4402b32b58c950bb2cb91e2f1ed8bba8','pages',27,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',19,'',0,0,2147483647,0,0,''),
('4757b12b90def24df1880d8a111e43d5','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_tile',2,'',0,0,2147483647,0,0,''),
('4c50552ba214ce72d9d786f4de43b368','sys_category',7,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',7,'categories',0,0,2147483647,0,1,''),
('505ac3050b1043f117f21c125ce5f915','tx_mtosafisitepackage_tile',6,'link',0,0,2147483647,0,'','typolink','7f897eb5d5b640dce3bedcdb56c2d987:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('655053dcf91ff4de04e0e7b0935ac0dc','tx_mtosafisitepackage_tile',5,'link',0,0,2147483647,0,'','typolink','a01eec11a0a46a8e86685cb8ec780ef1:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('679f66b060ba12c8427fbf2a710b0fd9','pages',29,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',21,'',0,0,2147483647,0,0,''),
('6e9153c8043ab894a418dc6522791810','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',1,'',0,0,2147483647,0,0,''),
('75c3df5c09e24b3c2c96c640da355e01','tx_mtosafisitepackage_tile',2,'link',0,0,2147483647,0,'','typolink','087881d39e3c58af824e5fb90e661a8e:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('77491718585910205641ef73b044aa19','sys_category',1,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',1,'categories',0,0,2147483647,0,1,''),
('7948bfb5fb5858eeb7961d595c01ddf5','tt_content',4,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('7e694f9466d958648b1c103f07e2eddd','pages',26,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('86aa77750d3d62492d28cf72adb0c6ec','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',4,0,'tx_mtosafisitepackage_tile',5,'',0,0,2147483647,0,0,''),
('ac3e2ceba954f0d2e5005157cb1c35c9','tt_content',3,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('b8390ee0400ed62108c64b63dfc80330','sys_category',4,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',4,'categories',0,0,2147483647,0,1,''),
('bc577547d4c72172ebdc852ea3747576','tx_mtosafisitepackage_tile',3,'link',0,0,2147483647,0,'','typolink','5add86f047c9d524d9e9595219c10eb5:0',0,0,'pages',8,'',0,0,2147483647,0,0,''),
('c54d6e1dbf8edbce22fb4011cf341c4a','pages',25,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('c56becdc4ea2ae3a8579c4d7b1d4aed1','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('ca34608fee503babde3755c56abc293f','tt_content',5,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('cc525b5738d587aa9038005247b67650','sys_category',2,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',2,'categories',0,0,2147483647,0,1,''),
('cd03540122f752ba28f3b2f778daed32','pages',24,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('d0c87340bc327a8355a748af77c43662','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_tile',3,'',0,0,2147483647,0,0,''),
('e347371ae65979f6857a13b1bbdc3e8a','sys_category',6,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',6,'categories',0,0,2147483647,0,1,''),
('f352f231282e4969b3ea85c3f9b4608f','sys_category',3,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',3,'categories',0,0,2147483647,0,1,''),
('fed36fd2032652e9a28f9e21e509e64e','pages',28,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\LanguagePackUpdateTimestampMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','mtosafi_sitepackage:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','mtosafi_sitepackage:Initialisation/dataImported','i:1;'),
(40,'extensionDataImport','news:ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l18n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1795334294,1794119207,1,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\">TYPO3</a>.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0),
(2,1,1795333042,1795332992,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Sidebar probe',0,'','','','<p>Rendered from the area sidebar.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0),
(3,1,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'News',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0),
(4,30,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'All news',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0),
(5,31,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'News article',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0),
(6,1,1795343750,1795343750,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_tiles',0,0,'','',0,'Popular services',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,6);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_tile`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_tile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_tile` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `icon` varchar(8) NOT NULL DEFAULT '',
  `label` varchar(100) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_tile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_tile` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_tile` VALUES
(1,1,1795343750,1795343750,0,0,1,0,0,0,NULL,'',0,0,0,0,6,'🏪','Single business permit','t3://page?uid=7'),
(2,1,1795343750,1795343750,0,0,2,0,0,0,NULL,'',0,0,0,0,6,'🏡','Land rates','t3://page?uid=6'),
(3,1,1795343750,1795343750,0,0,3,0,0,0,NULL,'',0,0,0,0,6,'🅿️','Parking fees','t3://page?uid=8'),
(4,1,1795343750,1795343750,0,0,4,0,0,0,NULL,'',0,0,0,0,6,'💧','Water connection','t3://page?uid=12'),
(5,1,1795343750,1795343750,0,0,5,0,0,0,NULL,'',0,0,0,0,6,'🧺','Market stalls','t3://page?uid=9'),
(6,1,1795343750,1795343750,0,0,6,0,0,0,NULL,'',0,0,0,0,6,'📣','Report a problem','t3://page?uid=15');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(NULL,1,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New fish market opens at the jetty','Sixty stalls, cold storage and clean water for traders and buyers.','<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.</p>\r\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.</p>\r\n<p><strong>Contact:</strong> Trade &amp; Markets Office, +254 700 000 010</p>',1793595600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-fish-market-opens-at-the-jetty',NULL,'',0.5,'',''),
(NULL,2,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Beach Road resurfacing starts','Works run for six weeks. Matatus take the diversion via Market Street.','<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.</p>\r\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.</p>\r\n<p><strong>Contact:</strong> Roads Department, +254 700 000 020</p>',1793077200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'beach-road-resurfacing-starts',NULL,'',0.5,'',''),
(NULL,3,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Free health camp in Ward 3','Eye tests, vaccinations and screening, open to every resident.','<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.</p>\r\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.</p>\r\n<p><strong>Contact:</strong> Health Department, +254 700 000 030</p>',1792472400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'free-health-camp-in-ward-3',NULL,'',0.5,'',''),
(NULL,4,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Pay land rates by mobile money from January','Residents can now pay land rates and business permits with their phone.','<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.</p>\r\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.</p>\r\n<p><strong>Contact:</strong> Revenue Department, +254 700 000 040</p>',1791781200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pay-land-rates-by-mobile-money-from-january',NULL,'',0.5,'',''),
(NULL,5,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Have your say on the budget 2027/28','Public participation forums in every ward in November.','<p>The municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.</p>\r\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.</p>\r\n<p><strong>Contact:</strong> Planning Office, +254 700 000 050</p>',1790830800,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'have-your-say-on-the-budget-2027-28',NULL,'',0.5,'',''),
(NULL,6,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Mto Safi named cleanest town on the coast','The monthly beach clean-ups and the new waste collection paid off.','<p>Mto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.</p>\r\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.</p>\r\n<p><strong>Contact:</strong> Environment Department, +254 700 000 060</p>',1789707600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'mto-safi-named-cleanest-town-on-the-coast',NULL,'',0.5,'',''),
(NULL,7,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New boreholes bring clean water to Ward 5','Three boreholes and twelve water kiosks serve 4,000 residents.','<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.</p>\r\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.</p>\r\n<p><strong>Contact:</strong> Water &amp; Sanitation Department, +254 700 000 070</p>',1788584400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-boreholes-bring-clean-water-to-ward-5',NULL,'',0.5,'','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-22 11:37:36
