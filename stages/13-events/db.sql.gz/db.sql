-- MariaDB dump 10.20-11.8.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.9-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1795336957,1795336957,0,0,'Edit pages, content and news of the Mto Safi site. Images upload to fileadmin/user_upload/news/','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','Editors','1','1','readFolder,addFolder,renameFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',0,'1,4,254','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','pages:doktype,pages:php_tree_stop,pages:categories,pages:layout,pages:extendToSubpages,pages:nav_title,pages:nav_hide,pages:subtitle,pages:target,pages:lastUpdated,pages:newUntil,pages:cache_timeout,pages:cache_tags,pages:no_search,pages:shortcut_mode,pages:content_from_pid,pages:keywords,pages:description,pages:abstract,pages:author,pages:author_email,pages:media,pages:is_siteroot,pages:mount_pid_ol,pages:module,pages:l18n_cfg,pages:backend_layout,pages:backend_layout_next_level,pages:hidden,pages:starttime,pages:endtime,pages:fe_group,pages:rowDescription,pages:seo_title,pages:no_index,pages:no_follow,pages:sitemap_changefreq,pages:sitemap_priority,pages:canonical_link,pages:og_title,pages:og_description,pages:og_image,pages:twitter_title,pages:twitter_description,pages:twitter_image,pages:twitter_card,tt_content:categories,tt_content:layout,tt_content:frame_class,tt_content:space_before_class,tt_content:space_after_class,tt_content:date,tt_content:header_layout,tt_content:header_position,tt_content:header_link,tt_content:subheader,tt_content:imagewidth,tt_content:imageheight,tt_content:imageorient,tt_content:imageborder,tt_content:image_zoom,tt_content:imagecols,tt_content:pages,tt_content:recursive,tt_content:sectionIndex,tt_content:linkToTop,tt_content:hidden,tt_content:starttime,tt_content:endtime,tt_content:fe_group,tt_content:rowDescription,tt_content:sys_language_uid,tt_content:bullets_type,tt_content:table_class,tt_content:table_caption,tt_content:table_delimiter,tt_content:table_enclosure,tt_content:table_header_position,tt_content:table_tfoot,tt_content:file_collections,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:uploads_description,tt_content:uploads_type,sys_category:hidden,sys_category:starttime,sys_category:endtime,sys_category:description,sys_category:sys_language_uid,sys_category:images,sys_category:single_pid,sys_category:shortcut,sys_category:seo_headline,sys_category:seo_title,sys_category:seo_description,sys_category:seo_text,sys_category:slug,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:title,sys_file_reference:link,sys_file_reference:description,sys_file_reference:alternative,sys_file_reference:crop,sys_file_reference:autoplay,sys_file_reference:showinpreview,tx_news_domain_model_news:sys_language_uid,tx_news_domain_model_news:hidden,tx_news_domain_model_news:starttime,tx_news_domain_model_news:endtime,tx_news_domain_model_news:fe_group,tx_news_domain_model_news:alternative_title,tx_news_domain_model_news:teaser,tx_news_domain_model_news:archive,tx_news_domain_model_news:author,tx_news_domain_model_news:author_email,tx_news_domain_model_news:categories,tx_news_domain_model_news:related,tx_news_domain_model_news:related_from,tx_news_domain_model_news:related_links,tx_news_domain_model_news:keywords,tx_news_domain_model_news:description,tx_news_domain_model_news:istopnews,tx_news_domain_model_news:content_elements,tx_news_domain_model_news:tags,tx_news_domain_model_news:fal_media,tx_news_domain_model_news:fal_related_files,tx_news_domain_model_news:sitemap_changefreq,tx_news_domain_model_news:sitemap_priority,tx_news_domain_model_link:sys_language_uid,tx_news_domain_model_link:hidden,tx_news_domain_model_link:description,tx_news_domain_model_tag:sys_language_uid,tx_news_domain_model_tag:hidden,tx_news_domain_model_tag:slug,tx_news_domain_model_tag:seo_headline,tx_news_domain_model_tag:seo_title,tx_news_domain_model_tag:seo_description,tx_news_domain_model_tag:seo_text','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:div,tt_content:CType:form_formframework,tt_content:CType:felogin_login,tt_content:CType:news_pi1,tt_content:CType:news_newsliststicky,tt_content:CType:news_newsdetail,tt_content:CType:news_newsselectedlist,tt_content:CType:news_newsdatemenu,tt_content:CType:news_categorylist,tt_content:CType:news_newssearchform,tt_content:CType:news_newssearchresult,tt_content:CType:news_taglist,tt_content:CType:mtosafi_tiles','0',NULL,'web_layout,records,media_management',NULL,'options.defaultUploadFolder = 1:/user_upload/news/','','',NULL,NULL);
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1794119204,1794119204,0,0,0,0,NULL,'a:7:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";i:0;}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\",\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":0}',0,NULL,'','_cli_','$argon2id$v=19$m=65536,t=16,p=1$SC5jQVhyTVMwZmIuZi9lVQ$my26zjcmtB0GZl+0EIiotj27ERAFI4Epms3l9llGZqM','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1794119204,1794119204,0,0,0,0,NULL,NULL,NULL,0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$NTQwSlBTTVJPdDBTeTNPaA$tH9SFkLNfU1mfU5cvq+Ot4SY54Kw5EpathLn0W0x2EY','',0,NULL,'','admin@mtosafi-demo.example','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'36_55515db536f0d7fc',1826908720,'x��\Z�r۸u_����}hBS$u��N�؎+q-g7��DBb�\nP��if�����S�%= )R�;��LB�\08�\0Ҿ��?�~�o$t�.�o����S /�R��j�\Z}c�틷��N�\"\r���\0$��|�`��nb �Q�C�o��oA�d龱Lgff��5M�����M%O��$�f��d�&@�KL�#�p��9IX���1���}��XG�L0F�ED�K�12Ҝ�1�@�_\r�u,�\0)O9\r�5������ʄ	2��T,��F>	��\"	��ȇ��7ﬣӓ�i/Nւ�)�{���4�6�g��v��\r�#y������t�� ��/�+�:bB��h����N��|�Ԁ��&�oY�:���X̭�D�<�����a�A���\r�J0��\ZN��=�c7۝6��n�;����ߵ��:Ak�\n�y�+W�ٝ^�u��m�1��3,{rh���2�D��b)�ґ,M�KO��^�5��9Qi\Z�dζoh��ʙJsW�]\'�HKS���.�}�C����ܺ��h��m���Bd��\\0�jQ�KY�X�~<)�N�ny]�I��lֵ[�V��6��c7\Z���ޅI���m��e������W���l�0R��Z0���&��J$=\Z��s����,�w}��.Ɯ�V�E��L��Ԧ3ij��Le:�����4��J��^��D�9�?#��pp��\\�*^U����W\'�Y���*M�dJ��AD�\0��vyɣ��g�2��p����r3p�>������C�I��h��݁\'�����$xo�K��b��\nb�S3�ST��	t�-��w������)�bi���݆�hP��G�V:�Rc8�/�S��^����,e��2���[��P;��g��𱩀Xж�y8\'Rx�W������b��@�a�V�5�Ua��ӕ1��O�da��?��Pö�Jۦ^�X	*!#�� \"�4g���P@�7���V\\.��yJЩN�S%�X,��7��eJ��ţN��ȋGN�E��1~��ퟒ�]��(���`\ZoT�~�Ӑ�9�K�nY�B��F񵨉~�f�L!�1�ie��|��j΃�\n�L�3�Č�ePU��\0������E�*��p�<�\n-�|m\0�44ފ��h���e�)k�j̰�\\���8d�m�)��<����dfB�ػ���4������Ꮲ\\G�N����TϯFǢq�����Y��6��y5�դR	p)���9��d��&�,���D�Rfcx����jR�U�V�y+%G#ݶ0�uIj�=u�9xEb$�X��j�=���B*~TH�\r���H���H����\r�WE����U�9r)���qGjܿ��ݗ=���W|��^����j̳E��|O\'�5���aB�\"�.�G�FR�\"��p�J����ft��/�6&V�K�χ���j�!]�����Z���N�v�@e�1nc,����o/J\n[Q]\Z�,kԤ��T�C�Ɨ}����v��=�y,�����ڰ��Z�?;�����i���9��lu^�����E��G(ʥG����o%��p �G��zĚ`\"����Cb�q�����K��}hc�)���R�.%�v!Kh|c��q�������S\r%#��4�rW�+�sf�ܐ�xO�h`{%�`*�e�X��e�x��Q�˓���\nU�K��m�$�\Z{iB���d���l��6y�6�d��W���nÇQ;wv}Vv1cL\Z[���ٶDX���·8ɋ�3P+\n��ì휵�;>��?.��wق2x�N�tŃ�f�n�hP��Lm�T\Z/�����`Fۛ�AѲU���A���FnO��/���c��#�\Z�<g��g1����Nw����\r��))v�z��	PN�N��m����sy��pG>]c�;�2��GTh�x6\r[Sݨ�\0W�[~Z��mҵ|缗N��9W���w����P�]�)G��ީ:Ç�,�b���1�����L@��\Z6=�7ѿwrZ^�͙|��\\Z�^���L<ex�ay�_��@u/����|[cU�Mj�H���Zv��թ}X��d���<\0WE#�d��G����j�v+�SN�xZ��f�\'x�>���]щZ�\r>W��� +\'����Y�zx>���vK�C������vqEw[9;���TM�+����.q���sy�c�����`eW_�)\'`b��B������T.p����iM;]�s�,3��n�H�������L��.�S�^�(�n/��0^�W�z��j�~�Z�7�7`E�o1��{o�.,P���\'#�.Np�����0��A콾��_�����\"�]K��h�&G��5ީ��z�CM5��K��Jodp�MX>��a����3�r�ٰ�5y\Z��n]?�C  7Ma\'|ZnOn��(`u\"R�nJB�p϶�З�3�:�KCT>��]N�Qd��M��&<����;-jc�f�Ȕ�#<kš>,�B�냝�q��*�����jPivc���^2ɗgUn��b��f�Ix5��^����/b´��4�a��E�-�����������Tĺ��JCI{�	��H��hs���9ƻ�\0B�I��?}}�W��JӃX�1}�.-USf�gR\n�]ԙ���[�$�<7+��i���r�\'@t��Cɪd@�� KS�d��\"����������&r�r�ޟ�Qb�$�j��IQ�:?�P_B3C)�\0v�*N�\'�V�A<��3�`�іG;n!],v�>n�j[1S���x+8�	�m���_��\'���`��a@Q�\\�\\tX^\"�#O�Z��3����rح��CY���ZyD���8��K����<\Zd ��캐�����D�kڷh����βw����(	\\#q�`���*m:w�{��?��q���A�E�e��kz���	P�\\NOos��X��g�ч|q?I��VY7��͑������܅������GT��Fz�;ȱ�5��8���̣��(�){��!��.�UgBi�X���+��tn{uό���J�0C}f2��L��?�����9�F�^W%/�8���&NKg��J��N��k�����²X��m�8*��e�����X�G�[���.��b1?����v-�?⋚Q���m�C\Z�OzSt�t`>�A\nL��C��4���̇�J��,�]��j����~��p��^7����y���\\Vl�7��>\Z\"�s��Z�&�aL����muZms~vv4kt��/N^��z?���;��~������A�ɹ\'��8���ݾ�X6;��=_wG���+~C[W���y����2�~���z?>��}�����Y����h�K�߼g�\'���A��\'O:��ϛ/�d�/^�ǿ�kz���Y߃*?��;p��o奭�_����V*��&����f�\"�U5Ԯ��N�*P�j#�WY�Q�6*����XO�*8\r�H�hɫ\"(�v+s�4�̊�eSSϾMo�-���=ݧd�K?�c���=��h]����K��C�lH���>��Z[ƩK��غB\"��W�ʚ�\"�n.X5��N���b|}��>��M۞��.�Z��j:m:�X�����y~���]�6g�ߠ^���5}�u]�c�u\ZS:s�Z���9̝N�㻝���>(;'),
(2,'31_657a15e631ff6012',1826908720,'x��\Z�v۸q_�����}hB��]���ı\'v�Z�nv�=>	I�y+@�֦9g��O����S�K:�)3��d}N\"r\0�}3\0��k��Aw`�t�.x`=惦�X��$�X�Y���5{k����{��N��\"��у!�����]������0F��Èe��*$�v�e6�{0���[�&�4YpI��T�xL�+&X@�k4^7�Mx,S.x<\')KҐ�,!�oa���(�	�H����d)|F�4��� V���F�*���g������LS|Ie�_R*�;B〄�g���e���7����N����k�狌x�~�n��If��v��5�#y������l�� ��?�+�*fB��x���f�N��|�Ԁ���r�8�:M�;��;l���0���5Y6۵�*��q� �]����ִ����S�`�=�E���&�0�\';r5�������F��,����=��B�zƳ��^�+2�rA\"*.Y�l\"�U��cY�:z��1eך3��f����]K�x�D�Ti�4Yi���n�V`/[�<ʍlK��l�C�+�Ef��cY��ŌE�c��K�t]�����۳Y�kO��vӝ6\Z��g~g&�zZ��oxm�D,�t��B�o%xgs�#�qN�\rs;�mb��Dҧqs�?���K��d\'\0}�`�91���C�b�mmA[YЦ�\r��U;:ʇ�$X+�B�� z�S�ȩ�Y�Fc�c�\Z�\r�XV�b%_\r�\Zd�$�U>�%��ۃ�(.=���1+�V+dJ����S\ZB\0��k�$��������u����/����F�E����CG��b��\n\"�S;�S���	��-��w���@�̖z�����|��D4�h�޸����\Z�釻�G|+`�NJ�r�TƢ��u7�`k�٠(|l* q�ma͉��Jx4�c�d�v�2���ƹ*L^\\`ֲF\'��c:�CA�n��cF԰m�Ҷ��-�����\na�@���7�0l���C�9��K����\0Щ�կ��f�:\nG\rn�ˌ�`�G����o%98\r��I���Qdr�D0I=B~\"Y\'l�Y�Q�z+,��rև�ݲ���7���kQ�c��2�\\�@���%�y�r�9*+�k0m�@3\ZJf�j?OB���np/�,V��*�X������V�E۶/kLY��Ռ���\Z=O\"�����͝�\n��0;�k����g\ZB�B��1����\\G�N���?W�_���+.�y����M�o@�y5�Ť2	p)����_\r�b�r\n�0H]�Y�ѩ��\n�I��Rw@8t��[�r�f��&L���߲�#�H���hZ\r���VH%�\n��5Xi���O��kau/�x�j��q)�*�7���\\�,�����I*�S0y\n�6��\"	S�R̄t\r����!G�\\�<ĸa�D��v��gؿ���]��y���F]��J<4C��{�:�#��gW�wZ�Qރ�s���iQjv��w\'�i7צ�Ũ�r\r;�\Zm�����a��n��<�mX�y��X4{#�ܨ��Z%�?h4�Y[K!o��w\r�t4�P^��ј_gk\"�o���Ă�D@P�c��Aĩ�,�6!��t�Ƴ,��n�k�<���-#�ͣ,���b]�,�$��>��$�4�������$>͠lD��2���H���f͎�2�^-\"��\r�����F�%�ͼC��\nU�i�V�P3� RL�I m ,�j>w���0� c�P�<�K�sӚrP��E\'ڋ�kE��V+빟i�ܽ���\'��E|\Z�йϛ]������T��͂2x��b�f\0}X�m^hP��EmYQ\Z/���\0_F�v�3,\n�\nt�(�KR�,a��t\Z�IY:��1�\n�<eB�,���t��y�\\��|D�^V�<�	ԩ�n⼆(��]@�*?\"F:�y��@px2�ph/L��-���!��7���͛�k��y/���s�&�uY%XY�U,S�cɧ-nC���y7�cy��ӟ�@*���k;��kh	�;��_���z�o�K��������3�7��������q��\Z�:mZ�Db��=���΄ �R��-�zC	��-͜�ÎB����*qv*�SN�x���f�/x���8�]ѱZ�58�+c�s9(��H�Xxz���hGKC��5�_y^q�5�rA�����u�&=.���-.i��W���1���`eO_��)\'`b��ʌg�^�9�\\݄�u��,h�^��w�n��d�G�����N}E����T��t�t�����|!�(x���Ir����Ӂ�wt+L��z�zЄ�p�{\'��D��c�*e�f\r���?����7�b�6�X��k�\Zϗ��^l�w+㹢^�PK\r��2��Z�Tp��6f�ܞ�i�$�q��Ն�������L��uC�N��i:;��p�r{^W�����R��?�RX��tFWGxϦ�I_��%�\\G�H`8x����R�.c-�s��^鳲B:Ի>�xF�ũ�u�V�=��	�+ԠYs����ψ��˳*��V1h�Yj��a���\'�0�	�Z{ј��\\$\"�A�l��K����}�;����=���6���/lC�����%8h*��	C�Tt+%h����@]\":~$mBnp��tԮ�1gb��;�3%��[����1.���h�����\'@�ePJɪd@���d�\\2�O�{s�pe�z�z���\\�\\����J�$V�V9�#j[�i���6� �#��Pũ�*��<L�4|��<���F�[�\Zː��-�W��&�^�����B~Ȋ��Ir%oi\rf�[����U�E��%�?�lq�e�	:�y��+����8tnB|����#Z5����g�9:���h<��8cs�ׅd}�\r�%��^˻A�D�?���<�/&�FI�\Z����\Z+����(������5Ǜ�\0�\\T��~���>@M�2�rzz�K�Ɗ/>��	\Z�˧��T�i�u3fI�\ZllM�Vw�c(\'W<��GEpo�7���!Z������d���%a�|e��r�����L�\Z���&��A����^�2c;t��#�P�d�񓌏���е���b#x�_W%/�9���ZNK��J��n��k���ۄ�m���\r�ZqT\Z)˒��J\'���Q�\n��w`�,�3�@�8�K����CT�8~�q�:\n5o*aE�P\'L�,�L��I��/�n�51�	��h�MH짪��3�`�]��T�k��7U���\\d,�7���[\"��ﵒm�hl��\Z��m�;����p�v/�ώ_���?���9:w~�����~����O��t�f�zT,����������ɛ�+~Mۗoxӟs����2���/�?>��}��,�h\r�{\'����kq�xr��|-�����a���i���ŋ���`M�\0�ڔ?��	�EB����@y�)�!m�4tEe�I�\n���V�DP�j!�S)��2��\"�W)���®�ԭ�z\n�U`}��P��\r-yU�����J0�0{�V���zʮ�u�v��ڽ\r�\"H��\"�(�M�g�:�����kyჯ���C*����@)�T�E0�_�\\�j$�\Z����H���fЙ��.m�M�R������t�N�W��.��Y�����/�lև�&����Ѿ�7����̣�Y�����A��?P�@'),
(3,'35_2d9c26877cc62e6c',1826908720,'x��\Z�r۸��6O�c��GϴH�[��I;qb\'��ܧo4 	I�I�)ٺ43}�>L��Q�$�H��i�Nr�63������A�3x��#�s6徱����y\"JY�\Z�ֳa�1��������d�����H@����\"���@����Ð��x*���tf�`ƣᗦI��|�r�܄���c,��d>q�h�n��(���ќ�L�#� 	�c_�r5�Q2����$b)=FƚsrB#�V������J�K@�SN�`M<�h�)��I�$�\\R*�-��O�(��e��سWo\Z�N�wK�=�%�/Rb��=ӱ��md���\Z�I���[�J�`r�`\\�`���l�*b22G�LȐ��N����]j@\nJH�d�h��X4w��7�&�7��%`�\rk��l�o4�4E$\r�������-�n�-����\\v0���ݢ����41��j�g��o7��A��8�c�^�j=�i�F+u2l�G�\0\"��1g�+�\ni�̮�\r-�񉲛��gW��ii���ž�V�S���4�l�F�*�=I�K�����RƍL^�4����z^�z�٬g��v�ݴ\\Ǳ-�=�:�0	Eв��c�\r2��}L����E>FBʣ�X�v:����I�F\"���bn>Ů��E�j0��|\r��CW�k%1p�\0��/yl\"���#c48z^��a�*N����竁��AF��>_壩�]�l\"b�����G+�V+��F��%��4\0ߙ�1ȉ����JNz˂G���_�$�:��³��\nEkDW����uQ�&�ȶ��\0Df�ff�\'&�/hetP��e�{0n%#/5Fc�p_<��� ���\Z��L���v7\n�`j�٠(l̕�\n���0�$���U4��a;�v�2��Ƹ*LN����	X����0	�	7���5ؓ�mە�M�l1�W\\&aTz�HA���@��A�5���V<YbN3�b>ЩM�/�<�\nG\rn�˔p�G���g��c������wHĮ�/�;���TlD��\nK7�i����G�4�@��F𵨉�1M�L!�1���L�|��j΃�\n�\ZT�3�Č	ˠ*�\0������E�*�w�8�-�|m\0�0t��Au޶m��\ZU��?d�Q9���\"d�l�(�=���ļ�dfLסN@g\ZB��a�Gr��(����`����\'�cъK!o��� �\r(c^\r|2�TB�\\J����_3�I�KJYP�LU���b�N�T��L�>K��Q6�J�Q�H�-Lf5�ZG*{:^��\'��[u�\'��K��T݀\Z��ډ��U:ӡj)�*���3��f%�\0�\rQ�VQ/�Oשي��I�~:[���XM�բG�B\Z^�S��6{D�5}6�� ��0����\'�I���_��ီ!/��}��[J�����r#�����V}��������E>6��i��t�˫hj���X�cU;)ET�L�>N��_�7�m6m�tc�8CW�^�6�!�R���-��G���(�ڰgB��Mw��Y��z�tz���������pz��<�p�Ґ��d���-�B��_1������:B�&����ݲ�h�����Q��i��Qw�y�.}����V�&�O&��A��3����!C�TC�C�YNNE�N��\0Y�~�ﵕ����\"O��-1#��$����	�B��N��$o����g�[\Z.�r0}�6=0hgР��_����<r��K���d#����a@�DR���wдA9X�\'�B0�e�t��Gr�̧��{i��ٕ5A�/�	=߼��ך�QZ��\'��r�n���T.�7���{ �,�V8�n�FP���@��f�iA�l�\Z�2����Ռ%x:	�����IS\ZI�-Kӵ1:ԃD��$v�j�v�ґ���Τ�����u���2��c��O�Y�\r*\\&�����i٦\r���4�o���4��1j����ƆLc��`A�Yri��Q�\nJJzG@�5��C�ᩚvr��h�(N�+IG�\r�:�G�=Ӈ�oQ�&��R�{��5�͡�7KM͝��+0��ق2x��5�Cp�t��W�j�~k+��xi�t�`F۵h��\n���TՃ9�9��>bI)��VvE\Z�GO��LP���t�5��Ns�G�z���rN�N�����X��jr�6�N�1T>��@�@�,�u]�\0W\0���l�$]�w�{�{U=�jb�!խ++��\Z�%D�]�\Z7�|Og����\0)�:��(b�W�[�1�ԃ,x�߉~����~�T�|#�|�h�,��L<e�\r��\\?|4��1RCo7�����ƵA�z��>�H̽��K�b�l����a��}��0&�g��;�ש&�\0J&�$�Ӈ~�xAWt�V�\n�+e�M*�5|6Ãv�c`�TԷ�������˽m���1C��\Z)�Nդ����>�K��q��G�f�أk��=���g���,](�R�E�9d\\\\݄�͖�5=��fm���x]�S�z��u-�i*.��.�S�^�90�i��d6+�\"9�\n�:<�:��VtF �#���zЄJq���XHvq���W%L�A����\"_��O�][�@A�&���\Z�V�sA�¡�\Z�]J�Z�Tp+��l��=\r�*8>4���W|��\"�Zx��f�My��\\5�s��^�=���Չ@H}�7�,�ɛ�/����/� �,�ps ��08�&<��������u�����#�d3���Pl\0E�χ�ҔV��%��^��s:W�a��\r�����#��ʍ����Yj~a�=	�`�@1]x8d�-��[�����L3�Mp�[nt|m�_;_%�X-�HIh�ӾR�6�`�on���r��D\0Έ����?}�l�nO4�01=��ӷm��J|)k�gRr�]��ڹ�k�8s�c<~/��i���2�%��P-%՝]\0N�, �;C��5gW�1��-���7�������Qڱ*���\ZQ�:��IB3C��\0v�*NՕ+ �@�4x��<ڲh��-�e��\"h���>��fj�/����BvȊ[G�����\Z�w��C���Y����:�{�	:����(��\n�8t���\0͡�{4��`�JD{��u@Ge�} p�3h�����Y_s��\n���4O���βg}Ln��K�� +���܊�9ro|N���������F����ҭ(�3Y��7��a��*��M��}�P�MRɦ]�̈́�B4ػ<�4^<X���P�C��{L��`�7��3����}yT�� `��gmŁ���qu&��wEu�q����\nAǶw��vݭ�3�]�	�E�\r��n�.Gԝ����|]�yQ�ٝ.�kzwv9�����1�v_8|צ0-��A[�F�{��������B��^�&�̋3I�/��?V/�U�&sV�*�ϴ�3�j\0[a�aS��s���9F;�Q2�f>�ħ�����`�U�LU%�iBgU���K�?,�7��\0��2�m�wZ�&t(&Xh~�҃:�9?;{6�����/J��_��]4��������ɹ\'?=���;�S,�|Ǟ���ֳ��7OV���/��7��������:y���I�/��/�Lg�\Z/�\'���������E�kI����v[/������_�G��kz�P�Y��\"?��\"�j�Na�B����_�����)��&5+ A�\n���v�BP�R�ePS�z�Y]�+���Ԫ��\nf�a��`�\r8z��t���[�N��0m���wz�>�+P\'3�6��?m:�|����C����i�M�!�W�&�2�ϳ����v������J�NEvM%\r��S1|���:-���:�U���t�V��}�����}h�\\o�\\��1֢�{>���>m۽�˚�۞юc��u�}��t;^Ƕ��������m��.u�}��:]�?��P'),
(4,'6_3f7368fe3a6e05a9',1826908720,'x��<�r�8��������%�D�[���8v��J<�3��͖\"!	c~H�Vr��w؇���(�$�\r�[�l\'�lnnR3�\0��\r\Z��c8�\r����%��\'|�}\"!��E̋4x3ڭAw���{����ϧ�d��xg�?ġ�|Oc���\\C��x�����\"J�!���8��}�3�N���?],xH��4�#���L0�LWh�i�p/��ޜ�F\"����}�eG�L0F��y$�ca1r�X\'���\\|<�e׾��<��qV��F��+\ZL��+J����P�&��B{���������ӓ�i�V��1��n6�.�gUd����	�����A�h�� ��+�K�ȵ�Dd���/\\\Z�8�*D�i�\0(!\n�a�����ycG�Q���\0���q���`�=�qICPD�h�۶Z=�m\Z�i{:���)�`ִ�F�6�]�Z�p���.�2z�N�e�\rC#@�^�р�G7��Z�x��	�)@�ᨡ ;�<��6g03\Z�B#�q�iJ�i;��Kή_D���܎{6[�^t��8U�Z�a{�Wq�a�rX�`,ʤ �17h$�°�k\Z�o��ՙ��Fg��uZͩi\Z�fgfuw���m��h�e6�{\Z�����~\0���{)���v��ԟI�z��a�)��.l���6�k]�!ؒy1��B�\0���t�-�\r幣�o���w�&u�	������\0G�L44jPɞ`��h �+���/����4m�6\"b��T��K�y��[��\'1�����������?�~$8��Mx4z�K����#��&=xn��G\r���գK�VNu�NQ��L��U��5��\0`z��:�4�j|���%һ7n)#+����x�o�\Z ���\Z��D��qM�����pr��MXc�3U\rswNBa=T������u�@�a<��5�Ub��#�6�����.xfn<Z�=IXծ�n�e����2!��ZhD�ٴ�\r4��\0֭q$�5E��a��N_p��N���\\�b\"J��!q���^G��U���4=����[�h�G�I��1��5�����.�s�˷�@<uy��>j�֊�\Z�:�傯EMԏ��q�����z���K��<Ȩ�n@�6Į�*s��\0V�tp��@�-�Xr�3(�l@�W(��IŃ꼭j�q�*k��ʸ\\���e�l�(���	o5�ҋ���>1xؙ�E�������7u�!9�����蘷����7�\Z�)H�0%�ˆ/&	�`��࡫�/�5!�\0��DO��ňH�3�6��TBI	�Ť�3��\ZE�.�!��T)�DR,��[rSћ��`H,�Ӳ>��7���fu\r����j;�S��\\s�m.�UY�Y�p�����E�=�5��e�M\Z�U��A8ω·�9]A�H~t=�6��Uw�,��U�K�k�oŢ֓b�>!V�����*m���&�J<S%�R�M�^���啍��Fޒ�k�[�`s�x^B�A�Ocx`!��L��C�I\n\'\n����(|��Õ۩z#���i�@�E	�|��(_S���?�9�6A�$wQR�g�Q�)9���Y]MB��\rfJ�\0)�[%˅�ut嵛誖��*�nf��n���(y�BU��M@�V�$5�pݰڼ�r��f�J�2��F<�\no��_\Z�ݹ��8L�4b���B܉]\Z�&w�$����s�¿��X�R�!<����F3>�q�P��s)��yd�k�<�oJ�8�w��q�׈a]v�O�F�V�Y����ƨ�j�V���>�\\v_\\�d�����+�Œ��\rKE?�J�1�,��ȔxR�jE|�`%�@4���%ub�}\nK2�,(n���Q�lwz̧���!���gk�\0��I�i��Q\n�6�s��^����9�a�-�)76���!����V�;rˤh+:s���a��& ��D�s�I�XZ�f��b��������mu{V����F����¿�JK̙����b�Zvt��p�BJ��~�i�CN.�X	w�l���l}��孀���C^�f�[b�Ub�U�A{Cۜ�smT��.�6�ވ��ָ	�5��\0ہ��{��շ�X����*�,�Ռ��a�{�J��q�rh0V&)�a��\0�L7%�z�s�=������,������|���0B����ո���f,��\Z�X~��C��#a$9�	\"E�f�lo��&�?��|�;j����]�)#-�Lp�o�	�%�����D�\r�C:)�y;�)C\0��	�Rta���f�|��b/��V����;��N��[��Y#��ioJ��\"�}�\"SZɯZb֏̚�Q��L�5�~\0�Ǉ��f4R�+T���m���U�6���d�##�Y9h�E��,��5D�*�&P܆������	������*-�H ]}m�ax��|�Q#+�Z�(R���E�!]��z��1�h�`��/õ���<n��ͤ�E�N��\Z���0����J)�^w1�[�u�_��q�����>�������u��~�d욿;�����8�?߲����`��ߢ�5w�;1������������P��@�>�$�zT��nG�>��~�� j�4�q{�\"�og�#�(č�)����[=F�E��n�o=����>&� ��E�Er�8E�VN �W�*@2�� \Z���R>�O�/�ĭ�\Z�YRM���iϑ<���̌f�U+P����#X�������n��U�����|.)�̭;�2��-X���*M~�zʨ� g>����Nw�쒧�\r1���l�=i\\?_����ݦ�&`��X��l8��?�=l�9�������i㾻:����x��v�����\ny/�d�5NQ�6����q]~v@�����5<��@�%�VM@�+m|�މzprj�z��<t:[�^���ގ��P~g��m��)ۂ� ��O~t?�>��zpz�)�#U��\Z%x�Fn�\'�������Tn��?C$�EGP2�% ��:�K���r$I�s���_�ҽ(\\������0�h�ڿ����EF��뵛E�h���˂�\Z���*���\nAf{�am%;=�.���8�jǯ/�g)��:l?~��}ui�L���4�x$oǽ�䌣[0�\Zݎm�ZlJgvwf����ѱ�6^�j���ҫ��� ��@1l5�$2��K�2�o�/dur����d:l�Ps|���=y3l�\0i*�&��|�ޟ`#� է^�6�!v ��C:�\r5�I�:��z��<��J{�Ԟ\n굼�)�,?�\"�R#%���mv�Ҿ}S*��6�q������yg!6|�E	���\ns�tv§��j���;!u\Z5�2?.��k�3�<�[�(k�� �����uN��=��o�6���\\}��r���\r6<.��9W��3\Z�2\\E�2������%j�l�.P�Gz�2�>�/�*]�ղ^@;�%;�7�ԝ�N脻,sA���k��ˆ���8J�Z����)J��D�$�G38��g:�:�B������1H*�ok�49%����Cy��a��n�k\rϘ��6d��X�\"��w���̛�O�9��V=���;�-�)�\"-,����I�R:3�OSS�pd�Z���a\"�X:�ß/�8�FaƲ�+�hD��p,}�	2�و�#Tr*�c�;��:�P\"ͽ�E�%n!:�;��H�2yf=������	\rlH�`�,�}�@1]��z�#��P��h��@���j.�A;��Ci��(�M��9tR��A�^�i�\rQEuT^N8cs�W���\nC�L{mc��D�h�Y�\\H`\Z�,��XQ�ms#�����	��Ul��������+�(	fOO׹Ta,��}�H�.������es��L4�dz.h����{�P^\\�������)��\rn��$���w�;��>k�����=!5|�J���0Z}�P)�$���\rܹ�Z*(%�/�b�u��d[�*ԑi����7X�p�*�\'�g��~�EidX\n�(�S�ma�	��x\"�f��GE��y\'��Y��\nH��=�u�s��>:�u=T�%��g�l��9Z�ʿ8��������TӖݠ5�PcIE���Z���E�{Q���l�i\"�7�Jp)�K7�:YT��n�衊>�Yٴ�����cQ���(&�߼�b��b�ؼ�j���3�m��������\Zk�q\\`�~@��%կ�Ų��3e���C�[r[Ku�q%Y�J�Ug�pՇd��̞�L�&-��H|\'��x��܋J����{7��4�7e�r��׿��ąu�.�{`S5���Ï���PX:s��\r�\n+jv�������ٻ�?;y���z�r���}����|v�{�����ώ�|�vO{�\r��Ğ�zG���ۧK~C;Woy˚����ϱc}�	_�=�����\r���������� ���8<��o��Fг��ɣ^����3~��/�������Ň+����+s�ȋ���6�_��f?�tO�_^�޳�`�n�I$T�U�XJ|T�k���Ґ*+B:Z�����zE2�.�Z�@���r�A}�H���~�CȠ�K6K�$�(!oJX�y��(s�Е�W�J��\n_i��X�4VN��\'E�I���ԴH�dNRlQ\Z0ҥ�*�Đ���4�UcG��[:i��T�m�n������&�����ov�>:��)m�Mft(�ul��1-�=�X�n�K��hٳ��7kv�}�e���Yw���N��4ͮm\r��N��{`�V�GgVw�f�����/����'),
(5,'1_88ef5c556644a5cb',1826908727,'x��<�r�Hv�\ZE2���!�B�f�)[�ly,[+�cϮ�XM�I��\0�ę��}��ʾ�*�J�a��I�%U�����rN7\0$(Q��I�gWOw�{�>��M�3�޷I���\":e#�ix�| !�S�\Z|3�m�����=~yp���!���?�����p���P5�ƨ7�G�_?`)%��	K��y:�;��^�3]\'���|�r��	O��H\\��yd�$@�Mt��$�1�$b\"�II\0���>0��I�I\"��ȁb����\n��(��� �)���$n�h�(~I���dxAi<�\r=�s��	��Cڞ�x�xr�|�D��2��YJ�n��[��\"b��l�^;	!p��0���I�`���r�82��D�Ma��\r��\\R0B\Z%�F#]F���qO�Q�>/\0���q��Y�&�ZcD0D�0���v�lZ�=n���ng<	&��1��q�֒�/�b/YL��lw۶:�� �\0/�h@�W��VOy��S�~C=�S�A��ڔ�L4�F2��הN�ה�.8��D���^r/��{l�����ĥ>�7ѱʒ\'��gɌ���_�)eA���&I�m���q��u&��錝�cc�2\rÙ��=�\nh�f�2���t_B��%�������0\'�@�Vk���W\"��P���)��@�y��=�\\\r9�\Zjb���[J]���A���G:b���5�\r�\0����ߠ�9�����@AW -��_䭩��4oXoD�@	p�n�CV�-G$\r\'s��Gԇ937�~��?Ŝtz��f>��;��r��\rφ��!QT��t��SݧcT���^k���@Q����������� �@��n�[��M���z�O=�k��d��*��zܰ�ʀ�t�8+���c�`��X�0�$�ݻ�Qԇ��54�t�[�\\�\\&G#C��<H\'��0�V���%�������M�n1�W�L�h��4_Z�\r,��6��/�5G����2}�a�C�:U����u&_m�\r��7�yJ��ƣ\n��G���e3��q�H2���\'!���(wR\'�c�X�^~+��Os��\rպf��^�V��EMԇ��y\n���L=ө�r�92*�+0��@�\',��%X��=]�(,�WY�L�3��b@��\nPC\'k3�n����Ɣ��֎A9��R��X���j�*N墁nD���-@QL��2��3!C���ᷢ\\GB����?������y�/!]��@��I�1Qp�y̓@��׌@�`�|i-!Ne8�h�\rN%�T�L�~��a�Qv��2$(�ʰ�Ȉp&s,�j���(��N��}fn&1�eΧK��L�DA�ʀÑ%�]L�	� D��=6�s?;a�уT$��(�9�W�%#h쒖l�%�\'Y(�0arI*�.ɝF<�R=cU>sH��ւ�+�,��y,qc�uͥ��\'̯���:��B\'Z��D*�uO@l\Z��%��/��,�~i}^? �@c_;��q\\����oޫ>���&�{�f�͕�f�����)� ڦ��gY;&�j�x@-��\rL�|A=.�s��`5�dM�(�ac�k(rG�NcQ�x���&�:v�luM��IV�R�-��*�2���q.���H���rͬ���`R�h\r�m\r^�p�ą;���Ri_�v,KkJ�R�\\	�k�d }��GD�)�}p�����{�F�����Җ��%e���1��<q���ޒ�R4����ں���7���z���:��:Y��N�-ף?*�>�w�e�L��{S��d��卮~@}w��Pr�N,���I���\0d͌�&9QU� t!�Gd�f��x�z��@���o���+%�����$n�֢w�-]��3n����~T���.�����\0���ܛ��F&��դ�Xp΃����KH�cz�\'P:���͢op�!c�i�&!�ȯ��jM�U��ue���{WK��[)�#���)p\n\0y�ʲ������-E}\rw��g5\"�?2/�0X����?���p��DCv�Vh�@@���l��T>Y\Z>�y��o\ZY�����J���iݶ�I!�%?��|VF�`?��Ar���zyC��y��TD�����X5����f�wcyQW?ˆ��o��2���z�b�_+ӽ.^��H��h��+IŨz\Z\Z�9 ����eۢCI��D�\"�%���͝�;�EM*r���K&��\"��e�����O�ǒ���?���L�SE� �O-��n�G�����\Zi��P���(�����K&���D����\'�s���QD�ӿf\"�1|yG(�D{��N�\\mo��Wu{�U����ϓ4�t�b�î����W���xpE�Z><;x:b�����{x����,E��\r+���Q}ɾ1 �=�x_�������R�3D�\r��|���`٥\"��by�*��W�;!*:�#X�ARB��Q����ϟ�3���Sc���\Z���MS7,m`�b��1�}�y���:�-�3uO&<������`����m�����U�̢�}XQ|���N��ڱ�K\Z��DnƉlϗxbhE�V�+��md��/:�gˆ�Q��<�G|MG=��cV	��Szd�eX�n�ϙ�;�����Э6��M^����ԏpg��	PT̒y<�.&@`�_h���Z�	��r��$��\\2v��(S��Sz��	<ܜ�3cd�)��a\Z3�������z�E]�x#� �OȾ��X�n�=���2qi���k�W�+�=\\��,s�ɂ���1��h��Tu_�TLE�?Z���2*|�_:��P��.�;[�:��Ҝ[���1���Ҿ�����ճ��;���ɟ���	�f%�lM���I��x���MS�-m�<\\�3(u)�M��Bk�d�-��,�b�兄��$��l�g����l�GIה/iɀY�6\Za��j\"\"�?����g��_�~NR(ϧ�u���ڍu]����\0��n�V��̊�\\�e/0��V�\0AE^q<��� (�\'��3�=rX	̐�@^1z�w�d3U�m�����n��:(�c�~�0���wb��^Yr�!%�\'��L�\Z�4�EM6l�F��A�S�/S��@��I7;��H�?���]q&Ov�7C_�̗��\'�ŝ��L��ug&xG��<�G���|6�U.�\r�����ܲ�����KV�oJ��tJb�����3uN\"qgB@��	�U\ZXup$�<\Z�wa��q���k��ڟ�dR����п�?\"];U�@5���N�Vֿ�h|��σp��^��DX����Y��� L&%{)O����R�`f�ӽ�0��1-��� �j�<���i��.��H��d!e������p�ssx�*�,�@��;A��d��g���Ƌ�]Ol���n\0m�ũ=���`e�ډM|U�$|���X\Z����4�R4\\w���b��R�@���x����wNNɫ��Bѹ�����;&�2�U��\\=�7���y�#U��j�H�3���w���|xn��_��#�\r���V�\'1��ɨ.(�Ԍ:es�{\"���H<<̧Ҙ{�ʅ(��\n�����Ԡ�Yi�\0�Q��z�i�v��_�ς�W,��K���y!��fOK�U*;=(�X��8��i�/�y�*���3z�~#;��t:�c�)Sy��)Mf8چ�ݖ�6�-ӞL���[�I��n����2E����D�t�F{���K��@,س�(�SY���#��=���i���|ڃ�=HGy{p2|{ b��96�o�����ڈ���~�����Bɝ�Zh8���[koW�sE���]e��R\Z/�H	72�ǆ,��Q0e��A��r�X��5���b�w�z���H��/L�B�s>.�\0����kK`�#�5,\n��\rM����1��B%�;�`���ޯ�4��a�=n�(��Ma-S*��hD�n��bU�����\nW�\n�d�өD�w�խ����O3�|�W�ƲV��Y/�	oJ����@6_�=����`��D���4Ch�T�r#ϱkx�]�����V�v��סH����6h*����	J�)h���\'=y������1u[:i�e6e��l @J�zu&%7r>�&�sܝ)��j��Xs��\'�,J!7K��]\0�,咡~�P�3�#��u3(Q|���9�č��2u+�fD��8�ú�2ֈ�#Tr*��c���bL���M�5��*�BX���8��l�:.�L�|�|B#�=�!+n����C��`��=t	^�72��%үy:;V�`Q�|�J�]���6��=t\'��4�����S����9\Z��a\n�AA���d]ō,�5�\r�\'j��Coʲgu�?^)	\\#�E���Ҧ��S�~g|V�����ꋊ�Z�����&@��||�ɥ\nc�e��ڠ�]n�_OR��)�f�D�\Z����4��Z��m(�/y\n����ޭ�nf9�\'h\r���wY��߁�}�J{����>������\"7XM�dE�b����bcL�RH2UH*�{A`��{�k�u�H�,���9�bl����g5�ETD�`�	�\\Đ������&�o��0Ke<*Z?�ʜ:cM*��{�!a����9:[\r�z��J�B�N�y�KL���f\Z��1x��\'����RZ��x���\0�-hܸ����v�I�H�@��|��@���s��\07���\"�1Mt�k��pG��jmn������5��v�▚똷�ܮLlh��E��/�����M[6f��,\'6��c+f��Vl�.�b�Q0Whk���~�?ӟ��O1���p��7:�Ns����TV�|{Ơ\n���P ,T$-�aN�m�I�OT�üs`�� *xj[�_Vo`��[4YPϢ�\r��Tn��U`��y0O�6^���)��~��\\:܉\\���6h�[-�K�޷*��I���g�����̨����ٓ�Ѿ�>~��S����㷍���%sv(B:<w㇏���|���/�M�b���#���ɫG~E��W�v��x~�f��\\%Ϻ�������͂\Z�.N�ћ���Y�����__���h���v��G��|��f���7ޒ��,�_M΃�m?/:������h#N���7�7�:x14����l�\ruN�6J�Pӣ�Q�dd�~�OA-�-���YL�d!�Y�r*�&�Z�D߮���T@u+����(�,C��\nLIT�%av�����y$I���5��l�R��̷K\rMGy�$$�d��~$5ev�<�\0��+�Y{w}��c[�����$ϖ��I\Z���bR��2&��)��E�V$-\"�9��+yM�:�T�`��{#[�iUljK��r#j�b�	|�=\n��|Qh��OҰ��I������K�Ҥ�s#>�	��{{�ȡn��QqS����]�ే���V��|x�Ucr�ju����ؤ��L�鴭��6ƶ�=�aV����}�iB+3ڞ՜�j6i��l�4{lwu;��2�-���X��i:F�5q�dB;��ㆇ�'),
(6,'36_20b833d6b25c3c4b',1826908871,'x��:�r�8��������	M���Y[�b;N�$g)3���r�$$aL\\����Nս�=���G�\'�n��H�v�̬�R�Fw��z��}μ�g�tɮxh��^w�B���,�\r�5p�3�߾�0����Y�q4y6��h�<4Xb~�c4�<#�7�YNI��2c�������ߚ&y����\r�3�3���a������KL,�\'K�2�F��d@�}�̣d!#\"e	��Z�L���&�V��ǒ��F�k �sN�hK�h�9��Y�$�]S*W�gB��D<`I��$��������g5ցH��/W9�G#�t:΀��>�rt�d\\$ �d�i����D2��|��$Lf��4Y��)y���k\r��	y�y��oS�=ri=3M�oēk�\Z�d%��а�h�Ȭ�3\nà;�{���{����\Z,:�k��u\Z��2+Kq�m����~�븶m`ƀ.bX0��m��s�Gl�q��HJe��j�A�u�.YN�FC�qǖ��LI�94�4���)b��ж���ت�n8�I��k�7<�W�!ۀ�L��y�l3h�m��}�|�l�X^YIY3gqj�\n��\Zv�~�=\Z�����a�����t��`p\0Hh��m��o����\Zf(���)S�����;�3�5�MD�A��c7!��A�:�����釕*O�\rO�ʓ�v$��ttB[:�Ǿ�����^��DYJ���\Z��1��-�$W�R��\rr�\Zd5%�r4�Oˁ�A$���F���I���jF��dr�N������#�\"��������:x���$���{��#Cx��cK�hRM��S3�>�`�$�s��P@4`������p/N�*Ѡ�zO��l��d�_K������6�y�Wկw��s�\0SΎDc���X�Ӿ�y�$�~��G#�4ѵ���/�R��[��!��/cr�?�>�bH�]��|�`�q�}�n[\\&\Z)�1*��A���g���Ð�`�p7\Z�*^KR��q�4W��#���`2SO\\�ʕ|l)\Z-�y��s��=u9�{����4�[�<���ؔa��$��G��65`������W�`��</E[zt�s���v�o%M��4�:�Z�@�����2b%�RU�-�6d`��2V@��.\"���n\r���\"6��\Z��Pʵ����^�e�~�[\\ٚ���L��Ř�1�aA�A�Qt%.PkK�;�����?�8}AJ��8�1����o��7�cɆK��l�\r��`��^\r�fV���	��<���\n�of�����ofվJ=��تoc�Q��n[�,z&5��u��9�xUa\"4F~3�^��{)%��Rmj�-�Z�h�/3ԝ\"��J�+c���\Z��R���]m����w۴\'�9�D#��f�,Ǻ�Ʋ[���46�Q<L��R��Z�!�	!��7�����D�o�lA�Q^�������\n�a�ģb���yLSzO\'�խ�f����ފ?V���}*���(��4��uTB����)Ԝ�\'B���rh���iۦ��!�ņ�>x��[Dn��po��Ǭ�o{N^1\n]Ӆ�!���(���]����N�47�r�/�݁���R\"�x\n�C\\\rc�%Y���$���8n-Λ�K�̡oU���9+����n�G\\�%ˈg�2��D�u���\0,ԩ�HPф�P�-�G��o���fYN�I	g�+�(5j��Cx�������s��\no*���w,�_�%�W%M\r��ȡWf�k~��J�ݩ�/������:`���n�����ZSo��	u�X��\n-��NhP��Dk�P�;�\nD�����̸�X\ZЕSm Is�#w�iB�g����N9 |�5yV/�����J���>\'�fU�=\0)���q�|HY���+�N�{�H\'�\"	!wA�c���~BS����s[HDݧ�gdw�E̻�[�.e��ҶK�۶Q�2l���i\0���=nfP��6$d}�Tu�_%@*��[3�[���o���촾��1��Х��n�ߙy����r�_��As+���|{c͠M[�H���Rq5�ա$}\\���5/_(��`\\�˗)l�˅�U��A#u�%KP\0�LH��O=o{k�L��ƚ/�3~�\Zo���Q�zx<�&��fK�;C���W�vu}5�AN�3rv�+�յ����)�g����$Т/���>�\n3]}=v�������r��{�74[��.���Å�ho�w�.z�;���3w(.�=Z��Z<����v�B���ex�K�Q�Թ8�k������gD�5��.LP�����.�B��3�(c����H}����7�d��,Q���H��LE�7>l���z�C=5hy�V�T�Nٌ����i���/8��~\'B�R�Pp�����F���G(]3@��k �d�xCl\"#u���@��o}?���S�_S����s��\0����G)\0�e�A�h��KX��=O��q*b}(Vi�����)l[\Zp��M�[XeN��4X����GygW����X��`����B�2��v���*E!k[/˔�VB��:/v�@�����w���L1s1LN��v��TL�C�\r�����,UJ���d,��R	,��݉�.\r� ��\0Rϻ`�\":���3k^LH-��fJ�N���\"�����G�׊��H�dˡ�ʚ�_\0΢�j���}�\Z\\\n�3�X.0�V���,+u?�i��VMc�F����M]�MXnb� �\0u�*I��Xe���i�\Z�e��NCZ�눝&��Y�����.�1ޑ����\"qȪ��8�ַ6+��#�F�c��\Z�y�:պ �.<a��G*`��4])�a8�ˌ�i\Zmߋ$`o8����<��(�|�J������^Ͼ��\\Ͽ<��V��/%��H\Z�)�b��&�Jy�7(���9�ĻK���+F�ߠ����\0h	0f��?ޕR����/��E����,�m�u�̘�L��I�Փ�=������P��T�O&z�Y(���7x�4���G�SE,P�lmK��]�lb���j!v�WOz�F��������+���>���\'�џ�a�E}j�S�\\���WM�=bO����u�.ְ�٭z��CJ��&�l�:���u)�v�s\\�4X���]���	��������&S�/\n�b��K����Eg�؞��B<���XQ�7/�;��\\�B��Ka�\"��P�?��hY!=�x���\n\'�B���[�:6�qݑ�T�\rY.{�gmlv8&�Xlx���:�����8Yt����g���?�]~:��~�m����#�D��<�/_����ӡ񼚶8�����;\'��^m�-�_��`�;g�?���������W��>4���B�\"����|��t�A^��?���r+������a�ݫ�k>ۄ�����pKO���h���s������W�ٕ��_����Ϊ�QH��AP��\"��\0�4h��a�U �\Z hԘ8T�v\Z0W��l�`\r���54p��M[�_�`�_k�UOs/���o՝���:��U(�P�*�MQ�!Z �$Z�yX���Ͷ�U\0��r[x���F��4TV)��*��nS.Y3�\\g0긘J�v�������¡��`Ⱥ�3p��w��s��h��a�e�����]{�z#�7\n�``�\'��=���.��t1�:�1���_��'),
(7,'36_bae7eee50673f8c3',1826908886,'x��:�v�8���\n4�g�CS�D�\"kO�؎�vⵔ��x�DB�$�(��L�������)�%[�)ӎݝI�6�B��U(\0�C�~V���J�]��zŇ��+\r\nD��$��Ww��Ck��ۏ���Gd�����$����b��ij!��p����Q�2J���e��:[�}�x1�ƶɋ���\"�l�x����I���\0��mb���K�,I�D\Z1�	����k�G�B2FD���Z�L���&�V��ǒ��V� �3N�hK�hf8~OU�$��P*W�B��D<`���u��ɇO����A�u ҭ��UF���o{-�K�b��9�q	H+Ye\Z g+�%��߀\"�	�\n؜&!c��<-�C���\02pB����d�T��\\:/l���(F��9YI�8��k���iy�0�=���yg>���9h�h�}�C�����H,Ł�,���\r�v�뻮E������wwq�^�x���b���/b��U7<�YP.G�Axab\"_ZK��LH��vh�N�u(Up7�ݦBf�[f�Ðm�M����\Z�C��j�m#�V�e�Q��2�Nn�@)��r��th�/}ן�=�ݚ{��j���{\0Hh���<׷H�BN-�*��Q�O���)O\nf>�v���̿\nˀ&\"������� {`�9lVT��l�q68����q6:N�crz4�V[�:5@���Ȼ`��(�5��5w�ȡZR] 3�� �m@V^2B�)F3��i1�?����2h��<IX[�P)M��k�Oi鶀`�s�������?l�����������<�Cz��2��M�N5��cN����S&1���{\0\rD���le&+��6>*AĀr�=���Q�Y�yy*�fFؤ�)\\�{Լ���΁&\0l8;e��%�d�>���(|��F#�,1�����a���\r�U��\Z��5>�ȟ���t<�B<i�~\\�4�W�Z�(Fe���P��x0D��#��\rWk\\���\0��3O���b�9�Fm����pOFS���X8\np\Zр�D����l��IvQoդ,��ؙ^�*��1�\n�G��󜃤w���I�m(�P�贱3�\\F��ZȠ��׆,���b9T��\"��6Ѐ@aɺ.b-]�ΠA�	�\\;@���ePS��������+̸Z\\��;3��	d�DW₴fvJ�ط��/\r�����+R��Ź���(����K6\\�e�o��K�@��z���$L���*��3��3ȁ�E��C�N��.]XY�񅆒\Z��j^��@p�T������ȴ-L�=����:T�L����@��y=����{)%��RMz�)�\Z�i�/34�!��L�*c���\Z��R�����N��ʞ!����){�����\Z�lYs/?��D���aCy�R�V�#��� H9�^Y��S%���]GY��\Z��k���G�Pε�����ww�O���ދ�{#�H��-�S��ǂF�OIKOQ	\Z�)��Q3��F�ˡ��y���o�}�,�����ٸA�Fݿ8���g$\"�f,XA���@�(\\�$߷��>5Q��HA��,�M�$�|�����g3�H9lVĂ@J2���V0�\"l����\0�P}�(\r^�i$�L�������D�V �K�k�uP����H*����EiMS�0�f�x���H^��`X�U3�h.K��PY�X2V�dK��o�K�\Z�\"_�Qv��G��}�W�B�>-���<�д=����x+��(\"�\\��L��Kˮ9��\r�y%�������>2lE�w�b@\rg(��Me�2��:�:N�w\\����AWޮB�7�0r��!������A<���x�(l\0/\r���.>Bv�;�z�ey������4u>�,�Z��\n�P#��$�[<�:��r���H9h	<<�|5�4�p���\rb�g�(w!{娸Yr�ش�{�am�^�N����9z�VH��@BVH9�XO��H%��`k�`�`;��_����\\6���c�W����g�HH˙y���������m�XDx�N����eH��R)��\r%xF��>�\r�6���B��ۮ�Z�TK$�\0hH�f�=|O7t�g�~�/�3~Q��A����J?,<�����cN�!��n/�\\��C�A� �3�2v�i�W�ݘ�\Z�)��:�0�I`D�^�ak��7��7wt�:����*㙾zG�\ng�a�`����z^{о?�z�������ͥ�G�Ԉ�m-:l��V��ņ�W��q�ӛ�86kͫ����C+x�b��8l�������j\"$�:�A��6����a��֟��O�d�6�X����M�kr\"½�^m�0���@��Ln�L\ro��MY��70�sB��z}؉�-����o�Z�u�#��\"��+ ��}�������\Zw7���]��)����W9�F��wqt! �N·\"(Bֽ�k��	�Nt��U�Bs����v[5�I�:��aF��44�P�Gqq����X�h���9�F�۫\"��F�Z�2#!I/5�V+!�`��ې \\����VY��U�Y��T[h��@��>�`���.��R��x9A�b4i���ߟ�ͥ�� ӆ��\\~+G/�sf�D�T��\0m�5o<�S���*~�:�{a��ȭ:(U��p\Z�E���S��B8��cu��[A\nDL���4��NEc�`UK8��Mu�au��t���%�_@`QYFbN��п,����j�B�XG�t��,1��y�w�4E���C��#��8�N�2�#�#�F��b��\n�y�:5� ��3a��G:`��2]�)>�p�����q�� ������ȣ3��R ߯nK�F\Z\nST齎{�繙u.Y�n�ΐ;#Ah�R���fU�v�ɽC�L��%�}y`p�p�h������EZ�����R�2V~���m��S�_x����_�͔��4��9�4]=�ܽ�H�ny�{Be�l��{���	z�ϣ�[^y��7Q����.����:&,\r�ˎa�|դ7]��m���Oݽ��;�)~��i�iQ��;ŋ���y�ù��pF;�ZW�b���ݨ?�.�M���6���HU���`3:�u~B�+]��O���KX@����n��G|������|�}B��}��rbj\0� \nX�b5��x�~7O=�{ح��ͳ�\r��B�5��8~�3���>1�n\\���BSl�w��>[�X冟�mmؿ�,b�5�4!������d���,ߞ}��,��������t��?]�$ZNg�|�����O���r����f�;n���z��wԿ�������n~ZG��w����7��8���̺� ����|��t�Q^�;�r�z\'�����^��7��|�	W���ᖞ)�p����g��^^\Z�յ��_���L#��h�v\r�!�S���@uk M�W�5�_u4�M�iI[5X_��\Zl�a5����4���u4[��C0ˮ��c��hfw�\"���+ӥ��P���u[��@\\ý�Gb���a14ȇ�V]��R�����k���;\r�]���̧���KVO������L�y}ؓtX��:���^�/�����[��m�oѰ�겁�\r�?\0�v0h�^�ѹ��!�t��v���kw|��[���{��?E\'�'),
(8,'13_40cbd1fbdf013f36',1826908889,'x��\\�r�8���O���^�]BK��Y[��$N��c+���l� ��$%+���w�����Q�I� )R�9�Mvf�DR���n��[v�C�����w��o5(�#�����f׶���ǯ��>?!����|!\rfG�ח�u��>�)q�TF,>2�xjv����;�$�4��,�$�1#�6K&�K&+2^5�Ix�\\�`FB&B��X����`���(�JƈY@\"�H��c=u2���ǷO$��R�k`�cN=oE�h�%��Q�$���T��;B�x�aA�I�B�ӗ�kO����$��cb�z]Ӯ�m\"�����\rL\'�\"��JV��9�HC��/`!ˀ�ĜS!}\Z�854��Db0BF�Z-^��q(�v`��_����;28�1�\\��Q��\"����:��մ�Ƥ9�u{��V0��]�Ik�>h-�yb&���OV��j4�e�1��=j�v�����1�=6K�2�/����#P�M��1c�D\Zi��ˎ���r�B�g�Pȸ�u��x~��T�gV5#�z��B?+*\"�W��Ź:��b懵T/N�:u��t�&uZ�i�jMZ�V�>�m�^oM��!tB}4-�g[-������\0�y�����a\">�A&�}��Ma�� ҡ�8�?��9��|q肾1�j1Z�L�����v0�J)�փ��2�yh����?�Č�%�1\ZS�jTMHE?�~6\Zę�d����E�\Z�pB���Fd����vuŃ�{�QH��(�e�zOS��>����HN��z�Zx%�����j������bQ�\Z�*��G\'��K&��6���AQ��љ����^���$�I����[�ȉ��~�/�j�;	�\Z�`�\Z�*��~�eݵ���q�,r�H@�<J6-�������z\0 �b�� �!���U���b�1��_�)D>����x�R�M�Ҷ��-�|)d\"F�37��eF�	,��H	��8P���Z�(�}Μs~�@NY��R����ă��Q��a�n�Q��߳�!#�u�\\x`y�%&s��$`K��U-��X�U�>�����lꃚnݰ\\\rY�ik�W�&��4E�1X��q6�X&5��Bv�uhbJ���T�=������Iy��pA�A���y�	E\ZmDPU�m�pRa�����dXc�L�L�-8߃�^|%[�R��&f`�MI�~\'�U�\0v�|��z�lv,Xp)�����4}�&��W\r�-��A�ޕH���ԍ�L�3ņ�R^0���!��sE%%�g��޹�`8���\r�\rJ�2L��\Z�co*Fc��đ�?)�5}#�ĝ¬�A5VE_e�;��V�j�����S�;LhP%��	E�:�E��A1U�~�[ճzy�-�H�/\nt�^�S,���tٔ&^�~�����MBTh�GW�s��}��[��}������0�\"`��}h^v���Ž�X��,ڰ��.n�ղ�\Zv|^�v��Ju���6���>�\"��t\"Ŵ�Bglf�Q1�2�Kc\Z`&����Z�Ty�H���`\n޳�sWt۬���-�rﺥ�X�R/��k�Y�ƃ)�%x�Y(�C�zy��a�>7�B�6���σZ��Uz���P��i�c�ol�RY)��~wS\r�;KQ���I�P�@-�	���I����QO�L�#�\Z�>ekZ@a��!y&s*\'�������e:�� [=Ɨ�CHøH@���;���kP\0!td�����\n(��T9F�h}�y���r�U��d���&�\Z~Z�}���q_�j�v��.��p<���{@�ZU�]*\Z7+��F��TΘ��ʣ�⎿��D�����7���?�u- �ME��ގ���y*�eڝ���՘v�����l\"\'�ü�px��-W���7s<�V^�U.%O8����n|@��:�͌��Yd�ι�cx,d�gkپ\n����D�$p�X{k�k�#��U����9X�X��h����B�Ǫ\ry@ ���w,�W��^���8����z�\'�%�f��,�.�ɣ$��,���A�%���c(��ĉ�3��\"^��,?c��L�s���I*��,�ᥢ�����8���Ín�̾_��I#�g��tU�<}m��M_\'	$1q�˦��#󦯕Ğ�A��7{_\'��gI�7�Sڎ���|�%|)��O�5\0��\0غ~����`&!MƸ��z�Pp��9�)L���I=2v,�!1Ra�B!�����+\0\"7꓁��4���?i�]���7n�~�-j��ԇ6�_�BR�uK�=��Y�)C�.E���^}���g�[�I��O���}~���R3�U�鷲�*;�^k]vZ�������#���ԛ;���\rnt2�E�f�Y��祅�T&<VY܂�XL\'�������X@�	��(�N|\n�y�V➈�a���1���{�M�Q~#h�>��A�C/��-����ѿp���U����\\�d6\'3ط|�ս���J8�LW͔�4������������V�c���>�0{\0�ڝ~#��IN��Ao\'Qq����~���f^h�Y3��zt��R��0i��}2I��_\0��>2~�N�.`��gD��	�@��������������k����2�@�+��䃩�Ƴ��T�~�W���諫�Pr��J�\r���[�����ۼ;u]<�-<��J��`\"1h�G��t~��<7Ĳ���q�:@&`��^Ϋ��Lf.���r�p$���{�\'�ûtB��\n)I����������߬�nsK���s/�9����X�P�K#7�������7!O��m-c���@�]ω~�BȢ���m�2���3џ��8�^3f�{�l�����/,<f�;��X��d�p��۝og�V�H\0/��E?��@`_@�C�y�����ҫ����é�%xK��h@\"��\0N\059���]o�<�z�F�#�|��y�.*]Cq�/F�/���\\f��3f�傹�v�Ӭ%��{_�x�S]������UȐd7�>�:=ȯu�[�8���/�<p�h����~��]}��B����$�y��1>��G7`tǚv脶�u�V�M]X~�v\\��z������Ƞ���D��:�h���P=��H�?S�ٍ���=���0��7<�����\r�\\����������6���|�3������?d�AZ߀g��-P�%0�c�n�wJ홢^�+���I˕�����K���j�6�H�|�q]/�SpY�\Z\n�\"l�Y]�}=�xV�����3>)���m��(b�#RW;����^g�]��.N�**X�K\\(lp�{�R@����X8���\\6n*��y��{���o��KA%�/vCeQ�k8(ӻ���t�X�\Z�����wM��⋽J7����N{�Nx3�)��;�>��B��n�P��I�a��oc�d`���u�N���+�)�oRQb����8h*�1ީ� ,чԒ@��/��Յۚ�GP�Kֿ`��vTS�n�j�t P\n!~�:S+�g<K�K���fe�\rg^{DT�ZT^�⥗BS�2�O���pd1�nN�c2[X�����}\\q��b���\ZY�\Z�U-j��\0��pG������P2�Ąz!O�m�f�x�4�b��4�M�}��:�!�-�������2�����@��o	�S���o��>�k�\Z]�,~O��n@16�MC�����\"����z)�=��\Z��x�B���8�^�+���P��kZ[2Gz��w������ZI�\Z�!�1gE�6�[�=�����Ng��0�������/5������	Pf�Lηg�a,�]��\r��>��w�T�ius�D�\Z���J\Z����m,�KzS�ޙ�vF�q}�����8��\"������1Gٳ2�@�{�����y���h-�>��giڇm\rl�p.�RC�R��\n��:׸��¨B2i��	��OR��4`:m}P|��\\�9�(\'��Pr!!��b��;N���Ji�΀4b?/�;���N4 m@>�P?�p�?ʰ=:��z�tK���\n1`���v���.޷{-����k�g�fՍ��W��zAem�\\�l;����85e��,ۂ�6[��l��C��~F��As6z�Y���n\nh�>AEi[��\\�\\~�#,�_:�q��OX}A����0�/d��/`������<��ˇ��)cy^�Zͺ���l��*���\Z��P�ͻp\Z�*^��Dh��}��o��\r���s�Ǐ�0������V�۪������\"f�]���g\\�?�G�J�S]�1wS�*���u�n���GX��R�e���\0�?W_<dUk������2�f4 �3ſ�-[)����Us��!������f$�y�7�5�9�[msvq�tZ�\\����K�y>{}�����b��8�7�;����?/_��aӓ٣U�I��h��т����k�pf�~v�S�9�o��7�:?�a�p�bO��G��W�wo����I/����u�/5�˅;.N߻+zZ�@du��ﯽWX٣{A�tY��8��}��{����ћL\0�\"=�BC��>��S��1���Ɋ���FC7�ce!�&�Hj�H\r$�J�&��%�b�)�:H�H]$�J���i�H��f�hzE����zD��㫴ڿ�5��vKC�nU�h	�,����+��l����.����CY�nQ�j�Vo���B�v^���5Piζo�;46j]��[�Z��g�*��g�9,�܄\\�2&t�v��EL���zǢ�z�q�I���=��n��m��Ӯ7�]f1{ڳ��֛lڞ:t�L�i�e]{Ҡ�6��z��t�^�c���NZͦ5�������7�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'36_55515db536f0d7fc','pages_1'),
(2,'36_55515db536f0d7fc','pages_5'),
(3,'36_55515db536f0d7fc','pages_11'),
(4,'36_55515db536f0d7fc','pages_12'),
(5,'36_55515db536f0d7fc','pages_13'),
(6,'36_55515db536f0d7fc','pages_14'),
(7,'36_55515db536f0d7fc','pages_15'),
(8,'36_55515db536f0d7fc','pages_35'),
(9,'36_55515db536f0d7fc','pages_36'),
(10,'36_55515db536f0d7fc','pages_17'),
(11,'36_55515db536f0d7fc','pages_18'),
(12,'36_55515db536f0d7fc','pages_19'),
(13,'36_55515db536f0d7fc','pages_20'),
(14,'36_55515db536f0d7fc','pages_21'),
(15,'36_55515db536f0d7fc','pages_16'),
(16,'36_55515db536f0d7fc','tt_content_47'),
(17,'36_55515db536f0d7fc','tx_news'),
(18,'36_55515db536f0d7fc','tx_news_domain_model_news_12'),
(19,'36_55515db536f0d7fc','tx_news_uid_12'),
(20,'36_55515db536f0d7fc','sys_category_1'),
(21,'36_55515db536f0d7fc','pages_9'),
(22,'36_55515db536f0d7fc','pageId_36'),
(23,'31_657a15e631ff6012','pages_1'),
(24,'31_657a15e631ff6012','pages_5'),
(25,'31_657a15e631ff6012','pages_11'),
(26,'31_657a15e631ff6012','pages_12'),
(27,'31_657a15e631ff6012','pages_13'),
(28,'31_657a15e631ff6012','pages_14'),
(29,'31_657a15e631ff6012','pages_15'),
(30,'31_657a15e631ff6012','pages_30'),
(31,'31_657a15e631ff6012','pages_31'),
(32,'31_657a15e631ff6012','pages_17'),
(33,'31_657a15e631ff6012','pages_18'),
(34,'31_657a15e631ff6012','pages_19'),
(35,'31_657a15e631ff6012','pages_20'),
(36,'31_657a15e631ff6012','pages_21'),
(37,'31_657a15e631ff6012','pages_16'),
(38,'31_657a15e631ff6012','tt_content_5'),
(39,'31_657a15e631ff6012','tx_news'),
(40,'31_657a15e631ff6012','tx_news_domain_model_news_1'),
(41,'31_657a15e631ff6012','tx_news_uid_1'),
(42,'31_657a15e631ff6012','sys_category_1'),
(43,'31_657a15e631ff6012','pageId_31'),
(44,'35_2d9c26877cc62e6c','pages_1'),
(45,'35_2d9c26877cc62e6c','pages_5'),
(46,'35_2d9c26877cc62e6c','pages_11'),
(47,'35_2d9c26877cc62e6c','pages_12'),
(48,'35_2d9c26877cc62e6c','pages_13'),
(49,'35_2d9c26877cc62e6c','pages_14'),
(50,'35_2d9c26877cc62e6c','pages_15'),
(51,'35_2d9c26877cc62e6c','pages_35'),
(52,'35_2d9c26877cc62e6c','pages_17'),
(53,'35_2d9c26877cc62e6c','pages_18'),
(54,'35_2d9c26877cc62e6c','pages_19'),
(55,'35_2d9c26877cc62e6c','pages_20'),
(56,'35_2d9c26877cc62e6c','pages_21'),
(57,'35_2d9c26877cc62e6c','pages_16'),
(58,'35_2d9c26877cc62e6c','tt_content_46'),
(59,'35_2d9c26877cc62e6c','tx_news'),
(60,'35_2d9c26877cc62e6c','tx_news_pid_32'),
(61,'35_2d9c26877cc62e6c','tx_news_domain_model_news_9'),
(62,'35_2d9c26877cc62e6c','tx_news_domain_model_news_10'),
(63,'35_2d9c26877cc62e6c','tx_news_domain_model_news_11'),
(64,'35_2d9c26877cc62e6c','tx_news_domain_model_news_12'),
(65,'35_2d9c26877cc62e6c','tx_news_domain_model_news_13'),
(66,'35_2d9c26877cc62e6c','pages_36'),
(67,'35_2d9c26877cc62e6c','pageId_35'),
(68,'6_3f7368fe3a6e05a9','pages_1'),
(69,'6_3f7368fe3a6e05a9','pages_5'),
(70,'6_3f7368fe3a6e05a9','pages_11'),
(71,'6_3f7368fe3a6e05a9','pages_12'),
(72,'6_3f7368fe3a6e05a9','pages_13'),
(73,'6_3f7368fe3a6e05a9','pages_14'),
(74,'6_3f7368fe3a6e05a9','pages_15'),
(75,'6_3f7368fe3a6e05a9','pages_6'),
(76,'6_3f7368fe3a6e05a9','pages_7'),
(77,'6_3f7368fe3a6e05a9','pages_8'),
(78,'6_3f7368fe3a6e05a9','pages_9'),
(79,'6_3f7368fe3a6e05a9','pages_10'),
(80,'6_3f7368fe3a6e05a9','pages_17'),
(81,'6_3f7368fe3a6e05a9','pages_18'),
(82,'6_3f7368fe3a6e05a9','pages_19'),
(83,'6_3f7368fe3a6e05a9','pages_20'),
(84,'6_3f7368fe3a6e05a9','pages_21'),
(85,'6_3f7368fe3a6e05a9','pages_16'),
(86,'6_3f7368fe3a6e05a9','tt_content_13'),
(87,'6_3f7368fe3a6e05a9','tt_content_14'),
(88,'6_3f7368fe3a6e05a9','tt_content_15'),
(89,'6_3f7368fe3a6e05a9','sys_file_12'),
(90,'6_3f7368fe3a6e05a9','sys_file_metadata_12'),
(91,'6_3f7368fe3a6e05a9','pageId_6'),
(92,'1_88ef5c556644a5cb','pages_1'),
(93,'1_88ef5c556644a5cb','pages_5'),
(94,'1_88ef5c556644a5cb','pages_11'),
(95,'1_88ef5c556644a5cb','pages_12'),
(96,'1_88ef5c556644a5cb','pages_13'),
(97,'1_88ef5c556644a5cb','pages_14'),
(98,'1_88ef5c556644a5cb','pages_15'),
(99,'1_88ef5c556644a5cb','pages_17'),
(100,'1_88ef5c556644a5cb','pages_18'),
(101,'1_88ef5c556644a5cb','pages_19'),
(102,'1_88ef5c556644a5cb','pages_20'),
(103,'1_88ef5c556644a5cb','pages_21'),
(104,'1_88ef5c556644a5cb','pages_16'),
(105,'1_88ef5c556644a5cb','tt_content_7'),
(106,'1_88ef5c556644a5cb','tt_content_6'),
(107,'1_88ef5c556644a5cb','tt_content_3'),
(108,'1_88ef5c556644a5cb','tt_content_45'),
(109,'1_88ef5c556644a5cb','sys_file_2'),
(110,'1_88ef5c556644a5cb','sys_file_metadata_2'),
(111,'1_88ef5c556644a5cb','sys_file_3'),
(112,'1_88ef5c556644a5cb','sys_file_metadata_3'),
(113,'1_88ef5c556644a5cb','pages_6'),
(114,'1_88ef5c556644a5cb','sys_file_4'),
(115,'1_88ef5c556644a5cb','sys_file_metadata_4'),
(116,'1_88ef5c556644a5cb','pages_7'),
(117,'1_88ef5c556644a5cb','pages_8'),
(118,'1_88ef5c556644a5cb','pages_9'),
(119,'1_88ef5c556644a5cb','tx_news'),
(120,'1_88ef5c556644a5cb','tx_news_pid_32'),
(121,'1_88ef5c556644a5cb','pages_30'),
(122,'1_88ef5c556644a5cb','tx_news_domain_model_news_1'),
(123,'1_88ef5c556644a5cb','tx_news_domain_model_news_2'),
(124,'1_88ef5c556644a5cb','tx_news_domain_model_news_3'),
(125,'1_88ef5c556644a5cb','pages_31'),
(126,'1_88ef5c556644a5cb','pages_35'),
(127,'1_88ef5c556644a5cb','tx_news_domain_model_news_9'),
(128,'1_88ef5c556644a5cb','tx_news_domain_model_news_10'),
(129,'1_88ef5c556644a5cb','tx_news_domain_model_news_11'),
(130,'1_88ef5c556644a5cb','pages_36'),
(131,'1_88ef5c556644a5cb','pageId_1'),
(132,'36_20b833d6b25c3c4b','pages_1'),
(133,'36_20b833d6b25c3c4b','pages_5'),
(134,'36_20b833d6b25c3c4b','pages_11'),
(135,'36_20b833d6b25c3c4b','pages_12'),
(136,'36_20b833d6b25c3c4b','pages_13'),
(137,'36_20b833d6b25c3c4b','pages_14'),
(138,'36_20b833d6b25c3c4b','pages_15'),
(139,'36_20b833d6b25c3c4b','pages_35'),
(140,'36_20b833d6b25c3c4b','pages_36'),
(141,'36_20b833d6b25c3c4b','pages_17'),
(142,'36_20b833d6b25c3c4b','pages_18'),
(143,'36_20b833d6b25c3c4b','pages_19'),
(144,'36_20b833d6b25c3c4b','pages_20'),
(145,'36_20b833d6b25c3c4b','pages_21'),
(146,'36_20b833d6b25c3c4b','pages_16'),
(147,'36_20b833d6b25c3c4b','tt_content_47'),
(148,'36_20b833d6b25c3c4b','tx_news'),
(149,'36_20b833d6b25c3c4b','tx_news_domain_model_news_9'),
(150,'36_20b833d6b25c3c4b','tx_news_uid_9'),
(151,'36_20b833d6b25c3c4b','sys_category_5'),
(152,'36_20b833d6b25c3c4b','pageId_36'),
(153,'36_bae7eee50673f8c3','pages_1'),
(154,'36_bae7eee50673f8c3','pages_5'),
(155,'36_bae7eee50673f8c3','pages_11'),
(156,'36_bae7eee50673f8c3','pages_12'),
(157,'36_bae7eee50673f8c3','pages_13'),
(158,'36_bae7eee50673f8c3','pages_14'),
(159,'36_bae7eee50673f8c3','pages_15'),
(160,'36_bae7eee50673f8c3','pages_35'),
(161,'36_bae7eee50673f8c3','pages_36'),
(162,'36_bae7eee50673f8c3','pages_17'),
(163,'36_bae7eee50673f8c3','pages_18'),
(164,'36_bae7eee50673f8c3','pages_19'),
(165,'36_bae7eee50673f8c3','pages_20'),
(166,'36_bae7eee50673f8c3','pages_21'),
(167,'36_bae7eee50673f8c3','pages_16'),
(168,'36_bae7eee50673f8c3','tt_content_47'),
(169,'36_bae7eee50673f8c3','tx_news'),
(170,'36_bae7eee50673f8c3','tx_news_domain_model_news_10'),
(171,'36_bae7eee50673f8c3','tx_news_uid_10'),
(172,'36_bae7eee50673f8c3','sys_category_8'),
(173,'36_bae7eee50673f8c3','pageId_36'),
(174,'13_40cbd1fbdf013f36','pages_1'),
(175,'13_40cbd1fbdf013f36','pages_5'),
(176,'13_40cbd1fbdf013f36','pages_11'),
(177,'13_40cbd1fbdf013f36','pages_12'),
(178,'13_40cbd1fbdf013f36','pages_13'),
(179,'13_40cbd1fbdf013f36','pages_14'),
(180,'13_40cbd1fbdf013f36','pages_15'),
(181,'13_40cbd1fbdf013f36','pages_17'),
(182,'13_40cbd1fbdf013f36','pages_18'),
(183,'13_40cbd1fbdf013f36','pages_19'),
(184,'13_40cbd1fbdf013f36','pages_20'),
(185,'13_40cbd1fbdf013f36','pages_21'),
(186,'13_40cbd1fbdf013f36','pages_16'),
(187,'13_40cbd1fbdf013f36','tt_content_29'),
(188,'13_40cbd1fbdf013f36','tt_content_30'),
(189,'13_40cbd1fbdf013f36','tt_content_31'),
(190,'13_40cbd1fbdf013f36','sys_file_19'),
(191,'13_40cbd1fbdf013f36','sys_file_metadata_19'),
(192,'13_40cbd1fbdf013f36','pages_7'),
(193,'13_40cbd1fbdf013f36','sys_file_15'),
(194,'13_40cbd1fbdf013f36','sys_file_metadata_15'),
(195,'13_40cbd1fbdf013f36','sys_file_18'),
(196,'13_40cbd1fbdf013f36','sys_file_metadata_18'),
(197,'13_40cbd1fbdf013f36','sys_file_20'),
(198,'13_40cbd1fbdf013f36','sys_file_metadata_20'),
(199,'13_40cbd1fbdf013f36','pageId_13');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'36__0_0_0_0',1797964720,'x��WMo�6��W,tRQ_����m.�z\"(��	K�JRq� ��C}���^v��n}�43\Z��{��,�^Eܑl�f�\Z^�N0�Ndar׿��k�I�mH�ZZ�q�\n�$<T1b��g�y�W��>�?�nc��i�AVe���d��x�\\�:�\n�K%;8^g(�|o�Rє6��(����*�\Z!��!g�T����+Ҕ)9��}pF���D�Ɯ�����C�d6��(mL��3��M���Ι�d��e%�uL~�\\���U�q��\Z� k\'{?E���p�1��Ǔ��ه\\��|4�6�o������~�p�@Ao2�*Sƅ�5n��Ôjفñ!@ݼ`Q����R�҅�B*�I�[%�k�@f�69���Z>M\0�6@�x~x���IW]����[�~����\rT^�rD��x�b�8Td�K����aT[��\\���,ؓ�ty�jg\ry�s�c��`���;�S���@��D��86��α�\'�|j�J3g���Q͵��+��خ�ۄ?;H���o$֜(�u�9Qג�;�ㇽTL��E�:9_k�k�5��$���nO�d������k����ƖFJJ�n�LF,�1$�̺SL*�n0-��suN�����:�Fc|7��i0n�������b�Ъc|���X���	��������U%�s����-܏�P����b��FPR��ǲ<;�~�K�Y��-v�^��0\0�y���;K�~x�48�(Q�u%����=G�ڄ���,��K�⺫���7K�2/d}*It�٫�~��&����]�2{�/!�S������WA��տ �h���E=\r� �.�i�P\Z��]O\'�~�b\Zʯ��8���N���;T����+00���.���Bu0������xkg\"����q��~z�~�K?xa��������fX��z�ϵݿj���v�Oi{��\'2�лӾ��ע�oi�)�^Dl]09JP�\"\Z�U�\"�&�4�$A!e�����I�J�5�(\rV�!��B\nOq��ʏ���	O�H�'),
(2,'5__0_0_0_0',1797964720,'x��VM��6��W,t�i�%K���a�M�t���A�#��$�$�������Lۛ9�h���7��̼7�,ȞDFnY�N�\'�����݊,��u�?����3ڰ��u\Z��*HW��P����3�C\r�(���C;i�aTe�h`����E��+�VJ�x��H���訥2���c�ֶ�<%�o@JtFH��~\\�Z�9*�l�AӚ�U�*�S�\r降�Ҏ)h��e��%?�ϰ�`/$фqQ�������6�GPT:w�3�ק�����:���Ѵנ���pƇ.:�=`ѐL��#�8�݇\\��r5�6m������ww���}�(\"N�`\"Ro���7.�l\rv��J6�;֎]jd�#Ⱥy���ౣR�ʥ�R*4���h5oԲM��rg���\r\nc`�`�bemW��:vh0-m-(+]��7e��\Z�~v}���k)E5i�v}�Q�\0�\'ٹT�f��vt���� O���� 7}�!��iO�>�%�)F2�8h�\0�>?w�3�T����Z�;4ϴ���!�N��Z#�%��VUl���u�������j`�غQf��F����^*�����\\:˵Q�0#�U��`@��`)j�V��P\r��BS+,%�qgm�\'�Kb�����$--�j9���Y�Cj��9��K�єn�����P� :?@[��Q���S�GmR�u��\r�E)I����N�Rֵ�/�$Ǳ+���B��o��++�V��`5=������/�h�G�荢1{a���H��v�=x48�\n��k��Wh�v\']ۀ�j9c�Z�6�?ۦ^�dr������+B��_��;y���y#G����$\"��0lh~���l��\Z_�7V�\r�qT�;��?���k�bMcv���o�������Dh�\Z�7S��~�\"?}֎V����*y*�}���z��y��!�=~��C 8.�Y�_��������m��G+?^��!.�*�_�<�0*�<Y��؏�0�!II��Ye���>�<��*\rI���u���(�e�~%A�|7N	�'),
(3,'11__0_0_0_0',1797964720,'x��UKo�8��(tRQ�R���-6��8=�D��H&,�Z��c��;�˴���nЛ�\r9��ˣ�I����,2y���\rb��m�_�[�5��m,�4��(KׂY��,�@@z/�pv+��f�<@��ZYÄ�5h����\0Zj�ax��<��Q�ʦtS9[�Z�߃�Z�V*u?�\0!m��n�J0s0�bMٱ�X}o�	�2\r�����4��#�۾. IGLȢ���OC�6�\n�*/f8�{s�ɀ��_��#!k�kC;�H�\'��g�����;��	�}�(q�C�i�eM?ޮ�����������*�F\"�)��Y઱�eZhU��X;v�V\Z<� ���ʺ�ǖ*-K�6G��P���Z���A��u:jF��=�0u\0Ӷ(���~��[��J2UW���ngV�ƜY�\\��n[j5\0�Z�R����	�T��:m<băZw�95^\Z���Y�>V����6���2]��0,����Czm3c?�n��粁����j�5vU�-P7�~�l`�9�{������2���꤈�J3�����r���X͸\0��u�5EHQ��ل���\"��HC���R֟�Y�T�mX8Xt�Td�P^��ul���RK\'���Qzn�\rʀV8^~���͠9*^u�\Zl@�(��<�bR�PU��s�����->�Ph���8b�H�*z&��ʋ��\n�/񆰬�G�x\Z�`��b�/=eGۅ;����h�Lߴ�_����F��TdQ|j�`�ʞ~vM}a������vjBH��_�S\'���7j�,?�O�p���B��+\\Ó�[kx�����Qqw��>�%��x{�~1;��û�n���v=�ƠF����7�!|ӎV����)y,���w5��<�^�q������\'\0I���I̿��+���	�l�*�ZdI�qQd\"\n�Xf�MB�bC�MŰ⼈x��,ķ��8I\n�F��$[�$M��$BX�I���S��n'),
(4,'12__0_0_0_0',1797964720,'x��U�n�6��+��8�7#c��H|i�!\'��&Z�r�a��S���nO�&H��I��XU�X��Q��̊�E�Q�\r�z�����o?��_ZzF��#�I�aOQv�d�GY�����VPʺ(J�*cD�����H^z��Z���2(=ߛ�TFt�5���rq�)���4Q�7BB�����4����F4jpW�fh�~� F��b����Y��l�:؀A2cTp���,�)o=1���_��>�Ʉ��߀�#Bטj5\Z4S��т�Ut�=`�(��;�G<Yp����54P�?6跻����w��Z��~87Ro�ed0n��Tq%[�s�*�r\0���yF���s����6�RaX�{�+�9x����d��;s��R��a��	 �}�$��Z��Շ�=�\\Y\nt���� ���������\rd�E=���}�#��N��m6�c5ܑiG�A��@��C�f�z�v\n��\'����O0��;Bz��\r�TcU3�`�h#�������|��S�e��_:#����͊l���&���� ti�ٺ^��V�$�c��TT��\r�s9��Fab&\0�ă�nN�\"P��`�@-���B#+-%�q�m(�kR��\'M�w��z=��0�Ak����>L�IԁP���v�=i��4eg�L�)	��=�b��˦�����q��J���\r��v�7�L8pX�����������5��셁�_z*�܅;��������K����c�&g�Z��ʜ�,�NY��И�����o�ۓm���mA�ٿ�m���wm]~9�0����Я�pA/��t&i�?XР�ϲ]>ׅ��b����֏�������Dh\r\Z�7s��~�\n~�*,Tbm�<�?~_�λ�my��/�����o���\'\0�l4B���o�w��_�\"�)Ip��4�q\Z$U�������<䁟\0�D��xe$Jh��<�HE�(O9��*�8�p\'�TU�iV�r����'),
(5,'13__0_0_0_0',1797964720,'x��UKo�6��W:�)MII�A��[��%�COM�d���:F��ޡ^��l��h��Iߐ�����<̟eNoy�d��ɣ<�e�\"�����<����$[EQf�h��.,IP����neQ@;Y�Wm�l`��\Z����yP���1��i�`<h������$tAi�Z�?�ZvV*�u?��B�Z���b:�`X�۪������AjJZ�q\r�����X�d�����&��e979���m�4S^L2�{s�ɈN�_��#\"m��z���f|h�g ��Ftr�?��}بⰄF��췻��������a��:%�Ĥ�\"g��>B���J�\Z�k�.5�G��Q��>1�t��1�e���(�\ZޱNK��C0��ܬ&�jg���-\nc`���yW�,r&M�`Ԕ��*����uG~�`]�XE)��}��mǬ@�T�,��\ns�)3��A�6��/ţz�7�l�ƴ�[�|�#�3�ώ�7��8s]��0,����C�sc?wn��e�ϭ���k�[`nn�\"�b��9�V1\\���e�k�I;8�.��^�ޖ����;X%�-:�k\ng��J\\�	�o���g��9Ii��?e�0�ZڰvpџsRӴe������\r;��͜/��չ��(V����s`F�1ي�/��ԫQx��\'_L�����~I1=���	��?��#�U��fg��˪��� �\Zo�fxƎ�Qv/-v��Sv�]��/^8\r�6�u��û��Q��^�Ð�ZNEF�V\r���i���W��ɚ%�h�Ɣf!I��5;����cW�����!�3Xh~y��y6}m1\'�j��3*�j��e�.�X���������~��q=�ƠF���᫟��_��;��vJ����q�]��6?O��[\\��[-��	@��al��m���KI��aR$�b��EMҍ�$��)�Q��9�MFS�N�T�V$#눊8�)�$��;OH\"�3J�2\"1_�a��\0J�\0��S'),
(6,'14__0_0_0_0',1797964720,'x��UMo�6��W:�.)�>��$h\n�F;������J�JRY/�����]�@\r#7��p���\r�a�,|K�4/�M� yp��v���_�K��\ZK�~�<��M�o&ӜZqaI���FX1FA��Vr.�ȋ\0�jke+����HV� �V�7.L�Fi+�zLf�o�@��a����\nr�O1��Ql���ps0��]=�Z����I\Z�:�S-:{5h�^��#.!�g�˪Z�M��T���M��-�ޜ�dB�����mB��F�c�p��#���\Z�9������P*~XS���������Ow��~��J\"�P8w�l�gl�~��,�L*�Z�k�Z5���0��>���\'J��o�k����=��=���M<����=�ba\0�mAcwB`�ϡl$���[�dO\'\r��e��݀�_����?���*�d=+�q���B@�T�7�AOk��0�:����)I�	8��a({��H����0��&�͟#3��n�����0�����CF�Sc?�nֹ��ϝ��z��UŶ����@����t:E���m�(�TH�N�؉�^infz�{g.ǝ��j��@�t�Я)\\@�q�&E�=c@\Z�䥕��ĭ\"%j�!q0�{��#����@uI�ZK����a|n$Ȁ40|�mǙ0���X3pqF��U�(�����\"�j\Z�_����m����7����$�\r9V�Ejw����l�\'��\rb�{i���H��v�?x4<���7%���&g����o9Y�Z�0CcO�8R_ٹ\'+�����8Q��W���oc�����A��e������b�ڒN�8ɿ�%\r�����s��n%_�_�p����w���8N�1�Qs33|��\n��U;X����S�\\��}\r;�z\Z��y�������ׂ�\0h�5�,b������i#��\n�U�<H$�0���8�Q�DU.0�ܹE�&�\"�6a\\\n����0De\Z�`MCpˈn�<F�?���'),
(7,'15__0_0_0_0',1797964720,'x��U�n�6��+�\rG��4����M�֋��Ȋ��+\r1���T����K���Hw\rZ#;��>��y���<��y��/:�r�ܻC,�~�����3�Ц�4��$��td�����D�0[!���\ZV���Vp�d��V�1���k�rY�^	�R�G�:r��ƃZ*#�j:J,��=%�A3%:#$�zm\0��l7�\r0}Ф�m��\nȔ����:�[�Q�����[�6C!�� �0.�r>��-�xe;L]do���^��&��H\'��4��\\^��#b3A5��\ZԱ�A4�Cq�w/X4\n&���#�8��C!�aq�����~�yz�|��맏���-v����\r���ړRɆt�ܱJ��p�\0�`��h:x�T�r�i-4�#�Ț�7Jܿ�\')q�3��\n`�����Pf�\nL�}十�gG�6�_�jҀ��#F`Gd�6�a�*�����7NȤ	\'vx�:�\'�����B��Y�l�G\'͝ ���PSU�q0̮��A�Sm�tvʹc����ֈz�5�Y�-;�n�B��M�f ���ֵ2ˁ4�$��Rq=�7�/���B5��q̒�\r�9�3HP6����7�Rг\nM����Ɲ�E�D.eH,������%����X�w��v��F��T�)�����7H�� 5N���0z\"-�{gU� ��F�yϮ�$)e]����8Ml�o\'�\n�rݯl�[�\nFkr�&�,���\n�ך��h���x\Zb��`;.-eG�{��hx�Uܥ��q��(�IďS�\\�Tyat�*�}mN�ڢ^Y�\'ؿ���={��WA��~��7�,�����������n���vN�8����Y6�缚��/v2F��~z����o���&BkԨ��*��û�����b%�7V�S���\r.q�������[?�����L[��m���k��e��d��X����*e��d]F���a�x��A�G���e���O�8b�YP��A�ъq�����a�'),
(8,'17__0_0_0_0',1797964720,'x��UKo�6��W:gS=�G�C�t��8{艠ɑLXU��c���e��(�ݶ��I�7��-��E�--Ҽx�ETx���-b����M���*<�\rm��ϓ(��<�85p���ǡ���\nΡ����Ы2F40cxZ�\"Y�@*%{�^A���h��2���a�Ǚ%��Sr�4S�3B�]���Ԓ�f����Դ�zZ��8����tTAk.`-{Ŗ\0��P{a�Le9��-�1q=�\"ҹӟ��>�dD\'�o���m�\ZMz\r�ؿ ���,\Z�{���\'3x�a#�a�\Z���k������ǻ���?\\H����3��L��LJ%�s�*5�G��l�y&���#R��m�m�0�ЎtJ k�(f�&�D���:�+�a������I0�W�JkK��t�W�\r&�#,F�FH<�1�RT�lշ1\n\0�$;���Ya��]`�5=����3V�?�u����)OK����#a��%G[�~snh���\n��a��hw2h�j�SΝ�la��5�^b�lVl�N�����ҧc�J��*�u��\"!���3���^*������t��FQfF\0���A�nN�Ԋ�\n���KA�* 4��RR\Zw�y��aeaޟ������Z�c�7����d����&M�U��Y4L�mI�� 5N��0z� -�{g�� �T�D{Ϯ�$)e]�����t�-��P*�ý>�}ne+�ə��.��G~���fxێ֨\r�q�)?r�܃N�#Ǩ�.�\Z����k��)s��0:e�6��ڢ��|Ov���voy�_}��r�//���r>p؇�,�_��m=S���i������F�}�����g\\����Z?����[�5jT�L���*��<�X���U���}�+�z��y�����}����>�b�><��Y�߷�7��_�UZ�>˙�R\'I��p�g��,�_E�U>�G�L��(cy\ZmX�x��d�)�yYf���	~l2^F<��X-'),
(9,'18__0_0_0_0',1797964720,'x��UMo�6��W{vQ����$h\n���9�DP�HK�$�$�����P_��u\nh�6�Mz3���{�ay�?˜ܲ<��g�G���bu���v���_�[�+k,k�H�$��0�GׂY����J@\r�(�軕B@;Y�¨�Z����1h��l�U	�Ҫ��&\'�*X��Fi+��9�Q���8_i��k�Y�0������9,�똃�5k��U@��&�I�Ҏih�lT��rA̰\Z��d,�����\Z��\'�Ty9�ܛӛ����:�!��1�7����hƇ6z��?�ЈL�=�#��8`�C��aI�����w�o?�����݅$��E�xo}�j-v��Z5�;֎]jT�#H�}���੣J�ʧ�Q*-4����h���(��&�D#��:�;�׶(����8cd!k<|54�$`rԖ��j���7�w���+}|��JYMzpl;j5\0r�:�v�\'+�-O#XK��U�����/:��x�j�\'�T2�،0N�R��/�݀3]��0,����C�3c?vn�7�-�?�V��]#W�u��,V�ӑh5�4��Qf��F	�I��a��0S{�{m.���j��`���Я)�A��q,&�F��;�4ԉL+e��[�J�҆��E�IM6-�e��V��Z:s���ɹ��(Z���&Ì����u/��ԫQ�/������k�_��9���	��?���#�U�䬦g��ê�H� �\Zo�fx؎�(��;);�.��/��GgZ������`��W0N-�\"s��o�`�ڞ&~qM}e�,��o-ޘ�,ү�xg����n�,?�O�p����opUϦϭ�4L���`U��>�f���2�������a�߾������[[��f���OW���ъ��_;%O��׸��A���}���?��ɗZ���$[C�,������/Q�����(�(�<`Q���m��d���6E�[�HAI��\"-@�8+\nBb��0+�:ʲu��$�,+K���OYK\0v'),
(10,'19__0_0_0_0',1797964720,'x��VM��6��W,t�lIɒ,-rX$AR�]���A��LXU�Z����ޡ�Lۛ�	r���3��pL�0�9��y���&��<�,�>����<��Ҧ�4��hf���4�V\\X�<�VQ�軕��v�<���Zو�c��>�΃R�J��79���Fi+��9�q�|�*�ڿ�i�Y���1���֊���1Cj�V=���lpI�QK:�Ek/`�z͖1�a;4�]��	�,gw��g0n�G����D3�7������:�!�&tcHo�>��������{�G<�qw\n���`���!��m�}�������$���Xo}�j-t��Z5�;�]jT�@�}\"���SG���O��TZ�ЎtZ���Q��&�D���:1w\0Ҷ ����ߵ|��pթZ��4���`*��n�xs�6PE)��}��mG�R�O2+�MO�yM�1�	��Ԧ/:`�x�i�#Y�b�Gfl��u�/��8S]	�aPe-۝�j��~��|so[���ZY/�F�*��ͭ_Z�2��*b�l�G��A\Z��`\'{���ڋ��r9�0VSfG\0�����~M�P��`1�\r����\')����l&QK����\Z�[��j9�.(��d�|��s#iA��������#�eu��Y��P�JD�?O��)U]�����8Hl�(��ӿ~�mU+�əpప.�vG\0~�7�e3<cGo��K����m���Aã�Q�}S2�+;1jrҫ�S˩���Ԫ��k{z�k�+{�d͢�fWg!J��5�-��X~>�0���o�/��b�M_Z�)�mʾ�������粍a_�_�z����ow��߸�Hc@��f����+���`�N쯝����װ��A������я��/x�_-��	\0��!d�m�n���LP�fi�\",X�)*/�UF�e�B�CY�1Ϣ�ga��Y�P\Z�%qZF+�]�\")�4D,N���1�Y�\n��'),
(11,'20__0_0_0_0',1797964720,'x��UKo�6��W:;�HiW�#	��/v9\\r�%VU��za��w�\\�S�@�An�7��7�pxN�g��[�\'Y�l�(:%�[���v�m�_��<p���$[EQL�x�#��K�*p0D	G߭����\0�\Z�T\r3�Ǡ�>��A�4���6\'y���Ʃ�.��uo�����{�¨�)���� �����a	^�,�xSv�6�?�0IE��@�.`�;#��p��@D���&L����m���X����a����ޞ�dD������60�e�s��f|��3�������?��}�hyXR����������ǻ��>���v�n�g�s~�n��\n�k�kG�jݡ����=1U���2mT鷭o�rP�F���Q���j��;whaf\0��PCw(�}\'X{���j\nmj>���,[u���4����ߜ9b��XS��I=�ۖ9��ҭ�r�]-�`=}`?�S��	Y����۴�s����/l�b���0N�Rk��9w쇛���a��jv2h�[����]z����S�T��5�[`��E�����t\Z�,p#�~�Y,���vp�k#�D/�_�ˁ��n�J�9��Dg��f�\nʢ���1�,�f�v��-2ez�a�ò;�IE҆��\\�#�.v�Z6�|�s#kP����o;L�5�T#�N������/���f��*�_���Jl���o~��ol�%x�΄��uy��?��k}CX�ãv�F1��r��e��h���J�6���M������I�}@\Z�ZNEF�S��U�4�KO���%\'K7�SK7&$�a�/�Y��卻�.?�O����/����M_[�	]�����F�}���9/e�������!׏�>�z���Mω�5jo&��~�\"?|ՎVdb�+y*��Ɲw=��<��>�����O��?<�dg���}����E��5)⬈%4�X�&KD��Ȁ\0�_��%�L&1Г�8ʲ8�2AS R�Iy��2٬��4[%��7��'),
(12,'21__0_0_0_0',1797964720,'x��UK��6��W:/6�dْ=,��)��śCNE�d��T��b�{�z��7\n��d�r^�7�G�����7Y�l�8z)�;�G�n���O���k,k��dI��l5Z��e�j�0x	ǳ;)�3��z���f�A+|$̓h�U��MN� ƃFi+����M䌫<���ײ�Ra���ik���[�阣�5k��U@���I�Ҏih�lT��� 	g��pI2aB��|��x2���Ty1�<��LFtr�\n\\��i���\'�H<�C=C�_\ZI&�����8`�c��q	����-��~������O�_IY0;���g���b�i�UC�S�إF�h�0���\'*��:���|���B�:�i�V{F1���$\Z������Lۢ0`�>��@��R2u_c�o�ɂ��[̺��Ķ�ﮣV #��I��[���������O.ȣ��E��\Z�-�B�<\'��L-ո���A7�LW`=��e���A���O��g�_�O����k��;�nN�\"���*s.�VQL��e�m��~ǃ��L�%�-�iV��#�U�ޢC��h)��U�����v�i���V��S����\rk������-�e�\\�V��Z:s����K#mQ���toF�Q��p�`�U�(</������kuXRLO��w� B��7?��۪VrV���eU]�vW~�7�e3<[��({�;�);ٮ����F\'gZ������a��W�0\n�-�\"��s����<��k��^=_��Z�+B�(���ku��y�&����!70Xh~��l��\"�D�:�,bT�G���-��x{�~1;�������p�z\"�A��۩�o~|C~���؉ÍS�T���w��8h����/������<���� ��P:�������IJ�Ӣ��\Z��z�^&�$����8M�U!\n���8I֫��1�M�&\"+�7\0x&�*NSFi��,K�DQ����'),
(13,'16__0_0_0_0',1797964720,'x��WM��6��W:/6���E�$h\n�{�7��JɄ%Q%�x����%Q��Mom��7�\r9_�\r�EX<�\"��E�Ϫ��șw�Xr7}�\'~%�����0io�����RIF5��M�Z��cЂ�ɋ?��qƠ�@^x�Uj�;�^���HVx5�F�ë\"(<ߛ*!5�%th�Q�Iqx��|�\\`���0�[Q���\0�QGEZ�7#m�,�O6�~O*��W������zj�	��x]��s�g�D���+<�ś;�7_@�$�[��S��%�+ps�C�d�Ȩ@�\r6���|��A7���9�c��>����h�~ޒ��>�?�����z��C�Q��T���vRKё�T;v�#\Z,@�\'»�\"$o\\\r�\\CG2H�V}�fu���\"&��8��\0��Q)]x};�(-Վ�r�Z\rX��s�y��o����\0ȇ\\J+d��L@��,�Zz�m�\'�{۱�S崡�_Ț��#�a���߱�<h�����aq-��2��*�i0�͜i���׼]sݘ��3�n�j��[��`�G�V�̝�=B2��70O����RiI+=X%5:tk\n-HP��Մ�w�DЋpE���ڝ�U�D�mH��KN� �IU7�uluI�=RK,���!�Z�EK*���n�ŗ7H�� -Μ[�4\nj\"�}Վ.��@����<�\n�m+k��i��>�PK��\r�{���BMxY4W���_#a�M/��4*D�F:�=�\'ە;����d��d�)���=�B]D����ZΕnέ�����/����޳�뿺z킽\\�Q䡟��׊�[޻qh����!73X?�n�����4���a7��>�����{��j\'cv���w~������+�\ZU�K����&��v�b\'7F�K���\\�7����?���w����o~���֟��e�[1����m��?�4IiW��Y�Q�Q�Y�%TP�q�R��,J��Ue@R�9dC�Fi��~qEQ\\�>K���1��D��'),
(14,'9__0_0_0_0',1797964720,'x��WK��6��W:����aY�E�$h\n${�7��JɄ%Q%�x�����2mo�}���Ő�!�����L� }�C�(I�:g�\rO�����B|[��V�֭�(	�`�\'���KF5�Y��aP��ދ;��pƠ��$uЫԚ�0a�\r\Zf#q�@J):<^�^�ΰP	�yS�G��9�[�����r�[��u7�\0�u%�����p�^��6eGK c��\r�<�!-���3X�N�s��;��/�9�G�񢘖�W:C�:�\n��Lww�8��?��Ƕ������g�`��2Z��`���[�x8�g�3����hZ��&�n���>������L�U��c\'�{�w��B.\Z�U&�5i�c�jѡ��<l�~ �n�%B��n�i)�PӖ���U��u8����޷0U\0��H��;&��TnA/\n\0e 䓪��<��[��7�i�Ƙ�ۺ_�fZ�)ޯ1���#L�7-�\0�%Z��9���0��#90����q��K��ź�Zl��j�ЯdNa�0��=F��N�ɦ�ma�sś���ħJiͨ3�e�/���k`��7@��I�����x\ZAP�ol/SH-����~\'$Scy=s͜O;͔�4��Y�N�C;\'	�d0��5^��\\�.)��n�(sVf�iO*/nH^��v,uF�-��L=���ᩑ4HR!�h��P�o�cpR`�Y�\\���&� ��*��C�3�o�B����K��F4<�9!n���f���\ra^�7�a5�A��ʟ{J�3w��3����S�lӪ�b�0pr�q�ǖc����U��*}|�t�7<R\\�E(��.�{ܿ\'�௃�.~\\L�z��&�3ݽh�Ek�	�5b��!k�`F�\'(������h��d�M��4��K�����w��\\�\'���9�.?�N\"���;Æ�W(��[2�7V�d�Q����(�g2��a���}�|��ݵ�	W\n9���\n/~Zx?|ӎV����0yL��Bm�\Zm��.��C���>���Od���j�\'Y�y��Q/�p�t�0�!Z�[�9�2��aL�8�(c��4Ȃ���&n��,\\��*Z,�s\Z�8m\0vsdv'),
(15,'31__0_0_0_0',1797964720,'x��WMo�6��W:��]I+=I�h}�s艠�Y-����T����C}-�#�4m��7�\r5Ùy��|�?�<�ay��O�A\'Ep#�����q��5�խCH�ŋ�*��µ`f�\"��-i��B�f���B@3Y�Wm��a��7h����`\r�Ԫ��&\'y�F���M�6F}L���v��p-[+��\\���R|;y%x\Z�7�bMٱ�~o�	�2\r�=���4��G�	�}\\@������}�4�\Z`�o�<���v�4U�!�	ܙ�\r��\\���6�3�/��d1�}Y=C��0������x�c�%�sh4��qO��x������ȃm1�!���\Z�e�k�j�r�*ժC����}��nᱥJ���뱴P���Z����u<�H��ݷ0U\0�m�)0Zo�a|X!�LՕ�X��\r��[v�c6�x��,G�*oZj5\0�E�~k9v���q�\"R��:.<b5ă��{k�r4�3�O;�X\r0Nڜ��sW�ntC�t	��0�J6[�Iό�Ժ)�Pb��\Z+�����\0u��\'�V���Y�9���J����;���K�\rs>�0V3n\0�d�E�~N�R��`6a�k�*�I���HZ)���LG��2$�iO*�j(_���X��-��N=\n�l\r����t3m��±�O�O�8HeëN�X-wׂ���[<��Rt��J��Ӯ��7xe�Zß~��q�\Z�YEO8�?��,���K-DX��=v؍��;i�	瞲��̝����`�Lߔ��z��u���r̷hql�`��~vT������;��K�ENt~��{�q~$��(�҅�s�jz���(����5�u�����UL�71\r/���+��#v����-]�Ea��k� �q䞰\'Å}�����N����K�Fq�-<s�qU}��E�=S^<���݇�o��v5�� G��X�7?�!?}юV����1yL���B��\Zm���wm_���k;�����Ƈ�D�(�~�_������JD\0�XlY��8���ˢ$�a��i�b�p��h�C��b�kB �(�V�	n$�4͒,Y�8*��/�^N�'),
(16,'35__0_0_0_0',1797964720,'x��UKo�6��W:���JFFb4Z_�9�DP$�%VU��za��w��rW�\\�GZ�&͐���o8$�W��;��Y���0�z��;�����ۍ����3ڐ�i�i\'�衊�W�4����C<���v6d�Q�1��\r�񖹖M�WJ��^�(�|o<��2�����$��(��<|�*�!!���3ajI�sX���5i��TO�>HR#��Q�5+����K�ȟ�f\0�&D�dc�,��:���ظ	�������ƃ>�d�N�����9\0ڸj4�5W\'�P8���^�DSx����v���d�%5���m�/�ۧ��z�����w������q�d��S�R#{p86��,���tX*Q��YJ��\r�p�x�����Ɠh�ܛc�g�l�؁��P��?�$]��t�=_���j.E5qm��u�(΁ٹ�R`��J�v��D59�s�����/:�T;0��/UN16�&j�������Uq�ؠ�Z�{�2h�h��̜�k��skD��\Zڮ�c;�n�� �>�{+��Dѝen$s�}Ϗ����E�%Y4)�Q���\0]��@@��`6bЄ�`q�\r������Ҹ3����ĚY�I�6-�e�\\�B�@-�9_��� \\���j��QsX����бo(�W�!�(�/��$.e]��R��41t/!/���YN[�\nJj|��,�Uj{��(�h���t\Zt`�\0��H�ɷ\n�^\\\rN>Js]�����(�I�6`��{����^�u_���o��BEg�Կ�O�(Ȣ+�4B(��ߧ�t��e\Z˯��<�|a����?���뿾�Aq�d3���x�ڼP`�������o-&BkШ��~��;�ß��Hn������Xw7���ӿ�������������\0$��,�\\�.�߷����ߢ2�B�ifE����IF�\r\"))J��>h��0����M�ь�2������qșp���`$J�43��Q�\"�8@��'),
(17,'6__0_0_0_0',1797964720,'x��WK��6��W:��وz�Ң�E4�{�7����d��T��b�{�z��7A�E����f8��7�l��ٓȂ�-��I�W�̻Yr�k�o1|K2�hC��h��ai4X�b��3�2����}���x3i�ATe�����1�0Ye^�q�d��e��\r�Z*#��:��\ZE����=�T��	W�!8��t;EE���k\\���H��X|o�;*�7�%�7�ֲSt��l�>�Q<bL��3��M��+,�;�	���Lt�\\�\0��U�q��\Z� ���w�1����h���x�9ܽ�%��W�i��\Z�ݮ�}����������A�\r��vƝ���.�B�\Z��ڡK����`�n��[��b�D�͎T^��J��콁��u<r�ɭٷ|�\0�m��tl7�H�\nZ�-t�UWڏd�VA�M�ߴd_C��-�������a\r��i`�i�Q�èd�N�±�ΎԀ*����� � �]�¸�ӡ�|�sc��\0î�;����Ѯ5Q%7%W��:HO{�ͧ��9sB6|��1��s\rmUtñ�_�6�RoB#��Dэe�	��Q[��I���^dߘ�]\'�6�P3\0P%�tk\n&]l�	Q�cAN: 4��RR\Zw�f�b9�!�0�NgR�U�iQ�ǡ�9�[-�f>��7@\\�l����hh�1~�`�������K&�YUr7��:l��K���p���`�J*|B8,˳���_����߳�7��섁ΟGJ��p������F�b�)��-89���c�1ɂ�ت��*s|�}r��6>�[t�ۋ��?��m�ŏ�IROd�fp&���h�ߡ�V@쐍�x\r̉���S����M��4�A�ё&�I�#���_��<�����1L��taW�X60?�B�L_��%��J��}���q�m��3�����>�z������\Z8���/~Z��j+tbwe�<���m�\Zmz�.?^���b>��������� �ӈ��(�\"�&y�1�Wa��0A�*d��$EΗ!�ubI��*/\"Z�9IP��qJSx�s?_�`��$_\0��b�'),
(18,'7__0_0_0_0',1797964720,'x��WMo�6��W>��dEɒ,=��n�mu��A�#��$�$����P�d��.Z�-��7�\r9��7|K��Q��5K�$}��:��_�4�����-ķ(�mX�Z��I?Y�\\qf���s�x�ڵ��H�9zUƈ\ZF�A�]d������S�ν��PKeDS�Q���\\��й���\\\0�����`4z�iŚ�c%�]�\rϨ��Ж)h�	�e��)>⍰��`$��(��:ŕ�!o|E�s�7�}ɀ�?�{�Ǯ��5�4���x0�}��n�h@v��{<q�������h4��\\��7����nn�����Ɩ�q����`�i�dM�}�X�Zvhp0�]7T�-<�T*Q�m�-j��V	���|�w�8��ٶ0V\0�6H��;>�o�|�`�uZ4��̦+��\"�tՕ�#���\Z4\\�l[c����^�[/�[1��Y�rGېuK����eA��.1x�e0��m�a������Z��v*װ�tJl�c9�8��l�.;^hǝ���a��h���͗��?w\\6���QM�6�|\r�ε��7X�\'��TS���2��� �{�n��zW^b��;�e�(���,YgС��?�id3�LȔ\Z/vT��園Ҹc81�ʩ��ywܓ�,��K���[KǞO����H����n����sT4y�q8*��,E$�����I�BV��L!.������B�_����F6\"g=\"n����v���\raQ���~5��l��ʟzJ��w����ޖ3�]S�_<�0pr�W���-�$�C��U���\'{��px ��UȰFg~�2-=��_����A\\g?�Fy=�`����������Z�M6��v0c�3�o����5�Ui���&�M���&/I|/��5y��KV���x<�؇���ޠ�����x��X�+�qd�\'Y���n�l��4F���{�����n���f����jW��/3��w�h�Jl.,�w�����à����C�-~���C�ߋ�H���T���$!�_��H�����<���(x��|.�l���E>��0�Y\0�ϲ��E�a��Q��G�2���%Ib�`�/�o��l�'),
(19,'8__0_0_0_0',1797964720,'x��WMo�6��W>�)�%˖��.��AQg=�8�	K�JR�A�{��2me[�-���EzC��\r�̒ y�͒e�<h|�5�ϮE]�ou���\"�mXY[�,�0�~<�,����ĲLf\n0�z��9T\'3���%n���H��2���\r��̼Y�PKeD�ۅ˅��̓����S%j#$u۹\0.L!����`4z�i���a9�>�ֆgīh�Tfk٨t��xl�:�I�c\\dٰ\\\'�r��m����t��p��#����p~�}�\Z�R�F����V�1x���w�?����_K��F����|��{������&��.�\r�,m�ۅTV�L3%KZr�*��A��캹���ᾦR��m�m�0P���J���g������[��a�\0�m�mwl�~gj����\0�ŐP�h��\r��̫��l_b��]�mx;l�$�V�R&�\n����\Z�풵����c��ޞ�F���Jp�E�wrլkl�v�T��tL��u0Λ;G�Y�.���T��0�BT[i�ϴ�R�Y��\nv_*#�1��f�n��v��F���4T�j`*ݸ^��R%���N*���{�L睭�Q,5�Y�ƠC7\'\0)R�f0��%^�BS�/%�qGnd)�c��iO\nU4��q;�z��-��=��ᩑVHZ �hۡ�稨Ң�pR`\r�I�H\\���%���,\n�C�S�n�L�_��s��JV\"e=!n���h�����(�;��\Z�`v�`姞�m���8q�l)S�5-�Kf\'{�Z��wl9&�[�0�?�kg*���!�~�8K�3��E��Ý��%���ԋ7�����`\"�g�=k����V@l���t�\\3�2�C����gM~Q��=���H����sBb�[��<��9+r�]~8�D���w�\r͏�P�ӷd|��X��qd�\'Y��n�lOd\Z��Z߽���ͯ�W�&Bk䨾�+|����v�b%v���}���%j�e7h��t�x��?��b>������#�$[,B���ck�Kx<�l��q�qJ�{�:�tI�%	��D�-�Q\Zfd��=���G?���2>���e�'),
(20,'10__0_0_0_0',1797964720,'x��WM��6��W:�����d[Z��H��@��z��\'��(��$�$����ޡ�L[���\"��O�r�3�O�I�<���d\'�\Z�VdލH��=6�cO��3�Ъ��8\n��aoa*���,���x�\r���ڭ�2^�@�x�U#*>b��י��/�P���:A��{�B-�uх�k������=�L��	��z<��l7�Ep}Ф�u�҂�!��AJ�פ���fk�*6�#l�B؀(\Z�L���\\\'���7���tb�#�ק\'����3pq�1���J�Vs5�����wet����\Z�;�x4�bR���`���!�n7��>������������ָ]`�6Pe�+Y��;T��-A��U�\Z\"�(ٖܶ\n�+ڐF	���ד�\r����\Z>V\0�m�]w�w* ���N��6���e[t� �[��-�n衂���n۵̯�m��~��ha�m�Q�C�d�v�A�84�U ZI�b�\n���M�6�~�T��_Ȕ��c��0|�P�6=_h眪���KQ������~測��smD9�5�Y�-\'v��$��@}:�$�SŶ���7��\'I��a/U���\"{��g���(�L@��5���	� ��&0��˃�U@hb���4��M�%r*���Y{ޓ�k��b��N)�Ak���i=�΍�\Z��螶�s����m��\n��|�\"�g��%�$�,K����>N����s��tÇ�����%9#l��,���s}XT��v\\\rd0{a��sO��6s�n�9�G�*sM�����_�C�ZNI��S+\\	miN?�+h.�щ����8Z^��;����������o��.~\\��z&��3��h�Ek�\r��b�l4!�`J�\'�������{�����s�\'���#M�����5�%|G����I�>\\}c����\ne|4}M�W���\0�}���w�m��L�����>�z���[�5pT�*��i�~���P���e�~��\n����z�������ࣘ�d�|��B���8H9[���i�/)OWgA���a��!�b�c��~�r�a��(���8�0��%[y@��y�1^� �iw'),
(21,'1__0_0_0_0',1797964727,'x�uUMo�8��(tRQ�dI����hsqz艠ȑLX�$���w�/�v��p>ތXA�7Y����ś)�\"�dAƷ~z�--k,k����Io�|31\\faf6��Q�Ef[\Z��{�K!�[��Ы�V��`x:�#YT@k���`�AL�Fi+�z1$�\"���ײ�R�EO��6�VS�ŜmXW�:��%xCC�LCgo`����H��v����$3&dU-�H�\"xJ��!^}R�\r� ���h��6���߃�T6~M�h��Gs���}\0�gc�A�����$^���\Z�ٽgƓ�t��T�zBj�gG>||����U^�(I�uf�]��[�Ug�5�Ҫ��N�J�\Z��0�B��T�=��TiY��v:�Z��^Kd�)���\'�̄:�SK��E5�-E�}W��h���%�9���a���k���ۯ�O��&�Ԩ��+���O����J�����wӠK��=�\Z\0;�z_,�Pc�`�)�4�����\0Q��j7�=��x��]�}d���O��kC�H���z����C�Qc����f�KL�wge��\Z�����~�J��O�e�������Ȍ��\"���J3O6q[�v���X͸�\0̒\r�9EHQm.��BA��JvUi���Vʮ#y�j-C�`1\\��!YGyu� ��ϲ���P��9J�-������L���� ��ԇzQh/��W���j\Zu\\�������������u�S�䬡W*�ê���A��&\",�q7��Q�(-���S~�n��o�Fg�3-|*��&���u��T\\_�\Z���ˋ��	��W$�*�L��ҨJci\"/s²2���n3��,bI�7��q�l�O!\rY(n�$���2���֣z'),
(22,'30__0_0_0_0',1797964727,'x��UM��6��W:/6�dɒ=,��)��e7����d��T��b�{��2m9��3E.��f8�y�C�0�9���6�_L�A/yp\'��\r��/�IXci�\r�6��(��d�0ͩ+�6���C4��$碝�, ��V6b���h���yP\nRi���&�y����(me[\rI����Mhux/Ӳ�R�]c�����a1�c��Դ�zZ	2�?���\Z��tT�֮`�z͖1�a;�.��qY�����3������D3x0癌��\n\\���&tcHo�>�G3>���` O�=�ϸ�������j0=~~$��?>��x��Ӈ�+I@�z�z�w���ˤԪ!ݩv`�Q=<C��3�M\'�;�������J+\ZڑNK��c0��Ɠh���c\'f m���y3}������m;�P��#�[�j�cv����^��o\'��U��0^�!ǚ�9��O�/:��(h��d8�HG�i��q���np����0(����C]Sc?un��7xP����z�5rU�� nB�\"�b��9�z��T��ei�G}/�������Y3-�Ք��*io!�_S8���*XL��^z��4ĉG+e�yZ$H�BC�`�_���iKXY-ǁꂲ=���=_����HZ��a��lśQsD���q�PWա���g_G�����a�.=M��+(J-~�o޸�������B3pXU������`�o��t`���H�ɶ\n�\\\rO6F5�M��x��(�I�.`��-��\n�s�����ů���2�g�]ߥ�0�\\٥��m��]�-,���r9\\Ї�?�)0����l���݆q�}���j��y�oW�����}����[ǉ44jn\'������U;X��ÍS�T��}��f��y��w;�����ݎ���><�dk���\'����m�_�����q¸�I�f���FdY�¤�&(B^�o��iJ��\"	�\"��b��\"�Q��Ac���B\\�(�,+Oy����`');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'36__0_0_0_0','pageId_1'),
(2,'36__0_0_0_0','pageId_35'),
(3,'36__0_0_0_0','pageId_36'),
(4,'5__0_0_0_0','pageId_1'),
(5,'5__0_0_0_0','pageId_5'),
(6,'11__0_0_0_0','pageId_1'),
(7,'11__0_0_0_0','pageId_11'),
(8,'12__0_0_0_0','pageId_1'),
(9,'12__0_0_0_0','pageId_12'),
(10,'13__0_0_0_0','pageId_1'),
(11,'13__0_0_0_0','pageId_13'),
(12,'14__0_0_0_0','pageId_1'),
(13,'14__0_0_0_0','pageId_14'),
(14,'15__0_0_0_0','pageId_1'),
(15,'15__0_0_0_0','pageId_15'),
(16,'17__0_0_0_0','pageId_1'),
(17,'17__0_0_0_0','pageId_17'),
(18,'18__0_0_0_0','pageId_1'),
(19,'18__0_0_0_0','pageId_18'),
(20,'19__0_0_0_0','pageId_1'),
(21,'19__0_0_0_0','pageId_19'),
(22,'20__0_0_0_0','pageId_1'),
(23,'20__0_0_0_0','pageId_20'),
(24,'21__0_0_0_0','pageId_1'),
(25,'21__0_0_0_0','pageId_21'),
(26,'16__0_0_0_0','pageId_1'),
(27,'16__0_0_0_0','pageId_16'),
(28,'9__0_0_0_0','pageId_1'),
(29,'9__0_0_0_0','pageId_5'),
(30,'9__0_0_0_0','pageId_9'),
(31,'31__0_0_0_0','pageId_1'),
(32,'31__0_0_0_0','pageId_30'),
(33,'31__0_0_0_0','pageId_31'),
(34,'35__0_0_0_0','pageId_1'),
(35,'35__0_0_0_0','pageId_35'),
(36,'6__0_0_0_0','pageId_1'),
(37,'6__0_0_0_0','pageId_5'),
(38,'6__0_0_0_0','pageId_6'),
(39,'7__0_0_0_0','pageId_1'),
(40,'7__0_0_0_0','pageId_5'),
(41,'7__0_0_0_0','pageId_7'),
(42,'8__0_0_0_0','pageId_1'),
(43,'8__0_0_0_0','pageId_5'),
(44,'8__0_0_0_0','pageId_8'),
(45,'10__0_0_0_0','pageId_1'),
(46,'10__0_0_0_0','pageId_5'),
(47,'10__0_0_0_0','pageId_10'),
(48,'1__0_0_0_0','pageId_1'),
(49,'30__0_0_0_0','pageId_1'),
(50,'30__0_0_0_0','pageId_30');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_kesearch_tags` text DEFAULT NULL,
  `tx_kesearch_abstract` text DEFAULT NULL,
  `tx_kesearch_resultimage` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1795334294,1794119207,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"}',0,0,0,0,1,1,31,31,1,1795372569,0,0,0,0,0.5,1,'Home','/','TCEMAIN.permissions.groupid = 1\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete',0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__Home','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(2,1,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(3,2,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,1795333022,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(4,2,1795333042,1795333022,1,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(5,1,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','pagets__SidebarLeft','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(6,5,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(7,5,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(8,5,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Parking fees','/revenue-payments/parking-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(9,5,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Market fees','/revenue-payments/market-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(10,5,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Waiver of interest','/revenue-payments/waiver-of-interest',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(11,1,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Health','/health',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(12,1,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Environment & water','/environment-water',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(13,1,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Trade & tourism','/trade-tourism',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(14,1,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Public participation','/public-participation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(15,1,1795369027,1795334294,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\"}',0,0,0,0,1,1,31,31,0,1795369027,0,0,0,0,0.5,1,'Contact','/contact',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(16,1,1795348009,1795334294,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795348009,0,0,0,0,0.5,1,'Search','/search',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(17,1,1795334294,1795334294,0,0,0,0,'0',2048,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'E-services portal','/e-services-portal',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(18,1,1795334294,1795334294,0,0,0,0,'0',2304,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Accessibility statement','/accessibility-statement',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(19,1,1795334294,1795334294,0,0,0,0,'0',2560,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Privacy policy','/privacy-policy',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(20,1,1795334294,1795334294,0,0,0,0,'0',2816,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Access to information','/access-to-information',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(21,1,1795334294,1795334294,0,0,0,0,'0',3072,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Tenders','/tenders',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(22,1,1795334294,1795334294,0,0,0,0,'0',3328,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Service navigation','/service-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(23,1,1795334294,1795334294,0,0,0,0,'0',3584,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Footer navigation','/footer-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(24,22,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,17,0,0,0,0.5,4,'E-services portal','/e-services-portal-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(25,22,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,15,0,0,0,0.5,4,'Contact','/contact-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(26,23,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,18,0,0,0,0.5,4,'Accessibility statement','/accessibility-statement-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(27,23,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,19,0,0,0,0.5,4,'Privacy policy','/privacy-policy-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(28,23,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,20,0,0,0,0.5,4,'Access to information','/access-to-information-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(29,23,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,21,0,0,0,0.5,4,'Tenders','/tenders-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(30,1,1795336956,1795336956,0,0,0,0,'0',3200,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795336956,0,0,0,0,0.5,1,'News','/news',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(31,30,1795348009,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795348009,0,0,0,0,0.5,1,'Article','/news/article',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(32,1,1795336956,1795336956,0,0,0,0,'0',3840,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'News records','/news-records',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(33,1,1795348009,1795345582,0,0,0,0,'0',3136,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795345582,0,0,0,0,0.5,1,'Page not found','/page-not-found',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','',NULL,'',1,1,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(34,1,1795348009,1795348009,0,0,0,0,'0',4096,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Search index','/search-index',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(35,1,1795372569,1795372569,0,0,0,0,'0',3264,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795372569,0,0,0,0,0.5,1,'Events','/events',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(36,35,1795372569,1795372569,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795372569,0,0,0,0,0.5,1,'Event','/events/event',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `tx_kesearch_filter` text DEFAULT NULL,
  `tx_kesearch_filtersubcat` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,32,1795336956,1795336956,0,0,0,0,256,NULL,0,0,NULL,'',0,0,0,0,0,'Trade & markets',0,0,0,0,'','','',NULL,'',NULL,'trade-markets',NULL,NULL),
(2,32,1795336956,1795336956,0,0,0,0,512,NULL,0,0,NULL,'',0,0,0,0,0,'Roads & transport',0,0,0,0,'','','',NULL,'',NULL,'roads-transport',NULL,NULL),
(3,32,1795336956,1795336956,0,0,0,0,768,NULL,0,0,NULL,'',0,0,0,0,0,'Health',0,0,0,0,'','','',NULL,'',NULL,'health',NULL,NULL),
(4,32,1795336956,1795336956,0,0,0,0,1024,NULL,0,0,NULL,'',0,0,0,0,0,'Revenue & payments',0,0,0,0,'','','',NULL,'',NULL,'revenue-payments',NULL,NULL),
(5,32,1795336956,1795336956,0,0,0,0,1280,NULL,0,0,NULL,'',0,0,0,0,0,'Public participation',0,0,0,0,'','','',NULL,'',NULL,'public-participation',NULL,NULL),
(6,32,1795336956,1795336956,0,0,0,0,1536,NULL,0,0,NULL,'',0,0,0,0,0,'Environment',0,0,0,0,'','','',NULL,'',NULL,'environment',NULL,NULL),
(7,32,1795336956,1795336956,0,0,0,0,1792,NULL,0,0,NULL,'',0,0,0,0,0,'Water',0,0,0,0,'','','',NULL,'',NULL,'water',NULL,NULL),
(8,32,1795336956,1795336956,0,0,0,0,2048,NULL,0,0,NULL,'',0,0,0,0,0,'Education',0,0,0,0,'','','',NULL,'',NULL,'education',NULL,NULL);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,1,0,1,'tx_news_domain_model_news','categories'),
(1,12,0,1,'tx_news_domain_model_news','categories'),
(2,2,0,1,'tx_news_domain_model_news','categories'),
(3,3,0,1,'tx_news_domain_model_news','categories'),
(4,4,0,1,'tx_news_domain_model_news','categories'),
(4,13,0,1,'tx_news_domain_model_news','categories'),
(5,5,0,1,'tx_news_domain_model_news','categories'),
(5,9,0,1,'tx_news_domain_model_news','categories'),
(6,6,0,1,'tx_news_domain_model_news','categories'),
(6,8,0,1,'tx_news_domain_model_news','categories'),
(7,7,0,1,'tx_news_domain_model_news','categories'),
(8,10,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml','165cd81b05433cbd58fd78992daf226ea111f5bf','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','data.xml','df6041a9d17e792b9962e4b87dbaa3b47094afb7',1795348019,1795348019,139896,1,1,'text/xml',0,0),
(2,0,1795344511,1795344511,'/user_upload/slides/slide-coast.svg','ff045dfdd71e6acbcb55576edfcd297e7b28ce67','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-coast.svg','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795344511,1795344511,1233,1,2,'image/svg+xml',0,0),
(3,0,1795344511,1795344511,'/user_upload/slides/slide-rates.svg','1e61ced89c016178e02a3c5bf79eb2de9fc6ddef','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-rates.svg','930ad2b62005be8ab906802601193f671beda593',1795344511,1795344511,1214,1,2,'image/svg+xml',0,0),
(4,0,1795344511,1795344511,'/user_upload/slides/slide-community.svg','fa4ea1a512790f3c4a1936302b29a1a691654ebb','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-community.svg','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795344511,1795344511,900,1,2,'image/svg+xml',0,0),
(8,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml.files/20ea8f7cede2a53c268a4bab9647c06acfed9ff3','3a0d8dd4dab01965f63cc1874ec27659e68ab2d4','a20b30e6345e127e49790026ced895ee898ede1b','','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795348019,1795348019,900,1,2,'image/svg+xml',0,0),
(9,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml.files/54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','bf9643ba7780e40c2cad570672027d3debcd9d69','a20b30e6345e127e49790026ced895ee898ede1b','','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795348019,1795348019,1233,1,2,'image/svg+xml',0,0),
(10,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml.files/930ad2b62005be8ab906802601193f671beda593','aa2ff46d1695ecafd15b9d47e0b7f1c24c270008','a20b30e6345e127e49790026ced895ee898ede1b','','930ad2b62005be8ab906802601193f671beda593','930ad2b62005be8ab906802601193f671beda593',1795348019,1795348019,1214,1,2,'image/svg+xml',0,0),
(11,0,1795368020,1795368020,'/user_upload/pages/revenue.svg','1cd73fe883ea2a924471d5fd501fa4302aefed05','41e6d150c75718d77d7de5232176c747d5e946ab','svg','revenue.svg','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd',1795366717,1795366717,1527,1,2,'image/svg+xml',0,0),
(12,0,1795368020,1795368020,'/user_upload/pages/land-rates.svg','d5f7763ccb54d96ca705ae00a952c4e667420ed2','41e6d150c75718d77d7de5232176c747d5e946ab','svg','land-rates.svg','443957829800f283dbb2ffd610ad644b542355be',1795366717,1795366717,1341,1,2,'image/svg+xml',0,0),
(13,0,1795368020,1795368020,'/user_upload/pages/business-permit.svg','9de9cf466345826e6e0004eaff218214e0ed670c','41e6d150c75718d77d7de5232176c747d5e946ab','svg','business-permit.svg','3cdd6e20a13e650cec99679b5eb52e67c529921a',1795366717,1795366717,1796,1,2,'image/svg+xml',0,0),
(14,0,1795368020,1795368020,'/user_upload/pages/parking.svg','d5d63aa11f9836ff8a5574041dd005fc33d3063e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','parking.svg','21e3ea6329d902fadb8e700a33b813364ae0f517',1795366717,1795366717,1635,1,2,'image/svg+xml',0,0),
(15,0,1795368020,1795368020,'/user_upload/pages/market.svg','9b5ab031812f7b3000919f31d93eb6834eef44f1','41e6d150c75718d77d7de5232176c747d5e946ab','svg','market.svg','f4699dfad158612a22995a697549a4f0b4e34d51',1795366717,1795366717,1219,1,2,'image/svg+xml',0,0),
(16,0,1795368020,1795368020,'/user_upload/pages/waiver.svg','c29d9ffd11670a33b99b6be69ccd5d853c4477e3','41e6d150c75718d77d7de5232176c747d5e946ab','svg','waiver.svg','fe4ef5de488313ec55bf32751c903663094ef756',1795366717,1795366717,2156,1,2,'image/svg+xml',0,0),
(17,0,1795368020,1795368020,'/user_upload/pages/health.svg','a1bb0acb15caed893f46871a75b18a2a72fbed07','41e6d150c75718d77d7de5232176c747d5e946ab','svg','health.svg','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a',1795366717,1795366717,1263,1,2,'image/svg+xml',0,0),
(18,0,1795368020,1795368020,'/user_upload/pages/water.svg','6b1802ac603aa6da515cf8c4311e08b581f6e965','41e6d150c75718d77d7de5232176c747d5e946ab','svg','water.svg','4555d9ca1525f63e42e91e3b6f492963d65bc496',1795366717,1795366717,1246,1,2,'image/svg+xml',0,0),
(19,0,1795368020,1795368020,'/user_upload/pages/tourism.svg','8c1f6765ae9538e3fd436189d04637f5e020d708','41e6d150c75718d77d7de5232176c747d5e946ab','svg','tourism.svg','b2596f9cc022b1e81e206e3533d1e5944587bb51',1795366717,1795366717,1109,1,2,'image/svg+xml',0,0),
(20,0,1795368020,1795368020,'/user_upload/pages/office.svg','ce61dc3f063e40c13764b7cd0cdc993f1a605920','41e6d150c75718d77d7de5232176c747d5e946ab','svg','office.svg','2a62d5fb10462c90782877bc4254dec0a59e82a0',1795366717,1795366717,1396,1,2,'image/svg+xml',0,0),
(21,0,1795368020,1795368020,'/user_upload/pages/participation.svg','a4da72511bdbadb3e3b61b67f2225a182ed42e62','41e6d150c75718d77d7de5232176c747d5e946ab','svg','participation.svg','36f0d096874cc84265f1180798b35e74ccb363dc',1795366717,1795366717,1413,1,2,'image/svg+xml',0,0),
(22,0,1795368020,1795368020,'/user_upload/pages/portal.svg','2d8f4684e52b0f63833ec132ac661878cbbd3f8e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','portal.svg','83926aff612828d0f180cb5c7549588e6e10c537',1795366717,1795366717,1459,1,2,'image/svg+xml',0,0),
(23,0,1795368020,1795368020,'/user_upload/pages/accessibility.svg','6f0b06a790eb2db4ac6f06627a44c9b86354e777','41e6d150c75718d77d7de5232176c747d5e946ab','svg','accessibility.svg','ac912b916c948f19149c48cc52ef27f3e3a9a2eb',1795366717,1795366717,1311,1,2,'image/svg+xml',0,0),
(24,0,1795368020,1795368020,'/user_upload/pages/privacy.svg','37eb3d14802d29b87df0e485e47493b1d99c8c21','41e6d150c75718d77d7de5232176c747d5e946ab','svg','privacy.svg','9b8e53905ab5b20c15fdeb594911c71feb55252c',1795366717,1795366717,658,1,2,'image/svg+xml',0,0),
(25,0,1795368020,1795368020,'/user_upload/pages/documents.svg','aabcfbfda5ee6ee108add7c25755e60125aac964','41e6d150c75718d77d7de5232176c747d5e946ab','svg','documents.svg','55578155722872d3dbe552da247abdf9eab0f079',1795366717,1795366717,1109,1,2,'image/svg+xml',0,0),
(26,0,1795368020,1795368020,'/user_upload/pages/tenders.svg','6d7a69908a1ccb7e07fe72d25353ab2cd97bcd6e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','tenders.svg','4466965824279af3d0752afc1c381bc67bf02cb3',1795366717,1795366717,1327,1,2,'image/svg+xml',0,0),
(27,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','241e84244ec067649ea2d0ea239961dfa9a911b0','a20b30e6345e127e49790026ced895ee898ede1b','','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd',1795368054,1795368054,1527,1,2,'image/svg+xml',0,0),
(28,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/21e3ea6329d902fadb8e700a33b813364ae0f517','6a072c5f3058ce87c7e331226dca617a46514da7','a20b30e6345e127e49790026ced895ee898ede1b','','21e3ea6329d902fadb8e700a33b813364ae0f517','21e3ea6329d902fadb8e700a33b813364ae0f517',1795368054,1795368054,1635,1,2,'image/svg+xml',0,0),
(29,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/2a62d5fb10462c90782877bc4254dec0a59e82a0','f87fdf05d0c5c61478c0495b9bdfbbc7ef865a85','a20b30e6345e127e49790026ced895ee898ede1b','','2a62d5fb10462c90782877bc4254dec0a59e82a0','2a62d5fb10462c90782877bc4254dec0a59e82a0',1795368054,1795368054,1396,1,2,'image/svg+xml',0,0),
(30,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','ed73bf77934c98f376223a1eba8ff16bdb0e4491','a20b30e6345e127e49790026ced895ee898ede1b','','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a',1795368054,1795368054,1263,1,2,'image/svg+xml',0,0),
(31,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/36f0d096874cc84265f1180798b35e74ccb363dc','a54eec23cb10896de868963d7d569a38d725ac3e','a20b30e6345e127e49790026ced895ee898ede1b','','36f0d096874cc84265f1180798b35e74ccb363dc','36f0d096874cc84265f1180798b35e74ccb363dc',1795368054,1795368054,1413,1,2,'image/svg+xml',0,0),
(32,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/3cdd6e20a13e650cec99679b5eb52e67c529921a','25689a616091f047048ed8215f8d79c80c92bc66','a20b30e6345e127e49790026ced895ee898ede1b','','3cdd6e20a13e650cec99679b5eb52e67c529921a','3cdd6e20a13e650cec99679b5eb52e67c529921a',1795368054,1795368054,1796,1,2,'image/svg+xml',0,0),
(33,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/443957829800f283dbb2ffd610ad644b542355be','437c9cf197a4e167c48cce35f9538beacf1f475c','a20b30e6345e127e49790026ced895ee898ede1b','','443957829800f283dbb2ffd610ad644b542355be','443957829800f283dbb2ffd610ad644b542355be',1795368054,1795368054,1341,1,2,'image/svg+xml',0,0),
(34,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/4466965824279af3d0752afc1c381bc67bf02cb3','876fedf79b3161dac6bb747b570e6881d0fd47dd','a20b30e6345e127e49790026ced895ee898ede1b','','4466965824279af3d0752afc1c381bc67bf02cb3','4466965824279af3d0752afc1c381bc67bf02cb3',1795368054,1795368054,1327,1,2,'image/svg+xml',0,0),
(35,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/4555d9ca1525f63e42e91e3b6f492963d65bc496','b56ad440266757db55d031cf5fadd6751129372d','a20b30e6345e127e49790026ced895ee898ede1b','','4555d9ca1525f63e42e91e3b6f492963d65bc496','4555d9ca1525f63e42e91e3b6f492963d65bc496',1795368054,1795368054,1246,1,2,'image/svg+xml',0,0),
(36,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/55578155722872d3dbe552da247abdf9eab0f079','332bc17e608fc5c104c37f7288f517e6cedc1a7f','a20b30e6345e127e49790026ced895ee898ede1b','','55578155722872d3dbe552da247abdf9eab0f079','55578155722872d3dbe552da247abdf9eab0f079',1795368054,1795368054,1109,1,2,'image/svg+xml',0,0),
(37,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/83926aff612828d0f180cb5c7549588e6e10c537','f1ccf1dbc49175f378508d2526bfe6ef0b0e8b77','a20b30e6345e127e49790026ced895ee898ede1b','','83926aff612828d0f180cb5c7549588e6e10c537','83926aff612828d0f180cb5c7549588e6e10c537',1795368054,1795368054,1459,1,2,'image/svg+xml',0,0),
(38,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/9b8e53905ab5b20c15fdeb594911c71feb55252c','7a588fa8f56093604f80ae9ca00ea4a846772935','a20b30e6345e127e49790026ced895ee898ede1b','','9b8e53905ab5b20c15fdeb594911c71feb55252c','9b8e53905ab5b20c15fdeb594911c71feb55252c',1795368054,1795368054,658,1,2,'image/svg+xml',0,0),
(39,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/ac912b916c948f19149c48cc52ef27f3e3a9a2eb','9c987bfeb026319721c2e53237d64ad0598d506d','a20b30e6345e127e49790026ced895ee898ede1b','','ac912b916c948f19149c48cc52ef27f3e3a9a2eb','ac912b916c948f19149c48cc52ef27f3e3a9a2eb',1795368054,1795368054,1311,1,2,'image/svg+xml',0,0),
(40,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/b2596f9cc022b1e81e206e3533d1e5944587bb51','574411d8e13602a441cd710d24e3dd2a6f2e4ffb','a20b30e6345e127e49790026ced895ee898ede1b','','b2596f9cc022b1e81e206e3533d1e5944587bb51','b2596f9cc022b1e81e206e3533d1e5944587bb51',1795368054,1795368054,1109,1,2,'image/svg+xml',0,0),
(41,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/f4699dfad158612a22995a697549a4f0b4e34d51','4ed4ed3f9e93d9dd9aedeec17c0b25716c4cb631','a20b30e6345e127e49790026ced895ee898ede1b','','f4699dfad158612a22995a697549a4f0b4e34d51','f4699dfad158612a22995a697549a4f0b4e34d51',1795368054,1795368054,1219,1,2,'image/svg+xml',0,0),
(42,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/fe4ef5de488313ec55bf32751c903663094ef756','4aab823a35c5d45231c0f2be8f8973d294206e96','a20b30e6345e127e49790026ced895ee898ede1b','','fe4ef5de488313ec55bf32751c903663094ef756','fe4ef5de488313ec55bf32751c903663094ef756',1795368054,1795368054,2156,1,2,'image/svg+xml',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `tx_kesearch_no_search` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1795334315,1795334315,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0,0),
(2,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1600,600,0),
(3,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,1600,600,0),
(4,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,1600,600,0),
(8,0,1795348018,1795348018,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,0,0,0),
(9,0,1795348018,1795348018,0,0,NULL,'',0,0,0,0,NULL,NULL,0,9,NULL,0,0,0),
(10,0,1795348018,1795348018,0,0,NULL,'',0,0,0,0,NULL,NULL,0,10,NULL,0,0,0),
(11,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,11,NULL,1200,800,0),
(12,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,12,NULL,1200,800,0),
(13,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,13,NULL,1200,800,0),
(14,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,14,NULL,1200,800,0),
(15,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,15,NULL,1200,800,0),
(16,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,16,NULL,1200,800,0),
(17,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,17,NULL,1200,800,0),
(18,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,18,NULL,1200,800,0),
(19,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,19,NULL,1200,800,0),
(20,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,20,NULL,1200,800,0),
(21,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,21,NULL,1200,800,0),
(22,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,22,NULL,1200,800,0),
(23,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,23,NULL,1200,800,0),
(24,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,24,NULL,1200,800,0),
(25,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,25,NULL,1200,800,0),
(26,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,26,NULL,1200,800,0),
(27,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,27,NULL,0,0,0),
(28,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,28,NULL,0,0,0),
(29,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,29,NULL,0,0,0),
(30,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,30,NULL,0,0,0),
(31,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,31,NULL,0,0,0),
(32,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,32,NULL,0,0,0),
(33,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,33,NULL,0,0,0),
(34,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,34,NULL,0,0,0),
(35,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,35,NULL,0,0,0),
(36,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,36,NULL,0,0,0),
(37,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,37,NULL,0,0,0),
(38,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,38,NULL,0,0,0),
(39,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,39,NULL,0,0,0),
(40,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,40,NULL,0,0,0),
(41,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,41,NULL,0,0,0),
(42,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,42,NULL,0,0,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1795344523,1795344523,1,2,'/_processed_/8/b/csm_slide-coast_a539169108.svg','csm_slide-coast_a539169108.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','Image.CropScaleMask','a539169108',1600,560),
(2,1795344523,1795344523,1,3,'/_processed_/f/f/csm_slide-rates_202cf46cda.svg','csm_slide-rates_202cf46cda.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','930ad2b62005be8ab906802601193f671beda593','Image.CropScaleMask','202cf46cda',1600,560),
(3,1795344523,1795344523,1,4,'/_processed_/e/b/csm_slide-community_e5b6b5187d.svg','csm_slide-community_e5b6b5187d.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','Image.CropScaleMask','e5b6b5187d',1600,560),
(4,1795368035,1795368035,1,19,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','7733916107',1200,800),
(5,1795368035,1795368035,1,19,'',NULL,'','a:3:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"crop\";N;}','8e17f053c0ee386607a1a7dd4c1234c3571c7b95','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','d525cc5c74',600,400),
(6,1795368035,1795368035,1,19,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','4c457691d0',295,196),
(7,1795368035,1795368035,1,15,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','355bf597e6',1200,800),
(8,1795368035,1795368035,1,15,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','c5cd09fac1',295,196),
(9,1795368035,1795368035,1,18,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','0492c25a1a',1200,800),
(10,1795368035,1795368035,1,18,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','a1ad152454',295,196),
(11,1795368035,1795368035,1,20,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','ac2f4c151d',1200,800),
(12,1795368035,1795368035,1,20,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','5d58cc317b',295,196),
(13,1795368194,1795368194,1,15,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','f357b6f0a8',300,200),
(14,1795368277,1795368277,1,12,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','443957829800f283dbb2ffd610ad644b542355be','Image.CropScaleMask','4bc69b387a',1200,800),
(15,1795368277,1795368277,1,12,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','443957829800f283dbb2ffd610ad644b542355be','Image.CropScaleMask','0d8c01c268',300,200),
(16,1795368277,1795368277,1,17,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','Image.CropScaleMask','3e1c804694',1200,800),
(17,1795368277,1795368277,1,17,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','Image.CropScaleMask','f8fef5c0ea',300,200),
(18,1795369031,1795369031,1,20,'',NULL,'','a:3:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"crop\";N;}','8e17f053c0ee386607a1a7dd4c1234c3571c7b95','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','3f32331746',600,400),
(19,1795370248,1795370248,1,11,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','Image.CropScaleMask','fc806927c3',1200,800),
(20,1795370248,1795370248,1,11,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','Image.CropScaleMask','fe6db4f4b0',300,200),
(21,1795370253,1795370253,1,18,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','499a6e3fa6',300,200),
(22,1795370257,1795370257,1,21,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','36f0d096874cc84265f1180798b35e74ccb363dc','Image.CropScaleMask','09b0a67918',1200,800),
(23,1795370257,1795370257,1,21,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','36f0d096874cc84265f1180798b35e74ccb363dc','Image.CropScaleMask','a3b8c8f19e',300,200);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,1,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(2,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,2,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(3,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,4,NULL,NULL,3,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(4,5,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,11,NULL,'A mobile phone confirming a payment, beside a stack of coins',11,'tt_content','image',1,'','Pay by mobile money: the receipt arrives on your phone.',NULL,0,0),
(5,6,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,12,NULL,'Two houses on surveyed plots on a green hillside',13,'tt_content','image',1,'','Every plot in the valuation roll has a rateable value.',NULL,0,0),
(6,7,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,13,NULL,'A shop with a striped awning and a framed business permit',16,'tt_content','image',1,'','One permit a year covers trade, health and fire safety.',NULL,0,0),
(7,8,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,14,NULL,'Two cars parked beside a parking sign',18,'tt_content','image',1,'','Parking on Beach Road is paid Monday to Saturday, 7:00 to 18:00.',NULL,0,0),
(8,9,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,15,NULL,'Two market stalls with fruit and vegetables',20,'tt_content','image',1,'','Stalls at the central market on Market Street.',NULL,0,0),
(9,10,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,16,NULL,'A calendar with a ticked check mark beside it',22,'tt_content','image',1,'','Clear your arrears before 30 June to have the interest waived.',NULL,0,0),
(10,11,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,17,NULL,'A health centre with a red cross sign',24,'tt_content','image',1,'','Mto Safi Town health centre, open Monday to Saturday.',NULL,0,0),
(11,12,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,18,NULL,'A river running through green land, with a water tower and a tap',26,'tt_content','image',1,'','The river gives the town its name: Mto Safi means \"clean river\".',NULL,0,0),
(12,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,19,NULL,'A dhow sailing at sunset with a palm tree on the beach',29,'tt_content','image',1,'','A dhow leaves the old harbour at sunset.',NULL,0,0),
(13,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,19,NULL,'A dhow sailing at sunset with a palm tree on the beach',31,'tt_content','image',1,'','Sunset over the old dhow harbour.',NULL,0,0),
(14,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,15,NULL,'Two market stalls with fruit and vegetables',31,'tt_content','image',2,'','Mangoes, tomatoes and sukuma wiki at the central market.',NULL,0,0),
(15,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,18,NULL,'A river running through green land, with a water tower and a tap',31,'tt_content','image',3,'','The river mouth, where the mangrove boardwalk starts.',NULL,0,0),
(16,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,20,NULL,'The municipal office with a flag on the roof',31,'tt_content','image',4,'','The municipal office, built in 1962, on Beach Road.',NULL,0,0),
(17,14,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,21,NULL,'Residents gathered in front of a board at a public forum',32,'tt_content','image',1,'','Budget forum in the municipal hall, Central ward.',NULL,0,0),
(18,15,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,20,NULL,'The municipal office with a flag on the roof',34,'tt_content','image',1,'','The municipal office on Beach Road.',NULL,0,0),
(19,17,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,22,NULL,'A laptop showing a login form, beside a padlock',37,'tt_content','image',1,'','Log in with your eCitizen account.',NULL,0,0),
(20,18,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,23,NULL,'A web page with clear headings and a focused button, beside the accessibility symbol',38,'tt_content','image',1,'','Example image: replace it together with the text.',NULL,0,0),
(21,19,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,24,NULL,'A shield with a padlock',39,'tt_content','image',1,'','Example image: replace it together with the text.',NULL,0,0),
(22,20,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,25,NULL,'A folder of documents and a magnifying glass',40,'tt_content','image',1,'','Requests are answered within 21 days.',NULL,0,0),
(23,21,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,26,NULL,'A building under construction with a crane, and a sealed envelope',42,'tt_content','image',1,'','Bids go in a sealed envelope to the procurement office.',NULL,0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1795334315,1795334315,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1795336957,0,0,0,NULL,'News images','1:/user_upload/news/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1795332992,1,'BE',1,0,2,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"Sidebar probe\",\"bodytext\":\"<p>Rendered from the area sidebar.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795332992,\"t3ver_stage\":0,\"tstamp\":1795332992,\"uid\":2}',0,'0400$Ab_ebDixmlobc09ZW_wpQOm13MVZdCpf:01dbc21fdb1263685b9147b3b1596ea8'),
(2,1795332999,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":null},\"newRecord\":{\"backend_layout\":\"pagets__Default\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$xqYtF2Yzjz8vs6EvJQvzLj3QUpVEEGdA:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1795333001,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Default\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\"}}',0,'0400$dxU1W8i-7n0ls8Dxve2BCaS2_U6etDoY:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1795333004,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Home\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"}}',0,'0400$12o7r9be8NdlTq7M72UstYxByrD_Sh_g:e175f7045d7ccbfb26ffcf279422c2e5'),
(5,1795333006,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\"}}',0,'0400$s0fUPA88SDA-I6r3a2F12T6-HMxysVUK:e175f7045d7ccbfb26ffcf279422c2e5'),
(6,1795333009,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarRight\"},\"newRecord\":{\"backend_layout\":\"pagets__Narrow\"}}',0,'0400$rWk3qQFI-05fLi5WkRdZtrLMsXXEvAU3:e175f7045d7ccbfb26ffcf279422c2e5'),
(7,1795333011,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Narrow\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$Xfdponrx3mLaIVs0SAIfgknY-Uy1U1cn:e175f7045d7ccbfb26ffcf279422c2e5'),
(8,1795333022,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":2}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:f11830df10b4b0bca2db34810c2241b3'),
(9,1795333022,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"backend_layout\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":3}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(10,1795333022,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":4}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:412add0b3eb6ec8f1cb6710aea92e21e'),
(11,1795333042,4,'BE',1,0,2,'tt_content',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:01dbc21fdb1263685b9147b3b1596ea8'),
(12,1795333042,4,'BE',1,0,4,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:412add0b3eb6ec8f1cb6710aea92e21e'),
(13,1795333042,4,'BE',1,0,3,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(14,1795333042,4,'BE',1,0,2,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:f11830df10b4b0bca2db34810c2241b3'),
(15,1795334294,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"backend_layout\":\"pagets__SidebarLeft\",\"backend_layout_next_level\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":5}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7ef5a4e3e11db8ac3fea4d7a75468161'),
(16,1795334294,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":6}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c75354c439a48dbde16b03ac553a080d'),
(17,1795334294,1,'BE',1,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":7}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:df50bb24cbce671cf0d61f42fbbef601'),
(18,1795334294,1,'BE',1,0,8,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/parking-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Parking fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":8}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:595375f2fb9f014e091eb08fbc51ec88'),
(19,1795334294,1,'BE',1,0,9,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/market-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Market fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":9}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(20,1795334294,1,'BE',1,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/waiver-of-interest\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Waiver of interest\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":10}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e904af5a60392ab3165f5849f5877e45'),
(21,1795334294,1,'BE',1,0,11,'pages','{\"doktype\":\"1\",\"slug\":\"\\/health\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":11}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:51bca2bcf14079cc366c99de31802400'),
(22,1795334294,1,'BE',1,0,12,'pages','{\"doktype\":\"1\",\"slug\":\"\\/environment-water\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Environment & water\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":12}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:d6f57183d4ec29f4a568a174f36b861b'),
(23,1795334294,1,'BE',1,0,13,'pages','{\"doktype\":\"1\",\"slug\":\"\\/trade-tourism\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Trade & tourism\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":13}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:8a89606121863fe3a2ec2ea63ba83d69'),
(24,1795334294,1,'BE',1,0,14,'pages','{\"doktype\":\"1\",\"slug\":\"\\/public-participation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":14}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aaa274fb7a5f76c9749f1b2c8fba84a4'),
(25,1795334294,1,'BE',1,0,15,'pages','{\"doktype\":\"1\",\"slug\":\"\\/contact\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1536,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":15}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c97934f122918253f51c81fbe45fd105'),
(26,1795334294,1,'BE',1,0,16,'pages','{\"doktype\":\"1\",\"slug\":\"\\/search\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1792,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Search\",\"nav_hide\":1,\"backend_layout\":\"pagets__SidebarRight\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":16}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:878fab4218e507eb25dda6ac21dd7ff1'),
(27,1795334294,1,'BE',1,0,17,'pages','{\"doktype\":\"1\",\"slug\":\"\\/e-services-portal\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2048,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":17}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:dd30e16e220c1cff5911b320aa60dbce'),
(28,1795334294,1,'BE',1,0,18,'pages','{\"doktype\":\"1\",\"slug\":\"\\/accessibility-statement\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2304,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":18}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:9e9e8c5ba4be654320a3cd25d73d01a4'),
(29,1795334294,1,'BE',1,0,19,'pages','{\"doktype\":\"1\",\"slug\":\"\\/privacy-policy\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2560,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":19}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:25dbd94d40a6ff54757b6e36bf898997'),
(30,1795334294,1,'BE',1,0,20,'pages','{\"doktype\":\"1\",\"slug\":\"\\/access-to-information\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2816,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":20}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:1d0206225cc3f30f7ba150ff3aae8ab7'),
(31,1795334294,1,'BE',1,0,21,'pages','{\"doktype\":\"1\",\"slug\":\"\\/tenders\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3072,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":21}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:bb4ab293ec9d3ccfe43678d078f6cea0'),
(32,1795334294,1,'BE',1,0,22,'pages','{\"doktype\":\"254\",\"slug\":\"\\/service-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3328,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Service navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":22}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e5087395befe41329009e7b123017494'),
(33,1795334294,1,'BE',1,0,23,'pages','{\"doktype\":\"254\",\"slug\":\"\\/footer-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3584,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Footer navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":23}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7e88f7aa7664c6f494370160b60358a1'),
(34,1795334294,1,'BE',1,0,24,'pages','{\"doktype\":\"4\",\"slug\":\"\\/e-services-portal-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":24}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:219ad4d34a3e23c6ccf2ca87da6bc52b'),
(35,1795334294,1,'BE',1,0,25,'pages','{\"doktype\":\"4\",\"slug\":\"\\/contact-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":25}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:464961a1483e7dda27d23c882ff696bb'),
(36,1795334294,1,'BE',1,0,26,'pages','{\"doktype\":\"4\",\"slug\":\"\\/accessibility-statement-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":26}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:544939248209022b223d317bc97b7099'),
(37,1795334294,1,'BE',1,0,27,'pages','{\"doktype\":\"4\",\"slug\":\"\\/privacy-policy-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":27}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:97019c60b3ac7f8b98007c072afa2f0f'),
(38,1795334294,1,'BE',1,0,28,'pages','{\"doktype\":\"4\",\"slug\":\"\\/access-to-information-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":28}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aa68f552fa168869c47f8dbefb43cba0'),
(39,1795334294,1,'BE',1,0,29,'pages','{\"doktype\":\"4\",\"slug\":\"\\/tenders-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":29}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:2d7ab27da714dae3c89a6e0cb79b80cd'),
(40,1795334294,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\"}\"}}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e175f7045d7ccbfb26ffcf279422c2e5'),
(41,1795334294,4,'BE',1,0,1,'tt_content',NULL,0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7fa2c035f26826fe83eeecaaeddc4d40'),
(42,1795336956,1,'BE',1,0,30,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3200,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":30}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:e3e225390eee037c1380949b378763b1'),
(43,1795336956,1,'BE',1,0,31,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\\/article\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":30,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Article\",\"nav_hide\":1,\"backend_layout\":\"pagets__Article\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":31}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:9cb7b2b3fac90492135e3538aed4605a'),
(44,1795336956,1,'BE',1,0,32,'pages','{\"doktype\":\"254\",\"slug\":\"\\/news-records\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3840,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News records\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":32}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:302984e7412d7a45766e1d6304831138'),
(45,1795336956,1,'BE',1,0,1,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"trade-markets\",\"pid\":32,\"sorting\":256,\"title\":\"Trade & markets\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c6c8e24453121a7d668fe4b1031ebf88'),
(46,1795336956,1,'BE',1,0,2,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"roads-transport\",\"pid\":32,\"sorting\":512,\"title\":\"Roads & transport\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:497028e4af2a2cda8419e90cde34f71b'),
(47,1795336956,1,'BE',1,0,3,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"health\",\"pid\":32,\"sorting\":768,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:265912e2a2dda6b4b6be4e7069754d09'),
(48,1795336956,1,'BE',1,0,4,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"revenue-payments\",\"pid\":32,\"sorting\":1024,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:a832991055f9726888b6b83414d05630'),
(49,1795336956,1,'BE',1,0,5,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"public-participation\",\"pid\":32,\"sorting\":1280,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:55bc761d39a2d7a8b56679774f51dfe6'),
(50,1795336956,1,'BE',1,0,6,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"environment\",\"pid\":32,\"sorting\":1536,\"title\":\"Environment\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:0580043665451ed803b9e5d021b149fe'),
(51,1795336956,1,'BE',1,0,7,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"water\",\"pid\":32,\"sorting\":1792,\"title\":\"Water\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:e6068a768abec7500a6d253c29088f52'),
(52,1795336956,1,'BE',1,0,8,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"education\",\"pid\":32,\"sorting\":2048,\"title\":\"Education\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":8}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f564fff7cae82b30644518a57bd7a8a6'),
(53,1795336956,1,'BE',1,0,1,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-fish-market-opens-at-the-jetty\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New fish market opens at the jetty\",\"datetime\":1793595600,\"teaser\":\"Sixty stalls, cold storage and clean water for traders and buyers.\",\"bodytext\":\"<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night\\u2019s catch and running water at every stall.<\\/p>\\r\\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Trade &amp; Markets Office, +254 700 000 010<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:fccd16ea3664ec003726b2a72ea38f4b'),
(54,1795336956,1,'BE',1,0,2,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"beach-road-resurfacing-starts\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Beach Road resurfacing starts\",\"datetime\":1793077200,\"teaser\":\"Works run for six weeks. Matatus take the diversion via Market Street.\",\"bodytext\":\"<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.<\\/p>\\r\\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Roads Department, +254 700 000 020<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:640f28e5c1a5ec2efb19c26699b464a5'),
(55,1795336956,1,'BE',1,0,3,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"free-health-camp-in-ward-3\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Free health camp in Ward 3\",\"datetime\":1792472400,\"teaser\":\"Eye tests, vaccinations and screening, open to every resident.\",\"bodytext\":\"<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.<\\/p>\\r\\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Health Department, +254 700 000 030<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:1152fda277b2623b0152b5765fcb6b28'),
(56,1795336956,1,'BE',1,0,4,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"pay-land-rates-by-mobile-money-from-january\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Pay land rates by mobile money from January\",\"datetime\":1791781200,\"teaser\":\"Residents can now pay land rates and business permits with their phone.\",\"bodytext\":\"<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.<\\/p>\\r\\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Revenue Department, +254 700 000 040<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f3f39c24ca39d00c02ecd29ec2ad4225'),
(57,1795336956,1,'BE',1,0,5,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"have-your-say-on-the-budget-2027-28\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Have your say on the budget 2027\\/28\",\"datetime\":1790830800,\"teaser\":\"Public participation forums in every ward in November.\",\"bodytext\":\"<p>The municipality prepares its budget for 2027\\/28 and asks residents what matters most to them: roads, water, markets, health or schools.<\\/p>\\r\\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Planning Office, +254 700 000 050<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:bc83755a03cca2ca5c8daa03e9d6e32e'),
(58,1795336956,1,'BE',1,0,6,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"mto-safi-named-cleanest-town-on-the-coast\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Mto Safi named cleanest town on the coast\",\"datetime\":1789707600,\"teaser\":\"The monthly beach clean-ups and the new waste collection paid off.\",\"bodytext\":\"<p>Mto Safi has won this year\\u2019s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.<\\/p>\\r\\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Environment Department, +254 700 000 060<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:7e4fc5d3ec5edd1f76b0a3820eb3fb47'),
(59,1795336956,1,'BE',1,0,7,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-boreholes-bring-clean-water-to-ward-5\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New boreholes bring clean water to Ward 5\",\"datetime\":1788584400,\"teaser\":\"Three boreholes and twelve water kiosks serve 4,000 residents.\",\"bodytext\":\"<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.<\\/p>\\r\\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Water &amp; Sanitation Department, +254 700 000 070<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:31860b4bf14b13d2dc895987af663784'),
(60,1795336956,1,'BE',1,0,3,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"News\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">home<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:b92300cfb5d1d3645c9cb212a7f56c1f'),
(61,1795336956,1,'BE',1,0,4,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":30,\"sorting\":256,\"header\":\"All news\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:4d391f5ef79b8d5d10dffa8a07ca167d'),
(62,1795336956,1,'BE',1,0,5,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":31,\"sorting\":256,\"header\":\"News article\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c7626fc9bcba6f70beb6ebc085a400db'),
(63,1795343750,1,'BE',1,0,6,'tt_content','{\"CType\":\"mtosafi_tiles\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":128,\"header\":\"Popular services\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c0db6803ab1ec5f70c36e2a72187867b'),
(64,1795343750,1,'BE',1,0,1,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"icon\":\"\\ud83c\\udfea\",\"label\":\"Single business permit\",\"link\":\"t3:\\/\\/page?uid=7\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":1}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:55820ddffac9b29987f66a48c05c3e01'),
(65,1795343750,1,'BE',1,0,2,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"icon\":\"\\ud83c\\udfe1\",\"label\":\"Land rates\",\"link\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":2}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:b6549a503cf1dd498f3571f7d5d85d54'),
(66,1795343750,1,'BE',1,0,3,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"icon\":\"\\ud83c\\udd7f\\ufe0f\",\"label\":\"Parking fees\",\"link\":\"t3:\\/\\/page?uid=8\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":3}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:518760b21a46e7982878ebf568972b86'),
(67,1795343750,1,'BE',1,0,4,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":32,\"icon\":\"\\ud83d\\udca7\",\"label\":\"Water connection\",\"link\":\"t3:\\/\\/page?uid=12\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":4}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:ba2135e3eae99237605541429e1c8913'),
(68,1795343750,1,'BE',1,0,5,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":16,\"icon\":\"\\ud83e\\uddfa\",\"label\":\"Market stalls\",\"link\":\"t3:\\/\\/page?uid=9\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":5}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c65d007d6e8748b9615f1c9e01a28b86'),
(69,1795343750,1,'BE',1,0,6,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":8,\"icon\":\"\\ud83d\\udce3\",\"label\":\"Report a problem\",\"link\":\"t3:\\/\\/page?uid=15\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:632dfe70d9c02f2a21151ad96efaec1c'),
(70,1795344511,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:4cf496f597e7b095ce8b755e6cec3c0c'),
(71,1795344511,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"3\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:814fc0f720dfab882655a795e23a5b66'),
(72,1795344511,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"4\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:d2c609347a4764200256b39b9425159a'),
(73,1795344511,1,'BE',1,0,7,'tt_content','{\"CType\":\"mtosafi_slider\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":64,\"header\":\"Highlights\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":7}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:ea41b626baac59a1fe0716bc344af5d9'),
(74,1795344511,1,'BE',1,0,1,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"title\":\"Karibu Mto Safi\",\"text\":\"White beaches, a clean river and a municipality that serves you online, day and night.\",\"link\":\"t3:\\/\\/page?uid=13\",\"link_label\":\"Discover Mto Safi\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:1ffe01378bcddf3cd4b7ccc25f2930f6'),
(75,1795344511,1,'BE',1,0,2,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"title\":\"Pay your land rates by mobile money\",\"text\":\"Calculate what you owe and pay before 31 March to avoid interest.\",\"link\":\"t3:\\/\\/page?uid=6\",\"link_label\":\"Calculate land rates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:de55124b95b3be65ab1a5218e23dea0d'),
(76,1795344511,1,'BE',1,0,3,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"title\":\"Have your say on the budget\",\"text\":\"Join the public participation forums in every ward this month.\",\"link\":\"t3:\\/\\/page?uid=14\",\"link_label\":\"See the forum dates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:e8603ac799ba0c457941e1d26db41cb8'),
(77,1795345582,1,'BE',1,0,33,'pages','{\"doktype\":\"1\",\"slug\":\"\\/page-not-found\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3136,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Page not found\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"no_index\":1,\"no_follow\":1,\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":33}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:0c3ed5b51e5eff03577c1c2f671f9fbe'),
(78,1795345582,1,'BE',1,0,8,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":33,\"sorting\":256,\"header\":\"This page does not exist\",\"bodytext\":\"<p>The page you are looking for may have moved, or the address may be mistyped.<\\/p>\\r\\n<ul><li><a href=\\\"t3:\\/\\/page?uid=1\\\">Go to the home page<\\/a><\\/li><li><a href=\\\"t3:\\/\\/page?uid=16\\\">Search the site<\\/a><\\/li><\\/ul>\",\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":8}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:2097d84972a039cb6bfe093b17089287'),
(79,1795348009,1,'BE',1,0,34,'pages','{\"doktype\":\"254\",\"slug\":\"\\/search-index\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":4096,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Search index\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":34}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:152f249a1550628c00eb2837d4cfde70'),
(80,1795348009,2,'BE',1,0,16,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:878fab4218e507eb25dda6ac21dd7ff1'),
(81,1795348009,2,'BE',1,0,33,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:0c3ed5b51e5eff03577c1c2f671f9fbe'),
(82,1795348009,2,'BE',1,0,31,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:9cb7b2b3fac90492135e3538aed4605a'),
(83,1795348009,1,'BE',1,0,1,'tx_kesearch_filteroptions','{\"l10n_parent\":0,\"slug\":\"services\",\"hidden\":0,\"pid\":34,\"sorting\":256,\"title\":\"Services\",\"tag\":\"service\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"tag\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:5959a4f398aeb048aebac4b34bca8539'),
(84,1795348009,1,'BE',1,0,2,'tx_kesearch_filteroptions','{\"l10n_parent\":0,\"slug\":\"news\",\"hidden\":0,\"pid\":34,\"sorting\":512,\"title\":\"News\",\"tag\":\"news\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"tag\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":2}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:90ae5ff47c0a84f43bdf13d71c840463'),
(85,1795348009,1,'BE',1,0,1,'tx_kesearch_filters','{\"rendertype\":\"checkbox\",\"markAllCheckboxes\":\"0\",\"target_pid\":0,\"amount\":10,\"shownumberofresults\":\"1\",\"alphabeticalsorting\":0,\"hidden\":0,\"pid\":34,\"title\":\"Show only\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"alphabeticalsorting\\\":\\\"\\\",\\\"amount\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"markAllCheckboxes\\\":\\\"\\\",\\\"options\\\":\\\"\\\",\\\"rendertype\\\":\\\"\\\",\\\"shownumberofresults\\\":\\\"\\\",\\\"target_pid\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:37c8f0a5f51b180b553539a4ba22f33e'),
(86,1795348009,1,'BE',1,0,1,'tx_kesearch_indexerconfig','{\"type\":\"page\",\"index_content_with_restrictions\":\"no\",\"index_news_category_mode\":\"1\",\"index_use_page_tags\":\"0\",\"fileext\":\"pdf,ppt,doc,xls,docx,xlsx,pptx\",\"file_reference_fields\":\"media\",\"index_use_page_tags_for_files\":\"0\",\"index_page_doctypes\":\"1\",\"content_fields\":\"bodytext,subheader,header_link\",\"page_fields\":\"\",\"page_fields_hidden\":\"\",\"fal_storage\":\"0\",\"contenttypes\":\"text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline\",\"additional_tables\":\"[accordion]\\ntable = tx_bootstrappackage_accordion_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[tab]\\ntable = tx_bootstrappackage_tab_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[carousel]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_fullscreen]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_small]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[icon_group]\\ntable = tx_bootstrappackage_icon_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\n\\n[card_group]\\ntable = tx_bootstrappackage_card_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\nfields[] = link_title\\n\\n[timeline]\\ntable = tx_bootstrappackage_timeline_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\",\"hidden\":0,\"pid\":34,\"title\":\"Pages\",\"storagepid\":\"34\",\"startingpoints_recursive\":\"1\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:11382f33999b3ba5cfa81546397116be'),
(87,1795348009,1,'BE',1,0,2,'tx_kesearch_indexerconfig','{\"type\":\"news\",\"index_content_with_restrictions\":\"no\",\"index_news_category_mode\":\"1\",\"index_use_page_tags\":\"0\",\"fileext\":\"pdf,ppt,doc,xls,docx,xlsx,pptx\",\"file_reference_fields\":\"media\",\"index_use_page_tags_for_files\":\"0\",\"index_page_doctypes\":\"1\",\"content_fields\":\"bodytext,subheader,header_link\",\"page_fields\":\"\",\"page_fields_hidden\":\"\",\"fal_storage\":\"0\",\"contenttypes\":\"text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline\",\"additional_tables\":\"[accordion]\\ntable = tx_bootstrappackage_accordion_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[tab]\\ntable = tx_bootstrappackage_tab_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[carousel]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_fullscreen]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_small]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[icon_group]\\ntable = tx_bootstrappackage_icon_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\n\\n[card_group]\\ntable = tx_bootstrappackage_card_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\nfields[] = link_title\\n\\n[timeline]\\ntable = tx_bootstrappackage_timeline_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\",\"hidden\":0,\"pid\":34,\"title\":\"News\",\"storagepid\":\"34\",\"targetpid\":\"31\",\"startingpoints_recursive\":\"32\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":2}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:e9c59d805adb65b75c5f9ae69a7ee95b'),
(88,1795348009,1,'BE',1,0,9,'tt_content','{\"CType\":\"ke_search_pi1\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":16,\"sorting\":256,\"header\":\"Filter results\",\"pages\":\"34\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"MAIN\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"resultPage\\\">\\n                    <value index=\\\"vDEF\\\">16<\\/value>\\n                <\\/field>\\n                <field index=\\\"showTextInsteadOfResults\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"textForResults\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Type what you are looking for into the search field at the top of the page.&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"showNoResultsText\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"view\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"highlightSword\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultChars\\\">\\n                    <value index=\\\"vDEF\\\">200<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultsNumeration\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showResultUrl\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showDate\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"images\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"showTypeIcon\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showPageImages\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showNewsImages\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showFilePreview\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"pagebrowser\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"pagebrowserOnTop\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"pagebrowserAtBottom\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultsPerPage\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"maxPagesInPagebrowser\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"filter\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"filters\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":9}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:367f4f227870d8e2a11496a182574aa3'),
(89,1795348009,1,'BE',1,0,10,'tt_content','{\"CType\":\"ke_search_pi2\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":16,\"sorting\":128,\"header\":\"Search results\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"MAIN\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"loadFlexformsFromOtherCE\\\">\\n                    <value index=\\\"vDEF\\\">9<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":10}',0,'0400$vpXrqLCAGuB2w85UkB4ezd96Nu_zS1x9:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(90,1795368020,1,'BE',1,0,4,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Pay by mobile money: the receipt arrives on your phone.\",\"alternative\":\"A mobile phone confirming a payment, beside a stack of coins\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":5,\"uid_local\":\"11\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":4}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:cea5fcd7b97871880cfe3717d6b52ef4'),
(91,1795368020,1,'BE',1,0,5,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Every plot in the valuation roll has a rateable value.\",\"alternative\":\"Two houses on surveyed plots on a green hillside\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":6,\"uid_local\":\"12\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":5}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5f15a1453f67b933ed3314381f5d67e4'),
(92,1795368020,1,'BE',1,0,6,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"One permit a year covers trade, health and fire safety.\",\"alternative\":\"A shop with a striped awning and a framed business permit\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":7,\"uid_local\":\"13\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":6}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:768f9cd4e98812f969df7ebe17f11b50'),
(93,1795368020,1,'BE',1,0,7,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Parking on Beach Road is paid Monday to Saturday, 7:00 to 18:00.\",\"alternative\":\"Two cars parked beside a parking sign\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":8,\"uid_local\":\"14\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":7}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:117c97010b9af15cb554d115dba4e316'),
(94,1795368020,1,'BE',1,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Stalls at the central market on Market Street.\",\"alternative\":\"Two market stalls with fruit and vegetables\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":9,\"uid_local\":\"15\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":8}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(95,1795368020,1,'BE',1,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Clear your arrears before 30 June to have the interest waived.\",\"alternative\":\"A calendar with a ticked check mark beside it\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":10,\"uid_local\":\"16\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":9}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:729356755eb8ee035abf6b9b02e20c8f'),
(96,1795368020,1,'BE',1,0,10,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Mto Safi Town health centre, open Monday to Saturday.\",\"alternative\":\"A health centre with a red cross sign\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":11,\"uid_local\":\"17\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":10}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b34a074e38840d41041eaee66c42bb0d'),
(97,1795368020,1,'BE',1,0,11,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The river gives the town its name: Mto Safi means \\\"clean river\\\".\",\"alternative\":\"A river running through green land, with a water tower and a tap\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":12,\"uid_local\":\"18\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":11}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b70904b959c6d327947fc437df028f6f'),
(98,1795368020,1,'BE',1,0,12,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"A dhow leaves the old harbour at sunset.\",\"alternative\":\"A dhow sailing at sunset with a palm tree on the beach\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":12}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:fef2cecc4ff45c64d73fc27195ee5748'),
(99,1795368020,1,'BE',1,0,13,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Sunset over the old dhow harbour.\",\"alternative\":\"A dhow sailing at sunset with a palm tree on the beach\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":13}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5e1f4fea56ad8d21a419f2b59b059abf'),
(100,1795368020,1,'BE',1,0,14,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Mangoes, tomatoes and sukuma wiki at the central market.\",\"alternative\":\"Two market stalls with fruit and vegetables\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"15\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":14}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:2207c2b650522ebf0efd90eaad3962af'),
(101,1795368020,1,'BE',1,0,15,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The river mouth, where the mangrove boardwalk starts.\",\"alternative\":\"A river running through green land, with a water tower and a tap\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"18\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":15}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:53cbb769126fb106e07a09de5e196b60'),
(102,1795368020,1,'BE',1,0,16,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The municipal office, built in 1962, on Beach Road.\",\"alternative\":\"The municipal office with a flag on the roof\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":16}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5a9ade48273ee95d803333aed1c78820'),
(103,1795368020,1,'BE',1,0,17,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Budget forum in the municipal hall, Central ward.\",\"alternative\":\"Residents gathered in front of a board at a public forum\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":14,\"uid_local\":\"21\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":17}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:78ba90db28917b77e8d54ca398316d0e'),
(104,1795368020,1,'BE',1,0,18,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The municipal office on Beach Road.\",\"alternative\":\"The municipal office with a flag on the roof\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":15,\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":18}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:c9d27ac33ea45c5163a9ef7a25d8e7c7'),
(105,1795368020,1,'BE',1,0,19,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Log in with your eCitizen account.\",\"alternative\":\"A laptop showing a login form, beside a padlock\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":17,\"uid_local\":\"22\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":19}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7008e0248119dc3a255a0170bf6e9370'),
(106,1795368020,1,'BE',1,0,20,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Example image: replace it together with the text.\",\"alternative\":\"A web page with clear headings and a focused button, beside the accessibility symbol\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":18,\"uid_local\":\"23\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":20}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:97d0d1c7a42cd9603b2010379c1e4e4d'),
(107,1795368020,1,'BE',1,0,21,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Example image: replace it together with the text.\",\"alternative\":\"A shield with a padlock\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":19,\"uid_local\":\"24\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":21}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:bd8e6a36b477d61e04d92cfd10d00f96'),
(108,1795368020,1,'BE',1,0,22,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Requests are answered within 21 days.\",\"alternative\":\"A folder of documents and a magnifying glass\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":20,\"uid_local\":\"25\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":22}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:d6a5725e5b31cdd97b9c53c992e81850'),
(109,1795368020,1,'BE',1,0,23,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Bids go in a sealed envelope to the procurement office.\",\"alternative\":\"A building under construction with a crane, and a sealed envelope\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":21,\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":23}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a4b81cbb471961a3c12b21861b94f4e1'),
(110,1795368020,1,'BE',1,0,11,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":256,\"header\":\"Pay the municipality from wherever you are\",\"bodytext\":\"<p>Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.<\\/p>\\r\\n<p>Most of them can be paid by mobile money or by card in the <a href=\\\"t3:\\/\\/page?uid=17\\\">e-services portal<\\/a>, at any time of day. The cash office in the municipal office is open on working days.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":11}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7a14c618500ae24604910dfdd2f8ff12'),
(111,1795368020,1,'BE',1,0,12,'tt_content','{\"CType\":\"menu_subpages\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":512,\"header\":\"Payments and fees\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":12}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b13bbccfb8e2fc277be02db62485ced6'),
(112,1795368020,1,'BE',1,0,13,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":256,\"header\":\"How your land rates are calculated\",\"bodytext\":\"<p>Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.<\\/p>\\r\\n<p>Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":13}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:aa58d78b4f5fe95c0d2d1cb36d041737'),
(113,1795368020,1,'BE',1,0,14,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":512,\"header\":\"Rates for 2026\",\"bodytext\":\"Land use|Rate|Minimum per plot and year\\nResidential|0.5 % of the rateable value|KES 1,500\\nCommercial|1.2 % of the rateable value|KES 1,500\\nAgricultural|0.2 % of the rateable value|KES 1,500\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":14}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:338e104baa774eacaec42da729015b5f'),
(114,1795368020,1,'BE',1,0,15,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":768,\"header\":\"How to pay\",\"bodytext\":\"<p>Pay by mobile money, by card in the <a href=\\\"t3:\\/\\/page?uid=17\\\">e-services portal<\\/a>, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":15}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:cb118fde3da18e67b21a92b60bb8cbda'),
(115,1795368020,1,'BE',1,0,16,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":256,\"header\":\"One permit for your business\",\"bodytext\":\"<p>Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.<\\/p>\\r\\n<p>Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":16}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:43f02d513e41a72738b96558f7ee9015'),
(116,1795368020,1,'BE',1,0,17,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":512,\"header\":\"What you need to apply\",\"bodytext\":\"Your national ID or passport\\nThe KRA PIN of the business\\nThe plot number of the premises\\nA description of the activity and the number of employees\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":17}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:017157395cc6da9e5d2911de6dfd4b9e'),
(117,1795368020,1,'BE',1,0,18,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"26\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":8,\"sorting\":256,\"header\":\"Parking in the town centre\",\"bodytext\":\"<p>Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.<\\/p>\\r\\n<p>Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":18}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0a64be1ae1f9096cc345beb76e5e2095'),
(118,1795368020,1,'BE',1,0,19,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":8,\"sorting\":512,\"header\":\"Fees\",\"bodytext\":\"Vehicle|Per day|Per month\\nCar|KES 100|KES 2,000\\nPick-up and van|KES 150|KES 3,000\\nLorry|KES 300|KES 6,000\\nMotorcycle (boda boda)|KES 30|KES 500\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":19}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(119,1795368020,1,'BE',1,0,20,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":9,\"sorting\":256,\"header\":\"Selling at the municipal markets\",\"bodytext\":\"<p>Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.<\\/p>\\r\\n<p>Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":20}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(120,1795368020,1,'BE',1,0,21,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":9,\"sorting\":512,\"header\":\"Fees\",\"bodytext\":\"|Fee\\nStall, per month|KES 1,200\\nOpen space, per day|KES 50\\nFish market, per day|KES 80\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":21}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7fd72e21409e45562c51e7581fc2cb0d'),
(121,1795368020,1,'BE',1,0,22,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"26\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":256,\"header\":\"Interest waived when you clear your arrears\",\"bodytext\":\"<p>Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.<\\/p>\\r\\n<p>Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":22}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:1a929832156241f61c37ce68bcae4a3c'),
(122,1795368020,1,'BE',1,0,23,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":512,\"header\":\"How it works\",\"bodytext\":\"Ask for a statement of your arrears\\nApply for the waiver with the statement\\nPay the arrears without the interest within 30 days of the approval\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":23}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0cf00ee1adffc41f8b3231c0de35256e'),
(123,1795368020,1,'BE',1,0,24,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":11,\"sorting\":256,\"header\":\"Health services close to home\",\"bodytext\":\"<p>The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.<\\/p>\\r\\n<p>For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":24}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:94bb7a1dbcc4ac71f45ee11546313fe2'),
(124,1795368020,1,'BE',1,0,25,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":11,\"sorting\":512,\"header\":\"Health centres\",\"bodytext\":\"Health centre|Ward|Opening hours\\nMto Safi Town|Central|Mon\\u2013Sat 7:00\\u201319:00\\nPwani|Beach|Mon\\u2013Fri 8:00\\u201317:00\\nKijiji|Upper River|Mon\\u2013Fri 8:00\\u201317:00\\nMnarani|Mnarani|Mon\\u2013Fri 8:00\\u201317:00\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":25}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:581bf77acde559fe457e0d401d2ada7b'),
(125,1795368020,1,'BE',1,0,26,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":256,\"header\":\"A clean river for everyone\",\"bodytext\":\"<p>Mto Safi means \\\"clean river\\\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":26}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f6bb218c440a87df0e0eb5986e28af41'),
(126,1795368020,1,'BE',1,0,27,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":512,\"header\":\"Water connection\",\"bodytext\":\"<p>To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.<\\/p>\\r\\n<p>To report a leak or a burst pipe, call +254 700 000 001 at any time.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":27}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:9c3671c42eb2c0522de6952ddc52c9a7'),
(127,1795368020,1,'BE',1,0,28,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":768,\"header\":\"Waste collection\",\"bodytext\":\"Town centre: Monday and Thursday\\nBeach and Mnarani: Tuesday and Friday\\nUpper River: Wednesday and Saturday\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":28}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b5d015227f2b36f7786e2ff963ca9d51'),
(128,1795368020,1,'BE',1,0,29,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":256,\"header\":\"Karibu Mto Safi\",\"bodytext\":\"<p>White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.<\\/p>\\r\\n<p>The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under <a href=\\\"t3:\\/\\/page?uid=7\\\">Single business permit<\\/a>.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":29}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:12090f8e2b698e14ec860eca10ce232c'),
(129,1795368020,1,'BE',1,0,30,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":512,\"header\":\"Places to visit\",\"bodytext\":\"The dhow harbour and the fish market at sunrise\\nThe mangrove boardwalk at the river mouth\\nMto Safi beach and the coral garden\\nThe old town with its carved doors\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":30}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f6d670f6f6a9a0aecc0bb542c370acdf'),
(130,1795368020,1,'BE',1,0,31,'tt_content','{\"CType\":\"image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":768,\"header\":\"Impressions of Mto Safi\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":31}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a338b89fc8d0d789df4b1fd4d37a174b'),
(131,1795368020,1,'BE',1,0,32,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":14,\"sorting\":256,\"header\":\"Have your say on the budget\",\"bodytext\":\"<p>Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.<\\/p>\\r\\n<p>You can also send your views in writing to the clerk until 15 May.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":32}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:eeb3ef2adec88a8b5b3e3c510b74be1d'),
(132,1795368020,1,'BE',1,0,33,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":14,\"sorting\":512,\"header\":\"Forum dates\",\"bodytext\":\"Ward|Date|Place\\nCentral|4 May, 10:00|Municipal hall\\nBeach|6 May, 10:00|Pwani primary school\\nUpper River|8 May, 14:00|Kijiji social hall\\nMnarani|11 May, 10:00|Mnarani chief\'s camp\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":33}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:c1c3d2254ecfaef40b15a18e94a89b96'),
(133,1795368020,1,'BE',1,0,34,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":256,\"header\":\"Visit us\",\"bodytext\":\"<p>Mto Safi Municipality<br \\/>Municipal Office<br \\/>Beach Road 1<br \\/>P.O. Box 123, Mto Safi<\\/p>\\r\\n<p>Phone: <a href=\\\"tel:+254700000000\\\">+254 700 000 000<\\/a><br \\/>Email: <a href=\\\"mailto:info@mtosafi.example\\\">info@mtosafi.example<\\/a><\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":34}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5d9f35f4f50ff546dc3085666d071b48'),
(134,1795368020,1,'BE',1,0,35,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":512,\"header\":\"Opening hours\",\"bodytext\":\"Days|Hours\\nMon\\u2013Thu|8:00\\u201317:00\\nFriday|8:00\\u201313:00, 14:00\\u201317:00\\nSat, Sun|Closed\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":35}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:d31fbabb978b029b9ff62ab107e0a25e'),
(135,1795368020,1,'BE',1,0,36,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":768,\"header\":\"Report a problem\",\"bodytext\":\"<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\\\"mailto:report@mtosafi.example\\\">report@mtosafi.example<\\/a>, and say where it is.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":36}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:6fdd460ee24b22c6f60683a1eee4989a'),
(136,1795368020,1,'BE',1,0,37,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":17,\"sorting\":256,\"header\":\"Your municipal services online\",\"bodytext\":\"<p>In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.<\\/p>\\r\\n<p>Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":37}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:63988be2047e9f9c26151c5b9b4770d7'),
(137,1795368020,1,'BE',1,0,38,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":18,\"sorting\":256,\"header\":\"Example text\",\"bodytext\":\"<p>This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.<\\/p>\\r\\n<p>The design of this site targets WCAG 2.1 level AA.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":38}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:4bdce2eccaa2dfa57eb92d16572012a4'),
(138,1795368020,1,'BE',1,0,39,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":19,\"sorting\":256,\"header\":\"Example text\",\"bodytext\":\"<p>This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":39}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:eb04e3ff75360f80fc27ed5d3e94f482'),
(139,1795368020,1,'BE',1,0,40,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":20,\"sorting\":256,\"header\":\"Ask for the information we hold\",\"bodytext\":\"<p>Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.<\\/p>\\r\\n<p>We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":40}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f63ce2811b6be061690bfdf008a41f07'),
(140,1795368020,1,'BE',1,0,41,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":20,\"sorting\":512,\"header\":\"Published without a request\",\"bodytext\":\"The budget and the annual accounts\\nThe valuation roll\\nThe minutes of the municipal board\\nTenders and the contracts awarded\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":41}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0d86f780a4565c319d6988991b035f3a'),
(141,1795368020,1,'BE',1,0,42,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":21,\"sorting\":256,\"header\":\"Doing business with the municipality\",\"bodytext\":\"<p>The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":42}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5e996be55a352bc1f4f3f871c802dcec'),
(142,1795368020,1,'BE',1,0,43,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":21,\"sorting\":512,\"header\":\"Open tenders\",\"bodytext\":\"Number|Subject|Closes\\nMSM\\/T\\/01\\/2026|Resurfacing of Market Street|12 June\\nMSM\\/T\\/02\\/2026|Solar street lights, Beach ward|19 June\\nMSM\\/T\\/03\\/2026|Waste collection vehicles (2)|26 June\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":43}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:9390101edeadec5344c252f3b3b98ec9'),
(143,1795369027,2,'BE',1,0,15,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:c97934f122918253f51c81fbe45fd105'),
(144,1795369027,1,'BE',1,0,44,'tt_content','{\"CType\":\"form_formframework\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":128,\"header\":\"Write to us\",\"subheader\":\"The right department answers within five working days.\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">EXT:mtosafi_sitepackage\\/Resources\\/Private\\/Forms\\/contact.form.yaml<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795369027,\"t3ver_stage\":0,\"tstamp\":1795369027,\"uid\":44}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:3b272544b7c1a9f5690a42a5b760dca9'),
(145,1795369027,2,'BE',1,0,34,'tt_content','{\"oldRecord\":{\"colPos\":0,\"imageorient\":25,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"imageorient\":\"0\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:5d9f35f4f50ff546dc3085666d071b48'),
(146,1795369027,2,'BE',1,0,35,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:d31fbabb978b029b9ff62ab107e0a25e'),
(147,1795369027,2,'BE',1,0,36,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:6fdd460ee24b22c6f60683a1eee4989a'),
(148,1795372569,1,'BE',1,0,35,'pages','{\"doktype\":\"1\",\"slug\":\"\\/events\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3264,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Events\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":35}',0,'0400$Q3782IGoGjQ0KNvZnsH7Kn0yTjRNYEg-:d58411788d5a726dba77a4228008d89f'),
(149,1795372569,1,'BE',1,0,36,'pages','{\"doktype\":\"1\",\"slug\":\"\\/events\\/event\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":35,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Event\",\"nav_hide\":1,\"backend_layout\":\"pagets__Article\",\"no_search\":1,\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":36}',0,'0400$Q3782IGoGjQ0KNvZnsH7Kn0yTjRNYEg-:baa7a09b75230872aacb0cfcf5051237'),
(150,1795372569,1,'BE',1,0,8,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"beach-clean-up-day\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Beach clean-up day\",\"datetime\":1794715200,\"event_end\":1794729600,\"location_simple\":\"Public beach, meeting point at the lifeguard tower\",\"categories\":\"1\",\"teaser\":\"Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.\",\"bodytext\":\"<p>Residents, schools and businesses clean the beach together. Gloves, bags and water are provided. The cleanest group wins a tree for its school.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 7:00\\u201311:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":8}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:ff635a07b31923a6d7cd863a31313787'),
(151,1795372569,1,'BE',1,0,9,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"public-participation-forum-budget-2027-28\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Public participation forum: budget 2027\\/28\",\"datetime\":1795330800,\"event_end\":1795341600,\"location_simple\":\"Municipal hall, Beach Road 1\",\"categories\":\"1\",\"teaser\":\"Municipal hall, 10:00. Every resident may speak.\",\"bodytext\":\"<p>Every resident may speak. The forum is held in Kiswahili and English. Sign language interpretation is available on request until 15 November.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 10:00\\u201313:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":9}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:ea59bb16023727fc0c0128366bbe4ed3'),
(152,1795372569,1,'BE',1,0,10,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"youth-job-and-skills-fair\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Youth job and skills fair\",\"datetime\":1796450400,\"event_end\":1796472000,\"location_simple\":\"Mto Safi Polytechnic\",\"categories\":\"1\",\"teaser\":\"Mto Safi Polytechnic, 9:00\\u201315:00. Bring copies of your CV and certificates.\",\"bodytext\":\"<p>Employers from tourism, fishing, construction and IT present jobs and apprenticeships. Bring copies of your CV and certificates.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 9:00\\u201315:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Recommended, at the Education Office<\\/p>\",\"tx_mtosafisitepackage_registration_link\":\"t3:\\/\\/page?uid=15\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":10}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:74d687ec564a59b0360c2264c05d7a29'),
(153,1795372569,1,'BE',1,0,11,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"jamhuri-day-celebrations\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Jamhuri Day celebrations\",\"datetime\":1797055200,\"event_end\":1797073200,\"location_simple\":\"Municipal grounds\",\"teaser\":\"Municipal grounds, 9:00\\u201314:00. Flag raising, speeches, school choirs and traditional dances.\",\"bodytext\":\"<p>The municipality celebrates Jamhuri Day with the flag raising, speeches, school choirs and traditional dances.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 9:00\\u201314:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":11}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:a7708bdfd76f24b1743f6d30ac679090'),
(154,1795372569,1,'BE',1,0,12,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"festive-market-at-the-jetty\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Festive market at the jetty\",\"datetime\":1797685200,\"event_end\":1798138800,\"location_simple\":\"Jetty and fish market\",\"categories\":\"1\",\"teaser\":\"Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.\",\"bodytext\":\"<p>Food, crafts and music every evening before Christmas.<\\/p>\\r\\n<p><strong>Time:<\\/strong> Every evening, 16:00\\u201322:00<br \\/><strong>Cost:<\\/strong> Free entry<br \\/><strong>Registration:<\\/strong> Traders apply for a stall at the Trade &amp; Markets Office until 1 December<\\/p>\",\"tx_mtosafisitepackage_registration_link\":\"t3:\\/\\/page?uid=9\",\"tx_mtosafisitepackage_registration_label\":\"Apply for a stall\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":12}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:6c6005b66e9191f57d7fa62294c401ca'),
(155,1795372569,1,'BE',1,0,13,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"land-rates-help-desk\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Land rates help desk\",\"datetime\":1800252000,\"event_end\":1806494400,\"location_simple\":\"Municipal office, cash office\",\"categories\":\"1\",\"teaser\":\"Monday to Friday, 9:00\\u201315:00, at the cash office: help with your valuation notice and land rates.\",\"bodytext\":\"<p>Staff of the Revenue Department help you read your valuation notice, calculate your land rates and set up payment by mobile money.<\\/p>\\r\\n<p><strong>Time:<\\/strong> Monday to Friday, 9:00\\u201315:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":13}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:b01640b8cfd71f6a58c6ac688cc2a238'),
(156,1795372569,1,'BE',1,0,45,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":512,\"header\":\"Events\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">asc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\">today<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">36<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">events<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"extraEntryEventNews\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.eventRestriction\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":45}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:ef25e3b02a873bda1a67249f52737086'),
(157,1795372569,1,'BE',1,0,46,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":35,\"sorting\":256,\"header\":\"Upcoming events\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">asc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\">today<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">36<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">eventsPage<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"extraEntryEventNews\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.eventRestriction\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":46}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:e98a5e9f23ca3235102a132a15092d64'),
(158,1795372569,1,'BE',1,0,47,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":36,\"sorting\":256,\"header\":\"Event\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":47}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:4252955adc057961e279f23960919217');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1795330974,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lina.wolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1795330980,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lwolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(3,1795332992,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(4,1795332999,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1795333001,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(6,1795333004,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"4\"}',0,0,'',0,'','info',NULL,NULL),
(7,1795333006,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"5\"}',0,0,'',0,'','info',NULL,NULL),
(8,1795333009,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"6\"}',0,0,'',0,'','info',NULL,NULL),
(9,1795333011,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"7\"}',0,0,'',0,'','info',NULL,NULL),
(10,1795333022,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(11,1795333022,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(12,1795333022,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(13,1795333042,1,3,2,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(14,1795333042,1,3,4,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":4}',2,0,'',0,'','info',NULL,NULL),
(15,1795333042,1,3,3,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":3}',2,0,'',0,'','info',NULL,NULL),
(16,1795333042,1,3,2,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":2}',1,0,'',0,'','info',NULL,NULL),
(17,1795334294,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1795334294,1,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":6,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(19,1795334294,1,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":7,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(20,1795334294,1,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":8,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(21,1795334294,1,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":9,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(22,1795334294,1,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":10,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(23,1795334294,1,1,11,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(24,1795334294,1,1,12,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(25,1795334294,1,1,13,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":13,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1795334294,1,1,14,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":14,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(27,1795334294,1,1,15,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":15,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(28,1795334294,1,1,16,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(29,1795334294,1,1,17,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":17,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(30,1795334294,1,1,18,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":18,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(31,1795334294,1,1,19,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":19,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(32,1795334294,1,1,20,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(33,1795334294,1,1,21,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(34,1795334294,1,1,22,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(35,1795334294,1,1,23,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(36,1795334294,1,1,24,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":24,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(37,1795334294,1,1,25,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":25,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(38,1795334294,1,1,26,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":26,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(39,1795334294,1,1,27,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":27,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(40,1795334294,1,1,28,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":28,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(41,1795334294,1,1,29,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":29,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(42,1795334294,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"40\"}',0,0,'',0,'','info',NULL,NULL),
(43,1795334294,1,2,24,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":24,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(44,1795334294,1,2,25,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":25,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(45,1795334294,1,2,26,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":26,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(46,1795334294,1,2,27,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":27,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(47,1795334294,1,2,28,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":28,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(48,1795334294,1,2,29,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":29,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(49,1795334294,1,3,1,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(51,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(52,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(53,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(54,1795336956,1,1,30,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":30,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(55,1795336956,1,1,31,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":31,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(56,1795336956,1,1,32,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":32,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(57,1795336956,1,1,1,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(58,1795336956,1,1,2,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(59,1795336956,1,1,3,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(60,1795336956,1,1,4,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(61,1795336956,1,1,5,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(62,1795336956,1,1,6,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(63,1795336956,1,1,7,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(64,1795336956,1,1,8,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":8,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(65,1795336956,1,1,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(66,1795336956,1,1,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(67,1795336956,1,1,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(68,1795336956,1,1,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(69,1795336956,1,1,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(70,1795336956,1,1,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(71,1795336956,1,1,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(72,1795336956,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(73,1795336956,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":4,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(74,1795336956,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":5,\"pid\":31}',31,0,'',0,'','info',NULL,NULL),
(75,1795336956,1,2,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(76,1795336956,1,2,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(77,1795336956,1,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(78,1795336956,1,2,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(79,1795336956,1,2,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(80,1795336956,1,2,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(81,1795336956,1,2,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(82,1795343750,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1795343750,1,1,1,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(84,1795343750,1,1,2,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(85,1795343750,1,1,3,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(86,1795343750,1,1,4,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(87,1795343750,1,1,5,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(88,1795343750,1,1,6,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(89,1795343750,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(90,1795344511,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(91,1795344511,1,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(92,1795344511,1,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(93,1795344511,1,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(94,1795344511,1,1,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(95,1795344511,1,1,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(96,1795344511,1,1,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(97,1795344511,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(98,1795344511,1,2,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(99,1795344511,1,2,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(100,1795344511,1,2,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(101,1795345582,1,1,33,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":33,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(102,1795345582,1,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":8,\"pid\":33}',33,0,'',0,'','info',NULL,NULL),
(103,1795348009,1,1,34,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":34,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(104,1795348009,1,2,16,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":16,\"history\":\"80\"}',1,0,'',0,'','info',NULL,NULL),
(105,1795348009,1,2,33,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":33,\"history\":\"81\"}',1,0,'',0,'','info',NULL,NULL),
(106,1795348009,1,2,31,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":31,\"history\":\"82\"}',30,0,'',0,'','info',NULL,NULL),
(107,1795348009,1,1,1,'tx_kesearch_filteroptions',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filteroptions\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(108,1795348009,1,1,2,'tx_kesearch_filteroptions',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filteroptions\",\"uid\":2,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(109,1795348009,1,1,1,'tx_kesearch_filters',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filters\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(110,1795348009,1,2,1,'tx_kesearch_filters',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_kesearch_filters\",\"uid\":1,\"history\":0}',34,0,'',0,'','info',NULL,NULL),
(111,1795348009,1,1,1,'tx_kesearch_indexerconfig',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_indexerconfig\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(112,1795348009,1,1,2,'tx_kesearch_indexerconfig',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_indexerconfig\",\"uid\":2,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(113,1795348009,1,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":9,\"pid\":16}',16,0,'',0,'','info',NULL,NULL),
(114,1795348009,1,1,10,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":10,\"pid\":16}',16,0,'',0,'','info',NULL,NULL),
(115,1795348011,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n31 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n0 pages have been indexed. \n\n30 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 87 ms\nNews\n7 News and 0 related files have been indexed.\n\n\nIndexing process took 20 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 1 ms.\n\nFinished\nIndexing finished at 11/22/26, 12:46:52 (took 1 seconds).\nIndex contains 7 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(116,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(117,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(118,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(119,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(120,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(121,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(122,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(123,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(124,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(125,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(126,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(127,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(128,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(129,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(130,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(131,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(132,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(133,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(134,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(135,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(136,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(137,1795348709,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(138,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(139,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(140,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(141,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(142,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(143,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(144,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(145,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(146,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(147,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(148,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(149,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(150,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(151,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(152,1795365530,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(153,1795365530,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(154,1795365714,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(155,1795368020,1,1,4,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(156,1795368020,1,1,5,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(157,1795368020,1,1,6,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(158,1795368020,1,1,7,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(159,1795368020,1,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(160,1795368020,1,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(161,1795368020,1,1,10,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":10,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(162,1795368020,1,1,11,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":11,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(163,1795368020,1,1,12,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":12,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(164,1795368020,1,1,13,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":13,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(165,1795368020,1,1,14,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":14,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(166,1795368020,1,1,15,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":15,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(167,1795368020,1,1,16,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":16,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(168,1795368020,1,1,17,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":17,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(169,1795368020,1,1,18,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":18,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(170,1795368020,1,1,19,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":19,\"pid\":17}',17,0,'',0,'','info',NULL,NULL),
(171,1795368020,1,1,20,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":18}',18,0,'',0,'','info',NULL,NULL),
(172,1795368020,1,1,21,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":19}',19,0,'',0,'','info',NULL,NULL),
(173,1795368020,1,1,22,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(174,1795368020,1,1,23,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(175,1795368020,1,1,11,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":11,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(176,1795368020,1,1,12,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":12,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(177,1795368020,1,1,13,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":13,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(178,1795368020,1,1,14,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":14,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(179,1795368020,1,1,15,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":15,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(180,1795368020,1,1,16,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":16,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(181,1795368020,1,1,17,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":17,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(182,1795368020,1,1,18,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(183,1795368020,1,1,19,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":19,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(184,1795368020,1,1,20,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(185,1795368020,1,1,21,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":21,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(186,1795368020,1,1,22,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":22,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(187,1795368020,1,1,23,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":23,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(188,1795368020,1,1,24,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":24,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(189,1795368020,1,1,25,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":25,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(190,1795368020,1,1,26,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":26,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(191,1795368020,1,1,27,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":27,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(192,1795368020,1,1,28,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":28,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(193,1795368020,1,1,29,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":29,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(194,1795368020,1,1,30,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":30,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(195,1795368020,1,1,31,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":31,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(196,1795368020,1,1,32,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":32,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(197,1795368020,1,1,33,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":33,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(198,1795368020,1,1,34,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(199,1795368020,1,1,35,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":35,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(200,1795368020,1,1,36,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":36,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(201,1795368020,1,1,37,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":37,\"pid\":17}',17,0,'',0,'','info',NULL,NULL),
(202,1795368020,1,1,38,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":38,\"pid\":18}',18,0,'',0,'','info',NULL,NULL),
(203,1795368020,1,1,39,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":39,\"pid\":19}',19,0,'',0,'','info',NULL,NULL),
(204,1795368020,1,1,40,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":40,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(205,1795368020,1,1,41,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":41,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(206,1795368020,1,1,42,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":42,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(207,1795368020,1,1,43,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":43,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(208,1795368020,1,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":11,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(209,1795368020,1,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":13,\"history\":0}',6,0,'',0,'','info',NULL,NULL),
(210,1795368020,1,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',7,0,'',0,'','info',NULL,NULL),
(211,1795368020,1,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"history\":0}',8,0,'',0,'','info',NULL,NULL),
(212,1795368020,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(213,1795368020,1,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":22,\"history\":0}',10,0,'',0,'','info',NULL,NULL),
(214,1795368020,1,2,24,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":24,\"history\":0}',11,0,'',0,'','info',NULL,NULL),
(215,1795368020,1,2,26,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":26,\"history\":0}',12,0,'',0,'','info',NULL,NULL),
(216,1795368020,1,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',13,0,'',0,'','info',NULL,NULL),
(217,1795368020,1,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":31,\"history\":0}',13,0,'',0,'','info',NULL,NULL),
(218,1795368020,1,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',14,0,'',0,'','info',NULL,NULL),
(219,1795368020,1,2,34,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"history\":0}',15,0,'',0,'','info',NULL,NULL),
(220,1795368020,1,2,37,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":37,\"history\":0}',17,0,'',0,'','info',NULL,NULL),
(221,1795368020,1,2,38,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":38,\"history\":0}',18,0,'',0,'','info',NULL,NULL),
(222,1795368020,1,2,39,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":39,\"history\":0}',19,0,'',0,'','info',NULL,NULL),
(223,1795368020,1,2,40,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":40,\"history\":0}',20,0,'',0,'','info',NULL,NULL),
(224,1795368020,1,2,42,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":42,\"history\":0}',21,0,'',0,'','info',NULL,NULL),
(225,1795368024,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n31 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n16 pages have been indexed. \n\n14 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 182 ms\nNews\n7 News and 0 related files have been indexed.\n\n\nIndexing process took 34 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 2 ms.\n\nFinished\nIndexing finished at 11/22/26, 18:20:24 (took 0 seconds).\nIndex contains 23 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(226,1795369027,1,2,15,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":15,\"history\":\"143\"}',1,0,'',0,'','info',NULL,NULL),
(227,1795369027,1,1,44,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":44,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(228,1795369027,1,2,34,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"history\":\"145\"}',15,0,'',0,'','info',NULL,NULL),
(229,1795369027,1,2,35,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":35,\"history\":\"146\"}',15,0,'',0,'','info',NULL,NULL),
(230,1795369027,1,2,36,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":36,\"history\":\"147\"}',15,0,'',0,'','info',NULL,NULL),
(231,1795369943,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: The \"TYPO3\\CMS\\Form\\Mvc\\Configuration\\YamlSource\" service or alias has been removed or inlined when the container was compiled. You should either make it public, or stop using the container directly and use dependency injection instead. | Symfony\\Component\\DependencyInjection\\Exception\\ServiceNotFoundException thrown in file /var/www/html/vendor/symfony/dependency-injection/Container.php in line 243',5,'php','','',-1,0,'',0,'','error',NULL,NULL),
(232,1795372569,1,1,35,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":35,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(233,1795372569,1,1,36,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":36,\"pid\":35}',35,0,'',0,'','info',NULL,NULL),
(234,1795372569,1,1,8,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":8,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(235,1795372569,1,1,9,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":9,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(236,1795372569,1,1,10,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":10,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(237,1795372569,1,1,11,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":11,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(238,1795372569,1,1,12,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":12,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(239,1795372569,1,1,13,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":13,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(240,1795372569,1,1,45,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":45,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(241,1795372569,1,1,46,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":46,\"pid\":35}',35,0,'',0,'','info',NULL,NULL),
(242,1795372569,1,1,47,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":47,\"pid\":36}',36,0,'',0,'','info',NULL,NULL),
(243,1795372572,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n33 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n16 pages have been indexed. \n\n16 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 142 ms\nNews\n13 News and 0 related files have been indexed.\n\n\nIndexing process took 50 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 1 ms.\n\nFinished\nIndexing finished at 11/22/26, 19:36:12 (took 0 seconds).\nIndex contains 29 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(244,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(245,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(246,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(247,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(248,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('029d857185cc6f0a9a8ab7e9d2ef95f3','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',3,0,'tx_mtosafisitepackage_tile',4,'',0,0,2147483647,0,0,''),
('060db93adbf8c80a5c341ef5bfea77c8','sys_file_reference',22,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',25,'',0,0,2147483647,0,0,''),
('07db517ae886f8dc10be0c2ee0997e25','tt_content',47,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('08d2716299a7edd920edfd9427d93525','tx_mtosafisitepackage_tile',1,'link',0,0,2147483647,0,'','typolink','7f69a1aa54e9db8a5ae0d952977b4cd9:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('0bb42ee7906264eb370da9ee8c5cc360','tt_content',31,'image',0,0,2147483647,0,'','','',3,0,'sys_file_reference',16,'',0,0,2147483647,0,0,''),
('17d5bf3449012f6032742f906e754655','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',12,'',0,0,2147483647,0,0,''),
('19682de1c89f1c9f7f3c1f90896eef4d','tt_content',46,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('1a1b33ad44894354a18d0d45ff698eff','tx_kesearch_filters',1,'options',0,0,2147483647,0,'','','',0,0,'tx_kesearch_filteroptions',1,'',0,0,2147483647,0,0,''),
('1b2ed6872931f6bf2631618fb6288e67','tt_content',36,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('1c18b2c4fcfecf16eaa9eeff06c60c74','tt_content',45,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('1dd0e0354b52fbddbadff8931116243c','tx_kesearch_indexerconfig',2,'targetpid',0,0,2147483647,0,'','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('1fde6c7fd92bd9d8eafb8e741be22840','tt_content',4,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('20f5efef03fe691570c3d2cd2fc393cf','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('220bc45f86eae522c66204eabb90e306','tx_mtosafisitepackage_slide',3,'link',0,0,2147483647,0,'','typolink','bf1e9cf52cce365bffb23721ba63b67b:0',0,0,'pages',14,'',0,0,2147483647,0,0,''),
('222baf9b25427e410e9c39f6ec6f2b7f','sys_category',5,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',5,'categories',0,0,2147483647,0,1,''),
('225e9febc94acfa52497bc219ce6d31b','sys_file_reference',21,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',24,'',0,0,2147483647,0,0,''),
('2386acca52c4f18cefdc6b906df671e9','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',13,'',0,0,2147483647,0,0,''),
('2780872b4d83ef806371ff889b7799cc','tx_kesearch_indexerconfig',2,'startingpoints_recursive',0,0,2147483647,0,'','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('30ddbb32f1c31a45277a635e878cef2e','tt_content',31,'image',0,0,2147483647,0,'','','',1,0,'sys_file_reference',14,'',0,0,2147483647,0,0,''),
('313e461a539f46cf2465487a128c051c','tx_mtosafisitepackage_tile',4,'link',0,0,2147483647,0,'','typolink','e34f7e18c8dc8d47f12cbbc9ec0587df:0',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('33be7c7c27d73f38622f81fcce501fee','tt_content',9,'pages',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('37aaef61fe9da71c3d2158c1cc012f0c','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('397497f0d911d5b8550159f504d01194','tt_content',39,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',21,'',0,0,2147483647,0,0,''),
('39f11610b54678a8af0feb57210bb43f','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',5,0,'tx_mtosafisitepackage_tile',6,'',0,0,2147483647,0,0,''),
('3d2896994c41d754a6409b530412c846','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('3dd61fadc472ee3f5bb4d4e7e08a79a8','sys_file_reference',10,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',17,'',0,0,2147483647,0,0,''),
('415de9b0331ee3670c2a9526f1affae8','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',15,'',0,0,2147483647,0,0,''),
('4402b32b58c950bb2cb91e2f1ed8bba8','pages',27,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',19,'',0,0,2147483647,0,0,''),
('4502c999e76beaad402d5f8db6b86f25','tx_kesearch_indexerconfig',2,'storagepid',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('4757b12b90def24df1880d8a111e43d5','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_tile',2,'',0,0,2147483647,0,0,''),
('47d351b61ea29efbe541d4778add7530','tx_kesearch_indexerconfig',1,'storagepid',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('480b46ad69572f59b62b9a26b54a746b','sys_file_reference',17,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',21,'',0,0,2147483647,0,0,''),
('4b8649c4ac802e70df9887d61abb4741','tt_content',47,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('4c50552ba214ce72d9d786f4de43b368','sys_category',7,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',7,'categories',0,0,2147483647,0,1,''),
('505ac3050b1043f117f21c125ce5f915','tx_mtosafisitepackage_tile',6,'link',0,0,2147483647,0,'','typolink','7f897eb5d5b640dce3bedcdb56c2d987:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('5212307d56a434cda710fd02e8113f82','tt_content',34,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'+254700000000'),
('529b5cce1a84064c904a6c430d56ecd1','sys_file_reference',16,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('5429966bdbff8fa90d5c254833c7756c','tt_content',15,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('642b702d5002f29241f7c501f3d28cf1','tt_content',34,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('655053dcf91ff4de04e0e7b0935ac0dc','tx_mtosafisitepackage_tile',5,'link',0,0,2147483647,0,'','typolink','a01eec11a0a46a8e86685cb8ec780ef1:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('679f66b060ba12c8427fbf2a710b0fd9','pages',29,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',21,'',0,0,2147483647,0,0,''),
('68275e712ee6626930e72c076be4577e','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('6e9153c8043ab894a418dc6522791810','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',1,'',0,0,2147483647,0,0,''),
('7106458409a1a556fb1c60516e842efb','tt_content',18,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',7,'',0,0,2147483647,0,0,''),
('7140c40420dd9126c54556b8ad8d9764','tt_content',45,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',36,'',0,0,2147483647,0,0,''),
('71bd7ba8149169134006c9ca870e2006','sys_file_reference',12,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('75c3df5c09e24b3c2c96c640da355e01','tx_mtosafisitepackage_tile',2,'link',0,0,2147483647,0,'','typolink','087881d39e3c58af824e5fb90e661a8e:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('77491718585910205641ef73b044aa19','sys_category',1,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',1,'categories',0,0,2147483647,0,1,''),
('777a432b0e62b25c1b84f398c69e5955','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',1,'',0,0,2147483647,0,0,''),
('77d010084c16ba8308f7be5f1b76c604','tx_mtosafisitepackage_slide',1,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('7948bfb5fb5858eeb7961d595c01ddf5','tt_content',4,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('79562c633d5c093af983840b815f2b9e','sys_category',8,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',10,'categories',0,0,2147483647,0,1,''),
('7ab46b1e874e6100a8c759c1a43fea3f','sys_category',6,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',8,'categories',0,0,2147483647,0,1,''),
('7b21b2228a8fd7ec83265fb900741d46','sys_file_reference',11,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',18,'',0,0,2147483647,0,0,''),
('7e694f9466d958648b1c103f07e2eddd','pages',26,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('84ad13f6b52a918039bc14cd87042e29','tt_content',9,'pi_flexform',0,0,2147483647,0,'MAIN/lDEF/resultPage/vDEF/','','',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('86aa77750d3d62492d28cf72adb0c6ec','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',4,0,'tx_mtosafisitepackage_tile',5,'',0,0,2147483647,0,0,''),
('8a594b57465e8a76202e1a34021ac90f','tt_content',42,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',23,'',0,0,2147483647,0,0,''),
('8c33249d3a9ac4708bfc8836b16a1c9b','tt_content',16,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('91055865169ba9d2b0e9094d3dfcffd4','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('92d50c408e8ee6009a404279825f6f70','sys_category',4,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',13,'categories',0,0,2147483647,0,1,''),
('960e459a1c93d12d716e538716e03756','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_slide',3,'',0,0,2147483647,0,0,''),
('9f3a8d10770ff46f06c3be7aa44e54c5','tx_news_domain_model_news',10,'tx_mtosafisitepackage_registration_link',0,0,2147483647,0,'','typolink','55fca047b228a52e981d533d3c4a7abc:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('a26cc2e4f1d394f20c27cc3fccd65e97','tt_content',13,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('a337a79987cb444fbb435427ab45568c','sys_file_reference',18,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('a3cc86a75fef4d79b777c521a359bf5f','tt_content',29,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('a69870b2c147f2e9c49924c30bba8eb3','sys_file_reference',15,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',18,'',0,0,2147483647,0,0,''),
('a9bb4d70a473b52d4a259986ad3214b7','tt_content',38,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',20,'',0,0,2147483647,0,0,''),
('ac0835d3bd7450f46d3ba28dcaf8880b','sys_file_reference',7,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',14,'',0,0,2147483647,0,0,''),
('ac3e2ceba954f0d2e5005157cb1c35c9','tt_content',3,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('b1089f60cddf4fa1a393572b789b3a7f','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',16,'',0,0,2147483647,0,0,''),
('b3762b32222c8c42bbaf2d9242765aa5','tt_content',37,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',19,'',0,0,2147483647,0,0,''),
('b45c03698636f85bdd64f62aeebb4f5d','tt_content',46,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',36,'',0,0,2147483647,0,0,''),
('b8390ee0400ed62108c64b63dfc80330','sys_category',4,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',4,'categories',0,0,2147483647,0,1,''),
('b96dfec8962a424c335a15f010c09c64','tt_content',22,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('b9c912b6184055cadc4b89cb3b52ca24','tt_content',32,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',17,'',0,0,2147483647,0,0,''),
('bc577547d4c72172ebdc852ea3747576','tx_mtosafisitepackage_tile',3,'link',0,0,2147483647,0,'','typolink','5add86f047c9d524d9e9595219c10eb5:0',0,0,'pages',8,'',0,0,2147483647,0,0,''),
('bd0499781b8651f6a47dbdd267b552eb','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('bd9363e3c7ceb56b08c8192e9541bfc5','tt_content',45,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('bdab9f5c733a1925a2082d96913bc1f8','tt_content',31,'image',0,0,2147483647,0,'','','',2,0,'sys_file_reference',15,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('bf6cc0f81d2f48c8ad397ef2c3eee2b3','tx_mtosafisitepackage_slide',3,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('c038eefe78af750fd106e036d6e7bde9','tx_mtosafisitepackage_slide',2,'link',0,0,2147483647,0,'','typolink','e3c3bf6b59d1e8eefa995a17a3471d72:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('c14fd6ec1c7236724d685c3ae63e0ec4','tt_content',34,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',18,'',0,0,2147483647,0,0,''),
('c225a5dc51fe62e7b785fe672031e07b','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('c2914756c599ce17e7cb0585c6f86165','tt_content',36,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('c45d81bd65ed780c1f18939526272e2a','sys_file_reference',20,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',23,'',0,0,2147483647,0,0,''),
('c54d6e1dbf8edbce22fb4011cf341c4a','pages',25,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('c56becdc4ea2ae3a8579c4d7b1d4aed1','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('c66364f690722e7855542eee32488b3c','sys_file_reference',23,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('ca34608fee503babde3755c56abc293f','tt_content',5,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('cc525b5738d587aa9038005247b67650','sys_category',2,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',2,'categories',0,0,2147483647,0,1,''),
('cc547b9336a89588b41b9aac515676d6','tt_content',24,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('ccf27ed75cce3fdca300151061714b0a','tt_content',26,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',11,'',0,0,2147483647,0,0,''),
('cd03540122f752ba28f3b2f778daed32','pages',24,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('d0c87340bc327a8355a748af77c43662','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_tile',3,'',0,0,2147483647,0,0,''),
('d2ada98790a86b08a8930d6f5c005bb7','tx_kesearch_filters',1,'options',0,0,2147483647,0,'','','',1,0,'tx_kesearch_filteroptions',2,'',0,0,2147483647,0,0,''),
('d3722f9232f47d2b03aef4cb5dcf809b','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('d55a1800d95931fd7a591f388a8f53ce','tt_content',44,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','1ea3783b1efa0d9299000582e728ea8a',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml'),
('de3954d092ea613d54be22888c93616f','tt_content',40,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',22,'',0,0,2147483647,0,0,''),
('dee089dabcf4ebd689b72971842c5a43','tt_content',47,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('e05441bea25287ab7ef9a4d72341a937','tt_content',34,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('e3188deab7686e755c6f63b406715d99','sys_category',1,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',12,'categories',0,0,2147483647,0,1,''),
('e347371ae65979f6857a13b1bbdc3e8a','sys_category',6,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',6,'categories',0,0,2147483647,0,1,''),
('e3595e870a8b402d8071edf4009d6ee9','tt_content',11,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('e54c4b2d95c034daecb3f81498aa0289','tt_content',10,'pi_flexform',0,0,2147483647,0,'MAIN/lDEF/loadFlexformsFromOtherCE/vDEF/','','',0,0,'tt_content',9,'',0,0,2147483647,0,0,''),
('e5d5bafd27ede6e4bfb9f22c7119046d','sys_file_reference',13,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('e5db4317e6458f59a44dd32ed60180c6','tt_content',29,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('e911be4b97f51ea843bcb77ec5e2fe82','sys_category',5,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',9,'categories',0,0,2147483647,0,1,''),
('eb437033808db107b592ca03207f3bde','tx_news_domain_model_news',12,'tx_mtosafisitepackage_registration_link',0,0,2147483647,0,'','typolink','b89f1eea3897b9064c20c16343252f30:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('ef9e0e86be45638085e9662d9146b7af','sys_file_reference',19,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',22,'',0,0,2147483647,0,0,''),
('f28edf7f129f3dcd6cfeb403ba7a0e39','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('f352f231282e4969b3ea85c3f9b4608f','sys_category',3,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',3,'categories',0,0,2147483647,0,1,''),
('f5ed8c79cd8612b55a515f9f520c7ba6','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_slide',2,'',0,0,2147483647,0,0,''),
('f6143939c533cf455cf78face1748d83','sys_file_reference',14,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',15,'',0,0,2147483647,0,0,''),
('f640e46359138786bad533a1dc6c9adb','tx_mtosafisitepackage_slide',2,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('f6a0bea04b5b567e9d6942672112d49c','tt_content',31,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',13,'',0,0,2147483647,0,0,''),
('f9feddf408fc7808849da2413f760752','tt_content',20,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('fb534e0348cb0df4b46f46afc05eb5c6','tt_content',11,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('fc193642beeafd12f02297477a258ef6','tx_mtosafisitepackage_slide',1,'link',0,0,2147483647,0,'','typolink','af39f1ff3aa52a5bc109a0ba6e0c4e9d:0',0,0,'pages',13,'',0,0,2147483647,0,0,''),
('fce6d6e68799136a3291b364b914834b','tx_kesearch_indexerconfig',1,'startingpoints_recursive',0,0,2147483647,0,'','','',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('fed36fd2032652e9a28f9e21e509e64e','pages',28,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\LanguagePackUpdateTimestampMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','mtosafi_sitepackage:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','mtosafi_sitepackage:Initialisation/dataImported','i:1;'),
(40,'extensionDataImport','news:ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','ke_search:ext_tables_static+adt.sql','s:0:\"\";'),
(48,'extensionDataImport','altcha:ext_tables_static+adt.sql','s:0:\"\";'),
(49,'extensionDataImport','eventnews:ext_tables_static+adt.sql','s:0:\"\";'),
(52,'tx_kesearch','lastRun','a:3:{s:9:\"startTime\";i:1795372572;s:7:\"endTime\";i:1795372572;s:12:\"indexingTime\";i:0;}');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_slides` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l18n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1795334294,1794119207,1,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\">TYPO3</a>.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(2,1,1795333042,1795332992,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Sidebar probe',0,'','','','<p>Rendered from the area sidebar.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(3,1,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'News',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(4,30,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'All news',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(5,31,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'News article',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(6,1,1795343750,1795343750,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_tiles',0,0,'','',0,'Popular services',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,6,0),
(7,1,1795344511,1795344511,0,0,0,0,'0',64,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_slider',0,0,'','',0,'Highlights',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,3),
(8,33,1795345582,1795345582,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'This page does not exist',100,'','','','<p>The page you are looking for may have moved, or the address may be mistyped.</p>\r\n<ul><li><a href=\"t3://page?uid=1\">Go to the home page</a></li><li><a href=\"t3://page?uid=16\">Search the site</a></li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(9,16,1795348009,1795348009,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'ke_search_pi1',0,0,'','',0,'Filter results',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'34',0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"MAIN\">\n            <language index=\"lDEF\">\n                <field index=\"resultPage\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n                <field index=\"showTextInsteadOfResults\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"textForResults\">\n                    <value index=\"vDEF\">&lt;p&gt;Type what you are looking for into the search field at the top of the page.&lt;/p&gt;</value>\n                </field>\n                <field index=\"showNoResultsText\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"view\">\n            <language index=\"lDEF\">\n                <field index=\"highlightSword\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"resultChars\">\n                    <value index=\"vDEF\">200</value>\n                </field>\n                <field index=\"resultsNumeration\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showResultUrl\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showDate\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"images\">\n            <language index=\"lDEF\">\n                <field index=\"showTypeIcon\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showPageImages\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showNewsImages\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showFilePreview\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"pagebrowser\">\n            <language index=\"lDEF\">\n                <field index=\"pagebrowserOnTop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"pagebrowserAtBottom\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"resultsPerPage\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"maxPagesInPagebrowser\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"filter\">\n            <language index=\"lDEF\">\n                <field index=\"filters\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(10,16,1795348009,1795348009,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'ke_search_pi2',0,0,'','',0,'Search results',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"MAIN\">\n            <language index=\"lDEF\">\n                <field index=\"loadFlexformsFromOtherCE\">\n                    <value index=\"vDEF\">9</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(11,5,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Pay the municipality from wherever you are',0,'','','','<p>Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.</p>\r\n<p>Most of them can be paid by mobile money or by card in the <a href=\"t3://page?uid=17\">e-services portal</a>, at any time of day. The cash office in the municipal office is open on working days.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(12,5,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'menu_subpages',0,0,'','',0,'Payments and fees',0,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(13,6,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'How your land rates are calculated',0,'','','','<p>Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.</p>\r\n<p>Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(14,6,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Rates for 2026',0,'','','','Land use|Rate|Minimum per plot and year\nResidential|0.5 % of the rateable value|KES 1,500\nCommercial|1.2 % of the rateable value|KES 1,500\nAgricultural|0.2 % of the rateable value|KES 1,500',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(15,6,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'How to pay',0,'','','','<p>Pay by mobile money, by card in the <a href=\"t3://page?uid=17\">e-services portal</a>, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(16,7,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'One permit for your business',0,'','','','<p>Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.</p>\r\n<p>Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(17,7,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'What you need to apply',0,'','','','Your national ID or passport\nThe KRA PIN of the business\nThe plot number of the premises\nA description of the activity and the number of employees',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(18,8,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Parking in the town centre',0,'','','','<p>Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.</p>\r\n<p>Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.</p>',1,0,NULL,NULL,26,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(19,8,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Fees',0,'','','','Vehicle|Per day|Per month\nCar|KES 100|KES 2,000\nPick-up and van|KES 150|KES 3,000\nLorry|KES 300|KES 6,000\nMotorcycle (boda boda)|KES 30|KES 500',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(20,9,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Selling at the municipal markets',0,'','','','<p>Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.</p>\r\n<p>Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(21,9,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Fees',0,'','','','|Fee\nStall, per month|KES 1,200\nOpen space, per day|KES 50\nFish market, per day|KES 80',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(22,10,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Interest waived when you clear your arrears',0,'','','','<p>Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.</p>\r\n<p>Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.</p>',1,0,NULL,NULL,26,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(23,10,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'How it works',0,'','','','Ask for a statement of your arrears\nApply for the waiver with the statement\nPay the arrears without the interest within 30 days of the approval',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(24,11,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Health services close to home',0,'','','','<p>The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.</p>\r\n<p>For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(25,11,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Health centres',0,'','','','Health centre|Ward|Opening hours\nMto Safi Town|Central|Mon–Sat 7:00–19:00\nPwani|Beach|Mon–Fri 8:00–17:00\nKijiji|Upper River|Mon–Fri 8:00–17:00\nMnarani|Mnarani|Mon–Fri 8:00–17:00',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(26,12,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'A clean river for everyone',0,'','','','<p>Mto Safi means \"clean river\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(27,12,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Water connection',0,'','','','<p>To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.</p>\r\n<p>To report a leak or a burst pipe, call +254 700 000 001 at any time.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(28,12,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Waste collection',0,'','','','Town centre: Monday and Thursday\nBeach and Mnarani: Tuesday and Friday\nUpper River: Wednesday and Saturday',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(29,13,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Karibu Mto Safi',0,'','','','<p>White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.</p>\r\n<p>The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under <a href=\"t3://page?uid=7\">Single business permit</a>.</p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(30,13,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Places to visit',0,'','','','The dhow harbour and the fish market at sunrise\nThe mangrove boardwalk at the river mouth\nMto Safi beach and the coral garden\nThe old town with its carved doors',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(31,13,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'image',0,0,'','',0,'Impressions of Mto Safi',0,'','','',NULL,4,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(32,14,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Have your say on the budget',0,'','','','<p>Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.</p>\r\n<p>You can also send your views in writing to the clerk until 15 May.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(33,14,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Forum dates',0,'','','','Ward|Date|Place\nCentral|4 May, 10:00|Municipal hall\nBeach|6 May, 10:00|Pwani primary school\nUpper River|8 May, 14:00|Kijiji social hall\nMnarani|11 May, 10:00|Mnarani chief\'s camp',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(34,15,1795369027,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"colPos\":\"\",\"imageorient\":\"\"}',0,0,0,0,'default',1,NULL,0,'textpic',0,0,'','',0,'Visit us',0,'','','','<p>Mto Safi Municipality<br />Municipal Office<br />Beach Road 1<br />P.O. Box 123, Mto Safi</p>\r\n<p>Phone: <a href=\"tel:+254700000000\">+254 700 000 000</a><br />Email: <a href=\"mailto:info@mtosafi.example\">info@mtosafi.example</a></p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(35,15,1795369027,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'table',0,0,'','',0,'Opening hours',0,'','','','Days|Hours\nMon–Thu|8:00–17:00\nFriday|8:00–13:00, 14:00–17:00\nSat, Sun|Closed',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(36,15,1795369027,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Report a problem',0,'','','','<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\"mailto:report@mtosafi.example\">report@mtosafi.example</a>, and say where it is.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(37,17,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Your municipal services online',0,'','','','<p>In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.</p>\r\n<p>Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.</p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(38,18,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Example text',0,'','','','<p>This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.</p>\r\n<p>The design of this site targets WCAG 2.1 level AA.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(39,19,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Example text',0,'','','','<p>This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(40,20,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Ask for the information we hold',0,'','','','<p>Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.</p>\r\n<p>We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(41,20,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Published without a request',0,'','','','The budget and the annual accounts\nThe valuation roll\nThe minutes of the municipal board\nTenders and the contracts awarded',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(42,21,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Doing business with the municipality',0,'','','','<p>The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(43,21,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Open tenders',0,'','','','Number|Subject|Closes\nMSM/T/01/2026|Resurfacing of Market Street|12 June\nMSM/T/02/2026|Solar street lights, Beach ward|19 June\nMSM/T/03/2026|Waste collection vehicles (2)|26 June',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(44,15,1795369027,1795369027,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Write to us',0,'','','The right department answers within five working days.',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(45,1,1795372569,1795372569,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'Events',100,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">asc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\">today</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">36</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">35</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">events</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"extraEntryEventNews\">\n            <language index=\"lDEF\">\n                <field index=\"settings.eventRestriction\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(46,35,1795372569,1795372569,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'Upcoming events',100,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">asc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\">today</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">36</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">eventsPage</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"extraEntryEventNews\">\n            <language index=\"lDEF\">\n                <field index=\"settings.eventRestriction\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(47,36,1795372569,1795372569,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'Event',100,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">35</value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">35</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_eventnews_domain_model_location`
--

DROP TABLE IF EXISTS `tx_eventnews_domain_model_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_eventnews_domain_model_location` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `address` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `municipality` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(16) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `lat` double DEFAULT 0,
  `lng` double DEFAULT 0,
  `link` varchar(255) NOT NULL DEFAULT '',
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_eventnews_domain_model_location`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_eventnews_domain_model_location` WRITE;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_location` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_eventnews_domain_model_organizer`
--

DROP TABLE IF EXISTS `tx_eventnews_domain_model_organizer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_eventnews_domain_model_organizer` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_eventnews_domain_model_organizer`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_eventnews_domain_model_organizer` WRITE;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_organizer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_organizer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_filteroptions`
--

DROP TABLE IF EXISTS `tx_kesearch_filteroptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_filteroptions` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `tag` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `automated_tagging` text DEFAULT NULL,
  `automated_tagging_exclude` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_filteroptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_filteroptions` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_filteroptions` DISABLE KEYS */;
INSERT INTO `tx_kesearch_filteroptions` VALUES
(1,34,1795348009,1795348009,0,0,'{\"hidden\":\"\",\"slug\":\"\",\"tag\":\"\",\"title\":\"\"}',0,0,256,NULL,0,'Services','service','services',NULL,NULL),
(2,34,1795348009,1795348009,0,0,'{\"hidden\":\"\",\"slug\":\"\",\"tag\":\"\",\"title\":\"\"}',0,0,512,NULL,0,'News','news','news',NULL,NULL);
/*!40000 ALTER TABLE `tx_kesearch_filteroptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_filters`
--

DROP TABLE IF EXISTS `tx_kesearch_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_filters` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `options` text DEFAULT NULL,
  `rendertype` varchar(90) NOT NULL DEFAULT '',
  `markAllCheckboxes` smallint(6) NOT NULL DEFAULT 0,
  `target_pid` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL DEFAULT 0,
  `shownumberofresults` smallint(6) NOT NULL DEFAULT 0,
  `alphabeticalsorting` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_filters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_filters` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_filters` DISABLE KEYS */;
INSERT INTO `tx_kesearch_filters` VALUES
(1,34,1795348009,1795348009,0,0,'{\"alphabeticalsorting\":\"\",\"amount\":\"\",\"hidden\":\"\",\"markAllCheckboxes\":\"\",\"options\":\"\",\"rendertype\":\"\",\"shownumberofresults\":\"\",\"target_pid\":\"\",\"title\":\"\"}',0,0,NULL,0,'Show only','1,2','checkbox',0,0,10,1,0);
/*!40000 ALTER TABLE `tx_kesearch_filters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_index`
--

DROP TABLE IF EXISTS `tx_kesearch_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_index` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `starttime` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `fe_group` varchar(100) NOT NULL DEFAULT '0',
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `targetpid` text DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `hidden_content` mediumtext DEFAULT NULL,
  `params` text DEFAULT NULL,
  `type` tinytext DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `sortdate` int(11) NOT NULL DEFAULT 0,
  `orig_uid` varchar(255) NOT NULL DEFAULT '0',
  `orig_pid` int(11) NOT NULL DEFAULT 0,
  `title` text DEFAULT NULL,
  `language` int(11) NOT NULL DEFAULT 0,
  `directory` tinytext DEFAULT NULL,
  `hash` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  FULLTEXT KEY `tags` (`tags`),
  FULLTEXT KEY `title` (`title`),
  FULLTEXT KEY `titlecontent` (`title`,`content`),
  FULLTEXT KEY `titlecontenthiddencontent` (`title`,`content`,`hidden_content`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_index`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_index` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_index` DISABLE KEYS */;
INSERT INTO `tx_kesearch_index` VALUES
(1,34,1795372572,1795348011,0,0,'0',0,'31','Sixty stalls, cold storage and clean water for traders and buyers.\nThe new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.\r\nTraders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.\r\nContact: Trade &amp; Markets Office, +254 700 000 010','','&tx_news_pi1[news]=1&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Trademarkets#,#syscat1#,#news#','Sixty stalls, cold storage and clean water for traders and buyers.',1793595600,'1',32,'New fish market opens at the jetty',0,'',''),
(2,34,1795372572,1795348011,0,0,'0',0,'31','Works run for six weeks. Matatus take the diversion via Market Street.\nBeach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.\r\nDuring the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.\r\nContact: Roads Department, +254 700 000 020','','&tx_news_pi1[news]=2&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Roadstransport#,#syscat2#,#news#','Works run for six weeks. Matatus take the diversion via Market Street.',1793077200,'2',32,'Beach Road resurfacing starts',0,'',''),
(3,34,1795372572,1795348011,0,0,'0',0,'31','Eye tests, vaccinations and screening, open to every resident.\nThe municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.\r\nOn offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.\r\nContact: Health Department, +254 700 000 030','','&tx_news_pi1[news]=3&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Health#,#syscat3#,#news#','Eye tests, vaccinations and screening, open to every resident.',1792472400,'3',32,'Free health camp in Ward 3',0,'',''),
(4,34,1795372572,1795348011,0,0,'0',0,'31','Residents can now pay land rates and business permits with their phone.\nFrom 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.\r\nPayment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.\r\nContact: Revenue Department, +254 700 000 040','','&tx_news_pi1[news]=4&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Revenuepayments#,#syscat4#,#news#','Residents can now pay land rates and business permits with their phone.',1791781200,'4',32,'Pay land rates by mobile money from January',0,'',''),
(5,34,1795372572,1795348011,0,0,'0',0,'31','Public participation forums in every ward in November.\nThe municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.\r\nA forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.\r\nContact: Planning Office, +254 700 000 050','','&tx_news_pi1[news]=5&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Publicparticipation#,#syscat5#,#news#','Public participation forums in every ward in November.',1790830800,'5',32,'Have your say on the budget 2027/28',0,'',''),
(6,34,1795372572,1795348011,0,0,'0',0,'31','The monthly beach clean-ups and the new waste collection paid off.\nMto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.\r\nThe mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.\r\nContact: Environment Department, +254 700 000 060','','&tx_news_pi1[news]=6&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Environment#,#syscat6#,#news#','The monthly beach clean-ups and the new waste collection paid off.',1789707600,'6',32,'Mto Safi named cleanest town on the coast',0,'',''),
(7,34,1795372572,1795348012,0,0,'0',0,'31','Three boreholes and twelve water kiosks serve 4,000 residents.\nThree new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.\r\nA water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.\r\nContact: Water &amp; Sanitation Department, +254 700 000 070','','&tx_news_pi1[news]=7&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Water#,#syscat7#,#news#','Three boreholes and twelve water kiosks serve 4,000 residents.',1788584400,'7',32,'New boreholes bring clean water to Ward 5',0,'',''),
(8,34,1795372572,1795368024,0,0,'',0,'5','Pay the municipality from wherever you are\n Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.\r\n Most of them can be paid by mobile money or by card in the e-services portal, at any time of day. The cash office in the municipal office is open on working days.\n\n\n\n','','','page','#service#','',1795368020,'5',1,'Revenue & payments',0,'',''),
(9,34,1795372572,1795368024,0,0,'',0,'6','How your land rates are calculated\n Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.\r\n Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.\n\n\n\nRates for 2026\nLand use Rate Minimum per plot and year\nResidential 0.5 % of the rateable value KES 1,500\nCommercial 1.2 % of the rateable value KES 1,500\nAgricultural 0.2 % of the rateable value KES 1,500\n\n\n\nHow to pay\n Pay by mobile money, by card in the e-services portal, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.\n\n\n\n','','','page','#service#','',1795368020,'6',5,'Land rates',0,'',''),
(10,34,1795372572,1795368024,0,0,'',0,'7','One permit for your business\n Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.\r\n Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.\n\n\n\nWhat you need to apply\nYour national ID or passport\nThe KRA PIN of the business\nThe plot number of the premises\nA description of the activity and the number of employees\n\n\n\n','','','page','#service#','',1795334294,'7',5,'Single business permit',0,'',''),
(11,34,1795372572,1795368024,0,0,'',0,'8','Parking in the town centre\n Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.\r\n Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.\n\n\n\nFees\nVehicle Per day Per month\nCar KES 100 KES 2,000\nPick-up and van KES 150 KES 3,000\nLorry KES 300 KES 6,000\nMotorcycle (boda boda) KES 30 KES 500\n\n\n\n','','','page','#service#','',1795334294,'8',5,'Parking fees',0,'',''),
(12,34,1795372572,1795368024,0,0,'',0,'9','Selling at the municipal markets\n Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.\r\n Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.\n\n\n\nFees\n Fee\nStall, per month KES 1,200\nOpen space, per day KES 50\nFish market, per day KES 80\n\n\n\n','','','page','#service#','',1795368020,'9',5,'Market fees',0,'',''),
(13,34,1795372572,1795368024,0,0,'',0,'10','Interest waived when you clear your arrears\n Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.\r\n Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.\n\n\n\nHow it works\nAsk for a statement of your arrears\nApply for the waiver with the statement\nPay the arrears without the interest within 30 days of the approval\n\n\n\n','','','page','#service#','',1795334294,'10',5,'Waiver of interest',0,'',''),
(14,34,1795372572,1795368024,0,0,'',0,'11','Health services close to home\n The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.\r\n For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.\n\n\n\nHealth centres\nHealth centre Ward Opening hours\nMto Safi Town Central Mon–Sat 7:00–19:00\nPwani Beach Mon–Fri 8:00–17:00\nKijiji Upper River Mon–Fri 8:00–17:00\nMnarani Mnarani Mon–Fri 8:00–17:00\n\n\n\n','','','page','#service#','',1795368020,'11',1,'Health',0,'',''),
(15,34,1795372572,1795368024,0,0,'',0,'12','A clean river for everyone\n Mto Safi means \"clean river\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.\n\n\n\nWater connection\n To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.\r\n To report a leak or a burst pipe, call +254 700 000 001 at any time.\n\n\n\nWaste collection\nTown centre: Monday and Thursday\nBeach and Mnarani: Tuesday and Friday\nUpper River: Wednesday and Saturday\n\n\n\n','','','page','#service#','',1795368020,'12',1,'Environment & water',0,'',''),
(16,34,1795372572,1795368024,0,0,'',0,'13','Karibu Mto Safi\n White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.\r\n The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under Single business permit.\n\n\n\nPlaces to visit\nThe dhow harbour and the fish market at sunrise\nThe mangrove boardwalk at the river mouth\nMto Safi beach and the coral garden\nThe old town with its carved doors\n\n\n\n','','','page','#service#','',1795368020,'13',1,'Trade & tourism',0,'',''),
(17,34,1795372572,1795368024,0,0,'',0,'14','Have your say on the budget\n Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.\r\n You can also send your views in writing to the clerk until 15 May.\n\n\n\nForum dates\nWard Date Place\nCentral 4 May, 10:00 Municipal hall\nBeach 6 May, 10:00 Pwani primary school\nUpper River 8 May, 14:00 Kijiji social hall\nMnarani 11 May, 10:00 Mnarani chief\'s camp\n\n\n\n','','','page','#service#','',1795368020,'14',1,'Public participation',0,'',''),
(18,34,1795372572,1795368024,0,0,'',0,'15','Visit us\n Mto Safi Municipality Municipal Office Beach Road 1 P.O. Box 123, Mto Safi\r\n Phone: +254 700 000 000 Email: info@mtosafi.example\n\n\n\nOpening hours\nDays Hours\nMon–Thu 8:00–17:00\nFriday 8:00–13:00, 14:00–17:00\nSat, Sun Closed\n\n\n\nReport a problem\n A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to report@mtosafi.example, and say where it is.\n\n\n\n','','','page','#service#','',1795369027,'15',1,'Contact',0,'',''),
(19,34,1795372572,1795368024,0,0,'',0,'17','Your municipal services online\n In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.\r\n Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.\n\n\n\n','','','page','#service#','',1795334294,'17',1,'E-services portal',0,'',''),
(20,34,1795372572,1795368024,0,0,'',0,'18','Example text\n This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.\r\n The design of this site targets WCAG 2.1 level AA.\n\n\n\n','','','page','#service#','',1795334294,'18',1,'Accessibility statement',0,'',''),
(21,34,1795372572,1795368024,0,0,'',0,'19','Example text\n This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.\n\n\n\n','','','page','#service#','',1795334294,'19',1,'Privacy policy',0,'',''),
(22,34,1795372572,1795368024,0,0,'',0,'20','Ask for the information we hold\n Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.\r\n We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.\n\n\n\nPublished without a request\nThe budget and the annual accounts\nThe valuation roll\nThe minutes of the municipal board\nTenders and the contracts awarded\n\n\n\n','','','page','#service#','',1795334294,'20',1,'Access to information',0,'',''),
(23,34,1795372572,1795368024,0,0,'',0,'21','Doing business with the municipality\n The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.\n\n\n\nOpen tenders\nNumber Subject Closes\nMSM/T/01/2026 Resurfacing of Market Street 12 June\nMSM/T/02/2026 Solar street lights, Beach ward 19 June\nMSM/T/03/2026 Waste collection vehicles (2) 26 June\n\n\n\n','','','page','#service#','',1795334294,'21',1,'Tenders',0,'',''),
(24,34,1795372572,1795372572,0,0,'0',0,'36','Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.\nResidents, schools and businesses clean the beach together. Gloves, bags and water are provided. The cleanest group wins a tree for its school.\r\nTime: 7:00–11:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=8&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Environment#,#syscat6#,#news#','Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.',1794715200,'8',32,'Beach clean-up day',0,'',''),
(25,34,1795372572,1795372572,0,0,'0',0,'36','Municipal hall, 10:00. Every resident may speak.\nEvery resident may speak. The forum is held in Kiswahili and English. Sign language interpretation is available on request until 15 November.\r\nTime: 10:00–13:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=9&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Publicparticipation#,#syscat5#,#news#','Municipal hall, 10:00. Every resident may speak.',1795330800,'9',32,'Public participation forum: budget 2027/28',0,'',''),
(26,34,1795372572,1795372572,0,0,'0',0,'36','Mto Safi Polytechnic, 9:00–15:00. Bring copies of your CV and certificates.\nEmployers from tourism, fishing, construction and IT present jobs and apprenticeships. Bring copies of your CV and certificates.\r\nTime: 9:00–15:00Cost: FreeRegistration: Recommended, at the Education Office','','&tx_news_pi1[news]=10&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Education#,#syscat8#,#news#','Mto Safi Polytechnic, 9:00–15:00. Bring copies of your CV and certificates.',1796450400,'10',32,'Youth job and skills fair',0,'',''),
(27,34,1795372572,1795372572,0,0,'0',0,'36','Municipal grounds, 9:00–14:00. Flag raising, speeches, school choirs and traditional dances.\nThe municipality celebrates Jamhuri Day with the flag raising, speeches, school choirs and traditional dances.\r\nTime: 9:00–14:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=11&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#news#','Municipal grounds, 9:00–14:00. Flag raising, speeches, school choirs and traditional dances.',1797055200,'11',32,'Jamhuri Day celebrations',0,'',''),
(28,34,1795372572,1795372572,0,0,'0',0,'36','Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.\nFood, crafts and music every evening before Christmas.\r\nTime: Every evening, 16:00–22:00Cost: Free entryRegistration: Traders apply for a stall at the Trade &amp; Markets Office until 1 December','','&tx_news_pi1[news]=12&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Trademarkets#,#syscat1#,#news#','Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.',1797685200,'12',32,'Festive market at the jetty',0,'',''),
(29,34,1795372572,1795372572,0,0,'0',0,'36','Monday to Friday, 9:00–15:00, at the cash office: help with your valuation notice and land rates.\nStaff of the Revenue Department help you read your valuation notice, calculate your land rates and set up payment by mobile money.\r\nTime: Monday to Friday, 9:00–15:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=13&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Revenuepayments#,#syscat4#,#news#','Monday to Friday, 9:00–15:00, at the cash office: help with your valuation notice and land rates.',1800252000,'13',32,'Land rates help desk',0,'','');
/*!40000 ALTER TABLE `tx_kesearch_index` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_indexerconfig`
--

DROP TABLE IF EXISTS `tx_kesearch_indexerconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_indexerconfig` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `storagepid` text DEFAULT NULL,
  `targetpid` text DEFAULT NULL,
  `startingpoints_recursive` text DEFAULT NULL,
  `single_pages` text DEFAULT NULL,
  `sysfolder` text DEFAULT NULL,
  `index_content_with_restrictions` text DEFAULT NULL,
  `type` varchar(90) NOT NULL DEFAULT '',
  `index_news_category_mode` smallint(6) NOT NULL DEFAULT 0,
  `index_news_category_selection` text DEFAULT NULL,
  `index_extnews_category_selection` text DEFAULT NULL,
  `index_news_archived` smallint(6) NOT NULL DEFAULT 0,
  `index_news_useHRDatesSingle` smallint(6) NOT NULL DEFAULT 0,
  `index_news_useHRDatesSingleWithoutDay` smallint(6) NOT NULL DEFAULT 0,
  `index_news_files_mode` smallint(6) NOT NULL DEFAULT 0,
  `index_use_page_tags` smallint(6) NOT NULL DEFAULT 0,
  `index_use_page_tags_for_files` smallint(6) NOT NULL DEFAULT 0,
  `index_page_doctypes` varchar(255) NOT NULL DEFAULT '',
  `directories` text DEFAULT NULL,
  `fileext` tinytext DEFAULT NULL,
  `content_fields` text DEFAULT NULL,
  `page_fields` text DEFAULT NULL,
  `page_fields_hidden` text DEFAULT NULL,
  `file_reference_fields` text DEFAULT NULL,
  `file_collections` text DEFAULT NULL,
  `filteroption` int(11) NOT NULL DEFAULT 0,
  `fal_storage` int(11) NOT NULL DEFAULT 0,
  `contenttypes` text DEFAULT NULL,
  `additional_tables` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_indexerconfig`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_indexerconfig` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_indexerconfig` DISABLE KEYS */;
INSERT INTO `tx_kesearch_indexerconfig` VALUES
(1,34,1795348009,1795348009,0,0,0,'Pages','34',NULL,'1',NULL,NULL,'no','page',1,NULL,NULL,0,0,0,0,0,0,'1',NULL,'pdf,ppt,doc,xls,docx,xlsx,pptx','bodytext,subheader,header_link','','','media',NULL,0,0,'text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline','[accordion]\ntable = tx_bootstrappackage_accordion_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[tab]\ntable = tx_bootstrappackage_tab_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[carousel]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_fullscreen]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_small]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[icon_group]\ntable = tx_bootstrappackage_icon_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\n\n[card_group]\ntable = tx_bootstrappackage_card_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\nfields[] = link_title\n\n[timeline]\ntable = tx_bootstrappackage_timeline_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext'),
(2,34,1795348009,1795348009,0,0,0,'News','34','31','32',NULL,NULL,'no','news',1,NULL,NULL,0,0,0,0,0,0,'1',NULL,'pdf,ppt,doc,xls,docx,xlsx,pptx','bodytext,subheader,header_link','','','media',NULL,0,0,'text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline','[accordion]\ntable = tx_bootstrappackage_accordion_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[tab]\ntable = tx_bootstrappackage_tab_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[carousel]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_fullscreen]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_small]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[icon_group]\ntable = tx_bootstrappackage_icon_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\n\n[card_group]\ntable = tx_bootstrappackage_card_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\nfields[] = link_title\n\n[timeline]\ntable = tx_bootstrappackage_timeline_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext');
/*!40000 ALTER TABLE `tx_kesearch_indexerconfig` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_stat_search`
--

DROP TABLE IF EXISTS `tx_kesearch_stat_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_stat_search` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `searchphrase` text DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `hits` int(11) NOT NULL DEFAULT 0,
  `tagsagainst` text DEFAULT NULL,
  `language` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_stat_search`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_stat_search` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_stat_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_kesearch_stat_search` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_stat_word`
--

DROP TABLE IF EXISTS `tx_kesearch_stat_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_stat_word` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `word` text DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `pageid` int(11) NOT NULL DEFAULT 0,
  `resultsfound` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_stat_word`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_stat_word` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_stat_word` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_kesearch_stat_word` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_slide`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_slide` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(100) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  `link` text NOT NULL DEFAULT '',
  `link_label` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_slide`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_slide` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_slide` VALUES
(1,1,1795344511,1795344511,0,0,1,0,0,0,NULL,'',0,0,0,0,7,1,'Karibu Mto Safi','White beaches, a clean river and a municipality that serves you online, day and night.','t3://page?uid=13','Discover Mto Safi'),
(2,1,1795344511,1795344511,0,0,2,0,0,0,NULL,'',0,0,0,0,7,1,'Pay your land rates by mobile money','Calculate what you owe and pay before 31 March to avoid interest.','t3://page?uid=6','Calculate land rates'),
(3,1,1795344511,1795344511,0,0,3,0,0,0,NULL,'',0,0,0,0,7,1,'Have your say on the budget','Join the public participation forums in every ward this month.','t3://page?uid=14','See the forum dates');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_tile`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_tile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_tile` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `icon` varchar(8) NOT NULL DEFAULT '',
  `label` varchar(100) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_tile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_tile` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_tile` VALUES
(1,1,1795343750,1795343750,0,0,1,0,0,0,NULL,'',0,0,0,0,6,'🏪','Single business permit','t3://page?uid=7'),
(2,1,1795343750,1795343750,0,0,2,0,0,0,NULL,'',0,0,0,0,6,'🏡','Land rates','t3://page?uid=6'),
(3,1,1795343750,1795343750,0,0,3,0,0,0,NULL,'',0,0,0,0,6,'🅿️','Parking fees','t3://page?uid=8'),
(4,1,1795343750,1795343750,0,0,4,0,0,0,NULL,'',0,0,0,0,6,'💧','Water connection','t3://page?uid=12'),
(5,1,1795343750,1795343750,0,0,5,0,0,0,NULL,'',0,0,0,0,6,'🧺','Market stalls','t3://page?uid=9'),
(6,1,1795343750,1795343750,0,0,6,0,0,0,NULL,'',0,0,0,0,6,'📣','Report a problem','t3://page?uid=15');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `is_event` smallint(5) unsigned NOT NULL DEFAULT 0,
  `full_day` smallint(5) unsigned NOT NULL DEFAULT 0,
  `event_end` int(10) unsigned DEFAULT 0,
  `organizer` int(10) unsigned DEFAULT 0,
  `location` int(10) unsigned DEFAULT 0,
  `organizer_simple` varchar(255) NOT NULL DEFAULT '',
  `location_simple` varchar(255) NOT NULL DEFAULT '',
  `tx_mtosafisitepackage_registration_link` text NOT NULL DEFAULT '',
  `tx_mtosafisitepackage_registration_label` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(NULL,1,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New fish market opens at the jetty','Sixty stalls, cold storage and clean water for traders and buyers.','<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.</p>\r\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.</p>\r\n<p><strong>Contact:</strong> Trade &amp; Markets Office, +254 700 000 010</p>',1793595600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-fish-market-opens-at-the-jetty',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,2,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Beach Road resurfacing starts','Works run for six weeks. Matatus take the diversion via Market Street.','<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.</p>\r\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.</p>\r\n<p><strong>Contact:</strong> Roads Department, +254 700 000 020</p>',1793077200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'beach-road-resurfacing-starts',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,3,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Free health camp in Ward 3','Eye tests, vaccinations and screening, open to every resident.','<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.</p>\r\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.</p>\r\n<p><strong>Contact:</strong> Health Department, +254 700 000 030</p>',1792472400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'free-health-camp-in-ward-3',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,4,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Pay land rates by mobile money from January','Residents can now pay land rates and business permits with their phone.','<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.</p>\r\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.</p>\r\n<p><strong>Contact:</strong> Revenue Department, +254 700 000 040</p>',1791781200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pay-land-rates-by-mobile-money-from-january',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,5,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Have your say on the budget 2027/28','Public participation forums in every ward in November.','<p>The municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.</p>\r\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.</p>\r\n<p><strong>Contact:</strong> Planning Office, +254 700 000 050</p>',1790830800,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'have-your-say-on-the-budget-2027-28',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,6,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Mto Safi named cleanest town on the coast','The monthly beach clean-ups and the new waste collection paid off.','<p>Mto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.</p>\r\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.</p>\r\n<p><strong>Contact:</strong> Environment Department, +254 700 000 060</p>',1789707600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'mto-safi-named-cleanest-town-on-the-coast',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,7,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New boreholes bring clean water to Ward 5','Three boreholes and twelve water kiosks serve 4,000 residents.','<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.</p>\r\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.</p>\r\n<p><strong>Contact:</strong> Water &amp; Sanitation Department, +254 700 000 070</p>',1788584400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-boreholes-bring-clean-water-to-ward-5',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,8,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Beach clean-up day','Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.','<p>Residents, schools and businesses clean the beach together. Gloves, bags and water are provided. The cleanest group wins a tree for its school.</p>\r\n<p><strong>Time:</strong> 7:00–11:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1794715200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'beach-clean-up-day',NULL,'',0.5,'','',1,0,1794729600,0,0,'','Public beach, meeting point at the lifeguard tower','',''),
(NULL,9,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Public participation forum: budget 2027/28','Municipal hall, 10:00. Every resident may speak.','<p>Every resident may speak. The forum is held in Kiswahili and English. Sign language interpretation is available on request until 15 November.</p>\r\n<p><strong>Time:</strong> 10:00–13:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1795330800,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'public-participation-forum-budget-2027-28',NULL,'',0.5,'','',1,0,1795341600,0,0,'','Municipal hall, Beach Road 1','',''),
(NULL,10,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Youth job and skills fair','Mto Safi Polytechnic, 9:00–15:00. Bring copies of your CV and certificates.','<p>Employers from tourism, fishing, construction and IT present jobs and apprenticeships. Bring copies of your CV and certificates.</p>\r\n<p><strong>Time:</strong> 9:00–15:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Recommended, at the Education Office</p>',1796450400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'youth-job-and-skills-fair',NULL,'',0.5,'','',1,0,1796472000,0,0,'','Mto Safi Polytechnic','t3://page?uid=15',''),
(NULL,11,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Jamhuri Day celebrations','Municipal grounds, 9:00–14:00. Flag raising, speeches, school choirs and traditional dances.','<p>The municipality celebrates Jamhuri Day with the flag raising, speeches, school choirs and traditional dances.</p>\r\n<p><strong>Time:</strong> 9:00–14:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1797055200,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'jamhuri-day-celebrations',NULL,'',0.5,'','',1,0,1797073200,0,0,'','Municipal grounds','',''),
(NULL,12,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Festive market at the jetty','Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.','<p>Food, crafts and music every evening before Christmas.</p>\r\n<p><strong>Time:</strong> Every evening, 16:00–22:00<br /><strong>Cost:</strong> Free entry<br /><strong>Registration:</strong> Traders apply for a stall at the Trade &amp; Markets Office until 1 December</p>',1797685200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'festive-market-at-the-jetty',NULL,'',0.5,'','',1,0,1798138800,0,0,'','Jetty and fish market','t3://page?uid=9','Apply for a stall'),
(NULL,13,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Land rates help desk','Monday to Friday, 9:00–15:00, at the cash office: help with your valuation notice and land rates.','<p>Staff of the Revenue Department help you read your valuation notice, calculate your land rates and set up payment by mobile money.</p>\r\n<p><strong>Time:</strong> Monday to Friday, 9:00–15:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1800252000,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'land-rates-help-desk',NULL,'',0.5,'','',1,0,1806494400,0,0,'','Municipal office, cash office','','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_typo3altcha_domain_model_challenge`
--

DROP TABLE IF EXISTS `tx_typo3altcha_domain_model_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_typo3altcha_domain_model_challenge` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `challenge` varchar(1024) NOT NULL DEFAULT '',
  `is_solved` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_typo3altcha_domain_model_challenge`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_typo3altcha_domain_model_challenge` WRITE;
/*!40000 ALTER TABLE `tx_typo3altcha_domain_model_challenge` DISABLE KEYS */;
INSERT INTO `tx_typo3altcha_domain_model_challenge` VALUES
(1,0,1795369783,1795369783,0,'b14ee5adc9e3d8ee18dfd97186b9c47b',0),
(2,0,1795369826,1795369826,0,'3a8d6f989a1b179c9f9df3f63bddd99d',0),
(3,0,1795369830,1795369830,0,'4a35ec6b33d5b8fdb4a3f0b8bea722e2',1),
(4,0,1795369857,1795369856,0,'11e10a2ef2c615e04eabd25394088573',1),
(5,0,1795369996,1795369995,0,'80088554263ad4850116a834b4256890',1),
(6,0,1795370028,1795370028,0,'7bff55dfa221c741a872a7fe8f6d6846',0),
(7,0,1795370029,1795370029,0,'380f64900637163993edf48d4dae7f63',0),
(8,0,1795370029,1795370029,0,'7ea6b9d738dae73d8b9c6d01898e7e03',0),
(9,0,1795370029,1795370029,0,'56679ee611f164e7be08ed67e3a232ab',0),
(10,0,1795370029,1795370029,0,'87a11cfaeff5f8ad6ffe1bd9d16eb897',0),
(11,0,1795370029,1795370029,0,'a0117466d46cb4d1cf0ae91551f5b459',0),
(12,0,1795370029,1795370029,0,'ad0c1e52ab6d90c15a766811b6bf1eaa',0),
(13,0,1795370030,1795370030,0,'447d2a37ef3dda3201a77b29098a6977',0),
(14,0,1795370030,1795370030,0,'452d533e9477514627d604360c8275d1',0),
(15,0,1795370031,1795370031,0,'b043a0f62e4b4f084a1eddedb80731c2',0);
/*!40000 ALTER TABLE `tx_typo3altcha_domain_model_challenge` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-23  6:22:22
