-- MariaDB dump 10.20-11.8.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.9-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1795336957,1795336957,0,0,'Edit pages, content and news of the Mto Safi site. Images upload to fileadmin/user_upload/news/','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','Editors','1','1','readFolder,addFolder,renameFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',0,'1,4,254','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','pages:doktype,pages:php_tree_stop,pages:categories,pages:layout,pages:extendToSubpages,pages:nav_title,pages:nav_hide,pages:subtitle,pages:target,pages:lastUpdated,pages:newUntil,pages:cache_timeout,pages:cache_tags,pages:no_search,pages:shortcut_mode,pages:content_from_pid,pages:keywords,pages:description,pages:abstract,pages:author,pages:author_email,pages:media,pages:is_siteroot,pages:mount_pid_ol,pages:module,pages:l18n_cfg,pages:backend_layout,pages:backend_layout_next_level,pages:hidden,pages:starttime,pages:endtime,pages:fe_group,pages:rowDescription,pages:seo_title,pages:no_index,pages:no_follow,pages:sitemap_changefreq,pages:sitemap_priority,pages:canonical_link,pages:og_title,pages:og_description,pages:og_image,pages:twitter_title,pages:twitter_description,pages:twitter_image,pages:twitter_card,tt_content:categories,tt_content:layout,tt_content:frame_class,tt_content:space_before_class,tt_content:space_after_class,tt_content:date,tt_content:header_layout,tt_content:header_position,tt_content:header_link,tt_content:subheader,tt_content:imagewidth,tt_content:imageheight,tt_content:imageorient,tt_content:imageborder,tt_content:image_zoom,tt_content:imagecols,tt_content:pages,tt_content:recursive,tt_content:sectionIndex,tt_content:linkToTop,tt_content:hidden,tt_content:starttime,tt_content:endtime,tt_content:fe_group,tt_content:rowDescription,tt_content:sys_language_uid,tt_content:bullets_type,tt_content:table_class,tt_content:table_caption,tt_content:table_delimiter,tt_content:table_enclosure,tt_content:table_header_position,tt_content:table_tfoot,tt_content:file_collections,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:uploads_description,tt_content:uploads_type,sys_category:hidden,sys_category:starttime,sys_category:endtime,sys_category:description,sys_category:sys_language_uid,sys_category:images,sys_category:single_pid,sys_category:shortcut,sys_category:seo_headline,sys_category:seo_title,sys_category:seo_description,sys_category:seo_text,sys_category:slug,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:title,sys_file_reference:link,sys_file_reference:description,sys_file_reference:alternative,sys_file_reference:crop,sys_file_reference:autoplay,sys_file_reference:showinpreview,tx_news_domain_model_news:sys_language_uid,tx_news_domain_model_news:hidden,tx_news_domain_model_news:starttime,tx_news_domain_model_news:endtime,tx_news_domain_model_news:fe_group,tx_news_domain_model_news:alternative_title,tx_news_domain_model_news:teaser,tx_news_domain_model_news:archive,tx_news_domain_model_news:author,tx_news_domain_model_news:author_email,tx_news_domain_model_news:categories,tx_news_domain_model_news:related,tx_news_domain_model_news:related_from,tx_news_domain_model_news:related_links,tx_news_domain_model_news:keywords,tx_news_domain_model_news:description,tx_news_domain_model_news:istopnews,tx_news_domain_model_news:content_elements,tx_news_domain_model_news:tags,tx_news_domain_model_news:fal_media,tx_news_domain_model_news:fal_related_files,tx_news_domain_model_news:sitemap_changefreq,tx_news_domain_model_news:sitemap_priority,tx_news_domain_model_link:sys_language_uid,tx_news_domain_model_link:hidden,tx_news_domain_model_link:description,tx_news_domain_model_tag:sys_language_uid,tx_news_domain_model_tag:hidden,tx_news_domain_model_tag:slug,tx_news_domain_model_tag:seo_headline,tx_news_domain_model_tag:seo_title,tx_news_domain_model_tag:seo_description,tx_news_domain_model_tag:seo_text','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:div,tt_content:CType:form_formframework,tt_content:CType:felogin_login,tt_content:CType:news_pi1,tt_content:CType:news_newsliststicky,tt_content:CType:news_newsdetail,tt_content:CType:news_newsselectedlist,tt_content:CType:news_newsdatemenu,tt_content:CType:news_categorylist,tt_content:CType:news_newssearchform,tt_content:CType:news_newssearchresult,tt_content:CType:news_taglist,tt_content:CType:mtosafi_tiles','0',NULL,'web_layout,records,media_management',NULL,'options.defaultUploadFolder = 1:/user_upload/news/','','',NULL,NULL);
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1794119204,1794119204,0,0,0,0,NULL,'a:7:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";i:0;}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\",\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":0}',0,NULL,'','_cli_','$argon2id$v=19$m=65536,t=16,p=1$SC5jQVhyTVMwZmIuZi9lVQ$my26zjcmtB0GZl+0EIiotj27ERAFI4Epms3l9llGZqM','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1794119204,1794119204,0,0,0,0,NULL,NULL,NULL,0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$NTQwSlBTTVJPdDBTeTNPaA$tH9SFkLNfU1mfU5cvq+Ot4SY54Kw5EpathLn0W0x2EY','',0,NULL,'','admin@mtosafi-demo.example','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'33_482c7e3784ce494e',1826881589,'x���r۸u_����>4�%��P��NV�\'Qⱔ��HBb���lm���C?����~I�H����ޤ�ID��\r u���Q��H�]��x�]�~�@��3g��:��k���n2���1YeQ8>�	i�<2Xl��c4�E,��_�T���Xg������I�0_qI��\'y�<&⚥, ޖ\0�w61	�e�S/I�D2�	\"���+�G�\"e����D�u�32ђ�)�A�OR\Z�k�^Q�q\Z�[⧌f��k*�����J| 4H�}KX_���x������a��/�mʗ��Xácvڝ>�}b���đ\\� m�*�\09[1����?�P�:f�6��B��`����ro�8!K��je�D؇\"]�L���\n(�G�=Y�lqd�.�G�V�3�Xݎe{]o��\r�����u\Z��d+Kq(7˿X�a϶;�e�1��-X{|����g!���\"#6�4�@B82����H\r��ב��9�������� Ƃ�+n��b!�P\\��o8�ND�Uv\\� [l�4�˓\"\0L�ӐY�U��l2�b,{��&R�\"��C_��l�N� 8=2 �;�7j�dy\"�*) ]B�B\\��D�\n��d�������U�T�A��!�L\r2�\\��X�D��ba	\'���./y�*��!\Z����<�!��쒩�������8n�\r��\0~��Mwz]2���7j)u�1�@�pj��CW�X���c��\0\n��]�L�7KC��ݏKѠ�z��l�g�x��K���g�ؤ��*��~��ݝu\0�:pv$��R�*e��{�GK\"S�[�\r\ZB6\ZD���_�%P=7WM��KLpc<�ȟ��2i<�B<)�~\\i�4��k-e$���2H*�0�x*.\"܎Ƒ�ׂԆ�5�sŃ�A�>u����_t�QK�h���d��ɨKޯEE.�IH}�!x�G�)��	��5��z�&5��dbgz�V2X{�\n�G-������v�o$M�i�u�Zݘ�X.CVp-dPU�݀k�X�P��ڢ�*F�	4 PX���XK�3h�rC!�P-Cӽjʶ�^7��1�������aA��A�^tS��03�[����\ZB�D��))�����N�A��T�_M����e3�a\\K�@��j�Ye)L�u�ed����3ȁ_�\"Y{0V��L�.�,��LAI\r�լ���=�Z�୵Ռ����b�a֔��\'�g�RH�����	閦j�+9��[�$��E��n#��w�\\^��O��f�tf��3c7�{.I�>s�������ک�����/�F@^u������]�-YQ8@DbÂ\'@�_h��B�e�D���Q+c�°�V��Kܹ�:��a䨸��643��\nlG����o&���|C<R�f	D�7GkP��T���ݗ���Q��uGenՠ�N9���+��sW��wjy)i�~d�s.h@�tv���(n�ձ��r�ҋ�G��A�Y��;8�c�����;�H�p| LA8B�S.P�,��&���9����wH�/�y�u�܅�sx��\n����ɰ�s�nSF5�=�7e�\r;�1~V] ������ I���[87�a�Н�;��ߜ��ڮ�w�.��X�U�c�p��Ni9���A�i�w��Z=h��\"\r�r\n�/��:�@�G�JqH���(	X$T���[`�!�)�)����Z�TK$��(\0ZF�)O���_�\r���8B�r��Y;\"B��C��1� �6�{���!��ËG�����r�A��k`WWHOˋG}�[:�q�v�c_�b<�n���	v:��\\KgkOf<S7m/�\\�nvw�b��a��2���G�~`[�c/Tq���<U���}נ���+W�+y���\Z���D����ۆ�\n��2��smؠw1��.&\"eop�����_�����5���w�f��\ZpE�zz���59�����^�-.uՒY�n�No����X��h�v�T|�Q��;���b�3��ԝ�y�C��#�\r�* ���}�������4r��C��o�ts���ho��Mn;���&\n��d*������8E�]�����#Z�	�X��iF�p��u��k>�KE\Z/��e�?�[�\\}d_Ū]�%�α^[)�w�S�2\r!3�����+�f�:�	�6Pl����z$�:��b�`(�*�4*��C�\r����X���fBVb)�06^�p�Ezˏ��Cz��LN�-�3֚�R��C��Ҽ]x�M�?o����N�c/�w�\0	���$�_\0�¼2��}�:[�;{X0�V4B����4wQ�VEc5UU�6�6uI6��DfN���B\"TI��)a%Y�£�3Z��^Dwj�B�X��4�Y�V����.���Ni�`K��8d�g��x�meV�ϐ?	)\Z��2��+��ʳթ�tq	��=V�W�q�\"OqáWd4M�p�V�>{�1ueGg��H�s��#Y�-5ji(l�����-�S���8X��Y�JwF��HR��4�j�n�Nr/Q�{ӳs�w�u4.\Z.���ġ[�܃�\0cʵwv[J]��o@_���p��З�C�_��@���S��Y*�����1Q\Z�H/R�����]$��<��0�i�`��Ǎ���5�F�S^�Tw�������q���z�	��Bv�]-)zѕ��g0��^��\rp��\0�?k��S��ַS��ꚗc���T����U�*֠��z���¦�$�l�:�HUu)�\Zηs�\"&�_���]�ѓ\n��A�	�wȏ\r��w�fh�|�VL^�Â9�\ZP��������3�3�*�B�y�d��<���kQm]�Q���䜻D75\n��K!��u�.@�h�Eu?jӚp\"2Y�\"��&����t�i<=��~}����U���ճpы�v#�I�6��.L[�<1���@��j2&?ݼKχ����ߤ��d�������s>��W���`KO�z*���vs�\'��u��-+/-e�*�����r�d�@uk A�\Z���~\r��� [mtjX\rk GIڮ��\nfUa�����h-�\Z��[���e^�/5���U�|\Z(���㛄���N����������ݾ�۞�uz���v:=�i��5<j�قz]�����ѱ�e9]j\r��gC۲-ֱ����i/f��,��uځ5���Y�'),
(2,'16_fa15c8fad5e6ebf2',1826881589,'x���r۸���W`��>4�%RwZV\'�؉+�X�t���$!		Ip	J�6�L����~J���\0$E�to�D�����\0Rǲ��8FLW���w���y\"JY�\Z���m���b����	Y�a09�	h�:6Xd��cԟ��,��[�D���ؤKs��L��q���2W�x��-K�O�bɘ\'<Z���8`$D=�lW8���e�1����cd�%\'3\Z�Z!>�&4d�\"yDy�i숗0�j����YB��)M����O�H��&�a�ś����%֞�w	_�Sb�FC�n�}\"�ub���đ\\D m�J�\09]3����/�[P�6b�6g�R$!Ma����pw�)8!���j��XtE�j�&�7��{��d���Ѻ�![m{��^g`um��v��p4t]�`���V���B��lb%�v�Wk0�u:�в��E��=��z�ӀM�&�z��o:\0\"0���b�MEb�,��\rm��L�M	w��m,���z��t}�-��T/OsG�ң;�0�ʺ�t0�f,}��R�BʣCO�\\���3H�|N�\r���ң��8��s�]�P� �!F{K*;�\\h�|���) c��ci�����9�12ی[TI��.�\r|L\r2�t��6_ME��|�������h77<�X[�1�&�\r��c\Z@(/�7������i���i���\Z�/�����%xn��\"Q�\Z�-��f@]4�%��\Zs��P@4`�mfJ�Y�M���I\"\Z�Y�Ѵ���ԘL�×�i&�I��6)y���<��yw�@\0��=�\"��\nK�u�pEd�}��AHd��T6z}�˰\n���ys����� ��t��2�$��OwO\nV�+�f�b���L��$PS��\r<EQdn�ec�9�-�l1�C�C	>UY���7�qK�h�ͣx���d���׼(��8�[�\0<�����a��D��G�e�\Z�^R�7�z+lܐ�FQ��j�s-$���\r�H����j��f*V���\\sTU`w�Z��%�4�,���(���n\rm�\"V��\Z�ؐ˵��Ь�AM�V��M�+�:Ȥ\\\\��K2���|݄m�(̌�g\"�����?�0>\"9�Q��A�	R�����ɱh��l�-Ll`�=(^-|5�4��	�I���_3�Y�&KpB��҅�Ř\\*(�@��Us����V9x+-G5#=�����0k�|���TΤ�U�xl̰��<�c����S����+$��n�p�i~v_\r����Ԩ��E���L�\Z�FӔ�K�on<l¨^��U���g�j��������,\"K�݅\Z��nBZ���nr%�O�tyxqH~wĲ;OIџ����/g�Y�<�����L�����O`��e�E�)�<�f�i ��H�&pЎ?+�}֍r粗�t͒+Ħ�� ���Z��|�]�7e\n5K�1yV^ �§\n�� N��z;���;(s����o�N����{C��b,���1s8�AI��\\��͠Z}�Ї���V\rڸ��D������\\H��T)I���<���]�L�C�g�ξoA+�S.�8�\0h�%<N{�xE�t�vb/�+���w�r����_�c��@mP�>jC��%�nYVqٵ��Av�1Rv�*���K�a��1��,x�iQ�#괝a�P_�]� `�|�ʔ����%�k�݁����F��F���������n׳�=���j�0O�xݎcP����;6[�J�&\"|�:�B��^s�:m��w�@�E�qt�t`�r��t6����]��\"�MS�0� ��c��/�77ǀ\rJ��+4Zm@ȩ�k��zn�7��UK�����;���}6g9�Pôf��K�z�ً�-y�I\\���/��S  wMa��-���\'�x�\"#u�eh[����K�=Ë6\\��䴌ʁ����N6b�,�/OԻvkdf����\"�#~�\0�Vm�iJ�p��U�0SxAW�4(����3����G�e�ʭ�Q`�K!�W�IxM9�!+���1�V�I�mҌ`��[������T̆g�B{MG��u(��J1�߂��r��]�1;e9J%�������my��3i+�o�eK5����F���m�4o�<����%?��F�Z�#�(�iIV5�\0�YA�5C��5w��`ԭ���$W,��䧅�\Z�J\Z�a�\\����+�	�$43bP��PG��T}���\n�K�g0���ZD�i�0lv�4٨.V`j�o�f4F���C��f~!�a�-��\"�	�E�rU]1`y���x�>Ӻ ��)~��\'*`k���w0zyF�8voD䱗QttޙC\n\\�޻B�����Yx�k��9���O�˞�\'�do$�81�s)+��k?H�%J����L������V��FN��Z�)7��})u+>\'|�n,�%�>�R٦W�͜��4xvy��x�hs\"���)T�)M�G�?�T_�7��8��ʣ��T�?\'��Ϫ��\Z>��>��I�\']�^}�������?=Dބ���!h�xޯ����ฦ���u�,� �ٍz��¶�$�l�:���u�����S8����a�\'���&��[�_��C�9�l�:󙿀\0�V���8u{��(K8�v8�dV�r��/�i2/���}�I�$�yBw5���K���u�%@�`$yos>h��pB1Y�B��Fj���\0��,�]�w���Mz�u����g�����V�b�M�;�]�~yjdm������l�tw�\\��̮[��K�����ɠ����s>���W��7Gπ:(Z�v�[;h�A��̲��RV,Cz����(�Nd#�[uԫ���W@����#hX\r4���J�v6R0���\nVQ��Zvt_@ؙ��f�Rd\'w1OX5v8�0�>�=f�G���s�r������=��}�.�=��QϷi���Awiw�a�_��p9���ag��~��[�����Ӿ͆����;����œ');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'33_482c7e3784ce494e','pages_1'),
(2,'33_482c7e3784ce494e','pages_5'),
(3,'33_482c7e3784ce494e','pages_11'),
(4,'33_482c7e3784ce494e','pages_12'),
(5,'33_482c7e3784ce494e','pages_13'),
(6,'33_482c7e3784ce494e','pages_14'),
(7,'33_482c7e3784ce494e','pages_15'),
(8,'33_482c7e3784ce494e','pages_33'),
(9,'33_482c7e3784ce494e','pages_17'),
(10,'33_482c7e3784ce494e','pages_18'),
(11,'33_482c7e3784ce494e','pages_19'),
(12,'33_482c7e3784ce494e','pages_20'),
(13,'33_482c7e3784ce494e','pages_21'),
(14,'33_482c7e3784ce494e','pages_16'),
(15,'33_482c7e3784ce494e','tt_content_8'),
(16,'33_482c7e3784ce494e','pageId_33'),
(17,'16_fa15c8fad5e6ebf2','pages_1'),
(18,'16_fa15c8fad5e6ebf2','pages_5'),
(19,'16_fa15c8fad5e6ebf2','pages_11'),
(20,'16_fa15c8fad5e6ebf2','pages_12'),
(21,'16_fa15c8fad5e6ebf2','pages_13'),
(22,'16_fa15c8fad5e6ebf2','pages_14'),
(23,'16_fa15c8fad5e6ebf2','pages_15'),
(24,'16_fa15c8fad5e6ebf2','pages_16'),
(25,'16_fa15c8fad5e6ebf2','pages_17'),
(26,'16_fa15c8fad5e6ebf2','pages_18'),
(27,'16_fa15c8fad5e6ebf2','pages_19'),
(28,'16_fa15c8fad5e6ebf2','pages_20'),
(29,'16_fa15c8fad5e6ebf2','pages_21'),
(30,'16_fa15c8fad5e6ebf2','pageId_16');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_0_0',1797937589,'x�uTKo�6��W,xRQ/K\nzv�m.��DP�H&,�*I�1����2c�7�����fxA�7Y�إś)���R�YЇ�o���Kb���0ѻ<��8�㙩��&�4�2��h���� ��~�Wm��`����G����\Z�Fo0m���(me߬�4.�V�o`*-+z����U�q3�\\�ٰ����`�X�Z\Z�l�\Zz{5�jˎ+l�.��4Y0!�z57E䍔�:b���FK\nB�0�ëe-�@��w2��F/���\rV�d>�?�KF���ƜНa�}�?�V|j�G��Ftq��_�dű}.�8o����ڳ���_<>����&�8N(�Gg8�j���*�[\r��꘧S�R�F$<��P�+��\0�SZ6������l�Y{&����d��PG{`�Ӷ��i����[?M;6�D\'s��{̵��c���~���{�ij��/��������b\'NwN�K���]��y��:�����I��K�zh�F0�2o�\"E�\'(@��ڏ�j1^�{�¶���v�[k��������ke��iո�?wY�����[�n�F���\0�]��`#x��*P�\0�����ʌu�CG8��f�l���}ᥱ�Wv�J>Zt��� C��\n6\n��(�U�aN�Z)��L�	���\r���x=��f=������\'\0�l\rc������?J^�n��,q&��\\uۀ�T/\n����R�Vm�N[��e;��j�5�뇏ݔ{�ˊ��JE�X57���?\"²�n��\Z�aO��n=��Ɲ���ix�*��F��g�aW���!��:(C�fa�rY\"�Rp�!2� ��\n�<݅Q^�����(J�	��y,�8�)�s��k��'),
(2,'33__0_0_0_0',1797937589,'x��VMo�6��W:gSQ����`w�-��=�DP$%�D���1���%Qf,w�@�mo֛�g��IϢ@���n�g]�E0܊\"�o��~�D�)�\ri���i��iM�1|e��\r7|�N�{���DUƈ�;���HVǵ���*�0��TFt�xio�1)%︦J�FH�u?��L�F�G�u�Q�t�@j���G$iP��(ޙ���rA:،��	Q:cLT�s�xS�&���^�Ё��&:�\0�\'8ڸj54W\'�P�𱍞!�L���{�\'<u8���R��\ZL�_v�ǻ���w�߿���@��|*;�ŕ�-�O%CsZ9����m��h{��c�D��e����ǽ`5�`�px��Za��{�\n��\Z��H����ūN��\nR3�����ھ���\rx�Y<���TQ�z&ݶy�c�8bd�sK��\Z�Ƶ\'�yC��uc��=��Pڤ�kLG>���s�l�a���lǇ���N1Q57U6�{��Q�D���k�����Έf�kl��{����E�������;�5\'���(N��̟�G~<H���^d���d�RE��\0���5EĠ[�bj[x\Z�Y��VRJJ��\"L,�6l,̆sN\Z�u�V�rZ]��b���Z�����(x�,\Z�羸U��ο�8z� m��fٷ�ˋb������DJ%��&�߅�4Rt/$���ϜX�;�	J\Z|&!8,�Uj{�K,��;y�,�A�`)?�V�������F�b���r�^���&/n�8����&Lʣp��oB���y\r�����4\0ןQ=�_���ә.����T�\"���K�A���9aq�V%�z����Ow?��؞�A��f���wW�ߵ�:q��J��_�~���= ��2v�_��2F�2�N�؉��b��_�����>�����feJ�l�ʫ8��q�Vi��I��j��È��B�4K��6ц�4M�hK�0Fͪ<�F�愕%�`�FI��d��̹�'),
(3,'5__0_0_0_0',1797937589,'x��UM��6��W,t�i�eK���a�M�t���A�#��$�$�������Lۛڢ\r�`�g��,ʞdFnY�&ٓ�Y�I��,������W��XV�=����b����k�,\\X�,P��>J8�n��L�:0��V�0ax\Z�#�,(��Zux��H���h���)�c\'ζ���o�p-[+^u?�\0!m��n�J0s0�bMٱ�X|o�;*6�e\Z\Z{�i>�G�	�}܅$1!�br7zC�v�4Uޝ���i&:.�p����\r��#}d1�}=C�p肌�=�#O8�݇\\��|5�6l������ww���}s�d�l�2�Y��\Z�]��V5m��c�jա���n��[xl�Ҳ�is�J5ki�%Z�!��ģf���CS0m����!���XY��ի��jL�8��T]����}<���Z\nY�\Zp]߶�j\0�I�>��,1C0�.0���i{��#Ԧ�[��x�i�G:g?�X\r0�?@����L3]��0�����Cz�3c?�nȅ������j�u��[�nx�\"���Js:����[?�$Z��\"vp�+-��^���Ag���q;\0X%�,�k�&��V\\�	�P�K��: \ru��JY�fyR5�!q���9�Ȫ��(�����RK\'�Ŗ8���t��L���7E��ڠ4h�R��p��\Z3h�ʆW��3\"����_��/:EUUj?��:���s\n��?�.�\0\Z�H�*z&0<�ʋ���_�aY����Ec��\"C���G�E8��E��h�L����ʾܚ�dk�_�5����0�׷����Ό����YA��b���\r.����E�\\Ƅ�-*���f��z�H1;���뷿��z�z\"�A�����W?_�>kG+vb�<������u=��|_���&�ت���v�w����}�w���4Y�I�?(�|��E�&A��b\rL$y\Z���@�a�9�4MW�b�|	sF�8Z��:Lłs�L�a�\0Β��Gʐ'),
(4,'11__0_0_0_0',1797937589,'x��VK��6��W:/6��c��\"	�ڽxs艠đLXU���X��P/���@m� 7��pf�o8fy����ܱ<��/:soܻC�܍����_��3ڰ��$��0\n�h���3W�$�84``��O�;�9t��FUƈ�A�]$ͽ\nh������M�Z*#��:�$��(��<|]*�!��)pa\ZY��GM�����Տ6��!~G{��3W���*�����f샽��3�EU-�:GOo�ۄ_@Q���/�A�g2�s�7���\Z�V�A�:�G���|��EC2�w�Ox���wɏ��h������o�><�?����\"��C����,��3�eZ)���T;v��\Z� �晊���J%j�6K�0в��J���I��m<k�˽9��t\0�6(��<�\0�1;��J��Pϧ��VV�Ŝ+Q�\\���zj\0�!{��Y�1��xQÎ�\r��]�Or;=r��6t�]��c�����KG;�L�`�kD�w�Q�L�Ͻf����3�Ys\rmU��R�5�Z�˽�TS�΍�����=Rq=��؇�z�Y��b��\0��\r�5HQ��Մ���\"��M����Ɲ�U�T�m�X���4$�hY��qlu��=RK�W� �4�e@/7�Q�z�]�.\Z�A�)���]1IZɦ��5��46��C���^Yb;ى�5�B8xX�WW�#��¢��7�����_G�N��p������V2�Wӫ-���w�����\"B��O��(�[�y1��r9����Hͯ��\\L_[�Q����E��{���sY�؋�W��^?}��������\'BkԨ��;���w䧯�ъ�8�X%�叿op+�L��< ?V����ɿ���\'\0I6��E�?�����_�,-�$\nXV&~�i��(H�BN��W�_�����kȁ@G1/�� H����*���x3��C�<\r����\0r_�'),
(5,'12__0_0_0_0',1797937589,'x��UKo�6��W:�)ME=m=�A�@����=5�	K�JRq� ��C�L��{�k�7����y|�aY����ܲ,M����׋»E,�~�����3ڰ��t�a����`.�4�\n�����m��(���u�We�h`������2�Z)���:#��{���ʈ���i��\\�yJ�?��JtFH��at�0���+�h�AӚ�U�*�S��w��oi���ֲW|���3l�:�I<a�(��\\gh�y��	�Ν���i$#:9��p�]�h�kP���pƇ*:���hH&����g��C.��r5R��������ǻ�_�?\\(����2��\\��LK%�s�*5�G��v�<S�t��Q�D�ͶThXG;%�5oԲO�)��:�+�a���7޷OBɶ����]����R�+]��`�i�G�#$7�M)�I��ێ\Z�����l��*���̠fyZ x���r��v[;j�]�|�FG�!���v����8&Z�v� ��6�:;�㲅��ֈz�5�Y�-P;�n�B�J�B+�����2˄6�$��Rz*/�O�娳\\Ÿ̒��93HQ-6��BA4�V��\nM����Ɲ�E�T.eH,\\��=�ɪ�����X�����=_����-ʀ�8xn��<�QsT���8+���D$���I�Rֵ�/!��ŷ�PB�����6���ଦg��ò���A���!,��9;Z��^�������p��p\Z9�T�P�6�7��>��jF��?���ᬰ��6��/�3�}���#��\r�Й��\n������\nE�}�����Lܘ��Z?�����ׇ[�5jT�L������EY����*yJ��ƭt=���|_���\n&�\n�\0l�є�b�����}�����a\n<���+H	�$/S�#?��,b%˙����iIx dk?Y���8\'VQ��1K�0�,�9[��'),
(6,'13__0_0_0_0',1797937589,'x��Uˎ�6��+Zd5��zK�.I�hgcg�A��LXU���̿�R/���@}�I��u��%EP<�ݓ\"M�g]��7��ޏ���I�mHۏ@��ay4Y�b��+KZx�7��ы?��	�x�\0y�We�h���5�1�\n��Vr��@��{�A-�]=��E�����T��	�\'�	�H�_�\"HG5nHW��x.�A���❹��]D���6 �g���Z��NzS�&���NL�<�	����\'8\0ڸj54W\'�P��c��^�h�f���/8���R��\Z\ZL�O���f�����/��]IX�;���e���@�q�d��S�ХV`p0��\',ڞ?�X*Q��YJ��-�q�X�ћ���ųh�ܛcϗ@��1�ck�*��͛�	�Z4����f}�d��P�vUT��ٷ����(΁!ٻ$Sెܸv�7�(�ß�/l+7C���iLG>�5��G6�0c��衼<hǙ����\Z��dT;��co�9.;~��Ѭ���*���έ[��\ZH����Xs��������=?�bzn/�o����R7�L\0TIݚ�Ġ[�j�[x#�E��VRJJ�N�*L,�6$f�%\'\r�:L�z��.	��x�|=ėF܁p�f;΁�4�EG���k._����?�b���M#k��i��H^)��>��v��4�B8pY�W���_�\r`ю���4�����_{�O�+w��+���F�b��Ŗ��&<[��W-��<��|.\n�/o�xx�����/��opu.�/��(���NP��.�뺄my� !;������~}��=Z�F���ᛟo�_��:q��J���oa+�N��< �W𷸂�ߵ��\'\0H6\Z�E���񿲏_���~T�e��e���9�\'YZ�%c����aV�~^�D�H�y�#\Z<�h@��L2�U�FQ����O|l��'),
(7,'14__0_0_0_0',1797937589,'x��UMo�8��t�fE}X��=m�]�\rpz艠ȑLX�$U���w�i�J��.Z�&��p��4H�dJnY���\'����J��\"�������ԳƲ��d�al��µ`�$��`����;)��I=����L�Z��:�r��V-�7)I=���V�E�:Xw�$J=���p-+�b���T|?�%xs4�duѲ�X~o�$%�k�0\r�]�F���$�۾]B���y>��=��p~M��ӟ��9�ɀ��_�� m�+C[��	\'�o�c��\Z�1����	�}̔8ΩѴ�������������BȂ�!g��.\\��Ls�*ڜj�.U�E����>RY5��P�e���Q*-T����h�Go���jo�\rL�k[F�N�����Jɯ�x+�lؠ!���L��v珦��}�5>l��\\����\Zj5\0��\Z�p��xO0�:����y��{$Զ�\Zd�8M��\':�0�X0Λ;G��.��f�\0�`Xk)뽃��g�~h�YN�\Zj+���aW��f�-\r�0��P+j�i�s�LR��:+bǃ��%�;�w����U��b@��`)*��`6�(*|/�E�����R֝�Y�T�mXu�h/9)ɺ�</�����=RK\'�g� �4�\Ze@K>���L�AsTּl\\4؀zQ\"\n�<�bR4We��ק��;|,!��>ꈭU-9+�p�*��#��²ꟴ�7�����/#mN�E8��\"hp�q��lz��~a+�-E���bD�&����#O�3�<\\A�h~�	��d��\Z����`���ުj���f�4o��~x������7]O�1�Qs3v���+��g�h�N�;%����׸���A��_+�g\\��[���	@���t�}����g`�G\0!�I��`����#\"Z��� ��Y�Y%9ϣ��y�J8���Y��e\'<Add#��c˾i'),
(8,'15__0_0_0_0',1797937589,'x��UKo�6��W:���J+��	��/�z\"(r�%VU��za��w���:z�+�M�������eA�\"3rǲd���,̼N\n���n8��O�̳Ʋ��d�al��µ`�,I�	����������6�Ы�V�0c�\Z�\"i�@K�:o2�y�7^4J[ٔc��7F�����ek��X���V�f��1\'C+֔+�N�6R��-���+بN�%A�ϰ\Z�$�	Y�u��Mo,܆_@S���g�h�3���p����6�3�W�H8�C��>�ѐL��+�8`�S��i	���o;���������O?\\IY0{�w�e���b�i�UM۵v�R�:48A��3�u�-UZ�.m=��B�Z�j�V{�F1���$\Z�����Lۢ0`�>`.����R2UWzc���j���υ,\'����[j5\02�Z�T����G�i�N���}Oj��-�j�F4�]�|�#�3�Ί��ˋ��2]�u0�����Au3c?��<�e�ύ�Ւk�W��@�9u��+͹�E\r0����Y�VgE�tTZ������\\�4ˍ�\'�c����Э)�A���+XLH|��v�ih/!��u�j\"UK6=,�KN*�6���[�3~@j���r?�/��A�\n��vн5GeëN�E�\r�7%��gWL����qI1]��������QOl�\Z�YE/���Uy���[�!,�᷵�F1أ���kO��v��}x�4Xm�i��^����|g���K�/\"d��?��f����^�<�\\�\0�p�\'�G��7�*g��Veń�V%*��yOb/�_-H�{�������o��HcP��v��ߑ�jG+v�x�+y*����t3�������L��<��dk(���}�+��U���\n���m@�9D�� ��q��i�7$/�$`�v#�8��TD�<A$IDn�<�SV�a��7A&\0C,�['),
(9,'17__0_0_0_0',1797937589,'x��UKo�8��tN�������\r�lsqz�AQ#��$jI*��w�\'c�,�}�(����p83�7��H�5K׫�I�a�u\"��[_�����_��3ڰ��8�`\r�rf�̲N�*0�G�ߝ�sh&`�zU#j�0<M�\"I�@K%;�^�$�|op�Rє�1��\Z��S��4W�5B�]wCȅ�$�Oa	����V�);V��mxIE���LAc�`-;���?��o����#�����u���P�	@Q���O�A��d@����H�Z�N�Z�#��mt�{��!�;�O8���L���j4m��ҿn���>���q��LȂ�!g�3.\\6�L%k�.�c�j١���n��[xl�T�ti��\n5ki�Z����_ţhr�7��`��ѳc�߾�F<���TYe\r�*]ue�E��ӛ�	\r�[�����]K�@�d�R͑�3����Q�l<bw�{�����N{\Z�@����\0��5ھw٩�j�J0��V��;H�y�ͧ�Ny�e�O�՜kh��;�vz�\"���J�r\ZI50�wn�I$������x�*�c{�}a��e�(��\0`��3Э)�@�Z�cB9��R��M����Ɲ�Y�T�mXY8�N9�H�P^��qlu�����jI6��;��)�h���UA+�B7�~8� A*\Z^u9��[�|U1�sxt�%i!��f0f�,��w�jB��������FpV��aY�]m� �\Z����oԆ9�D�G�,��p�����b�L��ٖ��z|����#B6�����q܏�\Zc���t$����>���}:���O�(&ӻ�#�ST�YO�\r��l_bv���w�o����=Z�F���ዷ�/�ъ�8\\Z%����/qI]�6= �}#��6�����W�����\'1����e?�^%k?�`�ϲ �H� Z�����<AK^\0��6A�YnBX1�!cY�	)����$��Βu��,��i�z'),
(10,'18__0_0_0_0',1797937589,'x��UKo�6��W:�YQ���.��\\�=�DP$%�D���1���%Q��l���=���p���Cʨ|%�%e�)�u��(XpX~;����oSF�\r�i\'Q���1���-7|�ξ[��P�DUƈ�;���H^5Ǎ�#��%*�0��TF�u���&EI(��5Ub0BB��9g´��\\X���[�7#i8^ʟl��Ea��xo.`-GE����fj�M��c����.�3�7�\'���r���ӛ����9���U��:�b�Om����1Z�{�G<u8�܇J�Ú\ZL>����~������I\0z����,P��2����p������v�E7�K%\Z�6K�0�#�\0�9��Ût\r�;s��\0\\ۀ0&v\"p���k-*��᫩��$]��t;6�\'|�!���\'�P���U�fуe`;`�8����N�d�����Ғ�<m�N�G�0V�V��^+Yb�3S��k9�sG;�D5�x�؊~�!���6;��О�?�F��]c[�rl\'�/\"\\\r�ѧ#�K�9Qt�Gq���d���ㇽTL/�E���zRi�53\0U��@@��ȁtc+XM �^\rr�������s�J˵\r���=�u��VW��Z�8_���܈{�na��N��g�a��vd�����W%\"���\'_Lײm�~�b~-��\'�׊��O,���%->��Ej{��xXt��v�1��0���H��v�?x4:�(Ql5�ز_ٍ\'�1�W�1A���쫯F���y/�����\0�� }0����3}n�&I��C�=/SP�ٹO�8�o.$�z����w���؞ث��7K��~�B?}�V����*y)����t=�{@��\n���~�/���\'\0H6\Zc\'�����㗜�0Oy�2�4�iD�(�I�*����4��$لCU�I�!�\"FY�/�,�s�ea\\D		K�{SYZE���d��'),
(11,'19__0_0_0_0',1797937589,'x��UKo�6��W>�������.�ڠ�d=	�${��-W�3���T���n[���HQ$��\"Ƀ�Y����.�y�{�`�-`����M���=�\ri�H�8� �FU���$��x�\r����A0���r�*cD�g��H�{%Ǖ�=\\�s�{�7:j��h+��;닢�S���k�Dg������	SKz��\"HG�5�I[���x*��%5�[��[����]D����BOe9��<��p>r��s�?�\'�:����W+\0m\\5\Z����?���F��,\Z�)����s��\\Hv^����=��n�������o$,�pF{�@ek�˸T���Z;t��=��	���O�JT.m�RaxC:�)Vs�F1�7�$\Z&������a�X����#��Nւ��u_yS��u�Ƿ�����*JQM��~:l����\\�)�XAn\\;���kr��ß�/�A�����Ә�<�%�)F:�0cKu��}q�hǙ���*k�dP;��Sg�9���ӧֈz�5�U��vn�\"��@*�z\0Z�5\'��(�<p#��\0��$�S{�}[�#N\nm�f�J���� ��\nP��A.: 4��RR\Zw�ab��aga�_rR��Ŵ������#P�g�� �4�d�k87�a��9,ZZ��_4Xs��D$�3��I�Rֵ<-)�� �<��T�7�����VPR���aYm��G\0~�7�E3<c�7������o#e�m�=�	\Z�6J[L/��76�E���E!�~�/��������\0��@�`~�������E1�����}�����KX��	�A��}�������5hT�L���\n}�Y;X��k�����\Z���8h���W��u��+�]+xx�d�1���u�}�B�2�a������\"M���\0C1���$Aa�\re�!\"$�%lW���]�3N�2I�$.#�\'aJ� ���Ï�^'),
(12,'20__0_0_0_0',1797937589,'x��VMo�6��W:;�(i�d�`$AS��e�CN�i��D���^��J��^9\n�MP�b�g޼�,˓�I���e�d�4�:)�[�\'�m������#k,��Xmi�%�l�p-���e�G*��G�߽\Zl��jke\r�cЈY�Q�Ԫ��MN�(�G���M�\'�&Kg��H��{0\\��J�w�1@H[)~�a	�cN�V�);V��mxIE↶LCcg�Q��S�$���p�ň	Y����\r���h��;c��Lt�\n\\����6�3���#��{\ZCphJ����_x���N��t5��������û�w��|x?�v��g��a�j,�L�jڞkG�jա!���>RY���R�e�͵TZ�YK[-�jO� ��f1�F��=����-\n��N�e�q�\\Yu%�B�\r\"29*�T]��!�oY��ƪ7�X��k*d9j���o��\0�/Ն-���3���I��	�%�ݮŞ����}�Sc��\0��M�:��ݥ�n�K���V�9H�}f��M�������j�5uU�=P7�a�d`�y9�����0�������J3�K�K3x�3V3n\0�d�ŀaM�)j�U0�P5��i��Vʆ37ɔ�����Ewٓ��ʋr:�T�?`k����,.��A�\n�/̶�\n3h�ʆW���\r�W%��_�c(&EUU�8��>���s	��?��3��F5���^�rv�;��k}CX���v�F1أ���<��l��΂&ggZL�gW�|/�k1�[k1#d�ī�|-z�}�;q�}x�����_H����E�M_[�Y� �!��)*�G�6������!��>�~�����D\Z�\Z57#�W?_���jG+2q�vJ��?_�V��? �|�?V�?��ɿ���\'\0�l\r�^�?��7����$[�����e��_�[�\r�%�v�,YZ�$fE�%Ȯ`	�7銧��b��V��I�q�,x�\"l�!e,K��Orr��'),
(13,'21__0_0_0_0',1797937589,'x��UK��6��W:/6���=,��)����!\'�G2aITI*^c���C�̵6\n�MP�&}C������ 9�cy��O:s�ܻy@��n��I�mX�\r@��aY4Z\nř��%�=5���ك���r�*cD3�נ�.�ɽh�d��uNr��ƃZ*#���4��(��<�](�!1����0�,��[��賦5k��U@�����Ҏ)h�\nֲWŒ �g���I<a\\��|\\�x�7�PT:1�<闙���������Ѵנ.��pƇ6:߽04�L��<�q�����%4�������������_>�_IY����B![�]���\r�.�c�\Z٣���n�h:x�T�ri��\n\r�h�Z�����Ɠh�<�ss0m�ɺC���������ߚ�w[̺�Ķ�F #�sI-��\ns�(\03��Y�l<� ;������F��]�|lFgj��v��_���T����Z�G�ʹ���y����p��\ZQ/�����\0�Ω[��X�_\n��TS���2ˁ6����I*������G���Q�0#�U�ޠC��`)��V�����v������ҸS��ʥ\r��y�IM6--�j���޳��ҙ��|_i�2�5����{=j����{W\r� _����]1IZʺ��%��ep�>�P*��\rYb[ي���J8xYV���\n¯�h�g�r\Z�`N�`�מ��m�ν�r\Z\\lS|1=۲כ��������?��߬��y������ 7!}4?�W�l�ڪ�������*Qqe3�{{�v� 1;���݇��}��=Z�F����7?�!?}ՎV����*y*����t3���|���X���\n&��\n�\0$�hJg1����d?�,.�4$Q�AY�Ea�� �����AJ��1�� N�$�	�f�ד�~I�I\Z�$\'!�$��?nJ��'),
(14,'16__0_0_0_0',1797937589,'x��UKo�6��W:���V�#	��]��A�#-aITI*���ޡ^K�:\n�MP�&}C����Ê�x��aE�-�L�)�A�������Ͽ��-k,k�H�d���<�,\\f���,�^���^\n��E�^�����k�	Ɋ�Zk5`xS�\"��Q�ʮ�CG��V��`����\nc�M>@H�(���%��9\Zڰ�X\rt.�a���홆�^�F\r��	�p����$3&dU-�M�\'��p���*/f���2�	����\'8B�@���?�Y𱍞!�/8tCf����,8`�c��q\r����;�������ۻ�>����`����W��.�J����ڱK�\Z��ai��T�=<�TiY��9J��������Lb��Y4B=�cK0m�����;`���*�4C=�zkVVq�Ü+Y�\\���{j5\0�z�R��՘	�԰�z�x�.�{��95^:���Y�>�	ƉZkq���nx���z����CFm3c?�n��7|>uV6k�W�uS��V��r�]:x򲈁�J���\0ǃ����%�%�hV\Z���U���C��h)j�U����_v�i��V��3�ʐ��\r[�ᜓ�d�U�^�V��? �t����;$�\ZJw�`��o��O����P����KG�LB���� ��ԫ�Qx^���0E+�4�杝f���J�~�رݩNr��35�eU_�vW~�L�e;�d�Ө{�����l���N���3-Vӳ+��e�b�kƄ�Q���p�ݷ����|0�����>�����s1}i{�qB���[ޞ����]>�݉�x{�51;�������|w�z\"�A����o~|C~���؉ÕS�\\��}���j\Z����{9������L���<>�^^��}�}�\\�YgےT��6�Ѧ��<�*��Ҝ�	+	�io�<�Y\Z�$�x��a��Ô$���iL [�p��?�%�/');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_0_0','pageId_1'),
(2,'33__0_0_0_0','pageId_1'),
(3,'33__0_0_0_0','pageId_33'),
(4,'5__0_0_0_0','pageId_1'),
(5,'5__0_0_0_0','pageId_5'),
(6,'11__0_0_0_0','pageId_1'),
(7,'11__0_0_0_0','pageId_11'),
(8,'12__0_0_0_0','pageId_1'),
(9,'12__0_0_0_0','pageId_12'),
(10,'13__0_0_0_0','pageId_1'),
(11,'13__0_0_0_0','pageId_13'),
(12,'14__0_0_0_0','pageId_1'),
(13,'14__0_0_0_0','pageId_14'),
(14,'15__0_0_0_0','pageId_1'),
(15,'15__0_0_0_0','pageId_15'),
(16,'17__0_0_0_0','pageId_1'),
(17,'17__0_0_0_0','pageId_17'),
(18,'18__0_0_0_0','pageId_1'),
(19,'18__0_0_0_0','pageId_18'),
(20,'19__0_0_0_0','pageId_1'),
(21,'19__0_0_0_0','pageId_19'),
(22,'20__0_0_0_0','pageId_1'),
(23,'20__0_0_0_0','pageId_20'),
(24,'21__0_0_0_0','pageId_1'),
(25,'21__0_0_0_0','pageId_21'),
(26,'16__0_0_0_0','pageId_1'),
(27,'16__0_0_0_0','pageId_16');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1795334294,1794119207,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"}',0,0,0,0,1,1,31,31,1,1795344511,0,0,0,0,0.5,1,'Home','/','TCEMAIN.permissions.groupid = 1\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete',0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__Home','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,1,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(3,2,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,1795333022,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(4,2,1795333042,1795333022,1,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(5,1,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','pagets__SidebarLeft','','',0,0,'','','',NULL,0,'',NULL,0,''),
(6,5,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(7,5,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(8,5,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Parking fees','/revenue-payments/parking-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(9,5,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Market fees','/revenue-payments/market-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(10,5,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Waiver of interest','/revenue-payments/waiver-of-interest',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(11,1,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Health','/health',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(12,1,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Environment & water','/environment-water',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(13,1,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Trade & tourism','/trade-tourism',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(14,1,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Public participation','/public-participation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(15,1,1795334294,1795334294,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Contact','/contact',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(16,1,1795334294,1795334294,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Search','/search',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(17,1,1795334294,1795334294,0,0,0,0,'0',2048,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'E-services portal','/e-services-portal',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(18,1,1795334294,1795334294,0,0,0,0,'0',2304,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Accessibility statement','/accessibility-statement',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(19,1,1795334294,1795334294,0,0,0,0,'0',2560,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Privacy policy','/privacy-policy',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(20,1,1795334294,1795334294,0,0,0,0,'0',2816,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Access to information','/access-to-information',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(21,1,1795334294,1795334294,0,0,0,0,'0',3072,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Tenders','/tenders',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(22,1,1795334294,1795334294,0,0,0,0,'0',3328,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Service navigation','/service-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(23,1,1795334294,1795334294,0,0,0,0,'0',3584,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Footer navigation','/footer-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(24,22,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,17,0,0,0,0.5,4,'E-services portal','/e-services-portal-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(25,22,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,15,0,0,0,0.5,4,'Contact','/contact-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(26,23,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,18,0,0,0,0.5,4,'Accessibility statement','/accessibility-statement-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(27,23,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,19,0,0,0,0.5,4,'Privacy policy','/privacy-policy-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(28,23,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,20,0,0,0,0.5,4,'Access to information','/access-to-information-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(29,23,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,21,0,0,0,0.5,4,'Tenders','/tenders-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(30,1,1795336956,1795336956,0,0,0,0,'0',3200,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795336956,0,0,0,0,0.5,1,'News','/news',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(31,30,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795336956,0,0,0,0,0.5,1,'Article','/news/article',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(32,1,1795336956,1795336956,0,0,0,0,'0',3840,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'News records','/news-records',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(33,1,1795345582,1795345582,0,0,0,0,'0',3136,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795345582,0,0,0,0,0.5,1,'Page not found','/page-not-found',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','',NULL,'',1,1,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,32,1795336956,1795336956,0,0,0,0,256,NULL,0,0,NULL,'',0,0,0,0,0,'Trade & markets',0,0,0,0,'','','',NULL,'',NULL,'trade-markets'),
(2,32,1795336956,1795336956,0,0,0,0,512,NULL,0,0,NULL,'',0,0,0,0,0,'Roads & transport',0,0,0,0,'','','',NULL,'',NULL,'roads-transport'),
(3,32,1795336956,1795336956,0,0,0,0,768,NULL,0,0,NULL,'',0,0,0,0,0,'Health',0,0,0,0,'','','',NULL,'',NULL,'health'),
(4,32,1795336956,1795336956,0,0,0,0,1024,NULL,0,0,NULL,'',0,0,0,0,0,'Revenue & payments',0,0,0,0,'','','',NULL,'',NULL,'revenue-payments'),
(5,32,1795336956,1795336956,0,0,0,0,1280,NULL,0,0,NULL,'',0,0,0,0,0,'Public participation',0,0,0,0,'','','',NULL,'',NULL,'public-participation'),
(6,32,1795336956,1795336956,0,0,0,0,1536,NULL,0,0,NULL,'',0,0,0,0,0,'Environment',0,0,0,0,'','','',NULL,'',NULL,'environment'),
(7,32,1795336956,1795336956,0,0,0,0,1792,NULL,0,0,NULL,'',0,0,0,0,0,'Water',0,0,0,0,'','','',NULL,'',NULL,'water'),
(8,32,1795336956,1795336956,0,0,0,0,2048,NULL,0,0,NULL,'',0,0,0,0,0,'Education',0,0,0,0,'','','',NULL,'',NULL,'education');
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,1,0,1,'tx_news_domain_model_news','categories'),
(2,2,0,1,'tx_news_domain_model_news','categories'),
(3,3,0,1,'tx_news_domain_model_news','categories'),
(4,4,0,1,'tx_news_domain_model_news','categories'),
(5,5,0,1,'tx_news_domain_model_news','categories'),
(6,6,0,1,'tx_news_domain_model_news','categories'),
(7,7,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1795334316,1795334316,'/user_upload/_temp_/importexport/data.xml','165cd81b05433cbd58fd78992daf226ea111f5bf','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','data.xml','ebf3036b95d3c9c905f56c226d5364a9aefa6554',1795334316,1795334316,33933,1,1,'text/xml',0,0),
(2,0,1795344511,1795344511,'/user_upload/slides/slide-coast.svg','ff045dfdd71e6acbcb55576edfcd297e7b28ce67','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-coast.svg','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795344511,1795344511,1233,1,2,'image/svg+xml',0,0),
(3,0,1795344511,1795344511,'/user_upload/slides/slide-rates.svg','1e61ced89c016178e02a3c5bf79eb2de9fc6ddef','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-rates.svg','930ad2b62005be8ab906802601193f671beda593',1795344511,1795344511,1214,1,2,'image/svg+xml',0,0),
(4,0,1795344511,1795344511,'/user_upload/slides/slide-community.svg','fa4ea1a512790f3c4a1936302b29a1a691654ebb','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-community.svg','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795344511,1795344511,900,1,2,'image/svg+xml',0,0),
(5,0,1795344518,1795344518,'/user_upload/_temp_/importexport/data.xml.files/20ea8f7cede2a53c268a4bab9647c06acfed9ff3','3a0d8dd4dab01965f63cc1874ec27659e68ab2d4','a20b30e6345e127e49790026ced895ee898ede1b','','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795344518,1795344518,900,1,2,'image/svg+xml',0,0),
(6,0,1795344518,1795344518,'/user_upload/_temp_/importexport/data.xml.files/54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','bf9643ba7780e40c2cad570672027d3debcd9d69','a20b30e6345e127e49790026ced895ee898ede1b','','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795344518,1795344518,1233,1,2,'image/svg+xml',0,0),
(7,0,1795344518,1795344518,'/user_upload/_temp_/importexport/data.xml.files/930ad2b62005be8ab906802601193f671beda593','aa2ff46d1695ecafd15b9d47e0b7f1c24c270008','a20b30e6345e127e49790026ced895ee898ede1b','','930ad2b62005be8ab906802601193f671beda593','930ad2b62005be8ab906802601193f671beda593',1795344518,1795344518,1214,1,2,'image/svg+xml',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1795334315,1795334315,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0),
(2,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1600,600),
(3,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,1600,600),
(4,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,1600,600),
(5,0,1795344517,1795344517,0,0,NULL,'',0,0,0,0,NULL,NULL,0,5,NULL,0,0),
(6,0,1795344517,1795344517,0,0,NULL,'',0,0,0,0,NULL,NULL,0,6,NULL,0,0),
(7,0,1795344517,1795344517,0,0,NULL,'',0,0,0,0,NULL,NULL,0,7,NULL,0,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1795344523,1795344523,1,2,'/_processed_/8/b/csm_slide-coast_a539169108.svg','csm_slide-coast_a539169108.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','Image.CropScaleMask','a539169108',1600,560),
(2,1795344523,1795344523,1,3,'/_processed_/f/f/csm_slide-rates_202cf46cda.svg','csm_slide-rates_202cf46cda.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','930ad2b62005be8ab906802601193f671beda593','Image.CropScaleMask','202cf46cda',1600,560),
(3,1795344523,1795344523,1,4,'/_processed_/e/b/csm_slide-community_e5b6b5187d.svg','csm_slide-community_e5b6b5187d.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','Image.CropScaleMask','e5b6b5187d',1600,560);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,1,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(2,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,2,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(3,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,4,NULL,NULL,3,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1795334315,1795334315,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1795336957,0,0,0,NULL,'News images','1:/user_upload/news/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1795332992,1,'BE',1,0,2,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"Sidebar probe\",\"bodytext\":\"<p>Rendered from the area sidebar.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795332992,\"t3ver_stage\":0,\"tstamp\":1795332992,\"uid\":2}',0,'0400$Ab_ebDixmlobc09ZW_wpQOm13MVZdCpf:01dbc21fdb1263685b9147b3b1596ea8'),
(2,1795332999,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":null},\"newRecord\":{\"backend_layout\":\"pagets__Default\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$xqYtF2Yzjz8vs6EvJQvzLj3QUpVEEGdA:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1795333001,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Default\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\"}}',0,'0400$dxU1W8i-7n0ls8Dxve2BCaS2_U6etDoY:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1795333004,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Home\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"}}',0,'0400$12o7r9be8NdlTq7M72UstYxByrD_Sh_g:e175f7045d7ccbfb26ffcf279422c2e5'),
(5,1795333006,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\"}}',0,'0400$s0fUPA88SDA-I6r3a2F12T6-HMxysVUK:e175f7045d7ccbfb26ffcf279422c2e5'),
(6,1795333009,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarRight\"},\"newRecord\":{\"backend_layout\":\"pagets__Narrow\"}}',0,'0400$rWk3qQFI-05fLi5WkRdZtrLMsXXEvAU3:e175f7045d7ccbfb26ffcf279422c2e5'),
(7,1795333011,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Narrow\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$Xfdponrx3mLaIVs0SAIfgknY-Uy1U1cn:e175f7045d7ccbfb26ffcf279422c2e5'),
(8,1795333022,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":2}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:f11830df10b4b0bca2db34810c2241b3'),
(9,1795333022,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"backend_layout\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":3}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(10,1795333022,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":4}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:412add0b3eb6ec8f1cb6710aea92e21e'),
(11,1795333042,4,'BE',1,0,2,'tt_content',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:01dbc21fdb1263685b9147b3b1596ea8'),
(12,1795333042,4,'BE',1,0,4,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:412add0b3eb6ec8f1cb6710aea92e21e'),
(13,1795333042,4,'BE',1,0,3,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(14,1795333042,4,'BE',1,0,2,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:f11830df10b4b0bca2db34810c2241b3'),
(15,1795334294,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"backend_layout\":\"pagets__SidebarLeft\",\"backend_layout_next_level\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":5}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7ef5a4e3e11db8ac3fea4d7a75468161'),
(16,1795334294,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":6}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c75354c439a48dbde16b03ac553a080d'),
(17,1795334294,1,'BE',1,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":7}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:df50bb24cbce671cf0d61f42fbbef601'),
(18,1795334294,1,'BE',1,0,8,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/parking-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Parking fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":8}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:595375f2fb9f014e091eb08fbc51ec88'),
(19,1795334294,1,'BE',1,0,9,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/market-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Market fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":9}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(20,1795334294,1,'BE',1,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/waiver-of-interest\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Waiver of interest\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":10}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e904af5a60392ab3165f5849f5877e45'),
(21,1795334294,1,'BE',1,0,11,'pages','{\"doktype\":\"1\",\"slug\":\"\\/health\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":11}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:51bca2bcf14079cc366c99de31802400'),
(22,1795334294,1,'BE',1,0,12,'pages','{\"doktype\":\"1\",\"slug\":\"\\/environment-water\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Environment & water\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":12}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:d6f57183d4ec29f4a568a174f36b861b'),
(23,1795334294,1,'BE',1,0,13,'pages','{\"doktype\":\"1\",\"slug\":\"\\/trade-tourism\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Trade & tourism\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":13}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:8a89606121863fe3a2ec2ea63ba83d69'),
(24,1795334294,1,'BE',1,0,14,'pages','{\"doktype\":\"1\",\"slug\":\"\\/public-participation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":14}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aaa274fb7a5f76c9749f1b2c8fba84a4'),
(25,1795334294,1,'BE',1,0,15,'pages','{\"doktype\":\"1\",\"slug\":\"\\/contact\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1536,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":15}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c97934f122918253f51c81fbe45fd105'),
(26,1795334294,1,'BE',1,0,16,'pages','{\"doktype\":\"1\",\"slug\":\"\\/search\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1792,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Search\",\"nav_hide\":1,\"backend_layout\":\"pagets__SidebarRight\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":16}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:878fab4218e507eb25dda6ac21dd7ff1'),
(27,1795334294,1,'BE',1,0,17,'pages','{\"doktype\":\"1\",\"slug\":\"\\/e-services-portal\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2048,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":17}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:dd30e16e220c1cff5911b320aa60dbce'),
(28,1795334294,1,'BE',1,0,18,'pages','{\"doktype\":\"1\",\"slug\":\"\\/accessibility-statement\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2304,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":18}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:9e9e8c5ba4be654320a3cd25d73d01a4'),
(29,1795334294,1,'BE',1,0,19,'pages','{\"doktype\":\"1\",\"slug\":\"\\/privacy-policy\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2560,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":19}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:25dbd94d40a6ff54757b6e36bf898997'),
(30,1795334294,1,'BE',1,0,20,'pages','{\"doktype\":\"1\",\"slug\":\"\\/access-to-information\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2816,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":20}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:1d0206225cc3f30f7ba150ff3aae8ab7'),
(31,1795334294,1,'BE',1,0,21,'pages','{\"doktype\":\"1\",\"slug\":\"\\/tenders\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3072,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":21}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:bb4ab293ec9d3ccfe43678d078f6cea0'),
(32,1795334294,1,'BE',1,0,22,'pages','{\"doktype\":\"254\",\"slug\":\"\\/service-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3328,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Service navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":22}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e5087395befe41329009e7b123017494'),
(33,1795334294,1,'BE',1,0,23,'pages','{\"doktype\":\"254\",\"slug\":\"\\/footer-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3584,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Footer navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":23}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7e88f7aa7664c6f494370160b60358a1'),
(34,1795334294,1,'BE',1,0,24,'pages','{\"doktype\":\"4\",\"slug\":\"\\/e-services-portal-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":24}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:219ad4d34a3e23c6ccf2ca87da6bc52b'),
(35,1795334294,1,'BE',1,0,25,'pages','{\"doktype\":\"4\",\"slug\":\"\\/contact-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":25}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:464961a1483e7dda27d23c882ff696bb'),
(36,1795334294,1,'BE',1,0,26,'pages','{\"doktype\":\"4\",\"slug\":\"\\/accessibility-statement-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":26}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:544939248209022b223d317bc97b7099'),
(37,1795334294,1,'BE',1,0,27,'pages','{\"doktype\":\"4\",\"slug\":\"\\/privacy-policy-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":27}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:97019c60b3ac7f8b98007c072afa2f0f'),
(38,1795334294,1,'BE',1,0,28,'pages','{\"doktype\":\"4\",\"slug\":\"\\/access-to-information-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":28}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aa68f552fa168869c47f8dbefb43cba0'),
(39,1795334294,1,'BE',1,0,29,'pages','{\"doktype\":\"4\",\"slug\":\"\\/tenders-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":29}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:2d7ab27da714dae3c89a6e0cb79b80cd'),
(40,1795334294,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\"}\"}}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e175f7045d7ccbfb26ffcf279422c2e5'),
(41,1795334294,4,'BE',1,0,1,'tt_content',NULL,0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7fa2c035f26826fe83eeecaaeddc4d40'),
(42,1795336956,1,'BE',1,0,30,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3200,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":30}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:e3e225390eee037c1380949b378763b1'),
(43,1795336956,1,'BE',1,0,31,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\\/article\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":30,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Article\",\"nav_hide\":1,\"backend_layout\":\"pagets__Article\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":31}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:9cb7b2b3fac90492135e3538aed4605a'),
(44,1795336956,1,'BE',1,0,32,'pages','{\"doktype\":\"254\",\"slug\":\"\\/news-records\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3840,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News records\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":32}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:302984e7412d7a45766e1d6304831138'),
(45,1795336956,1,'BE',1,0,1,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"trade-markets\",\"pid\":32,\"sorting\":256,\"title\":\"Trade & markets\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c6c8e24453121a7d668fe4b1031ebf88'),
(46,1795336956,1,'BE',1,0,2,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"roads-transport\",\"pid\":32,\"sorting\":512,\"title\":\"Roads & transport\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:497028e4af2a2cda8419e90cde34f71b'),
(47,1795336956,1,'BE',1,0,3,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"health\",\"pid\":32,\"sorting\":768,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:265912e2a2dda6b4b6be4e7069754d09'),
(48,1795336956,1,'BE',1,0,4,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"revenue-payments\",\"pid\":32,\"sorting\":1024,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:a832991055f9726888b6b83414d05630'),
(49,1795336956,1,'BE',1,0,5,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"public-participation\",\"pid\":32,\"sorting\":1280,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:55bc761d39a2d7a8b56679774f51dfe6'),
(50,1795336956,1,'BE',1,0,6,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"environment\",\"pid\":32,\"sorting\":1536,\"title\":\"Environment\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:0580043665451ed803b9e5d021b149fe'),
(51,1795336956,1,'BE',1,0,7,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"water\",\"pid\":32,\"sorting\":1792,\"title\":\"Water\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:e6068a768abec7500a6d253c29088f52'),
(52,1795336956,1,'BE',1,0,8,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"education\",\"pid\":32,\"sorting\":2048,\"title\":\"Education\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":8}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f564fff7cae82b30644518a57bd7a8a6'),
(53,1795336956,1,'BE',1,0,1,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-fish-market-opens-at-the-jetty\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New fish market opens at the jetty\",\"datetime\":1793595600,\"teaser\":\"Sixty stalls, cold storage and clean water for traders and buyers.\",\"bodytext\":\"<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night\\u2019s catch and running water at every stall.<\\/p>\\r\\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Trade &amp; Markets Office, +254 700 000 010<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:fccd16ea3664ec003726b2a72ea38f4b'),
(54,1795336956,1,'BE',1,0,2,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"beach-road-resurfacing-starts\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Beach Road resurfacing starts\",\"datetime\":1793077200,\"teaser\":\"Works run for six weeks. Matatus take the diversion via Market Street.\",\"bodytext\":\"<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.<\\/p>\\r\\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Roads Department, +254 700 000 020<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:640f28e5c1a5ec2efb19c26699b464a5'),
(55,1795336956,1,'BE',1,0,3,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"free-health-camp-in-ward-3\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Free health camp in Ward 3\",\"datetime\":1792472400,\"teaser\":\"Eye tests, vaccinations and screening, open to every resident.\",\"bodytext\":\"<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.<\\/p>\\r\\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Health Department, +254 700 000 030<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:1152fda277b2623b0152b5765fcb6b28'),
(56,1795336956,1,'BE',1,0,4,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"pay-land-rates-by-mobile-money-from-january\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Pay land rates by mobile money from January\",\"datetime\":1791781200,\"teaser\":\"Residents can now pay land rates and business permits with their phone.\",\"bodytext\":\"<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.<\\/p>\\r\\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Revenue Department, +254 700 000 040<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f3f39c24ca39d00c02ecd29ec2ad4225'),
(57,1795336956,1,'BE',1,0,5,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"have-your-say-on-the-budget-2027-28\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Have your say on the budget 2027\\/28\",\"datetime\":1790830800,\"teaser\":\"Public participation forums in every ward in November.\",\"bodytext\":\"<p>The municipality prepares its budget for 2027\\/28 and asks residents what matters most to them: roads, water, markets, health or schools.<\\/p>\\r\\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Planning Office, +254 700 000 050<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:bc83755a03cca2ca5c8daa03e9d6e32e'),
(58,1795336956,1,'BE',1,0,6,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"mto-safi-named-cleanest-town-on-the-coast\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Mto Safi named cleanest town on the coast\",\"datetime\":1789707600,\"teaser\":\"The monthly beach clean-ups and the new waste collection paid off.\",\"bodytext\":\"<p>Mto Safi has won this year\\u2019s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.<\\/p>\\r\\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Environment Department, +254 700 000 060<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:7e4fc5d3ec5edd1f76b0a3820eb3fb47'),
(59,1795336956,1,'BE',1,0,7,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-boreholes-bring-clean-water-to-ward-5\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New boreholes bring clean water to Ward 5\",\"datetime\":1788584400,\"teaser\":\"Three boreholes and twelve water kiosks serve 4,000 residents.\",\"bodytext\":\"<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.<\\/p>\\r\\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Water &amp; Sanitation Department, +254 700 000 070<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:31860b4bf14b13d2dc895987af663784'),
(60,1795336956,1,'BE',1,0,3,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"News\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">home<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:b92300cfb5d1d3645c9cb212a7f56c1f'),
(61,1795336956,1,'BE',1,0,4,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":30,\"sorting\":256,\"header\":\"All news\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:4d391f5ef79b8d5d10dffa8a07ca167d'),
(62,1795336956,1,'BE',1,0,5,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":31,\"sorting\":256,\"header\":\"News article\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c7626fc9bcba6f70beb6ebc085a400db'),
(63,1795343750,1,'BE',1,0,6,'tt_content','{\"CType\":\"mtosafi_tiles\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":128,\"header\":\"Popular services\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c0db6803ab1ec5f70c36e2a72187867b'),
(64,1795343750,1,'BE',1,0,1,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"icon\":\"\\ud83c\\udfea\",\"label\":\"Single business permit\",\"link\":\"t3:\\/\\/page?uid=7\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":1}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:55820ddffac9b29987f66a48c05c3e01'),
(65,1795343750,1,'BE',1,0,2,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"icon\":\"\\ud83c\\udfe1\",\"label\":\"Land rates\",\"link\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":2}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:b6549a503cf1dd498f3571f7d5d85d54'),
(66,1795343750,1,'BE',1,0,3,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"icon\":\"\\ud83c\\udd7f\\ufe0f\",\"label\":\"Parking fees\",\"link\":\"t3:\\/\\/page?uid=8\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":3}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:518760b21a46e7982878ebf568972b86'),
(67,1795343750,1,'BE',1,0,4,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":32,\"icon\":\"\\ud83d\\udca7\",\"label\":\"Water connection\",\"link\":\"t3:\\/\\/page?uid=12\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":4}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:ba2135e3eae99237605541429e1c8913'),
(68,1795343750,1,'BE',1,0,5,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":16,\"icon\":\"\\ud83e\\uddfa\",\"label\":\"Market stalls\",\"link\":\"t3:\\/\\/page?uid=9\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":5}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c65d007d6e8748b9615f1c9e01a28b86'),
(69,1795343750,1,'BE',1,0,6,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":8,\"icon\":\"\\ud83d\\udce3\",\"label\":\"Report a problem\",\"link\":\"t3:\\/\\/page?uid=15\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:632dfe70d9c02f2a21151ad96efaec1c'),
(70,1795344511,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:4cf496f597e7b095ce8b755e6cec3c0c'),
(71,1795344511,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"3\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:814fc0f720dfab882655a795e23a5b66'),
(72,1795344511,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"4\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:d2c609347a4764200256b39b9425159a'),
(73,1795344511,1,'BE',1,0,7,'tt_content','{\"CType\":\"mtosafi_slider\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":64,\"header\":\"Highlights\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":7}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:ea41b626baac59a1fe0716bc344af5d9'),
(74,1795344511,1,'BE',1,0,1,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"title\":\"Karibu Mto Safi\",\"text\":\"White beaches, a clean river and a municipality that serves you online, day and night.\",\"link\":\"t3:\\/\\/page?uid=13\",\"link_label\":\"Discover Mto Safi\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:1ffe01378bcddf3cd4b7ccc25f2930f6'),
(75,1795344511,1,'BE',1,0,2,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"title\":\"Pay your land rates by mobile money\",\"text\":\"Calculate what you owe and pay before 31 March to avoid interest.\",\"link\":\"t3:\\/\\/page?uid=6\",\"link_label\":\"Calculate land rates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:de55124b95b3be65ab1a5218e23dea0d'),
(76,1795344511,1,'BE',1,0,3,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"title\":\"Have your say on the budget\",\"text\":\"Join the public participation forums in every ward this month.\",\"link\":\"t3:\\/\\/page?uid=14\",\"link_label\":\"See the forum dates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:e8603ac799ba0c457941e1d26db41cb8'),
(77,1795345582,1,'BE',1,0,33,'pages','{\"doktype\":\"1\",\"slug\":\"\\/page-not-found\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3136,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Page not found\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"no_index\":1,\"no_follow\":1,\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":33}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:0c3ed5b51e5eff03577c1c2f671f9fbe'),
(78,1795345582,1,'BE',1,0,8,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":33,\"sorting\":256,\"header\":\"This page does not exist\",\"bodytext\":\"<p>The page you are looking for may have moved, or the address may be mistyped.<\\/p>\\r\\n<ul><li><a href=\\\"t3:\\/\\/page?uid=1\\\">Go to the home page<\\/a><\\/li><li><a href=\\\"t3:\\/\\/page?uid=16\\\">Search the site<\\/a><\\/li><\\/ul>\",\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":8}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:2097d84972a039cb6bfe093b17089287');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1795330974,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lina.wolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1795330980,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lwolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(3,1795332992,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(4,1795332999,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1795333001,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(6,1795333004,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"4\"}',0,0,'',0,'','info',NULL,NULL),
(7,1795333006,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"5\"}',0,0,'',0,'','info',NULL,NULL),
(8,1795333009,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"6\"}',0,0,'',0,'','info',NULL,NULL),
(9,1795333011,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"7\"}',0,0,'',0,'','info',NULL,NULL),
(10,1795333022,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(11,1795333022,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(12,1795333022,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(13,1795333042,1,3,2,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(14,1795333042,1,3,4,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":4}',2,0,'',0,'','info',NULL,NULL),
(15,1795333042,1,3,3,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":3}',2,0,'',0,'','info',NULL,NULL),
(16,1795333042,1,3,2,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":2}',1,0,'',0,'','info',NULL,NULL),
(17,1795334294,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1795334294,1,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":6,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(19,1795334294,1,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":7,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(20,1795334294,1,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":8,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(21,1795334294,1,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":9,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(22,1795334294,1,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":10,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(23,1795334294,1,1,11,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(24,1795334294,1,1,12,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(25,1795334294,1,1,13,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":13,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1795334294,1,1,14,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":14,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(27,1795334294,1,1,15,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":15,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(28,1795334294,1,1,16,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(29,1795334294,1,1,17,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":17,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(30,1795334294,1,1,18,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":18,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(31,1795334294,1,1,19,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":19,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(32,1795334294,1,1,20,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(33,1795334294,1,1,21,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(34,1795334294,1,1,22,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(35,1795334294,1,1,23,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(36,1795334294,1,1,24,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":24,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(37,1795334294,1,1,25,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":25,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(38,1795334294,1,1,26,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":26,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(39,1795334294,1,1,27,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":27,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(40,1795334294,1,1,28,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":28,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(41,1795334294,1,1,29,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":29,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(42,1795334294,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"40\"}',0,0,'',0,'','info',NULL,NULL),
(43,1795334294,1,2,24,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":24,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(44,1795334294,1,2,25,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":25,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(45,1795334294,1,2,26,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":26,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(46,1795334294,1,2,27,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":27,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(47,1795334294,1,2,28,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":28,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(48,1795334294,1,2,29,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":29,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(49,1795334294,1,3,1,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(51,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(52,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(53,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(54,1795336956,1,1,30,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":30,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(55,1795336956,1,1,31,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":31,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(56,1795336956,1,1,32,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":32,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(57,1795336956,1,1,1,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(58,1795336956,1,1,2,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(59,1795336956,1,1,3,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(60,1795336956,1,1,4,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(61,1795336956,1,1,5,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(62,1795336956,1,1,6,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(63,1795336956,1,1,7,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(64,1795336956,1,1,8,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":8,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(65,1795336956,1,1,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(66,1795336956,1,1,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(67,1795336956,1,1,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(68,1795336956,1,1,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(69,1795336956,1,1,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(70,1795336956,1,1,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(71,1795336956,1,1,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(72,1795336956,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(73,1795336956,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":4,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(74,1795336956,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":5,\"pid\":31}',31,0,'',0,'','info',NULL,NULL),
(75,1795336956,1,2,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(76,1795336956,1,2,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(77,1795336956,1,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(78,1795336956,1,2,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(79,1795336956,1,2,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(80,1795336956,1,2,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(81,1795336956,1,2,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(82,1795343750,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1795343750,1,1,1,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(84,1795343750,1,1,2,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(85,1795343750,1,1,3,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(86,1795343750,1,1,4,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(87,1795343750,1,1,5,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(88,1795343750,1,1,6,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(89,1795343750,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(90,1795344511,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(91,1795344511,1,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(92,1795344511,1,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(93,1795344511,1,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(94,1795344511,1,1,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(95,1795344511,1,1,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(96,1795344511,1,1,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(97,1795344511,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(98,1795344511,1,2,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(99,1795344511,1,2,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(100,1795344511,1,2,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(101,1795345582,1,1,33,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":33,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(102,1795345582,1,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":8,\"pid\":33}',33,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('029d857185cc6f0a9a8ab7e9d2ef95f3','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',3,0,'tx_mtosafisitepackage_tile',4,'',0,0,2147483647,0,0,''),
('08d2716299a7edd920edfd9427d93525','tx_mtosafisitepackage_tile',1,'link',0,0,2147483647,0,'','typolink','7f69a1aa54e9db8a5ae0d952977b4cd9:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('1fde6c7fd92bd9d8eafb8e741be22840','tt_content',4,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('20f5efef03fe691570c3d2cd2fc393cf','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('220bc45f86eae522c66204eabb90e306','tx_mtosafisitepackage_slide',3,'link',0,0,2147483647,0,'','typolink','bf1e9cf52cce365bffb23721ba63b67b:0',0,0,'pages',14,'',0,0,2147483647,0,0,''),
('222baf9b25427e410e9c39f6ec6f2b7f','sys_category',5,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',5,'categories',0,0,2147483647,0,1,''),
('313e461a539f46cf2465487a128c051c','tx_mtosafisitepackage_tile',4,'link',0,0,2147483647,0,'','typolink','e34f7e18c8dc8d47f12cbbc9ec0587df:0',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('37aaef61fe9da71c3d2158c1cc012f0c','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('39f11610b54678a8af0feb57210bb43f','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',5,0,'tx_mtosafisitepackage_tile',6,'',0,0,2147483647,0,0,''),
('3d2896994c41d754a6409b530412c846','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('4402b32b58c950bb2cb91e2f1ed8bba8','pages',27,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',19,'',0,0,2147483647,0,0,''),
('4757b12b90def24df1880d8a111e43d5','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_tile',2,'',0,0,2147483647,0,0,''),
('4c50552ba214ce72d9d786f4de43b368','sys_category',7,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',7,'categories',0,0,2147483647,0,1,''),
('505ac3050b1043f117f21c125ce5f915','tx_mtosafisitepackage_tile',6,'link',0,0,2147483647,0,'','typolink','7f897eb5d5b640dce3bedcdb56c2d987:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('655053dcf91ff4de04e0e7b0935ac0dc','tx_mtosafisitepackage_tile',5,'link',0,0,2147483647,0,'','typolink','a01eec11a0a46a8e86685cb8ec780ef1:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('679f66b060ba12c8427fbf2a710b0fd9','pages',29,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',21,'',0,0,2147483647,0,0,''),
('68275e712ee6626930e72c076be4577e','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('6e9153c8043ab894a418dc6522791810','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',1,'',0,0,2147483647,0,0,''),
('75c3df5c09e24b3c2c96c640da355e01','tx_mtosafisitepackage_tile',2,'link',0,0,2147483647,0,'','typolink','087881d39e3c58af824e5fb90e661a8e:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('77491718585910205641ef73b044aa19','sys_category',1,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',1,'categories',0,0,2147483647,0,1,''),
('777a432b0e62b25c1b84f398c69e5955','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',1,'',0,0,2147483647,0,0,''),
('77d010084c16ba8308f7be5f1b76c604','tx_mtosafisitepackage_slide',1,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('7948bfb5fb5858eeb7961d595c01ddf5','tt_content',4,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('7e694f9466d958648b1c103f07e2eddd','pages',26,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('86aa77750d3d62492d28cf72adb0c6ec','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',4,0,'tx_mtosafisitepackage_tile',5,'',0,0,2147483647,0,0,''),
('91055865169ba9d2b0e9094d3dfcffd4','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('960e459a1c93d12d716e538716e03756','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_slide',3,'',0,0,2147483647,0,0,''),
('ac3e2ceba954f0d2e5005157cb1c35c9','tt_content',3,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('b8390ee0400ed62108c64b63dfc80330','sys_category',4,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',4,'categories',0,0,2147483647,0,1,''),
('bc577547d4c72172ebdc852ea3747576','tx_mtosafisitepackage_tile',3,'link',0,0,2147483647,0,'','typolink','5add86f047c9d524d9e9595219c10eb5:0',0,0,'pages',8,'',0,0,2147483647,0,0,''),
('bd0499781b8651f6a47dbdd267b552eb','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('bf6cc0f81d2f48c8ad397ef2c3eee2b3','tx_mtosafisitepackage_slide',3,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('c038eefe78af750fd106e036d6e7bde9','tx_mtosafisitepackage_slide',2,'link',0,0,2147483647,0,'','typolink','e3c3bf6b59d1e8eefa995a17a3471d72:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('c225a5dc51fe62e7b785fe672031e07b','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('c54d6e1dbf8edbce22fb4011cf341c4a','pages',25,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('c56becdc4ea2ae3a8579c4d7b1d4aed1','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('ca34608fee503babde3755c56abc293f','tt_content',5,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('cc525b5738d587aa9038005247b67650','sys_category',2,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',2,'categories',0,0,2147483647,0,1,''),
('cd03540122f752ba28f3b2f778daed32','pages',24,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('d0c87340bc327a8355a748af77c43662','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_tile',3,'',0,0,2147483647,0,0,''),
('d3722f9232f47d2b03aef4cb5dcf809b','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('e347371ae65979f6857a13b1bbdc3e8a','sys_category',6,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',6,'categories',0,0,2147483647,0,1,''),
('f352f231282e4969b3ea85c3f9b4608f','sys_category',3,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',3,'categories',0,0,2147483647,0,1,''),
('f5ed8c79cd8612b55a515f9f520c7ba6','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_slide',2,'',0,0,2147483647,0,0,''),
('f640e46359138786bad533a1dc6c9adb','tx_mtosafisitepackage_slide',2,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('fc193642beeafd12f02297477a258ef6','tx_mtosafisitepackage_slide',1,'link',0,0,2147483647,0,'','typolink','af39f1ff3aa52a5bc109a0ba6e0c4e9d:0',0,0,'pages',13,'',0,0,2147483647,0,0,''),
('fed36fd2032652e9a28f9e21e509e64e','pages',28,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\LanguagePackUpdateTimestampMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','mtosafi_sitepackage:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','mtosafi_sitepackage:Initialisation/dataImported','i:1;'),
(40,'extensionDataImport','news:ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_slides` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l18n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1795334294,1794119207,1,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\">TYPO3</a>.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(2,1,1795333042,1795332992,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Sidebar probe',0,'','','','<p>Rendered from the area sidebar.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(3,1,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'News',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(4,30,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'All news',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(5,31,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'News article',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(6,1,1795343750,1795343750,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_tiles',0,0,'','',0,'Popular services',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,6,0),
(7,1,1795344511,1795344511,0,0,0,0,'0',64,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_slider',0,0,'','',0,'Highlights',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,3),
(8,33,1795345582,1795345582,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'This page does not exist',100,'','','','<p>The page you are looking for may have moved, or the address may be mistyped.</p>\r\n<ul><li><a href=\"t3://page?uid=1\">Go to the home page</a></li><li><a href=\"t3://page?uid=16\">Search the site</a></li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_slide`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_slide` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(100) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  `link` text NOT NULL DEFAULT '',
  `link_label` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_slide`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_slide` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_slide` VALUES
(1,1,1795344511,1795344511,0,0,1,0,0,0,NULL,'',0,0,0,0,7,1,'Karibu Mto Safi','White beaches, a clean river and a municipality that serves you online, day and night.','t3://page?uid=13','Discover Mto Safi'),
(2,1,1795344511,1795344511,0,0,2,0,0,0,NULL,'',0,0,0,0,7,1,'Pay your land rates by mobile money','Calculate what you owe and pay before 31 March to avoid interest.','t3://page?uid=6','Calculate land rates'),
(3,1,1795344511,1795344511,0,0,3,0,0,0,NULL,'',0,0,0,0,7,1,'Have your say on the budget','Join the public participation forums in every ward this month.','t3://page?uid=14','See the forum dates');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_tile`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_tile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_tile` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `icon` varchar(8) NOT NULL DEFAULT '',
  `label` varchar(100) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_tile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_tile` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_tile` VALUES
(1,1,1795343750,1795343750,0,0,1,0,0,0,NULL,'',0,0,0,0,6,'🏪','Single business permit','t3://page?uid=7'),
(2,1,1795343750,1795343750,0,0,2,0,0,0,NULL,'',0,0,0,0,6,'🏡','Land rates','t3://page?uid=6'),
(3,1,1795343750,1795343750,0,0,3,0,0,0,NULL,'',0,0,0,0,6,'🅿️','Parking fees','t3://page?uid=8'),
(4,1,1795343750,1795343750,0,0,4,0,0,0,NULL,'',0,0,0,0,6,'💧','Water connection','t3://page?uid=12'),
(5,1,1795343750,1795343750,0,0,5,0,0,0,NULL,'',0,0,0,0,6,'🧺','Market stalls','t3://page?uid=9'),
(6,1,1795343750,1795343750,0,0,6,0,0,0,NULL,'',0,0,0,0,6,'📣','Report a problem','t3://page?uid=15');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(NULL,1,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New fish market opens at the jetty','Sixty stalls, cold storage and clean water for traders and buyers.','<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.</p>\r\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.</p>\r\n<p><strong>Contact:</strong> Trade &amp; Markets Office, +254 700 000 010</p>',1793595600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-fish-market-opens-at-the-jetty',NULL,'',0.5,'',''),
(NULL,2,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Beach Road resurfacing starts','Works run for six weeks. Matatus take the diversion via Market Street.','<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.</p>\r\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.</p>\r\n<p><strong>Contact:</strong> Roads Department, +254 700 000 020</p>',1793077200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'beach-road-resurfacing-starts',NULL,'',0.5,'',''),
(NULL,3,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Free health camp in Ward 3','Eye tests, vaccinations and screening, open to every resident.','<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.</p>\r\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.</p>\r\n<p><strong>Contact:</strong> Health Department, +254 700 000 030</p>',1792472400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'free-health-camp-in-ward-3',NULL,'',0.5,'',''),
(NULL,4,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Pay land rates by mobile money from January','Residents can now pay land rates and business permits with their phone.','<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.</p>\r\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.</p>\r\n<p><strong>Contact:</strong> Revenue Department, +254 700 000 040</p>',1791781200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pay-land-rates-by-mobile-money-from-january',NULL,'',0.5,'',''),
(NULL,5,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Have your say on the budget 2027/28','Public participation forums in every ward in November.','<p>The municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.</p>\r\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.</p>\r\n<p><strong>Contact:</strong> Planning Office, +254 700 000 050</p>',1790830800,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'have-your-say-on-the-budget-2027-28',NULL,'',0.5,'',''),
(NULL,6,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Mto Safi named cleanest town on the coast','The monthly beach clean-ups and the new waste collection paid off.','<p>Mto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.</p>\r\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.</p>\r\n<p><strong>Contact:</strong> Environment Department, +254 700 000 060</p>',1789707600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'mto-safi-named-cleanest-town-on-the-coast',NULL,'',0.5,'',''),
(NULL,7,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New boreholes bring clean water to Ward 5','Three boreholes and twelve water kiosks serve 4,000 residents.','<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.</p>\r\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.</p>\r\n<p><strong>Contact:</strong> Water &amp; Sanitation Department, +254 700 000 070</p>',1788584400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-boreholes-bring-clean-water-to-ward-5',NULL,'',0.5,'','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-22 12:09:13
