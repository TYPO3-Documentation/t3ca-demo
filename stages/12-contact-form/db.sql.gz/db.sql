-- MariaDB dump 10.20-11.8.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.9-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1795336957,1795336957,0,0,'Edit pages, content and news of the Mto Safi site. Images upload to fileadmin/user_upload/news/','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','Editors','1','1','readFolder,addFolder,renameFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',0,'1,4,254','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','pages:doktype,pages:php_tree_stop,pages:categories,pages:layout,pages:extendToSubpages,pages:nav_title,pages:nav_hide,pages:subtitle,pages:target,pages:lastUpdated,pages:newUntil,pages:cache_timeout,pages:cache_tags,pages:no_search,pages:shortcut_mode,pages:content_from_pid,pages:keywords,pages:description,pages:abstract,pages:author,pages:author_email,pages:media,pages:is_siteroot,pages:mount_pid_ol,pages:module,pages:l18n_cfg,pages:backend_layout,pages:backend_layout_next_level,pages:hidden,pages:starttime,pages:endtime,pages:fe_group,pages:rowDescription,pages:seo_title,pages:no_index,pages:no_follow,pages:sitemap_changefreq,pages:sitemap_priority,pages:canonical_link,pages:og_title,pages:og_description,pages:og_image,pages:twitter_title,pages:twitter_description,pages:twitter_image,pages:twitter_card,tt_content:categories,tt_content:layout,tt_content:frame_class,tt_content:space_before_class,tt_content:space_after_class,tt_content:date,tt_content:header_layout,tt_content:header_position,tt_content:header_link,tt_content:subheader,tt_content:imagewidth,tt_content:imageheight,tt_content:imageorient,tt_content:imageborder,tt_content:image_zoom,tt_content:imagecols,tt_content:pages,tt_content:recursive,tt_content:sectionIndex,tt_content:linkToTop,tt_content:hidden,tt_content:starttime,tt_content:endtime,tt_content:fe_group,tt_content:rowDescription,tt_content:sys_language_uid,tt_content:bullets_type,tt_content:table_class,tt_content:table_caption,tt_content:table_delimiter,tt_content:table_enclosure,tt_content:table_header_position,tt_content:table_tfoot,tt_content:file_collections,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:uploads_description,tt_content:uploads_type,sys_category:hidden,sys_category:starttime,sys_category:endtime,sys_category:description,sys_category:sys_language_uid,sys_category:images,sys_category:single_pid,sys_category:shortcut,sys_category:seo_headline,sys_category:seo_title,sys_category:seo_description,sys_category:seo_text,sys_category:slug,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:title,sys_file_reference:link,sys_file_reference:description,sys_file_reference:alternative,sys_file_reference:crop,sys_file_reference:autoplay,sys_file_reference:showinpreview,tx_news_domain_model_news:sys_language_uid,tx_news_domain_model_news:hidden,tx_news_domain_model_news:starttime,tx_news_domain_model_news:endtime,tx_news_domain_model_news:fe_group,tx_news_domain_model_news:alternative_title,tx_news_domain_model_news:teaser,tx_news_domain_model_news:archive,tx_news_domain_model_news:author,tx_news_domain_model_news:author_email,tx_news_domain_model_news:categories,tx_news_domain_model_news:related,tx_news_domain_model_news:related_from,tx_news_domain_model_news:related_links,tx_news_domain_model_news:keywords,tx_news_domain_model_news:description,tx_news_domain_model_news:istopnews,tx_news_domain_model_news:content_elements,tx_news_domain_model_news:tags,tx_news_domain_model_news:fal_media,tx_news_domain_model_news:fal_related_files,tx_news_domain_model_news:sitemap_changefreq,tx_news_domain_model_news:sitemap_priority,tx_news_domain_model_link:sys_language_uid,tx_news_domain_model_link:hidden,tx_news_domain_model_link:description,tx_news_domain_model_tag:sys_language_uid,tx_news_domain_model_tag:hidden,tx_news_domain_model_tag:slug,tx_news_domain_model_tag:seo_headline,tx_news_domain_model_tag:seo_title,tx_news_domain_model_tag:seo_description,tx_news_domain_model_tag:seo_text','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:div,tt_content:CType:form_formframework,tt_content:CType:felogin_login,tt_content:CType:news_pi1,tt_content:CType:news_newsliststicky,tt_content:CType:news_newsdetail,tt_content:CType:news_newsselectedlist,tt_content:CType:news_newsdatemenu,tt_content:CType:news_categorylist,tt_content:CType:news_newssearchform,tt_content:CType:news_newssearchresult,tt_content:CType:news_taglist,tt_content:CType:mtosafi_tiles','0',NULL,'web_layout,records,media_management',NULL,'options.defaultUploadFolder = 1:/user_upload/news/','','',NULL,NULL);
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1794119204,1794119204,0,0,0,0,NULL,'a:7:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";i:0;}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\",\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":0}',0,NULL,'','_cli_','$argon2id$v=19$m=65536,t=16,p=1$SC5jQVhyTVMwZmIuZi9lVQ$my26zjcmtB0GZl+0EIiotj27ERAFI4Epms3l9llGZqM','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1794119204,1794119204,0,0,0,0,NULL,NULL,NULL,0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$NTQwSlBTTVJPdDBTeTNPaA$tH9SFkLNfU1mfU5cvq+Ot4SY54Kw5EpathLn0W0x2EY','',0,NULL,'','admin@mtosafi-demo.example','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'15_69ec8b4d23ea1243',1826905995,'x��=�v�8���\ngz��td�\"%���Ƿ��m�N���IHBL�	�V�9g�a?f��S�K�\n )��9Iߦ[}b��P�\nM�Z��1�]5$Cz�\\�)�j���>�>W�I�L��U7��s��}������m�����R���BE%noM��Ƙr�8#Ŕo�>�u���Ɵk5e���#+�Ԏ�\n��{\ZQW��\n�q�+5��q�\"����G(1����#� �T	B�+q0��lKҕc�ø��s/\"czD���qF<o�8%\\����!���[B�Q�N!��x̡~�߅���������\\�NN#6qE��N��h��`PF���>\091|�6��fP��(���B��;ȽO��9�A4&�	zP �\'�A<���:����D��Z������M�AUEt���oH��덦庎njFS�mö:VǶa����R?�����n�\r���͎��\ntF/֨C��c���h�N�Q��kR|���:�0,HU��T%#�������1z�U�g.m���RORI�b�xtSC��>�S��#Jy��*N�a=��u�����c�5t���2[z�n6�F�5p��P	y`h���Z�2�.#�*�ҽ�Õy�\r��	���Zz��h镝�pw\ZMG�4̶kZ�=0:���~6����E�x,1��i�mM��y����\Zj�*�O����0S��\Z��q�����Y��fԥ�ٰw*�����[�y��/�_�wpt$�jmԉ E8.�ڴ5tT� 5qg.�KKy�$-(\n�h�\"���0ߧ�ڢE�w<���x�\n��]�8����{/bJ��h�Ö́o��G���2~7俍�@Q��;�1��<b#O/h�&S�?s\0D&���X6�kh� ��nR$(�ޣq�\"��:�(V�Ӑ:s#���l)`�|�I��K�,�I|&T�5�L3���8������C%��o���6UU��Qm���t3��]�p\"on�ݪ�c��2`���L\'���	XYפl�y��_0������M��H&2`D���\r��)�;Opڮ���֠�b��Sj\ZXl��\n��\'\\an�F9�O\'�zġ��ɣM�nRSx������a��̓��S���3���Q��%���6c|%jE~�j�����0��\Z�C����4� Z�\'ċij�m`EM�P�O�$�}24k��5�]�qɂ����Ó\nQV�?L+���Q{σ1�jJ�V@�ވ�Sh-$S�3A������çJ\nT�U���8��s����Ǣ�G�j��wg��xQ��]�&(�$b�X���1� ~u�Ćh�q�г��3U\nЯ�j��k�N6�y�.LCb���\r��`	-)���8�Uy�\Zi3��w��yd\n>C�_�Z�\\\n�KM�Uʖ��:7�����b�02�0�՘\"��\\: �\'O�Dy�٪M�&�5V	g� _P�x�V����hA������5SU�*¥2L֓��E�f~vX��w��Kiԗ�؇�W�m]��\'�	�cX��j����\0��(U\\ٻd\n���p�/\ZNn^�煲��s�M[	T\"�\n,ͧ��c(S�;rZ�3���k.�$�$���n����3Y���fH#,>rQ�d~�h�-��t/+\ZW4s��x�90��j�����:�u����P�lc�6;M�f���Eچcj�\rK;bY:1����Q\0|����\0I%��f2��$��·?���f���rG�	4�>��v�����p������v��9c�9߷��+o�j�P���о�t���Ծ<i�~u����>�p��@;e[/���ׯN\Z���g�aD�.o_���o^z�7����;���2����mm[o�7#����L����pZX�䝬C��ɛW޽�������zP/���]���80�\Z�M�5I� -]kuá�$�F��t�M�mЁ�H�l���\"��q�&�a��e�MU�?��77<�Ĝ�gQ\0\n��g�������?�IC>w8�M ����`�(���`�˜lL���:��;��2�P�|AY	vs�L�g9ԟ>Q�u�C��JoYW��f�Ҧ�۶�p4s��\r�9h5,���65uV{�ꃦH��ڲo(�򳧰y�o��r�	��1깱2&�-u����`D�OXD��\\(��N�Z�\"���E5*� 5�f	��d%6ӥ�\\V�M<Ohh%��ȳ�5���{��w�ˉ^�\\��J�#8�8�(��D�#�4[Hv$���_�Cb��h�k�¬�¬ez���,� ����\"\\�?�K!�����9�U�&�)�&yXUmD��Mo~9�����K�\'c�F��|9�J�\"���	W���G�V���V�j��_�}_P�0�u�*�@rce%�ߪ�� ��I���QS�AL7��b�$��8���������U&-\0��\"oa�rRkA�\\����z\"3TY�*�%�P�����\'�#̡\\����*�\n\\�K.ш��4�����&1��{L\"%y��[�l��J33ߣ��^�\rx$�c��h$9B��N�l���*���9�O٩D�=0����\'-���)�E6D������W8[\\A_fC�fxjAI<�(~��;���`G	\"�&��B\'��<�������O�VT�|�],�匨s[��59�d�<[��r+L$I�4�$���W��b�l���)����.6�ƹ�G%���2y���CXcT&��麒���q��0�3�IO>+�Y��?�`*]Fբ�+�v-_�ÿ́�F$T�r�����x�]�|��Fr䞹C���\"�%�gFQ)5��i�-��s�V�R���yPi����Ȝl��#�G�0H�Hb�ɬh/��U�$:�X<Kc%��X�N��ш\r�/#�PQ��4Oh�>��]Ct5�35o�ȝ��\0�?\n\"\\8����\\�����p����5?̟�Ё��ߜ/K����w�æZ_$��5Cw�ބS�\r��m(�_Ͳ,:~�eY��l\rV�n1���ʴ~�`���-��6<��ܹ,l�cj_9��J���\\��#R��j���{�\n�~U�7�a-���o��<�)�;W>X��z�i9�	^��Dp���[���[������y�CF[�@�g�	�d`��l����U<�*���f����.�5bw�j�`!�!N��4�<�؏E��ĉܸh��#S�g��N�TT+�\\\\	7,YV>oX�@)�\\���,\'�\r1���`O�uV�#;���6L�����Ս���$���$���Cq<O���z�5\n)E)�}y��8��χ��Q���g�=2T��c���sʐ�) zF�3R�a@�p�|Ts� ��`��V#zǂ	0�,��H),k��l�\'�w���$���#��w�_c<R�]�U�����˼B@���\Z�t��|˓��+jEzH��������X��K�0aż�)�X�G!{���{Ń�F�Qy.�^�E`)�v��\0K�\\Ar�s�;�=��-���֕g�\n�W��i������n�J�W@^�`x@]��+�H����J�T��N��\n l&E����u�Y�hM���󭇰�Iw�p����n��H>jo��9�!b�U�k��<�2�s̃zY�wE�^T B:V��i��?6\\�V����?N���4�����I�{�І�\\.����o��J�gf����{�y���#<�(X����9N�i\\�U��ϡ���|�)�OH(4����)��Y����5�G��-U��վő_�����oj�G������z^	�R�v��e�ճU��3���-��w��{s��_Wu�~�h��X���5k��O�������\"M��Tv��\\��#�/���l�3�{�XR��׳�k?&��ǲ>��.W�����%��zV~aoK	>\n<�赣��!��\\�W�����D�<�\0?�Q��q8u��C<���S4K_\0+\'^\"����K5�/Oĕ\"1�*�#\ZQ�q��a��W�Y����*����i��&7b��N�U\\�P��d�<���&ىY��HP�ټ�BgՓ��U�>L�r}Z�����*֯6�Bzf�0��� FE���jBP~����l��d�B/ ��E<�*�J�u�0}���nש�\\T�z�|a����׆�����P�5�ޛ<κ�/P��e�+��������xPc3F��E]`y����-H\Z�Y��/��~��X��=���҉���]\\i�ĩ0��y�u�|iQ�n<�\\��\r^�\ZD�!\n�G�^0�����H\0r������;r!Z�g�W��ŅJ ��� �I�]��>I<��W�U�]��w��qY��;��n\"� aY��aB�ٚ��m�F#�#*�����j�v5-�l�a ��FW�I��fw��+԰I������Ȯէ���~�-;�2�s��4���1g\\\\\Z��ckZ����n���N�n;��YZ�Mנ�@�b�p�s���UIWo��qH�8����^���H��Cs�S�ۀ��\n1����)4�ʫ����/����^a!� 4H>P�k\"v�����JCo]�����,!�pDnn��,���:�\"C����T��Fw�M�v$L��8pـ�Nf$�4D��1|�罋����T4m�1;�N\\�g\n`�\"t$�TS��|�M�Ӏ��Eo�g��Mn��uՇ�wPa�ww\'�Om�6@5�+��Ι�`,�C�F���Q��_�KGT�w���P��%���gz�\\2|�>_�p+��Ղ��Z�&�SS�k�٘f�Yy�]j���jg��:XÂ[��L��DgT����H-!�2�AW�=��8�R�w�y`��:bH����]q�]��5̪{N午q]L����IC��,{y&F�H%x�����ɱiT�(��L��8Ĉqqd�/\0/��#�#C�d�4%[���֍`���(X:��W�.����!��Qפ+g>j	2�׈�#TP*��D2��x[�\r��F7Ԃg�x�����$9�Ԕ\"fc\\����@zH��!����6襗���2�	��\n�r]_1>:�c�\nҩ����\n�-y`,�NL����J-���7=	|�>�W?����+�����h��̒�hg�3��>�e��]wH�����h�$P�0�� ����s�~e|̈́����.2.)-ކjusW\"\'����>��R���6���Ձ��\\s��K��V�74�X�+�����G��\\���8x�m��F:�X�Q\Z�y�O���߶L��<+C��[Ś05|����\\�=�P|�E^:��1�\\RK�.IV]ꔊ���D!�˫^s*��&A�ӹ�2r-��&/_U����0bAk�Ԏu�}B|Ҟ\n��]�|�Q�V����1�|�K��8�8_.p.J�����ۍꓜ�@�rN:,J6q獒ԥ�-MjPC�bp���V노䴚g贖�E��j�dA����)�9XJ��*�ٍ�ߚ��.���E� ��ʹG��LhӖ^�u�\r���?C�jJ�D5��Q������bu��=�ro�`�0\r�E�T´�͘C�*.��Ͷ��ȶOi�^t���Mk6ڸ~��N����߼�ðu����eN�7x������U��D���o�|[Z��1\r�M�͸ct*=Q����\Z�͞!|�c�4�|R��$�%��˕u�@,k��,˲ZI@��!�a$n6QT�L���eR����TW⚥Έ�Տo�b�nV.�U�>�Q���~��Z�#G�\r�vT�i�ڵ�����a�w�^��������u���n�^���7��;��������ꓴ�s���������+��6^�E;������~tx�w�`�{Ơ����\\��{�ڳ�����\r��׬�kڳK�L��g{\';�͇h��=��VΫ�+㝾�m������>���߻:�^퍏�]�������`S}��ڽb�{���V���4:��?���y������{�x���aw��08��N�A��g\'$���޸��������l_�s~޾�a��p���_ׯ���^���Śy��p�n�0m�O���NN,~9��}4y�b��W�@8*m��Au��\r���\\�\'��hB�򐖚�j\'����:5d@:�Z���v$Л���N�A�U\0Y��F�l�V���0=1�o�E��!(Ԍ�����$�1�]Q\"��щIm\Zߠ+J��!bt���~�����%��H�+X���2ǰ����B�ٶ\Z-�\n�:�AZ��l��0��mv:Z��vi�t\r�w��k9f�a\ZZ�r;M�iQӢ�I�ruW�\r��[��1ێ�S�6:�5h[n�MM[�?��\\'),
(2,'15_42eb9e57361411ce',1826905996,'x��<�r۸v�o�\\��N�Y\"��(�f;q�v<�r�����HHBB�$d[�73}�>L��Q�$=HQ��$��]gf��ppp�\0�<�K6�܄�鄅�6��O$(ౠ�p��k6���~�����_/���XF�GC��D$�?ui\\{{�\"��p�ȁ�%�	$ͨx�Ĭփ����jΣ�/X�\\�i�u�g¯iJCg�v`��M��8KX�⹓P�D���\0���>0�8��R�\'4v2�J�*ҝ3ú���8%Kz����	F�h�)%B��#��:�I��C�ЉX@��Wqm/���_\\�XS<Y�l�����j~��8|VFv��\09�1P�Rkt�R\'�0$�\nr�4�iN�O�D�8I\n$eӕ�H�A�.�	o�t^T�!#\0��S���Y�t�ԭOH���\r��A��|�9mM��~o:��\Za�k������#>����{��o7�~��\\&��{ԡ�O7���\"���o�\'�ӣN{�Q/hv`���N��ө?��z�F��A?	5�Ύ����:������py��p�������w�S\r==9�{d>����}uoZ_ݛԗGϞ�y��.2�+�Ny���GC0�����}`I\r��h�K�bwt	p�f�d�u���\0�1��5���>%dW�U�dJLC��L�Ku�LXS���%$��b��D`�30��s������<N��4\Z����_������n9]��P�\r�EkL����Ed�fxI�+�[��m$����258�%<��(9\n��wgܒG�p��*MAOe,pG��q_�Փ�\nցO��� >-e�sK��*��)eڠ��n����=_Y�l9w�4�R>�D�5׹f�X<u����{��+�@�dCdrGg`\r�dƆ���F\'�X��IXYהl�y���`F%i�p��G���H�	0B�5t(uؠ�b�\ncgm�Bl�y��.�_�k&��Gn\'+ᰰD#r��m8�H@<ɣM�i�)<vbz\r��ugUˀ�)����)�`5]2aH�UkIruD��m_��Qj5���(��&�|Q3��AZ�ц81#QF�Mb��`EM�P\Z��$�}24`��\0l�tV��*k+��B������v8��%_R���l4{�M�0����d��FA��\'��c�w��j\"p;�\0)�~6:\Z_���H[�\ZRQ������\r�=�H�a��R�-���\Z��S$�)�� �THׅ��]H�S�~�T�G�=&�m�.�!�TzCS��`����ۘ6�ݱʶ����~W�]D��3��V�XH!�ɂ�l�9�[�{��QR�Z�C�aI����B:#�H�\'�O5tw��,/�T����O:�#�wB����B��ю޻���3\\��EK�)�z��*+i�·�ã�y�\Z�Kc�\Z�{U�R4<�MH�A�\r%7��֚(U,�C������潖c�ź-���n��#\'����ᛓ��A��uھ��h4���(i7�~���t<��B���\'FڑX�h.�\Z�����z#p�S�-���f�� ��b{W����v���\n~`�X�\Z��+�p�`V	��s��]0j���h���������@]B\nj��Vt+��{�N��ޕq��Zr�2K����pkN���#{�:�r3Bg;�7�����E�K�WP�LVI�IXOd!�v\Z��t���B2(���ާ&+P����V����E\Z��U	Ve)�O!H�\n�J���J��z:؅�Z�j�C�sk��x�W����QR�mP&��=����9���d1����.��?��UU���6��5��Ұ����;�\\o9�f;��hl�Z����G�g0�zU�+�3����?d~\rf:��?V�`a�3\"��lK��Qd��8���X�s�[۞�a�v�����l�@|%�4��g혡j�Il���íT;|X%p��HNa�h�Z{�������������~�x~�oH�����ł�t��E���\0wC�\r��mo��\">�B)������?/�`�z�hN�\n*!{���i��¿}n�3�k��iDj3��:�1�3�J�����,h�$ge��\\Zמ��O6l(���	ɶA��K6��Ţ���C�Z�U��O���t���+\n�+x?�@R>�C���4×Tᯫ}�3\r��1��N�)��O��-)νf����ޮ��!�>Z�	t���%��w���)�����M����Z�c}��_�_�ع\\ſ==��$���ݫњ��L�~4T�\rL�i�hK�Q�z��]���>����=(�8I�A���=��0=s.<����i�?�U�R*��*�>��	S<h�sM2<s\\�?��\'�QDAÁ�(*�K��0sTY�xI%ö�^����X�@��ڹ^Д:L8,;�[2�Z�4���*n�\r�x��N��3�E��U\\B�<�ڭѓ�>���T~�n^A���$S�eU}�E\\��CЎ�>�X���\'�b�~�)l��XF2�:	rTT[��j��\ZC�T���du�G8\"��*��&ܚz��1�n]Ʈ�\\v���s�����k6e(�Z&������3���n��r/��]�`]K����]�gG=���zk��؆�f������\\P��f9V?�=A�&��[�v�=ȶ�҉������7 ���	F��<ŁS~ǂ8!]r�$�߱8�<��, ��pP0�E��G$`T��>9~�z|���w�?^q��x5�.݇u�ł��_�1^���r2��������$�E���C��{r>fqp�,�2���A~��}��\0o�f�G������M9DR5C�M���K�K(�x�Xu:��45n��,o����/axfy��|lv�T�w�g��nĔd��!O�@W �!Im��b��G98x=}��������F��P6�AW��m+�>R��D>&��I`1��e\"!xe�U-A\n��V҈BʄM\r�W��j@/H*[R�a�l,dF\'�ɩ��pU��\'prj��m���_?��5��\'�\n\r��<�`���l�M�u�������Zy�x��T��e��D����,$pB�����t���U��+p.ܚ�a��Y���+��X*�D:2�HA�2���.x��\0A��mb���0L�L�2�7Ʉ�lnq�vh��C�l]\\4*\0�sM3KT��Ɨ��N�pX�k^!)���?.�+M����X4?�����T�I��v�`..�Tx�ax� Kp�9�@���j��O��$�*u�b�>�\n��7�������i���P�@�J-�S��%��N~�|)-L-VA�$��P^�P�@���o��,�Y���ġL�Ǡ�Ψ��\'��X�!��|��܄Mf��ig�BS~����L�8�\Z�C〫�*`��n�c��]���\\��c@��73�xF���X-2�R��G��z¸�\'��#����軲�i�z3�	�F��[��/��D�|�+9�ѿ����`����|C����2��.�h�r ��d\r�kU\"%).��f�v�\'y��x�ú�YiDh+T���7�k׭a뉜�6?А�\n*p�M�t=Jd܍��[Tެ�Eڦb[2�4��[�F�8�4���1n����5;��ţ��7�wQ�:��5��3-Q\r&��+�+�!��\n��c5�4�����S������4���2��>��F��|��U���g)�D\0��n�]�2�7��H��2YɜA\'gH�6k\Z��(d\\DsH���ȣ��eE����0\n\\���֓�\nm)8�H7�:6�?��Qz*u\'�d1�_�Ƭ�`�X�\0���/�H�;&��\"��\rpE\'X�>��ᇌ��S>��t����1#�B���rj�ꞤkW�_lE����!|�r���!|�r��0��Mˠ��]4�p��ɔ���d�)������.ýJ~\nB{�QX�Q��hc�6��I,^O߃4�\'S%���Tб��	�O��-t�&y:*S��$��h;�W4��U��Ej�:�\n�q�����+����sW3���J����yI��ܙQ|jW��.�����fw\'�\r�7�fɯ��8�˗����X�	j�t��a��A�e���S�R�ꁺu~�*����,C����vب搇j���X�fG�8/h\n�*��\Z�17tsH/��S[�g���ϳGh��y�I*���}v�LngC`�ŏ/L�[66��<���\"WD��\\��d��{��T3��0TL;�n�M*�|���ױ�S�.�(B�.�]I��!�OW�%�\Z�̧Ƨ0��9d�kkx[��J�<c)�2�u��NAL1_�p���ZI���P�����Q����M�\Zw㳍��w�z���Ru�$u���0%�2��ϥ��z�ᵃ^�\"A{6�y�i��n6���5\Z�Y�92%>�$��1��St*Jb�X��0pɞ���P��-�/ �\n���	i��nQ��;��!��5��g`�}0\\y6Xp�x�@����~����@e?��/�!�.A9q�r��,���o{��|�\0�3�|����9j���!_��\n_ᓹj��ϟ�M�������#}�y� ���\rJ<�?Czu���?z2�L�����g��9&2U�����:��ZSQSL/Ю��9������7CL	��<cK���*�hl0[@���F�l�a�_�u��ܑz�m�f�}i�e(N�[���R�h��uñI\'Zv<\n�Y\r��Ե�X��3 �\\]�({3��)�wl�\r�U�#���ץ�ǋ+�yx�\\׬���:�8)��V�oDS�0�v,�q���r\'D]SE�|����L\n��\0��%01�G|J�gY��q�4\'\nԞ�T�$�D�2ui����K<�p��K���BC6�P\'Zc0���qD�]N3kꟘX���`B�m��r{lz��\0աm�/d7����}��M%� `o���t�����!0$˥���4�\Z��(�S�[9�t�$<H�%Ca^�\"Z�Nt/�������9oIO-?g��d�zb&6�7[M/��T���k����6���yp�1j��	3��P\\=�>1��M���%�9k����Iwfww��5��I\Z��v�i��@i��n?j�#��C�C��,f���{V�	�ᗼ��ߦ �Z�2�S�����|l�RS9�O� n�(��\n�p����I26e��[�9Or���XIʸ�$���K��\ZM2�W���د���ήQ�rH%�=d}�I��h�z��]\'�z��}��&`LG�t\Z\r���-��WK��ؠ�<C�W$�___�;n��o{�&	�$��;Ѫ�e�O��TN��u�^���$5Eu��w:M<��*����7���oQVl�MS=]땕p��RG7Ⴢ>1��R��cL�I��9wZ�J�+{�S���3D�+�O��j����$�*H�p�O��������`E�mEk�˅��m2����J����>P�{����f��%�i��u������q��D�tg�l0琶ٙ��}<#�\rȗ�\n�&��PA�H��@]�\n���P_Rڰa~C¼L������5�^D��?iI\n��vK��߄(��%x��5O�Tb�l\"�4�=]��pT<83�*�K�хf���\"n&��\"�dr�,�,yH�	\0@�9E��B(�ˣ������=��o�Q)?��1;̀tf^��M�A{֘�=��t��`�Oi؃�^���]:��a�߄��F�E�v�����F�M�_�?m�H��l�vf��Qצd');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'15_69ec8b4d23ea1243','pages_1'),
(2,'15_69ec8b4d23ea1243','pages_5'),
(3,'15_69ec8b4d23ea1243','pages_11'),
(4,'15_69ec8b4d23ea1243','pages_12'),
(5,'15_69ec8b4d23ea1243','pages_13'),
(6,'15_69ec8b4d23ea1243','pages_14'),
(7,'15_69ec8b4d23ea1243','pages_15'),
(8,'15_69ec8b4d23ea1243','pages_17'),
(9,'15_69ec8b4d23ea1243','pages_18'),
(10,'15_69ec8b4d23ea1243','pages_19'),
(11,'15_69ec8b4d23ea1243','pages_20'),
(12,'15_69ec8b4d23ea1243','pages_21'),
(13,'15_69ec8b4d23ea1243','pages_16'),
(14,'15_69ec8b4d23ea1243','tt_content_44'),
(15,'15_69ec8b4d23ea1243','tt_content_34'),
(16,'15_69ec8b4d23ea1243','tt_content_35'),
(17,'15_69ec8b4d23ea1243','tt_content_36'),
(18,'15_69ec8b4d23ea1243','sys_file_20'),
(19,'15_69ec8b4d23ea1243','sys_file_metadata_20'),
(20,'15_69ec8b4d23ea1243','pageId_15'),
(21,'15_42eb9e57361411ce','pages_1'),
(22,'15_42eb9e57361411ce','pages_5'),
(23,'15_42eb9e57361411ce','pages_11'),
(24,'15_42eb9e57361411ce','pages_12'),
(25,'15_42eb9e57361411ce','pages_13'),
(26,'15_42eb9e57361411ce','pages_14'),
(27,'15_42eb9e57361411ce','pages_15'),
(28,'15_42eb9e57361411ce','pages_17'),
(29,'15_42eb9e57361411ce','pages_18'),
(30,'15_42eb9e57361411ce','pages_19'),
(31,'15_42eb9e57361411ce','pages_20'),
(32,'15_42eb9e57361411ce','pages_21'),
(33,'15_42eb9e57361411ce','pages_16'),
(34,'15_42eb9e57361411ce','tt_content_44'),
(35,'15_42eb9e57361411ce','tt_content_34'),
(36,'15_42eb9e57361411ce','tt_content_35'),
(37,'15_42eb9e57361411ce','tt_content_36'),
(38,'15_42eb9e57361411ce','sys_file_20'),
(39,'15_42eb9e57361411ce','sys_file_metadata_20'),
(40,'15_42eb9e57361411ce','pageId_15'),
(41,'15_42eb9e57361411ce','tx_typo3altcha_domain_model_challenge_5');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'15__0_0_0_0',1797961995,'x��U�n�6��+�\rG�[2�0��)�z�qYIi��D��2��^�5�G�k�\Z�I��y./)��E�i^��\",�A0���n���_�K\n�hC�~�<��҉���W&��<&-<�n�hş�nc�[�����2F�|��\Zd�Wq\\+9�{]���頖ʈ���KF����#�T��	�\'�	�H�[�\"G4nHW��xN��I���D��\\�Z��\"��X��3�DU-�u���$tI���Wxޫ7�Ä߸�҉�_��>�oBg�W���L�Z��ձ�(\\��,\Z�ټs��������찺j�u���<=|�����	Ao�:I�����@�q�d��c�P�V@81�g,ڞ?�X*Q�ʹ����ǽ���7Iܿ�g)1�3��/��\rȅ���B�� 0��7���}��%�Y����9tD�nS)���X��w�	�5��Ο��In����j����8g�ä������j�jn�kD�s�Q�D�/��r����KgD��\Zڬ�c;�n�J��M�f ��Dѭke�n�I;~�K��\\^d_��A\'�6j���%ts\n�*l+�o� g\Z[	))�;U��\\ːX�\r�=iP�aZ��u(��;`�;y�d�1�@K���v����m���Ma=	��6�gU�\\^Ս��?�\n���M#�k��q���N^)���>���d\'(i�ಬ/\\�+\0_k&��߲�iP�������s������D1�J��e�\'��\"~���2���SVq=4���-�|����xٳ�8B(��o�E��������?������E1B�����,��sY�P��;��Z?=|�����[[�5hT��~����<�P���U���}��f\Z��y������G�����y�/b�������x��P�QZ%Q��<%A�x��$O�*Be�\"B}��X��gQB�(��I����i@Y�IL���3T	I��l��'),
(2,'5__0_0_0_0',1797961995,'x��VM��6��W,t�i��a�Z��H��@��zs艠đLXU���X��P_��M�Z4An���pf��X\Z�O\"%�,M6�N����nE\Z��������3ڰ��d�al���+�,,I�q��@�|w�sh&`�zU#j�0<\rw�u�@K%;�^�$�|op�Rє�1�W�����7�s%Z#$^u?�\0.L%���`6��iŚ�c%б�ކwT�oh�4fk٩|Ώ�l�>�I<b\\��S��M��Ν��y&:.Op����5�4�}$�𾋎�wX4$cx����x�1��8_���_[��n������oo�,�,�R�w�e!���.�Bɚ��ڱK����`Y7�T�-<�T*Q��YJ�����U���\rZ�o�Q3\\�ͱ����Aa��L�O������Uˎ5���e�����~Q��Ϯ~�b-�(G\rخ�Zj\0�$[���,1CЎ.0���y{�����Z�Z;�i�G:g?�X0�;@��.�L3U�q0����Az�3m>�vȹ��Çƈj�5�U�;�vx�\"���J}>��\Z��wn�I$��gE��x��뱽�>0�Ag�6��f\0�J���L E��\nfʡƗ�]t@hj���4���rn��¼��\"��E9�Vg,�#�t�Ql�%�hJ��`��{(zS_�\rJ�V(��g��у6�h��pA����$�sxtE\'i!�J�R֧��w��B��o���@#���^�rq�=��K�\",���;y�h�Adhis�-¹A��-g���U�\n�a��k0��-�b�s��U���g���N&g;�����	��?�ɓ���9F��.\'y���aC��w��\'���xń|k�N���yo��^�i�{����w���؞�Q��f��կW���ъ�8\\[%�����q7^�6=O?>���}�e>���_\0S�?����ퟳM�N֫<[�A��a�u���x��$\"	ل�jap��y�D9ِ$\"qX$K\0g�V\0~�����C�G�O�\"	�'),
(3,'11__0_0_0_0',1797961995,'x��VMo�8��(tRQ�,K����,��K�COE�d�%�:F���C}����Тz�ސ���p��(�9�ay���&��\"�A�����_�<�Ʋ��4K�xe��µ`.,i����%�n���@��U[+�1���M�@+�zor�a04J[�V�`B\"g[�V��`����\nCݏ.@H[+������Y[��:U?�0FMvLCk/`�z͗�H8�v�H�	�,��&Ǔ�X�����ʋ��ޜf2���W��G�\Z���ހ>�G���B��Cc2����d�c\n%Kh4=|y��><~�������E�MMD�-R�{��Uk�˴Ԫ�ݱv�R�z4xA���MOUZV>m�Ri�a��D�=����dҌP;{�`�\0�mQ;x�Xm���d꾚n��.���s.e5q������\0ȇ�|J9�Va&`<�1P��\r��]��/:��xmh�W�d9�،0�?(�/���e��aX\\-۝��f�~��0�e�ϭ���k��[�nH�\"���*s*�VQL��em�I;8�fj/q��@��X͸����5E3HQ��ń�7�\"��HC���R֟�E�T-mX;X���d�R^V�ulu����3���(97�e@k/?�A�f��-�{g\r6�^�����|1)Z��V�%��ql��C(5��_9b[�J�jz&������\n¯�l�G�x\Z�`��b�/=eGۅ;����h�Lߴ^������F��TdQ|j�`�ڞ~qM}e�������!Y�?|�����7j�,?�O�p����7��gӷ��j��~�5���S��s^�؋����^?~�����׮\'�Ԩ��:���w�o�ъ��_9%O���p�]��6?O��[\\��{-��	@���t�m���KQF��di�Ee%!/�w�b�딄�:�h��Lx��8\"	כM��RV��R�����!<ɿ,��'),
(4,'12__0_0_0_0',1797961995,'x��UMo�6��W:�)MI}ؒ��ݠ[����COER2aITI*��w�/�v�@[��ޤ��3��7������-��Y�b�(zɃ[���ᷛ~�o��X�t�Β(��,�9��Y���b��Fۭ�\\�3��x���F�-��4JA*�zor�(\r��V��3\\�R��y����0L��J�F�K[+���b��9RӶ�i%Ȕ��A�\Z��tT��^�F��-��h��P\'�eY��&�`��FOB��D3�7�7���pu�C�Ѝ!���>��PE�@��Fxr���d��>���@m�ؐ��6�?�=�r��B�������]`��PeRjՐ�;T�Q=�����Ȧ�QZV~�\\K�\r�H�%���ZF7ɤ�v�Љ�pm���!�}�$�j��Շ�=�\\;\nte�\Z� ���������\rdS�jR����#V�R��l�*��0�2 ���i��3ԇ?�M_t�m���Od���#a5�L_������� �Z�;TO��ҹ1��V쿴V��]#��\n���O-��� ��A5��^f��F�$�����L��uZ�)�#\0Y�ނC?�p	��e�P ��\nzVi���V��Ӷ���+���\'5N[��j9�.(�Ak����>L�I҂H\r���v�3j�Ȗ�=g6B�)�\\<�bR�Tu�����@�-<����O?|�\Z۪V2Z�3��aU]�vG\0~�o\0�fxΎ� ��*�);r���N�#Ǩ�>�\Zޗ�59��9�)s*�0:e�0}mO�����nO�-�G�6�8��_߶�~�˻6�.��O���o��w��g�k:���\Z�Y5�粐a_�_�������w�>ܸ�Hc@��f����W�����B%��N�S���5��q��������?<�dk���}ۿ�m�ZDI��4[%NZ\nT�1/��2Ci���(��\'+��t�|�d+�y�Y�֢`t��+EV��P�$!*�RD�_�d��'),
(5,'13__0_0_0_0',1797961995,'x��UKo�6��W:�)ME�l)�!�]t���{艠��LXU�Z���;�˴�-��m�7�r^�7�ٳ��=�Vi���0�zQx�����o7��_�yF�t�J�0��4\Z-\\���e�y�``��gw�(���4�Ы2F40cx\r��E֙W���1��H���xPKeD[\r���%Q�)y�\0�+�!1���\naj���[��裦5k��U@�����Ҏ)h��e��� �g���I<a�(�����7n�/��tb�3x�癌����:���ѴנN��pƇ6:߽`ѐL��\'<�q���\\�%4�6l�o���O��|��H\"Y��Ĥ�!g�7.\\��LK%ڝj�.5�G����<Q�t��Q�D��f)\Z��N	���7�ٿ�\'�ro����\r\nc`�ְU���w79��0jJ�}�M����#?:����(E5�o���Q\0Ȑ�\\�9�Xan�E`�5;��������M�wȲv\ZӲ/t�{�a�1wvt�_���T����Z�{�δ����.�->�F�K�����ڹu�����\0��j`��\\/�<h#ϊ��� U�����\\�8�5r��`��7�Э)�A�*�,&��7�]t@hj%��4�-¤riCbᢿ�&��Z�c�s��H-�9_�񥑶(Z����s�G�Q��/��\Z��x��\'WL�����aIq}\Z$��J��#Kl+[�YM/���eu�^A�5�����N��A�����d�r�^�r\Z�l���5%û��Q��^���?���,ϭ\nt_���/����ٳ5���5���__��~��;6F��/\'y����B��\\̳�k�9�bB���I6�粌q_�_�{�}����_�lO�֨Q}7u�����W�h�Nn�����[�y�������<�V~x�d�)���}ۿ�m�~H��O┗kȓ\0�<-y�њ�a��R�� -!\\��\'!IW����EP�~�b�$^�<)�<�)pGe����|'),
(6,'14__0_0_0_0',1797961995,'x��UMo�8��t�fEY�%=m�]�\rpz艠ȑLX�$U���w�i�J�a4�Mz3��y�ai�>ɔܲt��O&]�^+�w�Xx��6�/��S�\Z˪�6I�Z�A����lRO@	�(�໓B@=I�aTm��`����E��ˁZ��ޤ$�|op4J[Y}� �|I�zZށ�Z6V*�u?�\0!m��~\nK�:�hh��eб�ކIJ�״a\Zj���j5�/H�	�=]B���y>��=��p��\n�*\'�?�s~���\0\'8����m\r�S��j�{\Z�����;�\'<�p���L��\ZM�/[��n���������-$�]0;�o���j�,�\\��6�ڑ�J�hp0�m��TV\r<6TiY�m�Z*-T����h�Go���jo�\rL�-\n��N�l��f��W�x+�lؠ!���L����G������\Z�XQ.�Q	���Z\r��R��p�=-�`u`%;�s��9j�f\rv�8$��+�kc����Αi�K�n��.�:�Z�z� �򙱟�nօ������r�몫��v3���V��a�5�4߹Q&��J����AiaFzI��,ǝe�j��\0`���Э)�@���*�M(�\n�v��4���Vʺ7�����u���\'%�k��b>�Tg�ﱵt���D�FZ�h���޶�	3h�ʚ����\r�%��_��+&EsU��0_1>\r��c	����a��ZՒ��^�b��;��K}CXV��v�F1؃���2Rr�-¹A���3-\\Ӻc�0hr����@��s��s�Ӗ�<�sG�;�l���i冄$����+�gطv��r°��,4?��%=�����0\"�\'XҨ���>��ܭ�����!�o�������D\Z�\Z57#�Wo��oߴ��8\\wJ�￯q�]�6=O��k\\���Z���M���I̿��+��ςD~�l��[D~�\0�D�8!I���A�ML|�	�W�C��<��u�p�$�6��5�Gx&��:���'),
(7,'17__0_0_0_0',1797961995,'x��UKo�6��W:;�������h\n���s艠ȑ�XITI����ޡ^��u\nh� �M���p�ph�/\"ni����G����\"��~���V�g��M7�YEq��#��.�u�q�����m��shg �=���\r����H�{%�J���y�{�7\Zj��h+k�qj�8���\0͔茐x����0�d��m���&5m��V@��/��%UКX�^�%���a3�^$�EY��:GKoL�DO��t��gp�O#���pu�Cl�F�^�:�/�f|(�C���F��ޱ?�Ɍ�}($?,W#��sC~��<��x�����I`�{�z�v���`�I�dC�c�X�F�H8X�m7�D4<wD*Q�m�-\ZڑN	d�����$�h�ܙCs0l���c�߿�B<	���Pim	T���j��$~�������\r�R�jҀ���#F`�d続a7+������yZx���G��{����,�O>��I[r�u�sC;�TU`�E�s�A�T�O��r�e�O��kd�b[ vz�$����>�V\rT���e	i$w���Rq=�7�/���BE�̒��9�3HP+�v(�C�/=����\nKIi�Y[�I�R���yޓ:H[��j9��.(�ak����M6����)�h��ےUAj�B7�a8�(A\"ZV���A�����]mIRʺ�L���b[|5�T�{}l���V0Z�3�aY]\\m� �V���Qf/6��Sv�.ܹ/��G�Q�]j5<6;%:��:�S�Tsat�*�}mN/~�E}c���^�_��8��_��;��[^�	v��|���0XH�~��z�>���8	��-okT�G�̟�~��|��1:�����?�~{��5Z�F��T�_���>�#���_[%O��׸��A����}��?����/���㾟��c����5�~�^�Y��E�0`v]3��\0���(�����:\Z�\Z���q��E٪�҂�U�>N+��xU�(�4�>_�\r�\0�'),
(8,'18__0_0_0_0',1797961995,'x��UMo�6��W{vQ����$h\n���9�DP�HK�$�$�����P_��u\nh� �Mz3���{�ay�?˜ܲ|���&��U/����v���_�[�+k,k��dI�a���pa��+5X���V\n�d�\n�jke3�Ǡ>��h�U��MN�U�\Z��V��s��%%q��j�ײ�Ra��1ik�wsX��1Ck�V=��N�6LR������ب^��$�a;4�%$Ʉ	Y�����s5n�O���r3�7�7�)�+pu�C�\rtcho@�#ьm������{�G<�q�܇B�Ò\ZM>����~������I f�����,p�Z�2-�jhw��Ԩ\rF�v�De��SG���O��TZhXG;-�j�Q��M2�F��=t0w\0�mQ;!:�q��B�x�jhz3H��-S�����o����+V���u������v�j\0�Lu>�OVx[0�F����i��	;%�C_tȻ�ZղOt�d���0N�R��/�݀3]��0,����C�3c?vn�7�-�?�V��]#W�u��,V�ӑh5�4��Qf��F	�I��a��0S{�{m.���j��`���Я)�A��q,&�F��;�4ԉL+e��[�J�҆��E�IMҖ�Z�c��wH-�9_����H[��q���aF�Q��p�`�U�(���I�Rյ�/WL��ŷ�dB��/?}�mU+9��p�.R�#��²��7�����_Fʎ��p������ƙ�i=�4;59���S˩��#�[5�����_\\S_ټ\'�7�W�7&$��W_��~�孛 ����<\\��`���;\\ճ�s�:�2��oyU��>�f���2�������a�߾������[[��f���/W���ъ��_;%O��׸��A����}�?���ɗZ���$[C�,���;��/�3\"6E�	O ^� � JI�,H���fi����H��\\s�r�ˠX\'%��Y�I�1�MPD��o7y\0�'),
(9,'19__0_0_0_0',1797961995,'x��UKo�6��W:����-=��n�6(��\'�&G2aITI*��w��i;[�@���I��3�}�aET�Ȃܲb�/�����\"�E,�~����\"�Ʋ��U��q��h�Z0�U���%}�Rhg /����\r��V�ȺJ��V=^o\nRa0:\Z��l+����%Ih��k�Y���1ik�wsX�阃�5k��U@��^R������ب^�%Aΰ\Z�.$�	Y���)�3��h��;�ܛ�LFt\n�\\�i���G�H<�C=C�phL���Og���F��r5�~}�?�=<��xw�Ç��@�9��Yવ�eZj���X;v�Q=\Z<� ���ʦ��*-+�6G��а�vZ���Q��M:�F��=t0w\0Ӷ(����_�|b�pթZ��4���`*�n����u=>`��&�]���\Z\0R�O2G+�\r��̼fu�xƾ�G��o:d�x�i�]�b�Ggl��u�ߜ;�qf��aXe-۝�jg�~��|o[�j���\\cW�us�.V��h5�4��Qfy�F	���a��0S{�{[.G�m�Ռ��*Yo1�_S4�U�*XLHm�o;�4�IJ+e�)[�I�҆���?�&��Z�c�7��Z:s��G鹑�(Z����s`F�Q��p�`�M�(���I�Rյ�/)���ķ�@B��7���۪VrV�3��aU]\\� �o�fxƎ�(��;)?�.��/�FGgZ��lxWv0jrҫ���S�E�U��k{z�k�{�d͆j�&��Q������aǦ�����!�0Xh~��l��bN���k⿼�QqU3.�������׏�>�|�����45jn�_}E����؉��S�T��}�;�z��y��|�u�����]~x�dk(���u����5�\"^�i��\\�<��\"��9��j�D<�	�Wb����!/�2L˲L�J��Di�y����¤�E�B�N�T�����'),
(10,'20__0_0_0_0',1797961995,'x��UKo�6��W:;���j%�#	��/v99�+�*Ie�0��;z.w�(�G�&}3��|�\r�eA�,3r˲$͞Mf^\'�w+���~����&󬱬n I�0��4\Z-\\faeI2O@�(�軓B@3i�aTm��a��4�E��W\0-��0��H����h���)�Koɦ7F����=�ek��\\�c�V����c��V�);V��l��\"~C[���+بN��ğa;�\'$�	Y��������T99�<�����<��\rtmhg@��G�ht�{�GC2�w�Ox<〹���%5�>?����}�������$�f�=�u��Uc�eZhU��T;�T�\rF����ʺ���*-K�m}K���������b�o�I4B�������Ea�	��;���+��dS(]�QD&Ce��+?��-�X����||��\nYNZ��ߵ�j\0�jݖs�j�7����Q��OȒxT]�bύCSþХ�)�v�q�Z{���ұn�K���V��;Ƞ}f짶�v�g�O���rװ����S��/V��qh5�4߹Qf��Z	�9���0��i��rc5�v�J�Y��� E��,&�E�/�`@\Z�L+eݙ[dJ�Bæ�Ewٓ�lʋr9�T�ﱵt���ėFڠh����v�\n3j�ʆW���\r�W%��_��+&EUU�\\q{\Z+���\n\r�飾��j$g�V�*u�������G��b�i��u��d[�s��\'gZ������a���>`��[�E��V\r���y◞���%gK��[K7\"$\r��?_��~��c��/\'�p�����pMϦ���(�ɼ&��5������s^��������!׏�>�~���Mω45jn&��~�\"?}ՎVd�p�+y*��Ɲw=��<��������O��?<�dk(���c����� �H�0��FA������-x�x��i\n�c�(|�\"\'��a�qEŜ�1�2Y�,}�o�<I!*�?��.'),
(11,'21__0_0_0_0',1797961995,'x��UɎ�6��+�c-��2�a`q�d.=>�DPdIM�$*$��`�=Em�n��b�I�b�<̟E��<��g�G���݉<��n����3�Ц�$��hf��a�S+&�=5���ٽ���r�*cD3�נ�.��^	�R�G�:r��ƃZ*#����$��&��<�͔茐��a�\\�Z��l6�p�I���UO+ S��N��oIG�fk�+��3l�BX�A<a\\��|\\�x�7�PD:>�<��HFt2�\n\\����Ѥנ������{a(d0�wΟ�x�}�\n�O�k�v�w���㻏��|x��vA�g�7n�l\rV��J6�;�Ujd����v�DD��SG���6�Ra���@֜�Q��m<��˃9u0W\0�6(��G(m�PJ��+o��93���èKQMݶ��w�(\0��ܦ2�[���v����$/O�ɣ��E�]�N!Z��,qN6�ƙZ����v|���8fW��� ���6�:;�����Z#�%��f��@윺I�A+})�V\rT��ke�i$w�\0��T\\O�\r�[�iZh�(3#�Y�ޠA7�p	��f�P���zU�����ҸS��ȥ[���\'u�����rK]Pv�֒����0�&I�2 5���{=j����=��k��JD�yO��$)e]��bz��J��7���l�5�^��ʵ���k}CX4óu>�b0Ga��kKٙ[�s/���g�Q�]j;�#59��\Z�K�Rdat�*�}m.�آ����Z���Z�A���Vg�~�;5�.?_O���/��p����f���1*�l��yc-ޮ�/F��~|����_nmM�֨Q};U���o����#��8�X%O��7��n�A����}��?�?���k�O\06�hBf1������\"��sƩ��6��2��t�IJ!�\n����4�q�J�@\Ze�-�6/�I�Є�2N˂�E�[�ˁe�V���'),
(12,'16__0_0_0_0',1797961995,'x��WMo�6��W,t������`w�-��Pg=4IɄ%Q%�u� ��CI�i;�[�tћ���p��IUϢBw����YWq��w�ew��|�WVF�\r��i�aX��1|��IT&ɫ��>��kw�1�;��8U#:�0��{�#E�7J��^W�\n�`^��2�o�ԑ\r&U���#�T��	��38��t�Ep}Ը%}3����)IZ�x ���\n�rTt� \nl�F؄(]0&��-��>�ĚEwA/��	�\nK����j3�d{nNp<r�i<j�N����S_�@�o�h����\'<u8��ǭd�55�6�o�/�����~���J=@���t4>-T�ڎk%;<�j�.ur���!Ёy¢�Ӏ��ϣ�XޑJ@��Y��m���ɽ9�u\0�m@)]�}3 -ݎͲ�^P���\\�f!�vw7`�8>��SJ��nµ����%Gy��]`�r3n�T{m��W��r9��a����q{��N3Q\r7ŵ��{�$v�͗��7��/��z��VEw۱���\0i�rm�x�tb��d����� �K{�}Z�\'�l�Q���*�h�@��ȁ4a+XC@{O����\nHIi��Ze��چ��l��EE�iݬۡ�[B�@-v��*�s$�����hvs,�܁{�na���Qг��i;2~�u�嫺����\'_aײm�a�wq�%��G�׊��O,۽�%-�Pl��Uj����Xt�KvZ\r\n1a����S��8�ա�)F�b~(���=�����aaˏ�+/�ϣ��5�_lS_��3�\r_�^g��֛ TFa��[��[��4��{1v���_�w��.�MoNR��-{3(���O��Ћ�W���^?~�������\'BkШ�]:���w�o�!\n�8�X%/�O�o�o�As�ӿ������)o������������n����s]�9�aQ�8Q��2�ͶQ�唅u�yɋ�E��8.yBy���u��,�kT��6�BR��*ۦ(�3B�?�I�-'),
(13,'1__0_0_0_0',1797961995,'x�uTKo�8��(tRQ/[\n��Ŷ@���COE�d�%�8F���C�L�ٛ�}�y~3� ś,�Vl���qR� �_?�����5���Ho�4��(O&�k�,�LBH�d6E �����ȋ\0�jke�Ϡ>�-�\nh�Հ�\r���dh����C��Vǯ`����\n=M@H�(~XM1s2�a]=�\Z�p.�`���홆���F\r��ّp�����3&dU-�H�\"xJ�X!�>��E�]a��WKx������*����K4\\���LB�>��3�9��[C�</��x�����޳?��c9�T*qZ=!����?w�_�?>����*�$I	�Fg�8e>Xt\\uGC+�Z���Ԫ	#(�Je��kO���?k�i�e=��D֞�I��}:�L��=���i[T�8RT�w�.���Y���)���Z�α��_��z��t�z\"�A����ß��D��_Y����)y.����x7-Z��m�S�pҪ���Q5�ƙ\"L[9K��	\n���vC٣Z�����е���v�q���5Cym�	�5X��5�;xȸj��߽�,�s����l�\\cW�u�/\"\\	V��\n5�4��^��V]q��Qia��&���V\Z���U���C��h)��U�R(�Gɮ: \ru��J�ue\"O�T�m�,��4d�Q^]ȫ�\0�5�.b��kK�(yy��2�ĩ�x3����^�x���h��F�|����{<�Pi����)w���5�JE�X�7���?\Z\"²o��\Z�a���n=�g�Ɲ���it�8�§��X`�,^�0\n/�K�E�%�������X�\"؄q��*��(aU�\0+Y�g�L�4� �i�m�0I6 ���I�e\0q����o7d�,#Y�N�4�J����');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'15__0_0_0_0','pageId_1'),
(2,'15__0_0_0_0','pageId_15'),
(3,'5__0_0_0_0','pageId_1'),
(4,'5__0_0_0_0','pageId_5'),
(5,'11__0_0_0_0','pageId_1'),
(6,'11__0_0_0_0','pageId_11'),
(7,'12__0_0_0_0','pageId_1'),
(8,'12__0_0_0_0','pageId_12'),
(9,'13__0_0_0_0','pageId_1'),
(10,'13__0_0_0_0','pageId_13'),
(11,'14__0_0_0_0','pageId_1'),
(12,'14__0_0_0_0','pageId_14'),
(13,'17__0_0_0_0','pageId_1'),
(14,'17__0_0_0_0','pageId_17'),
(15,'18__0_0_0_0','pageId_1'),
(16,'18__0_0_0_0','pageId_18'),
(17,'19__0_0_0_0','pageId_1'),
(18,'19__0_0_0_0','pageId_19'),
(19,'20__0_0_0_0','pageId_1'),
(20,'20__0_0_0_0','pageId_20'),
(21,'21__0_0_0_0','pageId_1'),
(22,'21__0_0_0_0','pageId_21'),
(23,'16__0_0_0_0','pageId_1'),
(24,'16__0_0_0_0','pageId_16'),
(25,'1__0_0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_kesearch_tags` text DEFAULT NULL,
  `tx_kesearch_abstract` text DEFAULT NULL,
  `tx_kesearch_resultimage` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1795334294,1794119207,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"}',0,0,0,0,1,1,31,31,1,1795344511,0,0,0,0,0.5,1,'Home','/','TCEMAIN.permissions.groupid = 1\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete',0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__Home','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(2,1,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(3,2,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,1795333022,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(4,2,1795333042,1795333022,1,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(5,1,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','pagets__SidebarLeft','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(6,5,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(7,5,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(8,5,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Parking fees','/revenue-payments/parking-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(9,5,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Market fees','/revenue-payments/market-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(10,5,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Waiver of interest','/revenue-payments/waiver-of-interest',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(11,1,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Health','/health',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(12,1,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Environment & water','/environment-water',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(13,1,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Trade & tourism','/trade-tourism',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(14,1,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Public participation','/public-participation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(15,1,1795369027,1795334294,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\"}',0,0,0,0,1,1,31,31,0,1795369027,0,0,0,0,0.5,1,'Contact','/contact',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(16,1,1795348009,1795334294,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795348009,0,0,0,0,0.5,1,'Search','/search',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(17,1,1795334294,1795334294,0,0,0,0,'0',2048,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'E-services portal','/e-services-portal',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(18,1,1795334294,1795334294,0,0,0,0,'0',2304,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Accessibility statement','/accessibility-statement',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(19,1,1795334294,1795334294,0,0,0,0,'0',2560,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Privacy policy','/privacy-policy',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(20,1,1795334294,1795334294,0,0,0,0,'0',2816,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Access to information','/access-to-information',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(21,1,1795334294,1795334294,0,0,0,0,'0',3072,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Tenders','/tenders',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(22,1,1795334294,1795334294,0,0,0,0,'0',3328,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Service navigation','/service-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(23,1,1795334294,1795334294,0,0,0,0,'0',3584,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Footer navigation','/footer-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(24,22,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,17,0,0,0,0.5,4,'E-services portal','/e-services-portal-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(25,22,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,15,0,0,0,0.5,4,'Contact','/contact-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(26,23,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,18,0,0,0,0.5,4,'Accessibility statement','/accessibility-statement-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(27,23,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,19,0,0,0,0.5,4,'Privacy policy','/privacy-policy-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(28,23,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,20,0,0,0,0.5,4,'Access to information','/access-to-information-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(29,23,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,21,0,0,0,0.5,4,'Tenders','/tenders-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(30,1,1795336956,1795336956,0,0,0,0,'0',3200,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795336956,0,0,0,0,0.5,1,'News','/news',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(31,30,1795348009,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795348009,0,0,0,0,0.5,1,'Article','/news/article',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(32,1,1795336956,1795336956,0,0,0,0,'0',3840,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'News records','/news-records',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(33,1,1795348009,1795345582,0,0,0,0,'0',3136,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795345582,0,0,0,0,0.5,1,'Page not found','/page-not-found',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','',NULL,'',1,1,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(34,1,1795348009,1795348009,0,0,0,0,'0',4096,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Search index','/search-index',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `tx_kesearch_filter` text DEFAULT NULL,
  `tx_kesearch_filtersubcat` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,32,1795336956,1795336956,0,0,0,0,256,NULL,0,0,NULL,'',0,0,0,0,0,'Trade & markets',0,0,0,0,'','','',NULL,'',NULL,'trade-markets',NULL,NULL),
(2,32,1795336956,1795336956,0,0,0,0,512,NULL,0,0,NULL,'',0,0,0,0,0,'Roads & transport',0,0,0,0,'','','',NULL,'',NULL,'roads-transport',NULL,NULL),
(3,32,1795336956,1795336956,0,0,0,0,768,NULL,0,0,NULL,'',0,0,0,0,0,'Health',0,0,0,0,'','','',NULL,'',NULL,'health',NULL,NULL),
(4,32,1795336956,1795336956,0,0,0,0,1024,NULL,0,0,NULL,'',0,0,0,0,0,'Revenue & payments',0,0,0,0,'','','',NULL,'',NULL,'revenue-payments',NULL,NULL),
(5,32,1795336956,1795336956,0,0,0,0,1280,NULL,0,0,NULL,'',0,0,0,0,0,'Public participation',0,0,0,0,'','','',NULL,'',NULL,'public-participation',NULL,NULL),
(6,32,1795336956,1795336956,0,0,0,0,1536,NULL,0,0,NULL,'',0,0,0,0,0,'Environment',0,0,0,0,'','','',NULL,'',NULL,'environment',NULL,NULL),
(7,32,1795336956,1795336956,0,0,0,0,1792,NULL,0,0,NULL,'',0,0,0,0,0,'Water',0,0,0,0,'','','',NULL,'',NULL,'water',NULL,NULL),
(8,32,1795336956,1795336956,0,0,0,0,2048,NULL,0,0,NULL,'',0,0,0,0,0,'Education',0,0,0,0,'','','',NULL,'',NULL,'education',NULL,NULL);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,1,0,1,'tx_news_domain_model_news','categories'),
(2,2,0,1,'tx_news_domain_model_news','categories'),
(3,3,0,1,'tx_news_domain_model_news','categories'),
(4,4,0,1,'tx_news_domain_model_news','categories'),
(5,5,0,1,'tx_news_domain_model_news','categories'),
(6,6,0,1,'tx_news_domain_model_news','categories'),
(7,7,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml','165cd81b05433cbd58fd78992daf226ea111f5bf','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','data.xml','df6041a9d17e792b9962e4b87dbaa3b47094afb7',1795348019,1795348019,139896,1,1,'text/xml',0,0),
(2,0,1795344511,1795344511,'/user_upload/slides/slide-coast.svg','ff045dfdd71e6acbcb55576edfcd297e7b28ce67','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-coast.svg','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795344511,1795344511,1233,1,2,'image/svg+xml',0,0),
(3,0,1795344511,1795344511,'/user_upload/slides/slide-rates.svg','1e61ced89c016178e02a3c5bf79eb2de9fc6ddef','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-rates.svg','930ad2b62005be8ab906802601193f671beda593',1795344511,1795344511,1214,1,2,'image/svg+xml',0,0),
(4,0,1795344511,1795344511,'/user_upload/slides/slide-community.svg','fa4ea1a512790f3c4a1936302b29a1a691654ebb','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-community.svg','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795344511,1795344511,900,1,2,'image/svg+xml',0,0),
(8,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml.files/20ea8f7cede2a53c268a4bab9647c06acfed9ff3','3a0d8dd4dab01965f63cc1874ec27659e68ab2d4','a20b30e6345e127e49790026ced895ee898ede1b','','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795348019,1795348019,900,1,2,'image/svg+xml',0,0),
(9,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml.files/54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','bf9643ba7780e40c2cad570672027d3debcd9d69','a20b30e6345e127e49790026ced895ee898ede1b','','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795348019,1795348019,1233,1,2,'image/svg+xml',0,0),
(10,0,1795348019,1795348019,'/user_upload/_temp_/importexport/data.xml.files/930ad2b62005be8ab906802601193f671beda593','aa2ff46d1695ecafd15b9d47e0b7f1c24c270008','a20b30e6345e127e49790026ced895ee898ede1b','','930ad2b62005be8ab906802601193f671beda593','930ad2b62005be8ab906802601193f671beda593',1795348019,1795348019,1214,1,2,'image/svg+xml',0,0),
(11,0,1795368020,1795368020,'/user_upload/pages/revenue.svg','1cd73fe883ea2a924471d5fd501fa4302aefed05','41e6d150c75718d77d7de5232176c747d5e946ab','svg','revenue.svg','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd',1795366717,1795366717,1527,1,2,'image/svg+xml',0,0),
(12,0,1795368020,1795368020,'/user_upload/pages/land-rates.svg','d5f7763ccb54d96ca705ae00a952c4e667420ed2','41e6d150c75718d77d7de5232176c747d5e946ab','svg','land-rates.svg','443957829800f283dbb2ffd610ad644b542355be',1795366717,1795366717,1341,1,2,'image/svg+xml',0,0),
(13,0,1795368020,1795368020,'/user_upload/pages/business-permit.svg','9de9cf466345826e6e0004eaff218214e0ed670c','41e6d150c75718d77d7de5232176c747d5e946ab','svg','business-permit.svg','3cdd6e20a13e650cec99679b5eb52e67c529921a',1795366717,1795366717,1796,1,2,'image/svg+xml',0,0),
(14,0,1795368020,1795368020,'/user_upload/pages/parking.svg','d5d63aa11f9836ff8a5574041dd005fc33d3063e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','parking.svg','21e3ea6329d902fadb8e700a33b813364ae0f517',1795366717,1795366717,1635,1,2,'image/svg+xml',0,0),
(15,0,1795368020,1795368020,'/user_upload/pages/market.svg','9b5ab031812f7b3000919f31d93eb6834eef44f1','41e6d150c75718d77d7de5232176c747d5e946ab','svg','market.svg','f4699dfad158612a22995a697549a4f0b4e34d51',1795366717,1795366717,1219,1,2,'image/svg+xml',0,0),
(16,0,1795368020,1795368020,'/user_upload/pages/waiver.svg','c29d9ffd11670a33b99b6be69ccd5d853c4477e3','41e6d150c75718d77d7de5232176c747d5e946ab','svg','waiver.svg','fe4ef5de488313ec55bf32751c903663094ef756',1795366717,1795366717,2156,1,2,'image/svg+xml',0,0),
(17,0,1795368020,1795368020,'/user_upload/pages/health.svg','a1bb0acb15caed893f46871a75b18a2a72fbed07','41e6d150c75718d77d7de5232176c747d5e946ab','svg','health.svg','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a',1795366717,1795366717,1263,1,2,'image/svg+xml',0,0),
(18,0,1795368020,1795368020,'/user_upload/pages/water.svg','6b1802ac603aa6da515cf8c4311e08b581f6e965','41e6d150c75718d77d7de5232176c747d5e946ab','svg','water.svg','4555d9ca1525f63e42e91e3b6f492963d65bc496',1795366717,1795366717,1246,1,2,'image/svg+xml',0,0),
(19,0,1795368020,1795368020,'/user_upload/pages/tourism.svg','8c1f6765ae9538e3fd436189d04637f5e020d708','41e6d150c75718d77d7de5232176c747d5e946ab','svg','tourism.svg','b2596f9cc022b1e81e206e3533d1e5944587bb51',1795366717,1795366717,1109,1,2,'image/svg+xml',0,0),
(20,0,1795368020,1795368020,'/user_upload/pages/office.svg','ce61dc3f063e40c13764b7cd0cdc993f1a605920','41e6d150c75718d77d7de5232176c747d5e946ab','svg','office.svg','2a62d5fb10462c90782877bc4254dec0a59e82a0',1795366717,1795366717,1396,1,2,'image/svg+xml',0,0),
(21,0,1795368020,1795368020,'/user_upload/pages/participation.svg','a4da72511bdbadb3e3b61b67f2225a182ed42e62','41e6d150c75718d77d7de5232176c747d5e946ab','svg','participation.svg','36f0d096874cc84265f1180798b35e74ccb363dc',1795366717,1795366717,1413,1,2,'image/svg+xml',0,0),
(22,0,1795368020,1795368020,'/user_upload/pages/portal.svg','2d8f4684e52b0f63833ec132ac661878cbbd3f8e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','portal.svg','83926aff612828d0f180cb5c7549588e6e10c537',1795366717,1795366717,1459,1,2,'image/svg+xml',0,0),
(23,0,1795368020,1795368020,'/user_upload/pages/accessibility.svg','6f0b06a790eb2db4ac6f06627a44c9b86354e777','41e6d150c75718d77d7de5232176c747d5e946ab','svg','accessibility.svg','ac912b916c948f19149c48cc52ef27f3e3a9a2eb',1795366717,1795366717,1311,1,2,'image/svg+xml',0,0),
(24,0,1795368020,1795368020,'/user_upload/pages/privacy.svg','37eb3d14802d29b87df0e485e47493b1d99c8c21','41e6d150c75718d77d7de5232176c747d5e946ab','svg','privacy.svg','9b8e53905ab5b20c15fdeb594911c71feb55252c',1795366717,1795366717,658,1,2,'image/svg+xml',0,0),
(25,0,1795368020,1795368020,'/user_upload/pages/documents.svg','aabcfbfda5ee6ee108add7c25755e60125aac964','41e6d150c75718d77d7de5232176c747d5e946ab','svg','documents.svg','55578155722872d3dbe552da247abdf9eab0f079',1795366717,1795366717,1109,1,2,'image/svg+xml',0,0),
(26,0,1795368020,1795368020,'/user_upload/pages/tenders.svg','6d7a69908a1ccb7e07fe72d25353ab2cd97bcd6e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','tenders.svg','4466965824279af3d0752afc1c381bc67bf02cb3',1795366717,1795366717,1327,1,2,'image/svg+xml',0,0),
(27,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','241e84244ec067649ea2d0ea239961dfa9a911b0','a20b30e6345e127e49790026ced895ee898ede1b','','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd',1795368054,1795368054,1527,1,2,'image/svg+xml',0,0),
(28,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/21e3ea6329d902fadb8e700a33b813364ae0f517','6a072c5f3058ce87c7e331226dca617a46514da7','a20b30e6345e127e49790026ced895ee898ede1b','','21e3ea6329d902fadb8e700a33b813364ae0f517','21e3ea6329d902fadb8e700a33b813364ae0f517',1795368054,1795368054,1635,1,2,'image/svg+xml',0,0),
(29,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/2a62d5fb10462c90782877bc4254dec0a59e82a0','f87fdf05d0c5c61478c0495b9bdfbbc7ef865a85','a20b30e6345e127e49790026ced895ee898ede1b','','2a62d5fb10462c90782877bc4254dec0a59e82a0','2a62d5fb10462c90782877bc4254dec0a59e82a0',1795368054,1795368054,1396,1,2,'image/svg+xml',0,0),
(30,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','ed73bf77934c98f376223a1eba8ff16bdb0e4491','a20b30e6345e127e49790026ced895ee898ede1b','','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a',1795368054,1795368054,1263,1,2,'image/svg+xml',0,0),
(31,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/36f0d096874cc84265f1180798b35e74ccb363dc','a54eec23cb10896de868963d7d569a38d725ac3e','a20b30e6345e127e49790026ced895ee898ede1b','','36f0d096874cc84265f1180798b35e74ccb363dc','36f0d096874cc84265f1180798b35e74ccb363dc',1795368054,1795368054,1413,1,2,'image/svg+xml',0,0),
(32,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/3cdd6e20a13e650cec99679b5eb52e67c529921a','25689a616091f047048ed8215f8d79c80c92bc66','a20b30e6345e127e49790026ced895ee898ede1b','','3cdd6e20a13e650cec99679b5eb52e67c529921a','3cdd6e20a13e650cec99679b5eb52e67c529921a',1795368054,1795368054,1796,1,2,'image/svg+xml',0,0),
(33,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/443957829800f283dbb2ffd610ad644b542355be','437c9cf197a4e167c48cce35f9538beacf1f475c','a20b30e6345e127e49790026ced895ee898ede1b','','443957829800f283dbb2ffd610ad644b542355be','443957829800f283dbb2ffd610ad644b542355be',1795368054,1795368054,1341,1,2,'image/svg+xml',0,0),
(34,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/4466965824279af3d0752afc1c381bc67bf02cb3','876fedf79b3161dac6bb747b570e6881d0fd47dd','a20b30e6345e127e49790026ced895ee898ede1b','','4466965824279af3d0752afc1c381bc67bf02cb3','4466965824279af3d0752afc1c381bc67bf02cb3',1795368054,1795368054,1327,1,2,'image/svg+xml',0,0),
(35,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/4555d9ca1525f63e42e91e3b6f492963d65bc496','b56ad440266757db55d031cf5fadd6751129372d','a20b30e6345e127e49790026ced895ee898ede1b','','4555d9ca1525f63e42e91e3b6f492963d65bc496','4555d9ca1525f63e42e91e3b6f492963d65bc496',1795368054,1795368054,1246,1,2,'image/svg+xml',0,0),
(36,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/55578155722872d3dbe552da247abdf9eab0f079','332bc17e608fc5c104c37f7288f517e6cedc1a7f','a20b30e6345e127e49790026ced895ee898ede1b','','55578155722872d3dbe552da247abdf9eab0f079','55578155722872d3dbe552da247abdf9eab0f079',1795368054,1795368054,1109,1,2,'image/svg+xml',0,0),
(37,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/83926aff612828d0f180cb5c7549588e6e10c537','f1ccf1dbc49175f378508d2526bfe6ef0b0e8b77','a20b30e6345e127e49790026ced895ee898ede1b','','83926aff612828d0f180cb5c7549588e6e10c537','83926aff612828d0f180cb5c7549588e6e10c537',1795368054,1795368054,1459,1,2,'image/svg+xml',0,0),
(38,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/9b8e53905ab5b20c15fdeb594911c71feb55252c','7a588fa8f56093604f80ae9ca00ea4a846772935','a20b30e6345e127e49790026ced895ee898ede1b','','9b8e53905ab5b20c15fdeb594911c71feb55252c','9b8e53905ab5b20c15fdeb594911c71feb55252c',1795368054,1795368054,658,1,2,'image/svg+xml',0,0),
(39,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/ac912b916c948f19149c48cc52ef27f3e3a9a2eb','9c987bfeb026319721c2e53237d64ad0598d506d','a20b30e6345e127e49790026ced895ee898ede1b','','ac912b916c948f19149c48cc52ef27f3e3a9a2eb','ac912b916c948f19149c48cc52ef27f3e3a9a2eb',1795368054,1795368054,1311,1,2,'image/svg+xml',0,0),
(40,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/b2596f9cc022b1e81e206e3533d1e5944587bb51','574411d8e13602a441cd710d24e3dd2a6f2e4ffb','a20b30e6345e127e49790026ced895ee898ede1b','','b2596f9cc022b1e81e206e3533d1e5944587bb51','b2596f9cc022b1e81e206e3533d1e5944587bb51',1795368054,1795368054,1109,1,2,'image/svg+xml',0,0),
(41,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/f4699dfad158612a22995a697549a4f0b4e34d51','4ed4ed3f9e93d9dd9aedeec17c0b25716c4cb631','a20b30e6345e127e49790026ced895ee898ede1b','','f4699dfad158612a22995a697549a4f0b4e34d51','f4699dfad158612a22995a697549a4f0b4e34d51',1795368054,1795368054,1219,1,2,'image/svg+xml',0,0),
(42,0,1795368054,1795368054,'/user_upload/_temp_/importexport/data.xml.files/fe4ef5de488313ec55bf32751c903663094ef756','4aab823a35c5d45231c0f2be8f8973d294206e96','a20b30e6345e127e49790026ced895ee898ede1b','','fe4ef5de488313ec55bf32751c903663094ef756','fe4ef5de488313ec55bf32751c903663094ef756',1795368054,1795368054,2156,1,2,'image/svg+xml',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `tx_kesearch_no_search` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1795334315,1795334315,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0,0),
(2,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1600,600,0),
(3,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,1600,600,0),
(4,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,1600,600,0),
(8,0,1795348018,1795348018,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,0,0,0),
(9,0,1795348018,1795348018,0,0,NULL,'',0,0,0,0,NULL,NULL,0,9,NULL,0,0,0),
(10,0,1795348018,1795348018,0,0,NULL,'',0,0,0,0,NULL,NULL,0,10,NULL,0,0,0),
(11,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,11,NULL,1200,800,0),
(12,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,12,NULL,1200,800,0),
(13,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,13,NULL,1200,800,0),
(14,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,14,NULL,1200,800,0),
(15,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,15,NULL,1200,800,0),
(16,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,16,NULL,1200,800,0),
(17,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,17,NULL,1200,800,0),
(18,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,18,NULL,1200,800,0),
(19,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,19,NULL,1200,800,0),
(20,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,20,NULL,1200,800,0),
(21,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,21,NULL,1200,800,0),
(22,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,22,NULL,1200,800,0),
(23,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,23,NULL,1200,800,0),
(24,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,24,NULL,1200,800,0),
(25,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,25,NULL,1200,800,0),
(26,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,26,NULL,1200,800,0),
(27,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,27,NULL,0,0,0),
(28,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,28,NULL,0,0,0),
(29,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,29,NULL,0,0,0),
(30,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,30,NULL,0,0,0),
(31,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,31,NULL,0,0,0),
(32,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,32,NULL,0,0,0),
(33,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,33,NULL,0,0,0),
(34,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,34,NULL,0,0,0),
(35,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,35,NULL,0,0,0),
(36,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,36,NULL,0,0,0),
(37,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,37,NULL,0,0,0),
(38,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,38,NULL,0,0,0),
(39,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,39,NULL,0,0,0),
(40,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,40,NULL,0,0,0),
(41,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,41,NULL,0,0,0),
(42,0,1795368053,1795368053,0,0,NULL,'',0,0,0,0,NULL,NULL,0,42,NULL,0,0,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1795344523,1795344523,1,2,'/_processed_/8/b/csm_slide-coast_a539169108.svg','csm_slide-coast_a539169108.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','Image.CropScaleMask','a539169108',1600,560),
(2,1795344523,1795344523,1,3,'/_processed_/f/f/csm_slide-rates_202cf46cda.svg','csm_slide-rates_202cf46cda.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','930ad2b62005be8ab906802601193f671beda593','Image.CropScaleMask','202cf46cda',1600,560),
(3,1795344523,1795344523,1,4,'/_processed_/e/b/csm_slide-community_e5b6b5187d.svg','csm_slide-community_e5b6b5187d.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','Image.CropScaleMask','e5b6b5187d',1600,560),
(4,1795368035,1795368035,1,19,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','7733916107',1200,800),
(5,1795368035,1795368035,1,19,'',NULL,'','a:3:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"crop\";N;}','8e17f053c0ee386607a1a7dd4c1234c3571c7b95','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','d525cc5c74',600,400),
(6,1795368035,1795368035,1,19,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','4c457691d0',295,196),
(7,1795368035,1795368035,1,15,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','355bf597e6',1200,800),
(8,1795368035,1795368035,1,15,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','c5cd09fac1',295,196),
(9,1795368035,1795368035,1,18,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','0492c25a1a',1200,800),
(10,1795368035,1795368035,1,18,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','a1ad152454',295,196),
(11,1795368035,1795368035,1,20,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','ac2f4c151d',1200,800),
(12,1795368035,1795368035,1,20,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','5d58cc317b',295,196),
(13,1795368194,1795368194,1,15,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','f357b6f0a8',300,200),
(14,1795368277,1795368277,1,12,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','443957829800f283dbb2ffd610ad644b542355be','Image.CropScaleMask','4bc69b387a',1200,800),
(15,1795368277,1795368277,1,12,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','443957829800f283dbb2ffd610ad644b542355be','Image.CropScaleMask','0d8c01c268',300,200),
(16,1795368277,1795368277,1,17,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','Image.CropScaleMask','3e1c804694',1200,800),
(17,1795368277,1795368277,1,17,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','Image.CropScaleMask','f8fef5c0ea',300,200),
(18,1795369031,1795369031,1,20,'',NULL,'','a:3:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"crop\";N;}','8e17f053c0ee386607a1a7dd4c1234c3571c7b95','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','3f32331746',600,400);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,1,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(2,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,2,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(3,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,4,NULL,NULL,3,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(4,5,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,11,NULL,'A mobile phone confirming a payment, beside a stack of coins',11,'tt_content','image',1,'','Pay by mobile money: the receipt arrives on your phone.',NULL,0,0),
(5,6,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,12,NULL,'Two houses on surveyed plots on a green hillside',13,'tt_content','image',1,'','Every plot in the valuation roll has a rateable value.',NULL,0,0),
(6,7,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,13,NULL,'A shop with a striped awning and a framed business permit',16,'tt_content','image',1,'','One permit a year covers trade, health and fire safety.',NULL,0,0),
(7,8,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,14,NULL,'Two cars parked beside a parking sign',18,'tt_content','image',1,'','Parking on Beach Road is paid Monday to Saturday, 7:00 to 18:00.',NULL,0,0),
(8,9,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,15,NULL,'Two market stalls with fruit and vegetables',20,'tt_content','image',1,'','Stalls at the central market on Market Street.',NULL,0,0),
(9,10,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,16,NULL,'A calendar with a ticked check mark beside it',22,'tt_content','image',1,'','Clear your arrears before 30 June to have the interest waived.',NULL,0,0),
(10,11,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,17,NULL,'A health centre with a red cross sign',24,'tt_content','image',1,'','Mto Safi Town health centre, open Monday to Saturday.',NULL,0,0),
(11,12,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,18,NULL,'A river running through green land, with a water tower and a tap',26,'tt_content','image',1,'','The river gives the town its name: Mto Safi means \"clean river\".',NULL,0,0),
(12,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,19,NULL,'A dhow sailing at sunset with a palm tree on the beach',29,'tt_content','image',1,'','A dhow leaves the old harbour at sunset.',NULL,0,0),
(13,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,19,NULL,'A dhow sailing at sunset with a palm tree on the beach',31,'tt_content','image',1,'','Sunset over the old dhow harbour.',NULL,0,0),
(14,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,15,NULL,'Two market stalls with fruit and vegetables',31,'tt_content','image',2,'','Mangoes, tomatoes and sukuma wiki at the central market.',NULL,0,0),
(15,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,18,NULL,'A river running through green land, with a water tower and a tap',31,'tt_content','image',3,'','The river mouth, where the mangrove boardwalk starts.',NULL,0,0),
(16,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,20,NULL,'The municipal office with a flag on the roof',31,'tt_content','image',4,'','The municipal office, built in 1962, on Beach Road.',NULL,0,0),
(17,14,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,21,NULL,'Residents gathered in front of a board at a public forum',32,'tt_content','image',1,'','Budget forum in the municipal hall, Central ward.',NULL,0,0),
(18,15,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,20,NULL,'The municipal office with a flag on the roof',34,'tt_content','image',1,'','The municipal office on Beach Road.',NULL,0,0),
(19,17,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,22,NULL,'A laptop showing a login form, beside a padlock',37,'tt_content','image',1,'','Log in with your eCitizen account.',NULL,0,0),
(20,18,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,23,NULL,'A web page with clear headings and a focused button, beside the accessibility symbol',38,'tt_content','image',1,'','Example image: replace it together with the text.',NULL,0,0),
(21,19,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,24,NULL,'A shield with a padlock',39,'tt_content','image',1,'','Example image: replace it together with the text.',NULL,0,0),
(22,20,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,25,NULL,'A folder of documents and a magnifying glass',40,'tt_content','image',1,'','Requests are answered within 21 days.',NULL,0,0),
(23,21,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,26,NULL,'A building under construction with a crane, and a sealed envelope',42,'tt_content','image',1,'','Bids go in a sealed envelope to the procurement office.',NULL,0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1795334315,1795334315,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1795336957,0,0,0,NULL,'News images','1:/user_upload/news/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1795332992,1,'BE',1,0,2,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"Sidebar probe\",\"bodytext\":\"<p>Rendered from the area sidebar.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795332992,\"t3ver_stage\":0,\"tstamp\":1795332992,\"uid\":2}',0,'0400$Ab_ebDixmlobc09ZW_wpQOm13MVZdCpf:01dbc21fdb1263685b9147b3b1596ea8'),
(2,1795332999,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":null},\"newRecord\":{\"backend_layout\":\"pagets__Default\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$xqYtF2Yzjz8vs6EvJQvzLj3QUpVEEGdA:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1795333001,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Default\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\"}}',0,'0400$dxU1W8i-7n0ls8Dxve2BCaS2_U6etDoY:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1795333004,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Home\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"}}',0,'0400$12o7r9be8NdlTq7M72UstYxByrD_Sh_g:e175f7045d7ccbfb26ffcf279422c2e5'),
(5,1795333006,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\"}}',0,'0400$s0fUPA88SDA-I6r3a2F12T6-HMxysVUK:e175f7045d7ccbfb26ffcf279422c2e5'),
(6,1795333009,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarRight\"},\"newRecord\":{\"backend_layout\":\"pagets__Narrow\"}}',0,'0400$rWk3qQFI-05fLi5WkRdZtrLMsXXEvAU3:e175f7045d7ccbfb26ffcf279422c2e5'),
(7,1795333011,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Narrow\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$Xfdponrx3mLaIVs0SAIfgknY-Uy1U1cn:e175f7045d7ccbfb26ffcf279422c2e5'),
(8,1795333022,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":2}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:f11830df10b4b0bca2db34810c2241b3'),
(9,1795333022,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"backend_layout\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":3}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(10,1795333022,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":4}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:412add0b3eb6ec8f1cb6710aea92e21e'),
(11,1795333042,4,'BE',1,0,2,'tt_content',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:01dbc21fdb1263685b9147b3b1596ea8'),
(12,1795333042,4,'BE',1,0,4,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:412add0b3eb6ec8f1cb6710aea92e21e'),
(13,1795333042,4,'BE',1,0,3,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(14,1795333042,4,'BE',1,0,2,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:f11830df10b4b0bca2db34810c2241b3'),
(15,1795334294,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"backend_layout\":\"pagets__SidebarLeft\",\"backend_layout_next_level\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":5}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7ef5a4e3e11db8ac3fea4d7a75468161'),
(16,1795334294,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":6}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c75354c439a48dbde16b03ac553a080d'),
(17,1795334294,1,'BE',1,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":7}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:df50bb24cbce671cf0d61f42fbbef601'),
(18,1795334294,1,'BE',1,0,8,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/parking-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Parking fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":8}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:595375f2fb9f014e091eb08fbc51ec88'),
(19,1795334294,1,'BE',1,0,9,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/market-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Market fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":9}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(20,1795334294,1,'BE',1,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/waiver-of-interest\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Waiver of interest\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":10}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e904af5a60392ab3165f5849f5877e45'),
(21,1795334294,1,'BE',1,0,11,'pages','{\"doktype\":\"1\",\"slug\":\"\\/health\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":11}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:51bca2bcf14079cc366c99de31802400'),
(22,1795334294,1,'BE',1,0,12,'pages','{\"doktype\":\"1\",\"slug\":\"\\/environment-water\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Environment & water\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":12}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:d6f57183d4ec29f4a568a174f36b861b'),
(23,1795334294,1,'BE',1,0,13,'pages','{\"doktype\":\"1\",\"slug\":\"\\/trade-tourism\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Trade & tourism\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":13}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:8a89606121863fe3a2ec2ea63ba83d69'),
(24,1795334294,1,'BE',1,0,14,'pages','{\"doktype\":\"1\",\"slug\":\"\\/public-participation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":14}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aaa274fb7a5f76c9749f1b2c8fba84a4'),
(25,1795334294,1,'BE',1,0,15,'pages','{\"doktype\":\"1\",\"slug\":\"\\/contact\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1536,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":15}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c97934f122918253f51c81fbe45fd105'),
(26,1795334294,1,'BE',1,0,16,'pages','{\"doktype\":\"1\",\"slug\":\"\\/search\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1792,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Search\",\"nav_hide\":1,\"backend_layout\":\"pagets__SidebarRight\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":16}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:878fab4218e507eb25dda6ac21dd7ff1'),
(27,1795334294,1,'BE',1,0,17,'pages','{\"doktype\":\"1\",\"slug\":\"\\/e-services-portal\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2048,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":17}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:dd30e16e220c1cff5911b320aa60dbce'),
(28,1795334294,1,'BE',1,0,18,'pages','{\"doktype\":\"1\",\"slug\":\"\\/accessibility-statement\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2304,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":18}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:9e9e8c5ba4be654320a3cd25d73d01a4'),
(29,1795334294,1,'BE',1,0,19,'pages','{\"doktype\":\"1\",\"slug\":\"\\/privacy-policy\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2560,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":19}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:25dbd94d40a6ff54757b6e36bf898997'),
(30,1795334294,1,'BE',1,0,20,'pages','{\"doktype\":\"1\",\"slug\":\"\\/access-to-information\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2816,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":20}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:1d0206225cc3f30f7ba150ff3aae8ab7'),
(31,1795334294,1,'BE',1,0,21,'pages','{\"doktype\":\"1\",\"slug\":\"\\/tenders\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3072,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":21}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:bb4ab293ec9d3ccfe43678d078f6cea0'),
(32,1795334294,1,'BE',1,0,22,'pages','{\"doktype\":\"254\",\"slug\":\"\\/service-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3328,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Service navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":22}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e5087395befe41329009e7b123017494'),
(33,1795334294,1,'BE',1,0,23,'pages','{\"doktype\":\"254\",\"slug\":\"\\/footer-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3584,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Footer navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":23}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7e88f7aa7664c6f494370160b60358a1'),
(34,1795334294,1,'BE',1,0,24,'pages','{\"doktype\":\"4\",\"slug\":\"\\/e-services-portal-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":24}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:219ad4d34a3e23c6ccf2ca87da6bc52b'),
(35,1795334294,1,'BE',1,0,25,'pages','{\"doktype\":\"4\",\"slug\":\"\\/contact-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":25}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:464961a1483e7dda27d23c882ff696bb'),
(36,1795334294,1,'BE',1,0,26,'pages','{\"doktype\":\"4\",\"slug\":\"\\/accessibility-statement-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":26}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:544939248209022b223d317bc97b7099'),
(37,1795334294,1,'BE',1,0,27,'pages','{\"doktype\":\"4\",\"slug\":\"\\/privacy-policy-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":27}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:97019c60b3ac7f8b98007c072afa2f0f'),
(38,1795334294,1,'BE',1,0,28,'pages','{\"doktype\":\"4\",\"slug\":\"\\/access-to-information-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":28}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aa68f552fa168869c47f8dbefb43cba0'),
(39,1795334294,1,'BE',1,0,29,'pages','{\"doktype\":\"4\",\"slug\":\"\\/tenders-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":29}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:2d7ab27da714dae3c89a6e0cb79b80cd'),
(40,1795334294,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\"}\"}}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e175f7045d7ccbfb26ffcf279422c2e5'),
(41,1795334294,4,'BE',1,0,1,'tt_content',NULL,0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7fa2c035f26826fe83eeecaaeddc4d40'),
(42,1795336956,1,'BE',1,0,30,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3200,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":30}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:e3e225390eee037c1380949b378763b1'),
(43,1795336956,1,'BE',1,0,31,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\\/article\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":30,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Article\",\"nav_hide\":1,\"backend_layout\":\"pagets__Article\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":31}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:9cb7b2b3fac90492135e3538aed4605a'),
(44,1795336956,1,'BE',1,0,32,'pages','{\"doktype\":\"254\",\"slug\":\"\\/news-records\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3840,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News records\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":32}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:302984e7412d7a45766e1d6304831138'),
(45,1795336956,1,'BE',1,0,1,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"trade-markets\",\"pid\":32,\"sorting\":256,\"title\":\"Trade & markets\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c6c8e24453121a7d668fe4b1031ebf88'),
(46,1795336956,1,'BE',1,0,2,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"roads-transport\",\"pid\":32,\"sorting\":512,\"title\":\"Roads & transport\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:497028e4af2a2cda8419e90cde34f71b'),
(47,1795336956,1,'BE',1,0,3,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"health\",\"pid\":32,\"sorting\":768,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:265912e2a2dda6b4b6be4e7069754d09'),
(48,1795336956,1,'BE',1,0,4,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"revenue-payments\",\"pid\":32,\"sorting\":1024,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:a832991055f9726888b6b83414d05630'),
(49,1795336956,1,'BE',1,0,5,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"public-participation\",\"pid\":32,\"sorting\":1280,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:55bc761d39a2d7a8b56679774f51dfe6'),
(50,1795336956,1,'BE',1,0,6,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"environment\",\"pid\":32,\"sorting\":1536,\"title\":\"Environment\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:0580043665451ed803b9e5d021b149fe'),
(51,1795336956,1,'BE',1,0,7,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"water\",\"pid\":32,\"sorting\":1792,\"title\":\"Water\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:e6068a768abec7500a6d253c29088f52'),
(52,1795336956,1,'BE',1,0,8,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"education\",\"pid\":32,\"sorting\":2048,\"title\":\"Education\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":8}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f564fff7cae82b30644518a57bd7a8a6'),
(53,1795336956,1,'BE',1,0,1,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-fish-market-opens-at-the-jetty\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New fish market opens at the jetty\",\"datetime\":1793595600,\"teaser\":\"Sixty stalls, cold storage and clean water for traders and buyers.\",\"bodytext\":\"<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night\\u2019s catch and running water at every stall.<\\/p>\\r\\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Trade &amp; Markets Office, +254 700 000 010<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:fccd16ea3664ec003726b2a72ea38f4b'),
(54,1795336956,1,'BE',1,0,2,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"beach-road-resurfacing-starts\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Beach Road resurfacing starts\",\"datetime\":1793077200,\"teaser\":\"Works run for six weeks. Matatus take the diversion via Market Street.\",\"bodytext\":\"<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.<\\/p>\\r\\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Roads Department, +254 700 000 020<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:640f28e5c1a5ec2efb19c26699b464a5'),
(55,1795336956,1,'BE',1,0,3,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"free-health-camp-in-ward-3\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Free health camp in Ward 3\",\"datetime\":1792472400,\"teaser\":\"Eye tests, vaccinations and screening, open to every resident.\",\"bodytext\":\"<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.<\\/p>\\r\\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Health Department, +254 700 000 030<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:1152fda277b2623b0152b5765fcb6b28'),
(56,1795336956,1,'BE',1,0,4,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"pay-land-rates-by-mobile-money-from-january\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Pay land rates by mobile money from January\",\"datetime\":1791781200,\"teaser\":\"Residents can now pay land rates and business permits with their phone.\",\"bodytext\":\"<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.<\\/p>\\r\\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Revenue Department, +254 700 000 040<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f3f39c24ca39d00c02ecd29ec2ad4225'),
(57,1795336956,1,'BE',1,0,5,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"have-your-say-on-the-budget-2027-28\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Have your say on the budget 2027\\/28\",\"datetime\":1790830800,\"teaser\":\"Public participation forums in every ward in November.\",\"bodytext\":\"<p>The municipality prepares its budget for 2027\\/28 and asks residents what matters most to them: roads, water, markets, health or schools.<\\/p>\\r\\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Planning Office, +254 700 000 050<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:bc83755a03cca2ca5c8daa03e9d6e32e'),
(58,1795336956,1,'BE',1,0,6,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"mto-safi-named-cleanest-town-on-the-coast\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Mto Safi named cleanest town on the coast\",\"datetime\":1789707600,\"teaser\":\"The monthly beach clean-ups and the new waste collection paid off.\",\"bodytext\":\"<p>Mto Safi has won this year\\u2019s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.<\\/p>\\r\\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Environment Department, +254 700 000 060<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:7e4fc5d3ec5edd1f76b0a3820eb3fb47'),
(59,1795336956,1,'BE',1,0,7,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-boreholes-bring-clean-water-to-ward-5\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New boreholes bring clean water to Ward 5\",\"datetime\":1788584400,\"teaser\":\"Three boreholes and twelve water kiosks serve 4,000 residents.\",\"bodytext\":\"<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.<\\/p>\\r\\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Water &amp; Sanitation Department, +254 700 000 070<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:31860b4bf14b13d2dc895987af663784'),
(60,1795336956,1,'BE',1,0,3,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"News\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">home<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:b92300cfb5d1d3645c9cb212a7f56c1f'),
(61,1795336956,1,'BE',1,0,4,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":30,\"sorting\":256,\"header\":\"All news\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:4d391f5ef79b8d5d10dffa8a07ca167d'),
(62,1795336956,1,'BE',1,0,5,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":31,\"sorting\":256,\"header\":\"News article\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c7626fc9bcba6f70beb6ebc085a400db'),
(63,1795343750,1,'BE',1,0,6,'tt_content','{\"CType\":\"mtosafi_tiles\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":128,\"header\":\"Popular services\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c0db6803ab1ec5f70c36e2a72187867b'),
(64,1795343750,1,'BE',1,0,1,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"icon\":\"\\ud83c\\udfea\",\"label\":\"Single business permit\",\"link\":\"t3:\\/\\/page?uid=7\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":1}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:55820ddffac9b29987f66a48c05c3e01'),
(65,1795343750,1,'BE',1,0,2,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"icon\":\"\\ud83c\\udfe1\",\"label\":\"Land rates\",\"link\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":2}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:b6549a503cf1dd498f3571f7d5d85d54'),
(66,1795343750,1,'BE',1,0,3,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"icon\":\"\\ud83c\\udd7f\\ufe0f\",\"label\":\"Parking fees\",\"link\":\"t3:\\/\\/page?uid=8\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":3}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:518760b21a46e7982878ebf568972b86'),
(67,1795343750,1,'BE',1,0,4,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":32,\"icon\":\"\\ud83d\\udca7\",\"label\":\"Water connection\",\"link\":\"t3:\\/\\/page?uid=12\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":4}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:ba2135e3eae99237605541429e1c8913'),
(68,1795343750,1,'BE',1,0,5,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":16,\"icon\":\"\\ud83e\\uddfa\",\"label\":\"Market stalls\",\"link\":\"t3:\\/\\/page?uid=9\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":5}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c65d007d6e8748b9615f1c9e01a28b86'),
(69,1795343750,1,'BE',1,0,6,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":8,\"icon\":\"\\ud83d\\udce3\",\"label\":\"Report a problem\",\"link\":\"t3:\\/\\/page?uid=15\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:632dfe70d9c02f2a21151ad96efaec1c'),
(70,1795344511,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:4cf496f597e7b095ce8b755e6cec3c0c'),
(71,1795344511,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"3\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:814fc0f720dfab882655a795e23a5b66'),
(72,1795344511,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"4\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:d2c609347a4764200256b39b9425159a'),
(73,1795344511,1,'BE',1,0,7,'tt_content','{\"CType\":\"mtosafi_slider\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":64,\"header\":\"Highlights\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":7}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:ea41b626baac59a1fe0716bc344af5d9'),
(74,1795344511,1,'BE',1,0,1,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"title\":\"Karibu Mto Safi\",\"text\":\"White beaches, a clean river and a municipality that serves you online, day and night.\",\"link\":\"t3:\\/\\/page?uid=13\",\"link_label\":\"Discover Mto Safi\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:1ffe01378bcddf3cd4b7ccc25f2930f6'),
(75,1795344511,1,'BE',1,0,2,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"title\":\"Pay your land rates by mobile money\",\"text\":\"Calculate what you owe and pay before 31 March to avoid interest.\",\"link\":\"t3:\\/\\/page?uid=6\",\"link_label\":\"Calculate land rates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:de55124b95b3be65ab1a5218e23dea0d'),
(76,1795344511,1,'BE',1,0,3,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"title\":\"Have your say on the budget\",\"text\":\"Join the public participation forums in every ward this month.\",\"link\":\"t3:\\/\\/page?uid=14\",\"link_label\":\"See the forum dates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:e8603ac799ba0c457941e1d26db41cb8'),
(77,1795345582,1,'BE',1,0,33,'pages','{\"doktype\":\"1\",\"slug\":\"\\/page-not-found\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3136,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Page not found\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"no_index\":1,\"no_follow\":1,\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":33}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:0c3ed5b51e5eff03577c1c2f671f9fbe'),
(78,1795345582,1,'BE',1,0,8,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":33,\"sorting\":256,\"header\":\"This page does not exist\",\"bodytext\":\"<p>The page you are looking for may have moved, or the address may be mistyped.<\\/p>\\r\\n<ul><li><a href=\\\"t3:\\/\\/page?uid=1\\\">Go to the home page<\\/a><\\/li><li><a href=\\\"t3:\\/\\/page?uid=16\\\">Search the site<\\/a><\\/li><\\/ul>\",\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":8}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:2097d84972a039cb6bfe093b17089287'),
(79,1795348009,1,'BE',1,0,34,'pages','{\"doktype\":\"254\",\"slug\":\"\\/search-index\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":4096,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Search index\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":34}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:152f249a1550628c00eb2837d4cfde70'),
(80,1795348009,2,'BE',1,0,16,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:878fab4218e507eb25dda6ac21dd7ff1'),
(81,1795348009,2,'BE',1,0,33,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:0c3ed5b51e5eff03577c1c2f671f9fbe'),
(82,1795348009,2,'BE',1,0,31,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:9cb7b2b3fac90492135e3538aed4605a'),
(83,1795348009,1,'BE',1,0,1,'tx_kesearch_filteroptions','{\"l10n_parent\":0,\"slug\":\"services\",\"hidden\":0,\"pid\":34,\"sorting\":256,\"title\":\"Services\",\"tag\":\"service\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"tag\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:5959a4f398aeb048aebac4b34bca8539'),
(84,1795348009,1,'BE',1,0,2,'tx_kesearch_filteroptions','{\"l10n_parent\":0,\"slug\":\"news\",\"hidden\":0,\"pid\":34,\"sorting\":512,\"title\":\"News\",\"tag\":\"news\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"tag\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":2}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:90ae5ff47c0a84f43bdf13d71c840463'),
(85,1795348009,1,'BE',1,0,1,'tx_kesearch_filters','{\"rendertype\":\"checkbox\",\"markAllCheckboxes\":\"0\",\"target_pid\":0,\"amount\":10,\"shownumberofresults\":\"1\",\"alphabeticalsorting\":0,\"hidden\":0,\"pid\":34,\"title\":\"Show only\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"alphabeticalsorting\\\":\\\"\\\",\\\"amount\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"markAllCheckboxes\\\":\\\"\\\",\\\"options\\\":\\\"\\\",\\\"rendertype\\\":\\\"\\\",\\\"shownumberofresults\\\":\\\"\\\",\\\"target_pid\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:37c8f0a5f51b180b553539a4ba22f33e'),
(86,1795348009,1,'BE',1,0,1,'tx_kesearch_indexerconfig','{\"type\":\"page\",\"index_content_with_restrictions\":\"no\",\"index_news_category_mode\":\"1\",\"index_use_page_tags\":\"0\",\"fileext\":\"pdf,ppt,doc,xls,docx,xlsx,pptx\",\"file_reference_fields\":\"media\",\"index_use_page_tags_for_files\":\"0\",\"index_page_doctypes\":\"1\",\"content_fields\":\"bodytext,subheader,header_link\",\"page_fields\":\"\",\"page_fields_hidden\":\"\",\"fal_storage\":\"0\",\"contenttypes\":\"text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline\",\"additional_tables\":\"[accordion]\\ntable = tx_bootstrappackage_accordion_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[tab]\\ntable = tx_bootstrappackage_tab_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[carousel]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_fullscreen]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_small]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[icon_group]\\ntable = tx_bootstrappackage_icon_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\n\\n[card_group]\\ntable = tx_bootstrappackage_card_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\nfields[] = link_title\\n\\n[timeline]\\ntable = tx_bootstrappackage_timeline_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\",\"hidden\":0,\"pid\":34,\"title\":\"Pages\",\"storagepid\":\"34\",\"startingpoints_recursive\":\"1\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:11382f33999b3ba5cfa81546397116be'),
(87,1795348009,1,'BE',1,0,2,'tx_kesearch_indexerconfig','{\"type\":\"news\",\"index_content_with_restrictions\":\"no\",\"index_news_category_mode\":\"1\",\"index_use_page_tags\":\"0\",\"fileext\":\"pdf,ppt,doc,xls,docx,xlsx,pptx\",\"file_reference_fields\":\"media\",\"index_use_page_tags_for_files\":\"0\",\"index_page_doctypes\":\"1\",\"content_fields\":\"bodytext,subheader,header_link\",\"page_fields\":\"\",\"page_fields_hidden\":\"\",\"fal_storage\":\"0\",\"contenttypes\":\"text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline\",\"additional_tables\":\"[accordion]\\ntable = tx_bootstrappackage_accordion_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[tab]\\ntable = tx_bootstrappackage_tab_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[carousel]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_fullscreen]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_small]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[icon_group]\\ntable = tx_bootstrappackage_icon_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\n\\n[card_group]\\ntable = tx_bootstrappackage_card_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\nfields[] = link_title\\n\\n[timeline]\\ntable = tx_bootstrappackage_timeline_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\",\"hidden\":0,\"pid\":34,\"title\":\"News\",\"storagepid\":\"34\",\"targetpid\":\"31\",\"startingpoints_recursive\":\"32\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":2}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:e9c59d805adb65b75c5f9ae69a7ee95b'),
(88,1795348009,1,'BE',1,0,9,'tt_content','{\"CType\":\"ke_search_pi1\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":16,\"sorting\":256,\"header\":\"Filter results\",\"pages\":\"34\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"MAIN\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"resultPage\\\">\\n                    <value index=\\\"vDEF\\\">16<\\/value>\\n                <\\/field>\\n                <field index=\\\"showTextInsteadOfResults\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"textForResults\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Type what you are looking for into the search field at the top of the page.&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"showNoResultsText\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"view\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"highlightSword\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultChars\\\">\\n                    <value index=\\\"vDEF\\\">200<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultsNumeration\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showResultUrl\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showDate\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"images\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"showTypeIcon\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showPageImages\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showNewsImages\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showFilePreview\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"pagebrowser\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"pagebrowserOnTop\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"pagebrowserAtBottom\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultsPerPage\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"maxPagesInPagebrowser\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"filter\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"filters\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":9}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:367f4f227870d8e2a11496a182574aa3'),
(89,1795348009,1,'BE',1,0,10,'tt_content','{\"CType\":\"ke_search_pi2\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":16,\"sorting\":128,\"header\":\"Search results\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"MAIN\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"loadFlexformsFromOtherCE\\\">\\n                    <value index=\\\"vDEF\\\">9<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":10}',0,'0400$vpXrqLCAGuB2w85UkB4ezd96Nu_zS1x9:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(90,1795368020,1,'BE',1,0,4,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Pay by mobile money: the receipt arrives on your phone.\",\"alternative\":\"A mobile phone confirming a payment, beside a stack of coins\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":5,\"uid_local\":\"11\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":4}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:cea5fcd7b97871880cfe3717d6b52ef4'),
(91,1795368020,1,'BE',1,0,5,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Every plot in the valuation roll has a rateable value.\",\"alternative\":\"Two houses on surveyed plots on a green hillside\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":6,\"uid_local\":\"12\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":5}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5f15a1453f67b933ed3314381f5d67e4'),
(92,1795368020,1,'BE',1,0,6,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"One permit a year covers trade, health and fire safety.\",\"alternative\":\"A shop with a striped awning and a framed business permit\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":7,\"uid_local\":\"13\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":6}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:768f9cd4e98812f969df7ebe17f11b50'),
(93,1795368020,1,'BE',1,0,7,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Parking on Beach Road is paid Monday to Saturday, 7:00 to 18:00.\",\"alternative\":\"Two cars parked beside a parking sign\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":8,\"uid_local\":\"14\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":7}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:117c97010b9af15cb554d115dba4e316'),
(94,1795368020,1,'BE',1,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Stalls at the central market on Market Street.\",\"alternative\":\"Two market stalls with fruit and vegetables\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":9,\"uid_local\":\"15\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":8}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(95,1795368020,1,'BE',1,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Clear your arrears before 30 June to have the interest waived.\",\"alternative\":\"A calendar with a ticked check mark beside it\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":10,\"uid_local\":\"16\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":9}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:729356755eb8ee035abf6b9b02e20c8f'),
(96,1795368020,1,'BE',1,0,10,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Mto Safi Town health centre, open Monday to Saturday.\",\"alternative\":\"A health centre with a red cross sign\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":11,\"uid_local\":\"17\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":10}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b34a074e38840d41041eaee66c42bb0d'),
(97,1795368020,1,'BE',1,0,11,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The river gives the town its name: Mto Safi means \\\"clean river\\\".\",\"alternative\":\"A river running through green land, with a water tower and a tap\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":12,\"uid_local\":\"18\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":11}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b70904b959c6d327947fc437df028f6f'),
(98,1795368020,1,'BE',1,0,12,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"A dhow leaves the old harbour at sunset.\",\"alternative\":\"A dhow sailing at sunset with a palm tree on the beach\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":12}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:fef2cecc4ff45c64d73fc27195ee5748'),
(99,1795368020,1,'BE',1,0,13,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Sunset over the old dhow harbour.\",\"alternative\":\"A dhow sailing at sunset with a palm tree on the beach\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":13}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5e1f4fea56ad8d21a419f2b59b059abf'),
(100,1795368020,1,'BE',1,0,14,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Mangoes, tomatoes and sukuma wiki at the central market.\",\"alternative\":\"Two market stalls with fruit and vegetables\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"15\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":14}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:2207c2b650522ebf0efd90eaad3962af'),
(101,1795368020,1,'BE',1,0,15,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The river mouth, where the mangrove boardwalk starts.\",\"alternative\":\"A river running through green land, with a water tower and a tap\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"18\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":15}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:53cbb769126fb106e07a09de5e196b60'),
(102,1795368020,1,'BE',1,0,16,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The municipal office, built in 1962, on Beach Road.\",\"alternative\":\"The municipal office with a flag on the roof\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":16}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5a9ade48273ee95d803333aed1c78820'),
(103,1795368020,1,'BE',1,0,17,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Budget forum in the municipal hall, Central ward.\",\"alternative\":\"Residents gathered in front of a board at a public forum\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":14,\"uid_local\":\"21\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":17}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:78ba90db28917b77e8d54ca398316d0e'),
(104,1795368020,1,'BE',1,0,18,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The municipal office on Beach Road.\",\"alternative\":\"The municipal office with a flag on the roof\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":15,\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":18}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:c9d27ac33ea45c5163a9ef7a25d8e7c7'),
(105,1795368020,1,'BE',1,0,19,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Log in with your eCitizen account.\",\"alternative\":\"A laptop showing a login form, beside a padlock\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":17,\"uid_local\":\"22\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":19}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7008e0248119dc3a255a0170bf6e9370'),
(106,1795368020,1,'BE',1,0,20,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Example image: replace it together with the text.\",\"alternative\":\"A web page with clear headings and a focused button, beside the accessibility symbol\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":18,\"uid_local\":\"23\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":20}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:97d0d1c7a42cd9603b2010379c1e4e4d'),
(107,1795368020,1,'BE',1,0,21,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Example image: replace it together with the text.\",\"alternative\":\"A shield with a padlock\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":19,\"uid_local\":\"24\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":21}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:bd8e6a36b477d61e04d92cfd10d00f96'),
(108,1795368020,1,'BE',1,0,22,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Requests are answered within 21 days.\",\"alternative\":\"A folder of documents and a magnifying glass\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":20,\"uid_local\":\"25\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":22}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:d6a5725e5b31cdd97b9c53c992e81850'),
(109,1795368020,1,'BE',1,0,23,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Bids go in a sealed envelope to the procurement office.\",\"alternative\":\"A building under construction with a crane, and a sealed envelope\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":21,\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":23}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a4b81cbb471961a3c12b21861b94f4e1'),
(110,1795368020,1,'BE',1,0,11,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":256,\"header\":\"Pay the municipality from wherever you are\",\"bodytext\":\"<p>Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.<\\/p>\\r\\n<p>Most of them can be paid by mobile money or by card in the <a href=\\\"t3:\\/\\/page?uid=17\\\">e-services portal<\\/a>, at any time of day. The cash office in the municipal office is open on working days.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":11}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7a14c618500ae24604910dfdd2f8ff12'),
(111,1795368020,1,'BE',1,0,12,'tt_content','{\"CType\":\"menu_subpages\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":512,\"header\":\"Payments and fees\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":12}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b13bbccfb8e2fc277be02db62485ced6'),
(112,1795368020,1,'BE',1,0,13,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":256,\"header\":\"How your land rates are calculated\",\"bodytext\":\"<p>Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.<\\/p>\\r\\n<p>Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":13}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:aa58d78b4f5fe95c0d2d1cb36d041737'),
(113,1795368020,1,'BE',1,0,14,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":512,\"header\":\"Rates for 2026\",\"bodytext\":\"Land use|Rate|Minimum per plot and year\\nResidential|0.5 % of the rateable value|KES 1,500\\nCommercial|1.2 % of the rateable value|KES 1,500\\nAgricultural|0.2 % of the rateable value|KES 1,500\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":14}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:338e104baa774eacaec42da729015b5f'),
(114,1795368020,1,'BE',1,0,15,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":768,\"header\":\"How to pay\",\"bodytext\":\"<p>Pay by mobile money, by card in the <a href=\\\"t3:\\/\\/page?uid=17\\\">e-services portal<\\/a>, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":15}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:cb118fde3da18e67b21a92b60bb8cbda'),
(115,1795368020,1,'BE',1,0,16,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":256,\"header\":\"One permit for your business\",\"bodytext\":\"<p>Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.<\\/p>\\r\\n<p>Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":16}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:43f02d513e41a72738b96558f7ee9015'),
(116,1795368020,1,'BE',1,0,17,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":512,\"header\":\"What you need to apply\",\"bodytext\":\"Your national ID or passport\\nThe KRA PIN of the business\\nThe plot number of the premises\\nA description of the activity and the number of employees\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":17}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:017157395cc6da9e5d2911de6dfd4b9e'),
(117,1795368020,1,'BE',1,0,18,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"26\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":8,\"sorting\":256,\"header\":\"Parking in the town centre\",\"bodytext\":\"<p>Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.<\\/p>\\r\\n<p>Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":18}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0a64be1ae1f9096cc345beb76e5e2095'),
(118,1795368020,1,'BE',1,0,19,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":8,\"sorting\":512,\"header\":\"Fees\",\"bodytext\":\"Vehicle|Per day|Per month\\nCar|KES 100|KES 2,000\\nPick-up and van|KES 150|KES 3,000\\nLorry|KES 300|KES 6,000\\nMotorcycle (boda boda)|KES 30|KES 500\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":19}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(119,1795368020,1,'BE',1,0,20,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":9,\"sorting\":256,\"header\":\"Selling at the municipal markets\",\"bodytext\":\"<p>Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.<\\/p>\\r\\n<p>Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":20}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(120,1795368020,1,'BE',1,0,21,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":9,\"sorting\":512,\"header\":\"Fees\",\"bodytext\":\"|Fee\\nStall, per month|KES 1,200\\nOpen space, per day|KES 50\\nFish market, per day|KES 80\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":21}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7fd72e21409e45562c51e7581fc2cb0d'),
(121,1795368020,1,'BE',1,0,22,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"26\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":256,\"header\":\"Interest waived when you clear your arrears\",\"bodytext\":\"<p>Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.<\\/p>\\r\\n<p>Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":22}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:1a929832156241f61c37ce68bcae4a3c'),
(122,1795368020,1,'BE',1,0,23,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":512,\"header\":\"How it works\",\"bodytext\":\"Ask for a statement of your arrears\\nApply for the waiver with the statement\\nPay the arrears without the interest within 30 days of the approval\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":23}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0cf00ee1adffc41f8b3231c0de35256e'),
(123,1795368020,1,'BE',1,0,24,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":11,\"sorting\":256,\"header\":\"Health services close to home\",\"bodytext\":\"<p>The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.<\\/p>\\r\\n<p>For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":24}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:94bb7a1dbcc4ac71f45ee11546313fe2'),
(124,1795368020,1,'BE',1,0,25,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":11,\"sorting\":512,\"header\":\"Health centres\",\"bodytext\":\"Health centre|Ward|Opening hours\\nMto Safi Town|Central|Mon\\u2013Sat 7:00\\u201319:00\\nPwani|Beach|Mon\\u2013Fri 8:00\\u201317:00\\nKijiji|Upper River|Mon\\u2013Fri 8:00\\u201317:00\\nMnarani|Mnarani|Mon\\u2013Fri 8:00\\u201317:00\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":25}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:581bf77acde559fe457e0d401d2ada7b'),
(125,1795368020,1,'BE',1,0,26,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":256,\"header\":\"A clean river for everyone\",\"bodytext\":\"<p>Mto Safi means \\\"clean river\\\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":26}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f6bb218c440a87df0e0eb5986e28af41'),
(126,1795368020,1,'BE',1,0,27,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":512,\"header\":\"Water connection\",\"bodytext\":\"<p>To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.<\\/p>\\r\\n<p>To report a leak or a burst pipe, call +254 700 000 001 at any time.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":27}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:9c3671c42eb2c0522de6952ddc52c9a7'),
(127,1795368020,1,'BE',1,0,28,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":768,\"header\":\"Waste collection\",\"bodytext\":\"Town centre: Monday and Thursday\\nBeach and Mnarani: Tuesday and Friday\\nUpper River: Wednesday and Saturday\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":28}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b5d015227f2b36f7786e2ff963ca9d51'),
(128,1795368020,1,'BE',1,0,29,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":256,\"header\":\"Karibu Mto Safi\",\"bodytext\":\"<p>White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.<\\/p>\\r\\n<p>The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under <a href=\\\"t3:\\/\\/page?uid=7\\\">Single business permit<\\/a>.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":29}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:12090f8e2b698e14ec860eca10ce232c'),
(129,1795368020,1,'BE',1,0,30,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":512,\"header\":\"Places to visit\",\"bodytext\":\"The dhow harbour and the fish market at sunrise\\nThe mangrove boardwalk at the river mouth\\nMto Safi beach and the coral garden\\nThe old town with its carved doors\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":30}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f6d670f6f6a9a0aecc0bb542c370acdf'),
(130,1795368020,1,'BE',1,0,31,'tt_content','{\"CType\":\"image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":768,\"header\":\"Impressions of Mto Safi\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":31}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a338b89fc8d0d789df4b1fd4d37a174b'),
(131,1795368020,1,'BE',1,0,32,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":14,\"sorting\":256,\"header\":\"Have your say on the budget\",\"bodytext\":\"<p>Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.<\\/p>\\r\\n<p>You can also send your views in writing to the clerk until 15 May.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":32}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:eeb3ef2adec88a8b5b3e3c510b74be1d'),
(132,1795368020,1,'BE',1,0,33,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":14,\"sorting\":512,\"header\":\"Forum dates\",\"bodytext\":\"Ward|Date|Place\\nCentral|4 May, 10:00|Municipal hall\\nBeach|6 May, 10:00|Pwani primary school\\nUpper River|8 May, 14:00|Kijiji social hall\\nMnarani|11 May, 10:00|Mnarani chief\'s camp\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":33}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:c1c3d2254ecfaef40b15a18e94a89b96'),
(133,1795368020,1,'BE',1,0,34,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":256,\"header\":\"Visit us\",\"bodytext\":\"<p>Mto Safi Municipality<br \\/>Municipal Office<br \\/>Beach Road 1<br \\/>P.O. Box 123, Mto Safi<\\/p>\\r\\n<p>Phone: <a href=\\\"tel:+254700000000\\\">+254 700 000 000<\\/a><br \\/>Email: <a href=\\\"mailto:info@mtosafi.example\\\">info@mtosafi.example<\\/a><\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":34}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5d9f35f4f50ff546dc3085666d071b48'),
(134,1795368020,1,'BE',1,0,35,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":512,\"header\":\"Opening hours\",\"bodytext\":\"Days|Hours\\nMon\\u2013Thu|8:00\\u201317:00\\nFriday|8:00\\u201313:00, 14:00\\u201317:00\\nSat, Sun|Closed\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":35}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:d31fbabb978b029b9ff62ab107e0a25e'),
(135,1795368020,1,'BE',1,0,36,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":768,\"header\":\"Report a problem\",\"bodytext\":\"<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\\\"mailto:report@mtosafi.example\\\">report@mtosafi.example<\\/a>, and say where it is.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":36}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:6fdd460ee24b22c6f60683a1eee4989a'),
(136,1795368020,1,'BE',1,0,37,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":17,\"sorting\":256,\"header\":\"Your municipal services online\",\"bodytext\":\"<p>In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.<\\/p>\\r\\n<p>Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":37}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:63988be2047e9f9c26151c5b9b4770d7'),
(137,1795368020,1,'BE',1,0,38,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":18,\"sorting\":256,\"header\":\"Example text\",\"bodytext\":\"<p>This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.<\\/p>\\r\\n<p>The design of this site targets WCAG 2.1 level AA.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":38}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:4bdce2eccaa2dfa57eb92d16572012a4'),
(138,1795368020,1,'BE',1,0,39,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":19,\"sorting\":256,\"header\":\"Example text\",\"bodytext\":\"<p>This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":39}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:eb04e3ff75360f80fc27ed5d3e94f482'),
(139,1795368020,1,'BE',1,0,40,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":20,\"sorting\":256,\"header\":\"Ask for the information we hold\",\"bodytext\":\"<p>Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.<\\/p>\\r\\n<p>We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":40}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f63ce2811b6be061690bfdf008a41f07'),
(140,1795368020,1,'BE',1,0,41,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":20,\"sorting\":512,\"header\":\"Published without a request\",\"bodytext\":\"The budget and the annual accounts\\nThe valuation roll\\nThe minutes of the municipal board\\nTenders and the contracts awarded\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":41}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0d86f780a4565c319d6988991b035f3a'),
(141,1795368020,1,'BE',1,0,42,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":21,\"sorting\":256,\"header\":\"Doing business with the municipality\",\"bodytext\":\"<p>The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":42}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5e996be55a352bc1f4f3f871c802dcec'),
(142,1795368020,1,'BE',1,0,43,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":21,\"sorting\":512,\"header\":\"Open tenders\",\"bodytext\":\"Number|Subject|Closes\\nMSM\\/T\\/01\\/2026|Resurfacing of Market Street|12 June\\nMSM\\/T\\/02\\/2026|Solar street lights, Beach ward|19 June\\nMSM\\/T\\/03\\/2026|Waste collection vehicles (2)|26 June\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":43}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:9390101edeadec5344c252f3b3b98ec9'),
(143,1795369027,2,'BE',1,0,15,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:c97934f122918253f51c81fbe45fd105'),
(144,1795369027,1,'BE',1,0,44,'tt_content','{\"CType\":\"form_formframework\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":128,\"header\":\"Write to us\",\"subheader\":\"The right department answers within five working days.\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">EXT:mtosafi_sitepackage\\/Resources\\/Private\\/Forms\\/contact.form.yaml<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795369027,\"t3ver_stage\":0,\"tstamp\":1795369027,\"uid\":44}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:3b272544b7c1a9f5690a42a5b760dca9'),
(145,1795369027,2,'BE',1,0,34,'tt_content','{\"oldRecord\":{\"colPos\":0,\"imageorient\":25,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"imageorient\":\"0\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:5d9f35f4f50ff546dc3085666d071b48'),
(146,1795369027,2,'BE',1,0,35,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:d31fbabb978b029b9ff62ab107e0a25e'),
(147,1795369027,2,'BE',1,0,36,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:6fdd460ee24b22c6f60683a1eee4989a');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=232 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1795330974,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lina.wolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1795330980,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lwolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(3,1795332992,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(4,1795332999,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1795333001,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(6,1795333004,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"4\"}',0,0,'',0,'','info',NULL,NULL),
(7,1795333006,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"5\"}',0,0,'',0,'','info',NULL,NULL),
(8,1795333009,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"6\"}',0,0,'',0,'','info',NULL,NULL),
(9,1795333011,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"7\"}',0,0,'',0,'','info',NULL,NULL),
(10,1795333022,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(11,1795333022,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(12,1795333022,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(13,1795333042,1,3,2,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(14,1795333042,1,3,4,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":4}',2,0,'',0,'','info',NULL,NULL),
(15,1795333042,1,3,3,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":3}',2,0,'',0,'','info',NULL,NULL),
(16,1795333042,1,3,2,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":2}',1,0,'',0,'','info',NULL,NULL),
(17,1795334294,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1795334294,1,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":6,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(19,1795334294,1,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":7,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(20,1795334294,1,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":8,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(21,1795334294,1,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":9,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(22,1795334294,1,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":10,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(23,1795334294,1,1,11,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(24,1795334294,1,1,12,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(25,1795334294,1,1,13,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":13,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1795334294,1,1,14,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":14,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(27,1795334294,1,1,15,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":15,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(28,1795334294,1,1,16,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(29,1795334294,1,1,17,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":17,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(30,1795334294,1,1,18,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":18,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(31,1795334294,1,1,19,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":19,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(32,1795334294,1,1,20,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(33,1795334294,1,1,21,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(34,1795334294,1,1,22,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(35,1795334294,1,1,23,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(36,1795334294,1,1,24,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":24,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(37,1795334294,1,1,25,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":25,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(38,1795334294,1,1,26,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":26,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(39,1795334294,1,1,27,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":27,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(40,1795334294,1,1,28,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":28,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(41,1795334294,1,1,29,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":29,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(42,1795334294,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"40\"}',0,0,'',0,'','info',NULL,NULL),
(43,1795334294,1,2,24,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":24,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(44,1795334294,1,2,25,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":25,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(45,1795334294,1,2,26,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":26,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(46,1795334294,1,2,27,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":27,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(47,1795334294,1,2,28,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":28,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(48,1795334294,1,2,29,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":29,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(49,1795334294,1,3,1,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(51,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(52,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(53,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(54,1795336956,1,1,30,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":30,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(55,1795336956,1,1,31,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":31,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(56,1795336956,1,1,32,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":32,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(57,1795336956,1,1,1,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(58,1795336956,1,1,2,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(59,1795336956,1,1,3,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(60,1795336956,1,1,4,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(61,1795336956,1,1,5,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(62,1795336956,1,1,6,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(63,1795336956,1,1,7,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(64,1795336956,1,1,8,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":8,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(65,1795336956,1,1,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(66,1795336956,1,1,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(67,1795336956,1,1,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(68,1795336956,1,1,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(69,1795336956,1,1,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(70,1795336956,1,1,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(71,1795336956,1,1,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(72,1795336956,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(73,1795336956,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":4,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(74,1795336956,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":5,\"pid\":31}',31,0,'',0,'','info',NULL,NULL),
(75,1795336956,1,2,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(76,1795336956,1,2,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(77,1795336956,1,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(78,1795336956,1,2,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(79,1795336956,1,2,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(80,1795336956,1,2,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(81,1795336956,1,2,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(82,1795343750,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1795343750,1,1,1,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(84,1795343750,1,1,2,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(85,1795343750,1,1,3,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(86,1795343750,1,1,4,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(87,1795343750,1,1,5,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(88,1795343750,1,1,6,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(89,1795343750,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(90,1795344511,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(91,1795344511,1,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(92,1795344511,1,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(93,1795344511,1,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(94,1795344511,1,1,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(95,1795344511,1,1,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(96,1795344511,1,1,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(97,1795344511,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(98,1795344511,1,2,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(99,1795344511,1,2,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(100,1795344511,1,2,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(101,1795345582,1,1,33,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":33,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(102,1795345582,1,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":8,\"pid\":33}',33,0,'',0,'','info',NULL,NULL),
(103,1795348009,1,1,34,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":34,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(104,1795348009,1,2,16,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":16,\"history\":\"80\"}',1,0,'',0,'','info',NULL,NULL),
(105,1795348009,1,2,33,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":33,\"history\":\"81\"}',1,0,'',0,'','info',NULL,NULL),
(106,1795348009,1,2,31,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":31,\"history\":\"82\"}',30,0,'',0,'','info',NULL,NULL),
(107,1795348009,1,1,1,'tx_kesearch_filteroptions',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filteroptions\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(108,1795348009,1,1,2,'tx_kesearch_filteroptions',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filteroptions\",\"uid\":2,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(109,1795348009,1,1,1,'tx_kesearch_filters',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filters\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(110,1795348009,1,2,1,'tx_kesearch_filters',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_kesearch_filters\",\"uid\":1,\"history\":0}',34,0,'',0,'','info',NULL,NULL),
(111,1795348009,1,1,1,'tx_kesearch_indexerconfig',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_indexerconfig\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(112,1795348009,1,1,2,'tx_kesearch_indexerconfig',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_indexerconfig\",\"uid\":2,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(113,1795348009,1,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":9,\"pid\":16}',16,0,'',0,'','info',NULL,NULL),
(114,1795348009,1,1,10,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":10,\"pid\":16}',16,0,'',0,'','info',NULL,NULL),
(115,1795348011,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n31 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n0 pages have been indexed. \n\n30 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 87 ms\nNews\n7 News and 0 related files have been indexed.\n\n\nIndexing process took 20 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 1 ms.\n\nFinished\nIndexing finished at 11/22/26, 12:46:52 (took 1 seconds).\nIndex contains 7 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(116,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(117,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(118,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(119,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(120,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(121,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(122,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(123,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(124,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(125,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(126,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(127,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(128,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(129,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(130,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(131,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(132,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(133,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(134,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(135,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(136,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(137,1795348709,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(138,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(139,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(140,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(141,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(142,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(143,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(144,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(145,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(146,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(147,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(148,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(149,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(150,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(151,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(152,1795365530,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(153,1795365530,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(154,1795365714,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(155,1795368020,1,1,4,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(156,1795368020,1,1,5,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(157,1795368020,1,1,6,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(158,1795368020,1,1,7,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(159,1795368020,1,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(160,1795368020,1,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(161,1795368020,1,1,10,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":10,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(162,1795368020,1,1,11,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":11,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(163,1795368020,1,1,12,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":12,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(164,1795368020,1,1,13,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":13,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(165,1795368020,1,1,14,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":14,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(166,1795368020,1,1,15,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":15,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(167,1795368020,1,1,16,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":16,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(168,1795368020,1,1,17,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":17,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(169,1795368020,1,1,18,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":18,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(170,1795368020,1,1,19,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":19,\"pid\":17}',17,0,'',0,'','info',NULL,NULL),
(171,1795368020,1,1,20,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":18}',18,0,'',0,'','info',NULL,NULL),
(172,1795368020,1,1,21,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":19}',19,0,'',0,'','info',NULL,NULL),
(173,1795368020,1,1,22,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(174,1795368020,1,1,23,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(175,1795368020,1,1,11,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":11,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(176,1795368020,1,1,12,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":12,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(177,1795368020,1,1,13,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":13,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(178,1795368020,1,1,14,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":14,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(179,1795368020,1,1,15,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":15,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(180,1795368020,1,1,16,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":16,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(181,1795368020,1,1,17,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":17,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(182,1795368020,1,1,18,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(183,1795368020,1,1,19,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":19,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(184,1795368020,1,1,20,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(185,1795368020,1,1,21,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":21,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(186,1795368020,1,1,22,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":22,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(187,1795368020,1,1,23,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":23,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(188,1795368020,1,1,24,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":24,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(189,1795368020,1,1,25,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":25,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(190,1795368020,1,1,26,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":26,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(191,1795368020,1,1,27,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":27,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(192,1795368020,1,1,28,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":28,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(193,1795368020,1,1,29,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":29,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(194,1795368020,1,1,30,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":30,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(195,1795368020,1,1,31,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":31,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(196,1795368020,1,1,32,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":32,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(197,1795368020,1,1,33,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":33,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(198,1795368020,1,1,34,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(199,1795368020,1,1,35,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":35,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(200,1795368020,1,1,36,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":36,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(201,1795368020,1,1,37,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":37,\"pid\":17}',17,0,'',0,'','info',NULL,NULL),
(202,1795368020,1,1,38,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":38,\"pid\":18}',18,0,'',0,'','info',NULL,NULL),
(203,1795368020,1,1,39,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":39,\"pid\":19}',19,0,'',0,'','info',NULL,NULL),
(204,1795368020,1,1,40,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":40,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(205,1795368020,1,1,41,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":41,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(206,1795368020,1,1,42,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":42,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(207,1795368020,1,1,43,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":43,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(208,1795368020,1,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":11,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(209,1795368020,1,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":13,\"history\":0}',6,0,'',0,'','info',NULL,NULL),
(210,1795368020,1,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',7,0,'',0,'','info',NULL,NULL),
(211,1795368020,1,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"history\":0}',8,0,'',0,'','info',NULL,NULL),
(212,1795368020,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(213,1795368020,1,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":22,\"history\":0}',10,0,'',0,'','info',NULL,NULL),
(214,1795368020,1,2,24,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":24,\"history\":0}',11,0,'',0,'','info',NULL,NULL),
(215,1795368020,1,2,26,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":26,\"history\":0}',12,0,'',0,'','info',NULL,NULL),
(216,1795368020,1,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',13,0,'',0,'','info',NULL,NULL),
(217,1795368020,1,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":31,\"history\":0}',13,0,'',0,'','info',NULL,NULL),
(218,1795368020,1,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',14,0,'',0,'','info',NULL,NULL),
(219,1795368020,1,2,34,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"history\":0}',15,0,'',0,'','info',NULL,NULL),
(220,1795368020,1,2,37,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":37,\"history\":0}',17,0,'',0,'','info',NULL,NULL),
(221,1795368020,1,2,38,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":38,\"history\":0}',18,0,'',0,'','info',NULL,NULL),
(222,1795368020,1,2,39,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":39,\"history\":0}',19,0,'',0,'','info',NULL,NULL),
(223,1795368020,1,2,40,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":40,\"history\":0}',20,0,'',0,'','info',NULL,NULL),
(224,1795368020,1,2,42,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":42,\"history\":0}',21,0,'',0,'','info',NULL,NULL),
(225,1795368024,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n31 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n16 pages have been indexed. \n\n14 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 182 ms\nNews\n7 News and 0 related files have been indexed.\n\n\nIndexing process took 34 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 2 ms.\n\nFinished\nIndexing finished at 11/22/26, 18:20:24 (took 0 seconds).\nIndex contains 23 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(226,1795369027,1,2,15,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":15,\"history\":\"143\"}',1,0,'',0,'','info',NULL,NULL),
(227,1795369027,1,1,44,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":44,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(228,1795369027,1,2,34,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"history\":\"145\"}',15,0,'',0,'','info',NULL,NULL),
(229,1795369027,1,2,35,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":35,\"history\":\"146\"}',15,0,'',0,'','info',NULL,NULL),
(230,1795369027,1,2,36,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":36,\"history\":\"147\"}',15,0,'',0,'','info',NULL,NULL),
(231,1795369943,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: The \"TYPO3\\CMS\\Form\\Mvc\\Configuration\\YamlSource\" service or alias has been removed or inlined when the container was compiled. You should either make it public, or stop using the container directly and use dependency injection instead. | Symfony\\Component\\DependencyInjection\\Exception\\ServiceNotFoundException thrown in file /var/www/html/vendor/symfony/dependency-injection/Container.php in line 243',5,'php','','',-1,0,'',0,'','error',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('029d857185cc6f0a9a8ab7e9d2ef95f3','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',3,0,'tx_mtosafisitepackage_tile',4,'',0,0,2147483647,0,0,''),
('060db93adbf8c80a5c341ef5bfea77c8','sys_file_reference',22,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',25,'',0,0,2147483647,0,0,''),
('08d2716299a7edd920edfd9427d93525','tx_mtosafisitepackage_tile',1,'link',0,0,2147483647,0,'','typolink','7f69a1aa54e9db8a5ae0d952977b4cd9:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('0bb42ee7906264eb370da9ee8c5cc360','tt_content',31,'image',0,0,2147483647,0,'','','',3,0,'sys_file_reference',16,'',0,0,2147483647,0,0,''),
('17d5bf3449012f6032742f906e754655','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',12,'',0,0,2147483647,0,0,''),
('1a1b33ad44894354a18d0d45ff698eff','tx_kesearch_filters',1,'options',0,0,2147483647,0,'','','',0,0,'tx_kesearch_filteroptions',1,'',0,0,2147483647,0,0,''),
('1b2ed6872931f6bf2631618fb6288e67','tt_content',36,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('1dd0e0354b52fbddbadff8931116243c','tx_kesearch_indexerconfig',2,'targetpid',0,0,2147483647,0,'','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('1fde6c7fd92bd9d8eafb8e741be22840','tt_content',4,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('20f5efef03fe691570c3d2cd2fc393cf','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('220bc45f86eae522c66204eabb90e306','tx_mtosafisitepackage_slide',3,'link',0,0,2147483647,0,'','typolink','bf1e9cf52cce365bffb23721ba63b67b:0',0,0,'pages',14,'',0,0,2147483647,0,0,''),
('222baf9b25427e410e9c39f6ec6f2b7f','sys_category',5,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',5,'categories',0,0,2147483647,0,1,''),
('225e9febc94acfa52497bc219ce6d31b','sys_file_reference',21,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',24,'',0,0,2147483647,0,0,''),
('2386acca52c4f18cefdc6b906df671e9','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',13,'',0,0,2147483647,0,0,''),
('2780872b4d83ef806371ff889b7799cc','tx_kesearch_indexerconfig',2,'startingpoints_recursive',0,0,2147483647,0,'','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('30ddbb32f1c31a45277a635e878cef2e','tt_content',31,'image',0,0,2147483647,0,'','','',1,0,'sys_file_reference',14,'',0,0,2147483647,0,0,''),
('313e461a539f46cf2465487a128c051c','tx_mtosafisitepackage_tile',4,'link',0,0,2147483647,0,'','typolink','e34f7e18c8dc8d47f12cbbc9ec0587df:0',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('33be7c7c27d73f38622f81fcce501fee','tt_content',9,'pages',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('37aaef61fe9da71c3d2158c1cc012f0c','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('397497f0d911d5b8550159f504d01194','tt_content',39,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',21,'',0,0,2147483647,0,0,''),
('39f11610b54678a8af0feb57210bb43f','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',5,0,'tx_mtosafisitepackage_tile',6,'',0,0,2147483647,0,0,''),
('3d2896994c41d754a6409b530412c846','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('3dd61fadc472ee3f5bb4d4e7e08a79a8','sys_file_reference',10,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',17,'',0,0,2147483647,0,0,''),
('415de9b0331ee3670c2a9526f1affae8','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',15,'',0,0,2147483647,0,0,''),
('4402b32b58c950bb2cb91e2f1ed8bba8','pages',27,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',19,'',0,0,2147483647,0,0,''),
('4502c999e76beaad402d5f8db6b86f25','tx_kesearch_indexerconfig',2,'storagepid',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('4757b12b90def24df1880d8a111e43d5','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_tile',2,'',0,0,2147483647,0,0,''),
('47d351b61ea29efbe541d4778add7530','tx_kesearch_indexerconfig',1,'storagepid',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('480b46ad69572f59b62b9a26b54a746b','sys_file_reference',17,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',21,'',0,0,2147483647,0,0,''),
('4c50552ba214ce72d9d786f4de43b368','sys_category',7,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',7,'categories',0,0,2147483647,0,1,''),
('505ac3050b1043f117f21c125ce5f915','tx_mtosafisitepackage_tile',6,'link',0,0,2147483647,0,'','typolink','7f897eb5d5b640dce3bedcdb56c2d987:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('5212307d56a434cda710fd02e8113f82','tt_content',34,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'+254700000000'),
('529b5cce1a84064c904a6c430d56ecd1','sys_file_reference',16,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('5429966bdbff8fa90d5c254833c7756c','tt_content',15,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('642b702d5002f29241f7c501f3d28cf1','tt_content',34,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('655053dcf91ff4de04e0e7b0935ac0dc','tx_mtosafisitepackage_tile',5,'link',0,0,2147483647,0,'','typolink','a01eec11a0a46a8e86685cb8ec780ef1:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('679f66b060ba12c8427fbf2a710b0fd9','pages',29,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',21,'',0,0,2147483647,0,0,''),
('68275e712ee6626930e72c076be4577e','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('6e9153c8043ab894a418dc6522791810','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',1,'',0,0,2147483647,0,0,''),
('7106458409a1a556fb1c60516e842efb','tt_content',18,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',7,'',0,0,2147483647,0,0,''),
('71bd7ba8149169134006c9ca870e2006','sys_file_reference',12,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('75c3df5c09e24b3c2c96c640da355e01','tx_mtosafisitepackage_tile',2,'link',0,0,2147483647,0,'','typolink','087881d39e3c58af824e5fb90e661a8e:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('77491718585910205641ef73b044aa19','sys_category',1,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',1,'categories',0,0,2147483647,0,1,''),
('777a432b0e62b25c1b84f398c69e5955','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',1,'',0,0,2147483647,0,0,''),
('77d010084c16ba8308f7be5f1b76c604','tx_mtosafisitepackage_slide',1,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('7948bfb5fb5858eeb7961d595c01ddf5','tt_content',4,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('7b21b2228a8fd7ec83265fb900741d46','sys_file_reference',11,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',18,'',0,0,2147483647,0,0,''),
('7e694f9466d958648b1c103f07e2eddd','pages',26,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('84ad13f6b52a918039bc14cd87042e29','tt_content',9,'pi_flexform',0,0,2147483647,0,'MAIN/lDEF/resultPage/vDEF/','','',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('86aa77750d3d62492d28cf72adb0c6ec','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',4,0,'tx_mtosafisitepackage_tile',5,'',0,0,2147483647,0,0,''),
('8a594b57465e8a76202e1a34021ac90f','tt_content',42,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',23,'',0,0,2147483647,0,0,''),
('8c33249d3a9ac4708bfc8836b16a1c9b','tt_content',16,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('91055865169ba9d2b0e9094d3dfcffd4','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('960e459a1c93d12d716e538716e03756','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_slide',3,'',0,0,2147483647,0,0,''),
('a26cc2e4f1d394f20c27cc3fccd65e97','tt_content',13,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('a337a79987cb444fbb435427ab45568c','sys_file_reference',18,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('a3cc86a75fef4d79b777c521a359bf5f','tt_content',29,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('a69870b2c147f2e9c49924c30bba8eb3','sys_file_reference',15,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',18,'',0,0,2147483647,0,0,''),
('a9bb4d70a473b52d4a259986ad3214b7','tt_content',38,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',20,'',0,0,2147483647,0,0,''),
('ac0835d3bd7450f46d3ba28dcaf8880b','sys_file_reference',7,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',14,'',0,0,2147483647,0,0,''),
('ac3e2ceba954f0d2e5005157cb1c35c9','tt_content',3,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('b1089f60cddf4fa1a393572b789b3a7f','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',16,'',0,0,2147483647,0,0,''),
('b3762b32222c8c42bbaf2d9242765aa5','tt_content',37,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',19,'',0,0,2147483647,0,0,''),
('b8390ee0400ed62108c64b63dfc80330','sys_category',4,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',4,'categories',0,0,2147483647,0,1,''),
('b96dfec8962a424c335a15f010c09c64','tt_content',22,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('b9c912b6184055cadc4b89cb3b52ca24','tt_content',32,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',17,'',0,0,2147483647,0,0,''),
('bc577547d4c72172ebdc852ea3747576','tx_mtosafisitepackage_tile',3,'link',0,0,2147483647,0,'','typolink','5add86f047c9d524d9e9595219c10eb5:0',0,0,'pages',8,'',0,0,2147483647,0,0,''),
('bd0499781b8651f6a47dbdd267b552eb','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('bdab9f5c733a1925a2082d96913bc1f8','tt_content',31,'image',0,0,2147483647,0,'','','',2,0,'sys_file_reference',15,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('bf6cc0f81d2f48c8ad397ef2c3eee2b3','tx_mtosafisitepackage_slide',3,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('c038eefe78af750fd106e036d6e7bde9','tx_mtosafisitepackage_slide',2,'link',0,0,2147483647,0,'','typolink','e3c3bf6b59d1e8eefa995a17a3471d72:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('c14fd6ec1c7236724d685c3ae63e0ec4','tt_content',34,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',18,'',0,0,2147483647,0,0,''),
('c225a5dc51fe62e7b785fe672031e07b','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('c2914756c599ce17e7cb0585c6f86165','tt_content',36,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('c45d81bd65ed780c1f18939526272e2a','sys_file_reference',20,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',23,'',0,0,2147483647,0,0,''),
('c54d6e1dbf8edbce22fb4011cf341c4a','pages',25,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('c56becdc4ea2ae3a8579c4d7b1d4aed1','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('c66364f690722e7855542eee32488b3c','sys_file_reference',23,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('ca34608fee503babde3755c56abc293f','tt_content',5,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('cc525b5738d587aa9038005247b67650','sys_category',2,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',2,'categories',0,0,2147483647,0,1,''),
('cc547b9336a89588b41b9aac515676d6','tt_content',24,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('ccf27ed75cce3fdca300151061714b0a','tt_content',26,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',11,'',0,0,2147483647,0,0,''),
('cd03540122f752ba28f3b2f778daed32','pages',24,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('d0c87340bc327a8355a748af77c43662','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_tile',3,'',0,0,2147483647,0,0,''),
('d2ada98790a86b08a8930d6f5c005bb7','tx_kesearch_filters',1,'options',0,0,2147483647,0,'','','',1,0,'tx_kesearch_filteroptions',2,'',0,0,2147483647,0,0,''),
('d3722f9232f47d2b03aef4cb5dcf809b','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('d55a1800d95931fd7a591f388a8f53ce','tt_content',44,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','1ea3783b1efa0d9299000582e728ea8a',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml'),
('de3954d092ea613d54be22888c93616f','tt_content',40,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',22,'',0,0,2147483647,0,0,''),
('e05441bea25287ab7ef9a4d72341a937','tt_content',34,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('e347371ae65979f6857a13b1bbdc3e8a','sys_category',6,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',6,'categories',0,0,2147483647,0,1,''),
('e3595e870a8b402d8071edf4009d6ee9','tt_content',11,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('e54c4b2d95c034daecb3f81498aa0289','tt_content',10,'pi_flexform',0,0,2147483647,0,'MAIN/lDEF/loadFlexformsFromOtherCE/vDEF/','','',0,0,'tt_content',9,'',0,0,2147483647,0,0,''),
('e5d5bafd27ede6e4bfb9f22c7119046d','sys_file_reference',13,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('e5db4317e6458f59a44dd32ed60180c6','tt_content',29,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('ef9e0e86be45638085e9662d9146b7af','sys_file_reference',19,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',22,'',0,0,2147483647,0,0,''),
('f28edf7f129f3dcd6cfeb403ba7a0e39','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('f352f231282e4969b3ea85c3f9b4608f','sys_category',3,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',3,'categories',0,0,2147483647,0,1,''),
('f5ed8c79cd8612b55a515f9f520c7ba6','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_slide',2,'',0,0,2147483647,0,0,''),
('f6143939c533cf455cf78face1748d83','sys_file_reference',14,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',15,'',0,0,2147483647,0,0,''),
('f640e46359138786bad533a1dc6c9adb','tx_mtosafisitepackage_slide',2,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('f6a0bea04b5b567e9d6942672112d49c','tt_content',31,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',13,'',0,0,2147483647,0,0,''),
('f9feddf408fc7808849da2413f760752','tt_content',20,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('fb534e0348cb0df4b46f46afc05eb5c6','tt_content',11,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('fc193642beeafd12f02297477a258ef6','tx_mtosafisitepackage_slide',1,'link',0,0,2147483647,0,'','typolink','af39f1ff3aa52a5bc109a0ba6e0c4e9d:0',0,0,'pages',13,'',0,0,2147483647,0,0,''),
('fce6d6e68799136a3291b364b914834b','tx_kesearch_indexerconfig',1,'startingpoints_recursive',0,0,2147483647,0,'','','',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('fed36fd2032652e9a28f9e21e509e64e','pages',28,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\LanguagePackUpdateTimestampMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','mtosafi_sitepackage:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','mtosafi_sitepackage:Initialisation/dataImported','i:1;'),
(40,'extensionDataImport','news:ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','ke_search:ext_tables_static+adt.sql','s:0:\"\";'),
(47,'tx_kesearch','lastRun','a:3:{s:9:\"startTime\";i:1795368024;s:7:\"endTime\";i:1795368024;s:12:\"indexingTime\";i:0;}'),
(48,'extensionDataImport','altcha:ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_slides` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l18n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1795334294,1794119207,1,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\">TYPO3</a>.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(2,1,1795333042,1795332992,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Sidebar probe',0,'','','','<p>Rendered from the area sidebar.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(3,1,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'News',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(4,30,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'All news',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(5,31,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'News article',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(6,1,1795343750,1795343750,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_tiles',0,0,'','',0,'Popular services',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,6,0),
(7,1,1795344511,1795344511,0,0,0,0,'0',64,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_slider',0,0,'','',0,'Highlights',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,3),
(8,33,1795345582,1795345582,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'This page does not exist',100,'','','','<p>The page you are looking for may have moved, or the address may be mistyped.</p>\r\n<ul><li><a href=\"t3://page?uid=1\">Go to the home page</a></li><li><a href=\"t3://page?uid=16\">Search the site</a></li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(9,16,1795348009,1795348009,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'ke_search_pi1',0,0,'','',0,'Filter results',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'34',0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"MAIN\">\n            <language index=\"lDEF\">\n                <field index=\"resultPage\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n                <field index=\"showTextInsteadOfResults\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"textForResults\">\n                    <value index=\"vDEF\">&lt;p&gt;Type what you are looking for into the search field at the top of the page.&lt;/p&gt;</value>\n                </field>\n                <field index=\"showNoResultsText\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"view\">\n            <language index=\"lDEF\">\n                <field index=\"highlightSword\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"resultChars\">\n                    <value index=\"vDEF\">200</value>\n                </field>\n                <field index=\"resultsNumeration\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showResultUrl\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showDate\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"images\">\n            <language index=\"lDEF\">\n                <field index=\"showTypeIcon\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showPageImages\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showNewsImages\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showFilePreview\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"pagebrowser\">\n            <language index=\"lDEF\">\n                <field index=\"pagebrowserOnTop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"pagebrowserAtBottom\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"resultsPerPage\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"maxPagesInPagebrowser\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"filter\">\n            <language index=\"lDEF\">\n                <field index=\"filters\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(10,16,1795348009,1795348009,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'ke_search_pi2',0,0,'','',0,'Search results',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"MAIN\">\n            <language index=\"lDEF\">\n                <field index=\"loadFlexformsFromOtherCE\">\n                    <value index=\"vDEF\">9</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(11,5,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Pay the municipality from wherever you are',0,'','','','<p>Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.</p>\r\n<p>Most of them can be paid by mobile money or by card in the <a href=\"t3://page?uid=17\">e-services portal</a>, at any time of day. The cash office in the municipal office is open on working days.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(12,5,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'menu_subpages',0,0,'','',0,'Payments and fees',0,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(13,6,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'How your land rates are calculated',0,'','','','<p>Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.</p>\r\n<p>Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(14,6,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Rates for 2026',0,'','','','Land use|Rate|Minimum per plot and year\nResidential|0.5 % of the rateable value|KES 1,500\nCommercial|1.2 % of the rateable value|KES 1,500\nAgricultural|0.2 % of the rateable value|KES 1,500',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(15,6,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'How to pay',0,'','','','<p>Pay by mobile money, by card in the <a href=\"t3://page?uid=17\">e-services portal</a>, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(16,7,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'One permit for your business',0,'','','','<p>Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.</p>\r\n<p>Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(17,7,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'What you need to apply',0,'','','','Your national ID or passport\nThe KRA PIN of the business\nThe plot number of the premises\nA description of the activity and the number of employees',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(18,8,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Parking in the town centre',0,'','','','<p>Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.</p>\r\n<p>Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.</p>',1,0,NULL,NULL,26,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(19,8,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Fees',0,'','','','Vehicle|Per day|Per month\nCar|KES 100|KES 2,000\nPick-up and van|KES 150|KES 3,000\nLorry|KES 300|KES 6,000\nMotorcycle (boda boda)|KES 30|KES 500',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(20,9,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Selling at the municipal markets',0,'','','','<p>Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.</p>\r\n<p>Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(21,9,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Fees',0,'','','','|Fee\nStall, per month|KES 1,200\nOpen space, per day|KES 50\nFish market, per day|KES 80',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(22,10,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Interest waived when you clear your arrears',0,'','','','<p>Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.</p>\r\n<p>Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.</p>',1,0,NULL,NULL,26,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(23,10,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'How it works',0,'','','','Ask for a statement of your arrears\nApply for the waiver with the statement\nPay the arrears without the interest within 30 days of the approval',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(24,11,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Health services close to home',0,'','','','<p>The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.</p>\r\n<p>For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(25,11,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Health centres',0,'','','','Health centre|Ward|Opening hours\nMto Safi Town|Central|Mon–Sat 7:00–19:00\nPwani|Beach|Mon–Fri 8:00–17:00\nKijiji|Upper River|Mon–Fri 8:00–17:00\nMnarani|Mnarani|Mon–Fri 8:00–17:00',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(26,12,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'A clean river for everyone',0,'','','','<p>Mto Safi means \"clean river\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(27,12,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Water connection',0,'','','','<p>To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.</p>\r\n<p>To report a leak or a burst pipe, call +254 700 000 001 at any time.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(28,12,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Waste collection',0,'','','','Town centre: Monday and Thursday\nBeach and Mnarani: Tuesday and Friday\nUpper River: Wednesday and Saturday',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(29,13,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Karibu Mto Safi',0,'','','','<p>White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.</p>\r\n<p>The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under <a href=\"t3://page?uid=7\">Single business permit</a>.</p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(30,13,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Places to visit',0,'','','','The dhow harbour and the fish market at sunrise\nThe mangrove boardwalk at the river mouth\nMto Safi beach and the coral garden\nThe old town with its carved doors',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(31,13,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'image',0,0,'','',0,'Impressions of Mto Safi',0,'','','',NULL,4,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(32,14,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Have your say on the budget',0,'','','','<p>Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.</p>\r\n<p>You can also send your views in writing to the clerk until 15 May.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(33,14,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Forum dates',0,'','','','Ward|Date|Place\nCentral|4 May, 10:00|Municipal hall\nBeach|6 May, 10:00|Pwani primary school\nUpper River|8 May, 14:00|Kijiji social hall\nMnarani|11 May, 10:00|Mnarani chief\'s camp',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(34,15,1795369027,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"colPos\":\"\",\"imageorient\":\"\"}',0,0,0,0,'default',1,NULL,0,'textpic',0,0,'','',0,'Visit us',0,'','','','<p>Mto Safi Municipality<br />Municipal Office<br />Beach Road 1<br />P.O. Box 123, Mto Safi</p>\r\n<p>Phone: <a href=\"tel:+254700000000\">+254 700 000 000</a><br />Email: <a href=\"mailto:info@mtosafi.example\">info@mtosafi.example</a></p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(35,15,1795369027,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'table',0,0,'','',0,'Opening hours',0,'','','','Days|Hours\nMon–Thu|8:00–17:00\nFriday|8:00–13:00, 14:00–17:00\nSat, Sun|Closed',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(36,15,1795369027,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Report a problem',0,'','','','<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\"mailto:report@mtosafi.example\">report@mtosafi.example</a>, and say where it is.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(37,17,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Your municipal services online',0,'','','','<p>In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.</p>\r\n<p>Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.</p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(38,18,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Example text',0,'','','','<p>This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.</p>\r\n<p>The design of this site targets WCAG 2.1 level AA.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(39,19,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Example text',0,'','','','<p>This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(40,20,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Ask for the information we hold',0,'','','','<p>Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.</p>\r\n<p>We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(41,20,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Published without a request',0,'','','','The budget and the annual accounts\nThe valuation roll\nThe minutes of the municipal board\nTenders and the contracts awarded',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(42,21,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Doing business with the municipality',0,'','','','<p>The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0),
(43,21,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Open tenders',0,'','','','Number|Subject|Closes\nMSM/T/01/2026|Resurfacing of Market Street|12 June\nMSM/T/02/2026|Solar street lights, Beach ward|19 June\nMSM/T/03/2026|Waste collection vehicles (2)|26 June',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0),
(44,15,1795369027,1795369027,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Write to us',0,'','','The right department answers within five working days.',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_filteroptions`
--

DROP TABLE IF EXISTS `tx_kesearch_filteroptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_filteroptions` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `tag` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `automated_tagging` text DEFAULT NULL,
  `automated_tagging_exclude` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_filteroptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_filteroptions` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_filteroptions` DISABLE KEYS */;
INSERT INTO `tx_kesearch_filteroptions` VALUES
(1,34,1795348009,1795348009,0,0,'{\"hidden\":\"\",\"slug\":\"\",\"tag\":\"\",\"title\":\"\"}',0,0,256,NULL,0,'Services','service','services',NULL,NULL),
(2,34,1795348009,1795348009,0,0,'{\"hidden\":\"\",\"slug\":\"\",\"tag\":\"\",\"title\":\"\"}',0,0,512,NULL,0,'News','news','news',NULL,NULL);
/*!40000 ALTER TABLE `tx_kesearch_filteroptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_filters`
--

DROP TABLE IF EXISTS `tx_kesearch_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_filters` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `options` text DEFAULT NULL,
  `rendertype` varchar(90) NOT NULL DEFAULT '',
  `markAllCheckboxes` smallint(6) NOT NULL DEFAULT 0,
  `target_pid` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL DEFAULT 0,
  `shownumberofresults` smallint(6) NOT NULL DEFAULT 0,
  `alphabeticalsorting` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_filters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_filters` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_filters` DISABLE KEYS */;
INSERT INTO `tx_kesearch_filters` VALUES
(1,34,1795348009,1795348009,0,0,'{\"alphabeticalsorting\":\"\",\"amount\":\"\",\"hidden\":\"\",\"markAllCheckboxes\":\"\",\"options\":\"\",\"rendertype\":\"\",\"shownumberofresults\":\"\",\"target_pid\":\"\",\"title\":\"\"}',0,0,NULL,0,'Show only','1,2','checkbox',0,0,10,1,0);
/*!40000 ALTER TABLE `tx_kesearch_filters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_index`
--

DROP TABLE IF EXISTS `tx_kesearch_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_index` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `starttime` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `fe_group` varchar(100) NOT NULL DEFAULT '0',
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `targetpid` text DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `hidden_content` mediumtext DEFAULT NULL,
  `params` text DEFAULT NULL,
  `type` tinytext DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `sortdate` int(11) NOT NULL DEFAULT 0,
  `orig_uid` varchar(255) NOT NULL DEFAULT '0',
  `orig_pid` int(11) NOT NULL DEFAULT 0,
  `title` text DEFAULT NULL,
  `language` int(11) NOT NULL DEFAULT 0,
  `directory` tinytext DEFAULT NULL,
  `hash` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  FULLTEXT KEY `tags` (`tags`),
  FULLTEXT KEY `title` (`title`),
  FULLTEXT KEY `titlecontent` (`title`,`content`),
  FULLTEXT KEY `titlecontenthiddencontent` (`title`,`content`,`hidden_content`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_index`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_index` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_index` DISABLE KEYS */;
INSERT INTO `tx_kesearch_index` VALUES
(1,34,1795368024,1795348011,0,0,'0',0,'31','Sixty stalls, cold storage and clean water for traders and buyers.\nThe new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.\r\nTraders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.\r\nContact: Trade &amp; Markets Office, +254 700 000 010','','&tx_news_pi1[news]=1&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Trademarkets#,#syscat1#,#news#','Sixty stalls, cold storage and clean water for traders and buyers.',1793595600,'1',32,'New fish market opens at the jetty',0,'',''),
(2,34,1795368024,1795348011,0,0,'0',0,'31','Works run for six weeks. Matatus take the diversion via Market Street.\nBeach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.\r\nDuring the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.\r\nContact: Roads Department, +254 700 000 020','','&tx_news_pi1[news]=2&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Roadstransport#,#syscat2#,#news#','Works run for six weeks. Matatus take the diversion via Market Street.',1793077200,'2',32,'Beach Road resurfacing starts',0,'',''),
(3,34,1795368024,1795348011,0,0,'0',0,'31','Eye tests, vaccinations and screening, open to every resident.\nThe municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.\r\nOn offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.\r\nContact: Health Department, +254 700 000 030','','&tx_news_pi1[news]=3&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Health#,#syscat3#,#news#','Eye tests, vaccinations and screening, open to every resident.',1792472400,'3',32,'Free health camp in Ward 3',0,'',''),
(4,34,1795368024,1795348011,0,0,'0',0,'31','Residents can now pay land rates and business permits with their phone.\nFrom 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.\r\nPayment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.\r\nContact: Revenue Department, +254 700 000 040','','&tx_news_pi1[news]=4&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Revenuepayments#,#syscat4#,#news#','Residents can now pay land rates and business permits with their phone.',1791781200,'4',32,'Pay land rates by mobile money from January',0,'',''),
(5,34,1795368024,1795348011,0,0,'0',0,'31','Public participation forums in every ward in November.\nThe municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.\r\nA forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.\r\nContact: Planning Office, +254 700 000 050','','&tx_news_pi1[news]=5&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Publicparticipation#,#syscat5#,#news#','Public participation forums in every ward in November.',1790830800,'5',32,'Have your say on the budget 2027/28',0,'',''),
(6,34,1795368024,1795348011,0,0,'0',0,'31','The monthly beach clean-ups and the new waste collection paid off.\nMto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.\r\nThe mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.\r\nContact: Environment Department, +254 700 000 060','','&tx_news_pi1[news]=6&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Environment#,#syscat6#,#news#','The monthly beach clean-ups and the new waste collection paid off.',1789707600,'6',32,'Mto Safi named cleanest town on the coast',0,'',''),
(7,34,1795368024,1795348012,0,0,'0',0,'31','Three boreholes and twelve water kiosks serve 4,000 residents.\nThree new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.\r\nA water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.\r\nContact: Water &amp; Sanitation Department, +254 700 000 070','','&tx_news_pi1[news]=7&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Water#,#syscat7#,#news#','Three boreholes and twelve water kiosks serve 4,000 residents.',1788584400,'7',32,'New boreholes bring clean water to Ward 5',0,'',''),
(8,34,1795368024,1795368024,0,0,'',0,'5','Pay the municipality from wherever you are\n Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.\r\n Most of them can be paid by mobile money or by card in the e-services portal, at any time of day. The cash office in the municipal office is open on working days.\n\n\n\n','','','page','#service#','',1795334294,'5',1,'Revenue & payments',0,'',''),
(9,34,1795368024,1795368024,0,0,'',0,'6','How your land rates are calculated\n Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.\r\n Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.\n\n\n\nRates for 2026\nLand use Rate Minimum per plot and year\nResidential 0.5 % of the rateable value KES 1,500\nCommercial 1.2 % of the rateable value KES 1,500\nAgricultural 0.2 % of the rateable value KES 1,500\n\n\n\nHow to pay\n Pay by mobile money, by card in the e-services portal, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.\n\n\n\n','','','page','#service#','',1795334294,'6',5,'Land rates',0,'',''),
(10,34,1795368024,1795368024,0,0,'',0,'7','One permit for your business\n Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.\r\n Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.\n\n\n\nWhat you need to apply\nYour national ID or passport\nThe KRA PIN of the business\nThe plot number of the premises\nA description of the activity and the number of employees\n\n\n\n','','','page','#service#','',1795334294,'7',5,'Single business permit',0,'',''),
(11,34,1795368024,1795368024,0,0,'',0,'8','Parking in the town centre\n Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.\r\n Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.\n\n\n\nFees\nVehicle Per day Per month\nCar KES 100 KES 2,000\nPick-up and van KES 150 KES 3,000\nLorry KES 300 KES 6,000\nMotorcycle (boda boda) KES 30 KES 500\n\n\n\n','','','page','#service#','',1795334294,'8',5,'Parking fees',0,'',''),
(12,34,1795368024,1795368024,0,0,'',0,'9','Selling at the municipal markets\n Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.\r\n Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.\n\n\n\nFees\n Fee\nStall, per month KES 1,200\nOpen space, per day KES 50\nFish market, per day KES 80\n\n\n\n','','','page','#service#','',1795334294,'9',5,'Market fees',0,'',''),
(13,34,1795368024,1795368024,0,0,'',0,'10','Interest waived when you clear your arrears\n Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.\r\n Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.\n\n\n\nHow it works\nAsk for a statement of your arrears\nApply for the waiver with the statement\nPay the arrears without the interest within 30 days of the approval\n\n\n\n','','','page','#service#','',1795334294,'10',5,'Waiver of interest',0,'',''),
(14,34,1795368024,1795368024,0,0,'',0,'11','Health services close to home\n The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.\r\n For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.\n\n\n\nHealth centres\nHealth centre Ward Opening hours\nMto Safi Town Central Mon–Sat 7:00–19:00\nPwani Beach Mon–Fri 8:00–17:00\nKijiji Upper River Mon–Fri 8:00–17:00\nMnarani Mnarani Mon–Fri 8:00–17:00\n\n\n\n','','','page','#service#','',1795334294,'11',1,'Health',0,'',''),
(15,34,1795368024,1795368024,0,0,'',0,'12','A clean river for everyone\n Mto Safi means \"clean river\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.\n\n\n\nWater connection\n To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.\r\n To report a leak or a burst pipe, call +254 700 000 001 at any time.\n\n\n\nWaste collection\nTown centre: Monday and Thursday\nBeach and Mnarani: Tuesday and Friday\nUpper River: Wednesday and Saturday\n\n\n\n','','','page','#service#','',1795334294,'12',1,'Environment & water',0,'',''),
(16,34,1795368024,1795368024,0,0,'',0,'13','Karibu Mto Safi\n White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.\r\n The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under Single business permit.\n\n\n\nPlaces to visit\nThe dhow harbour and the fish market at sunrise\nThe mangrove boardwalk at the river mouth\nMto Safi beach and the coral garden\nThe old town with its carved doors\n\n\n\n','','','page','#service#','',1795334294,'13',1,'Trade & tourism',0,'',''),
(17,34,1795368024,1795368024,0,0,'',0,'14','Have your say on the budget\n Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.\r\n You can also send your views in writing to the clerk until 15 May.\n\n\n\nForum dates\nWard Date Place\nCentral 4 May, 10:00 Municipal hall\nBeach 6 May, 10:00 Pwani primary school\nUpper River 8 May, 14:00 Kijiji social hall\nMnarani 11 May, 10:00 Mnarani chief\'s camp\n\n\n\n','','','page','#service#','',1795334294,'14',1,'Public participation',0,'',''),
(18,34,1795368024,1795368024,0,0,'',0,'15','Visit us\n Mto Safi Municipality Municipal Office Beach Road 1 P.O. Box 123, Mto Safi\r\n Phone: +254 700 000 000 Email: info@mtosafi.example\n\n\n\nOpening hours\nDays Hours\nMon–Thu 8:00–17:00\nFriday 8:00–13:00, 14:00–17:00\nSat, Sun Closed\n\n\n\nReport a problem\n A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to report@mtosafi.example, and say where it is.\n\n\n\n','','','page','#service#','',1795334294,'15',1,'Contact',0,'',''),
(19,34,1795368024,1795368024,0,0,'',0,'17','Your municipal services online\n In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.\r\n Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.\n\n\n\n','','','page','#service#','',1795334294,'17',1,'E-services portal',0,'',''),
(20,34,1795368024,1795368024,0,0,'',0,'18','Example text\n This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.\r\n The design of this site targets WCAG 2.1 level AA.\n\n\n\n','','','page','#service#','',1795334294,'18',1,'Accessibility statement',0,'',''),
(21,34,1795368024,1795368024,0,0,'',0,'19','Example text\n This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.\n\n\n\n','','','page','#service#','',1795334294,'19',1,'Privacy policy',0,'',''),
(22,34,1795368024,1795368024,0,0,'',0,'20','Ask for the information we hold\n Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.\r\n We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.\n\n\n\nPublished without a request\nThe budget and the annual accounts\nThe valuation roll\nThe minutes of the municipal board\nTenders and the contracts awarded\n\n\n\n','','','page','#service#','',1795334294,'20',1,'Access to information',0,'',''),
(23,34,1795368024,1795368024,0,0,'',0,'21','Doing business with the municipality\n The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.\n\n\n\nOpen tenders\nNumber Subject Closes\nMSM/T/01/2026 Resurfacing of Market Street 12 June\nMSM/T/02/2026 Solar street lights, Beach ward 19 June\nMSM/T/03/2026 Waste collection vehicles (2) 26 June\n\n\n\n','','','page','#service#','',1795334294,'21',1,'Tenders',0,'','');
/*!40000 ALTER TABLE `tx_kesearch_index` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_indexerconfig`
--

DROP TABLE IF EXISTS `tx_kesearch_indexerconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_indexerconfig` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `storagepid` text DEFAULT NULL,
  `targetpid` text DEFAULT NULL,
  `startingpoints_recursive` text DEFAULT NULL,
  `single_pages` text DEFAULT NULL,
  `sysfolder` text DEFAULT NULL,
  `index_content_with_restrictions` text DEFAULT NULL,
  `type` varchar(90) NOT NULL DEFAULT '',
  `index_news_category_mode` smallint(6) NOT NULL DEFAULT 0,
  `index_news_category_selection` text DEFAULT NULL,
  `index_extnews_category_selection` text DEFAULT NULL,
  `index_news_archived` smallint(6) NOT NULL DEFAULT 0,
  `index_news_useHRDatesSingle` smallint(6) NOT NULL DEFAULT 0,
  `index_news_useHRDatesSingleWithoutDay` smallint(6) NOT NULL DEFAULT 0,
  `index_news_files_mode` smallint(6) NOT NULL DEFAULT 0,
  `index_use_page_tags` smallint(6) NOT NULL DEFAULT 0,
  `index_use_page_tags_for_files` smallint(6) NOT NULL DEFAULT 0,
  `index_page_doctypes` varchar(255) NOT NULL DEFAULT '',
  `directories` text DEFAULT NULL,
  `fileext` tinytext DEFAULT NULL,
  `content_fields` text DEFAULT NULL,
  `page_fields` text DEFAULT NULL,
  `page_fields_hidden` text DEFAULT NULL,
  `file_reference_fields` text DEFAULT NULL,
  `file_collections` text DEFAULT NULL,
  `filteroption` int(11) NOT NULL DEFAULT 0,
  `fal_storage` int(11) NOT NULL DEFAULT 0,
  `contenttypes` text DEFAULT NULL,
  `additional_tables` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_indexerconfig`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_indexerconfig` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_indexerconfig` DISABLE KEYS */;
INSERT INTO `tx_kesearch_indexerconfig` VALUES
(1,34,1795348009,1795348009,0,0,0,'Pages','34',NULL,'1',NULL,NULL,'no','page',1,NULL,NULL,0,0,0,0,0,0,'1',NULL,'pdf,ppt,doc,xls,docx,xlsx,pptx','bodytext,subheader,header_link','','','media',NULL,0,0,'text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline','[accordion]\ntable = tx_bootstrappackage_accordion_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[tab]\ntable = tx_bootstrappackage_tab_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[carousel]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_fullscreen]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_small]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[icon_group]\ntable = tx_bootstrappackage_icon_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\n\n[card_group]\ntable = tx_bootstrappackage_card_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\nfields[] = link_title\n\n[timeline]\ntable = tx_bootstrappackage_timeline_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext'),
(2,34,1795348009,1795348009,0,0,0,'News','34','31','32',NULL,NULL,'no','news',1,NULL,NULL,0,0,0,0,0,0,'1',NULL,'pdf,ppt,doc,xls,docx,xlsx,pptx','bodytext,subheader,header_link','','','media',NULL,0,0,'text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline','[accordion]\ntable = tx_bootstrappackage_accordion_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[tab]\ntable = tx_bootstrappackage_tab_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[carousel]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_fullscreen]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_small]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[icon_group]\ntable = tx_bootstrappackage_icon_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\n\n[card_group]\ntable = tx_bootstrappackage_card_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\nfields[] = link_title\n\n[timeline]\ntable = tx_bootstrappackage_timeline_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext');
/*!40000 ALTER TABLE `tx_kesearch_indexerconfig` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_stat_search`
--

DROP TABLE IF EXISTS `tx_kesearch_stat_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_stat_search` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `searchphrase` text DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `hits` int(11) NOT NULL DEFAULT 0,
  `tagsagainst` text DEFAULT NULL,
  `language` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_stat_search`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_stat_search` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_stat_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_kesearch_stat_search` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_stat_word`
--

DROP TABLE IF EXISTS `tx_kesearch_stat_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_stat_word` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `word` text DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `pageid` int(11) NOT NULL DEFAULT 0,
  `resultsfound` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_stat_word`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_stat_word` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_stat_word` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_kesearch_stat_word` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_slide`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_slide` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(100) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  `link` text NOT NULL DEFAULT '',
  `link_label` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_slide`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_slide` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_slide` VALUES
(1,1,1795344511,1795344511,0,0,1,0,0,0,NULL,'',0,0,0,0,7,1,'Karibu Mto Safi','White beaches, a clean river and a municipality that serves you online, day and night.','t3://page?uid=13','Discover Mto Safi'),
(2,1,1795344511,1795344511,0,0,2,0,0,0,NULL,'',0,0,0,0,7,1,'Pay your land rates by mobile money','Calculate what you owe and pay before 31 March to avoid interest.','t3://page?uid=6','Calculate land rates'),
(3,1,1795344511,1795344511,0,0,3,0,0,0,NULL,'',0,0,0,0,7,1,'Have your say on the budget','Join the public participation forums in every ward this month.','t3://page?uid=14','See the forum dates');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_tile`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_tile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_tile` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `icon` varchar(8) NOT NULL DEFAULT '',
  `label` varchar(100) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_tile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_tile` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_tile` VALUES
(1,1,1795343750,1795343750,0,0,1,0,0,0,NULL,'',0,0,0,0,6,'🏪','Single business permit','t3://page?uid=7'),
(2,1,1795343750,1795343750,0,0,2,0,0,0,NULL,'',0,0,0,0,6,'🏡','Land rates','t3://page?uid=6'),
(3,1,1795343750,1795343750,0,0,3,0,0,0,NULL,'',0,0,0,0,6,'🅿️','Parking fees','t3://page?uid=8'),
(4,1,1795343750,1795343750,0,0,4,0,0,0,NULL,'',0,0,0,0,6,'💧','Water connection','t3://page?uid=12'),
(5,1,1795343750,1795343750,0,0,5,0,0,0,NULL,'',0,0,0,0,6,'🧺','Market stalls','t3://page?uid=9'),
(6,1,1795343750,1795343750,0,0,6,0,0,0,NULL,'',0,0,0,0,6,'📣','Report a problem','t3://page?uid=15');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(NULL,1,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New fish market opens at the jetty','Sixty stalls, cold storage and clean water for traders and buyers.','<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.</p>\r\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.</p>\r\n<p><strong>Contact:</strong> Trade &amp; Markets Office, +254 700 000 010</p>',1793595600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-fish-market-opens-at-the-jetty',NULL,'',0.5,'',''),
(NULL,2,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Beach Road resurfacing starts','Works run for six weeks. Matatus take the diversion via Market Street.','<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.</p>\r\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.</p>\r\n<p><strong>Contact:</strong> Roads Department, +254 700 000 020</p>',1793077200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'beach-road-resurfacing-starts',NULL,'',0.5,'',''),
(NULL,3,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Free health camp in Ward 3','Eye tests, vaccinations and screening, open to every resident.','<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.</p>\r\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.</p>\r\n<p><strong>Contact:</strong> Health Department, +254 700 000 030</p>',1792472400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'free-health-camp-in-ward-3',NULL,'',0.5,'',''),
(NULL,4,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Pay land rates by mobile money from January','Residents can now pay land rates and business permits with their phone.','<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.</p>\r\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.</p>\r\n<p><strong>Contact:</strong> Revenue Department, +254 700 000 040</p>',1791781200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pay-land-rates-by-mobile-money-from-january',NULL,'',0.5,'',''),
(NULL,5,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Have your say on the budget 2027/28','Public participation forums in every ward in November.','<p>The municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.</p>\r\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.</p>\r\n<p><strong>Contact:</strong> Planning Office, +254 700 000 050</p>',1790830800,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'have-your-say-on-the-budget-2027-28',NULL,'',0.5,'',''),
(NULL,6,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Mto Safi named cleanest town on the coast','The monthly beach clean-ups and the new waste collection paid off.','<p>Mto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.</p>\r\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.</p>\r\n<p><strong>Contact:</strong> Environment Department, +254 700 000 060</p>',1789707600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'mto-safi-named-cleanest-town-on-the-coast',NULL,'',0.5,'',''),
(NULL,7,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New boreholes bring clean water to Ward 5','Three boreholes and twelve water kiosks serve 4,000 residents.','<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.</p>\r\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.</p>\r\n<p><strong>Contact:</strong> Water &amp; Sanitation Department, +254 700 000 070</p>',1788584400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-boreholes-bring-clean-water-to-ward-5',NULL,'',0.5,'','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_typo3altcha_domain_model_challenge`
--

DROP TABLE IF EXISTS `tx_typo3altcha_domain_model_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_typo3altcha_domain_model_challenge` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `challenge` varchar(1024) NOT NULL DEFAULT '',
  `is_solved` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_typo3altcha_domain_model_challenge`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_typo3altcha_domain_model_challenge` WRITE;
/*!40000 ALTER TABLE `tx_typo3altcha_domain_model_challenge` DISABLE KEYS */;
INSERT INTO `tx_typo3altcha_domain_model_challenge` VALUES
(1,0,1795369783,1795369783,0,'b14ee5adc9e3d8ee18dfd97186b9c47b',0),
(2,0,1795369826,1795369826,0,'3a8d6f989a1b179c9f9df3f63bddd99d',0),
(3,0,1795369830,1795369830,0,'4a35ec6b33d5b8fdb4a3f0b8bea722e2',1),
(4,0,1795369857,1795369856,0,'11e10a2ef2c615e04eabd25394088573',1),
(5,0,1795369996,1795369995,0,'80088554263ad4850116a834b4256890',1),
(6,0,1795370028,1795370028,0,'7bff55dfa221c741a872a7fe8f6d6846',0),
(7,0,1795370029,1795370029,0,'380f64900637163993edf48d4dae7f63',0),
(8,0,1795370029,1795370029,0,'7ea6b9d738dae73d8b9c6d01898e7e03',0),
(9,0,1795370029,1795370029,0,'56679ee611f164e7be08ed67e3a232ab',0),
(10,0,1795370029,1795370029,0,'87a11cfaeff5f8ad6ffe1bd9d16eb897',0),
(11,0,1795370029,1795370029,0,'a0117466d46cb4d1cf0ae91551f5b459',0),
(12,0,1795370029,1795370029,0,'ad0c1e52ab6d90c15a766811b6bf1eaa',0),
(13,0,1795370030,1795370030,0,'447d2a37ef3dda3201a77b29098a6977',0),
(14,0,1795370030,1795370030,0,'452d533e9477514627d604360c8275d1',0),
(15,0,1795370031,1795370031,0,'b043a0f62e4b4f084a1eddedb80731c2',0);
/*!40000 ALTER TABLE `tx_typo3altcha_domain_model_challenge` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-22 18:56:35
