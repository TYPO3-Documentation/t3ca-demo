-- MariaDB dump 10.20-11.8.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.9-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1795336957,1795336957,0,0,'Edit pages, content and news of the Mto Safi site. Images upload to fileadmin/user_upload/news/','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','Editors','1','1','readFolder,addFolder,renameFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',0,'1,4,254','pages,tt_content,sys_category,sys_file,sys_file_metadata,sys_file_reference,tx_news_domain_model_news,tx_news_domain_model_link,tx_news_domain_model_tag,tx_mtosafisitepackage_tile','pages:doktype,pages:php_tree_stop,pages:categories,pages:layout,pages:extendToSubpages,pages:nav_title,pages:nav_hide,pages:subtitle,pages:target,pages:lastUpdated,pages:newUntil,pages:cache_timeout,pages:cache_tags,pages:no_search,pages:shortcut_mode,pages:content_from_pid,pages:keywords,pages:description,pages:abstract,pages:author,pages:author_email,pages:media,pages:is_siteroot,pages:mount_pid_ol,pages:module,pages:l18n_cfg,pages:backend_layout,pages:backend_layout_next_level,pages:hidden,pages:starttime,pages:endtime,pages:fe_group,pages:rowDescription,pages:seo_title,pages:no_index,pages:no_follow,pages:sitemap_changefreq,pages:sitemap_priority,pages:canonical_link,pages:og_title,pages:og_description,pages:og_image,pages:twitter_title,pages:twitter_description,pages:twitter_image,pages:twitter_card,tt_content:categories,tt_content:layout,tt_content:frame_class,tt_content:space_before_class,tt_content:space_after_class,tt_content:date,tt_content:header_layout,tt_content:header_position,tt_content:header_link,tt_content:subheader,tt_content:imagewidth,tt_content:imageheight,tt_content:imageorient,tt_content:imageborder,tt_content:image_zoom,tt_content:imagecols,tt_content:pages,tt_content:recursive,tt_content:sectionIndex,tt_content:linkToTop,tt_content:hidden,tt_content:starttime,tt_content:endtime,tt_content:fe_group,tt_content:rowDescription,tt_content:sys_language_uid,tt_content:bullets_type,tt_content:table_class,tt_content:table_caption,tt_content:table_delimiter,tt_content:table_enclosure,tt_content:table_header_position,tt_content:table_tfoot,tt_content:file_collections,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:uploads_description,tt_content:uploads_type,sys_category:hidden,sys_category:starttime,sys_category:endtime,sys_category:description,sys_category:sys_language_uid,sys_category:images,sys_category:single_pid,sys_category:shortcut,sys_category:seo_headline,sys_category:seo_title,sys_category:seo_description,sys_category:seo_text,sys_category:slug,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:title,sys_file_reference:link,sys_file_reference:description,sys_file_reference:alternative,sys_file_reference:crop,sys_file_reference:autoplay,sys_file_reference:showinpreview,tx_news_domain_model_news:sys_language_uid,tx_news_domain_model_news:hidden,tx_news_domain_model_news:starttime,tx_news_domain_model_news:endtime,tx_news_domain_model_news:fe_group,tx_news_domain_model_news:alternative_title,tx_news_domain_model_news:teaser,tx_news_domain_model_news:archive,tx_news_domain_model_news:author,tx_news_domain_model_news:author_email,tx_news_domain_model_news:categories,tx_news_domain_model_news:related,tx_news_domain_model_news:related_from,tx_news_domain_model_news:related_links,tx_news_domain_model_news:keywords,tx_news_domain_model_news:description,tx_news_domain_model_news:istopnews,tx_news_domain_model_news:content_elements,tx_news_domain_model_news:tags,tx_news_domain_model_news:fal_media,tx_news_domain_model_news:fal_related_files,tx_news_domain_model_news:sitemap_changefreq,tx_news_domain_model_news:sitemap_priority,tx_news_domain_model_link:sys_language_uid,tx_news_domain_model_link:hidden,tx_news_domain_model_link:description,tx_news_domain_model_tag:sys_language_uid,tx_news_domain_model_tag:hidden,tx_news_domain_model_tag:slug,tx_news_domain_model_tag:seo_headline,tx_news_domain_model_tag:seo_title,tx_news_domain_model_tag:seo_description,tx_news_domain_model_tag:seo_text','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:div,tt_content:CType:form_formframework,tt_content:CType:felogin_login,tt_content:CType:news_pi1,tt_content:CType:news_newsliststicky,tt_content:CType:news_newsdetail,tt_content:CType:news_newsselectedlist,tt_content:CType:news_newsdatemenu,tt_content:CType:news_categorylist,tt_content:CType:news_newssearchform,tt_content:CType:news_newssearchresult,tt_content:CType:news_taglist,tt_content:CType:mtosafi_tiles','0',NULL,'web_layout,records,media_management',NULL,'options.defaultUploadFolder = 1:/user_upload/news/','','',NULL,NULL);
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1794119204,1794119204,0,0,0,0,NULL,'a:7:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";i:0;}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\",\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":0}',0,NULL,'','_cli_','$argon2id$v=19$m=65536,t=16,p=1$SC5jQVhyTVMwZmIuZi9lVQ$my26zjcmtB0GZl+0EIiotj27ERAFI4Epms3l9llGZqM','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1794119204,1794119204,0,0,0,0,NULL,NULL,NULL,0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$NTQwSlBTTVJPdDBTeTNPaA$tH9SFkLNfU1mfU5cvq+Ot4SY54Kw5EpathLn0W0x2EY','',0,NULL,'','admin@mtosafi-demo.example','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'6_3f7368fe3a6e05a9',1827067569,'x��<�r7��w��lr�{��7MqK�e[�h˒\'Y�T��D4_7�h����a��=�=�u��!E�r��E��3\r����ntС�?���P��]qKyȇ݇bzn��H�7����Ce���WG�?��y����������a�Z�=#�E��s\Z�,:P�h������+U%{���,��x��%�E�\Z�ZD%�\r}pwF|��6#�GB�Ǿ����d\Z0F<��$���d�H�N&ԅn9��$�[z�5 ����\"f�h$)����rqMi0�~&Ե��M�P��=}�����t�@���U�g�h�A_՛z�x�*�}r|��s�ۀ�A�h�x@M̈/�#K�!�9q�^���	~p@n�� D~8l4�����`��SU����k�h(�(d��Ҹ�!D�h��2[=��k-�m���a@�M���i����\rۛy��b�w�7�Zz_����\Z\r(��Ʊq�#�l|�l �pԐ�=�.�@�1���@!�r(R�G�;��Ζ�D��KnE��-`\\T�� L54��4T�b��he�p�X�IAH+b��H�a�a���:f�lS�3������uZMC׵f�35��P	��ִ��u�0�����Jpg�#�nJ��ii�֫��&u=�C�S��^X���-��>�X#`��L��\n-�FK������\\(���9$n�.�ǷP� \"tHu��}�q�Y\\]Q�֜�@�F�ؔ�v���jH?72<k%�<�\r#\rݸ澊\\������/\0�,��Q����E�\Z���$n�⋴4�|���BD�\0��vu�]�k��O��$��>��M���d���_�|p�6��������o�N���)�5�2V�.��q���@�_�\0��B��\0�L���l��@����HP\"�;�22#e|$v�S���j�9W�h5Y��\"`���K:�6��;��^A�\Z�S����55�5Mj�*5<G����d����ܙ�00�kn�?P\"�	����Y�\\c%&��p�Q�0�:����\r�G+P|�\Z�T�z��^�����+$�`�R�7PE��Q$`}G°RT�ès>�x�S&0��_�Q֨!p���G�[�T�鬟�}��l��0�h�Lj��˖�/�;���/���^�eb��Q���!K+#�@�9,|-j\"TՋ#p���P#o6�YJ5�A�/vCk1�Ĕ�!K�\"��l����P��,��\"\n4k����rR��:k��p\\3��������3�aRmA)�hv�[�4S��A \"�(����e-�o�����#�Ȏ@��F��<yS�0��sP¼(�lRQ\0N�2x�(�K|M$��&���300A$�ze|&���lR�S�G��B��!1Aɘ�I,�o���քƘ9{@b�c�\r�Q���w\'3�+�u�W[񎢿���Yn3�/ʒ�u�>�R�]ށ�Q�+)Qڤ�Y�O�3����0Ǧ+�?�U\r�� �Vm6�68mY�\n�\Z�[Ѩ�I���0V&�Y�*-PE^]3�\n<s]N⥪�{�o�R7�l������Dݪ�����r�\0Ո၅�k�@NR8��/�x�k �N��g��ۗ��\05%�\'�����|	�7U9��a�\n.���O�<���RƳֺ:	�)q]��n��4^�ѕ�L�*�TM��E�S\\�$��t�\"y�@U��M��t-A�/j�aoH�w�{���zA�[�£\\߄���zˀ�~�nE8��+�X4g� �cǅB-���H�A�.�{�-w^��֠��mp��ʧє�b\\�(D_��Q}?���F1�Mi��1�63w1�eW�o{�j�2s�\\0���\Z�B�)Z����\"��\\zd���@��������	%��1�̹m�)��&�eF|�`%��7��ڱ\\���&s�{\0�#jز��oB��j�^y��l�胻�Щ�,y\"r��5rA������W�=H�E?���F�:D����u]��\'�L���2�`�\nY��,��y$�%�;(M���j6�5_�\rǵ)���m�-���^�㿆so	�V0c��j�\Z�Qj�PИ�))V$�i�U�rr��\n��xo���[g���(oT\Z��(7��E���5mt����8�ʸ��ۆ�1���7a���g�;0/bĞ��rˍ�fl�n_E�� �:#n.��g�u57�T4��R%� ����tQ����7�5���`�\\�#X��d����RBݗ�*����АF���)��]b!F�Hp�D���|�Z��,� ;��T�^�?j����뮈�\0�HK#\\��\'O�!�~��Y�|k䛴S�u�w�]\"&��@�6�z�|��bקܒ���n�{�k���-������4�7�Jy���9�Z򋆘�-��_˕��Fu�}�_�m�֣��B4��ۖnXpkA�I~�NH�-2\n>iڀl^��e0�Áw��k�m��8����\n|N�˝��Ui����/�<4�ѝOSjd�V�E�,��(ܧ	~Y���fm�v�e�{�xx�VM�L��I�w½U������QJ9��E�o����q|A��f�K3{6��ւ�<�a���4 m_�Àv`��f@�������pp��8�=\Z^��ۉ���.�n/?��z�b8��M\"�G��Y�����v8��)�¥)�����|����,�e���x�^n~e��]즛�!�we�L�\ṛR�����*��p7�Ҟ��\"`�խ&;�*<Łr�����W���O�@6`c#��0,��ۜ���tS����B��J��S�R�\nŶ�>�����Q\0�J��P�\\�s.�Z;��^�t׎d��0jk��$///(��敮����K��Rak�S�lk�QRqd��c�����!�A3k���S���<�ȓ[7��[�0��8#i�f��Q�+l�|*�J�O<��F��C����R&�HgԐ�P�[[¾�}\0їm���d��˙�:d�g>�E�uc�`����A>\n	#��p4���(�9�%�1����`�)�;�Xhܨ3TQ_����u�/II���~��0���s�{����/3B�3+��%��Ap���Ó`J�\'}� ��d�Ća�mX$����&�b���ֶ�n��	���h��$!�#��L���<����U\'+�$��?��3�E#˒��(`�~CCqM���vX�;X�K�a9Ɏ\\յ�im�P\'����\\�~Ò��X�L9A�N ��\ZSD�����Ym\n���t�8����rq0~���Ѳ?6��<? ��\"��Ά_�a����<[=@�I+=ʲ�{:V�=����ܫ7i8O>\rL:�O���|�3�q?\Z�F�<ZxL��QO�v�6$�J�;Ӛ#�U�<:��U�֔���5k?E(�Z_]%\'kb�\Z/ژ	)�Vw�{�8�����+1�##�#Z�5��ܣ�����}�Ȼ!��z�?I\n�?M	���w����ɵ`��tP|o,�}`�I��)a���j��D\\&?}�6�w	�j��Mg�����ĩzj�݆lF\\�#B��b�\n����5W*F;�J��w\"��\Zy��g�N{�����g����,/�ý�D߬|���2�։@�Q��5������)x\n<�U���^ģɥ����Bx*���碋Ĉ@�`��Gw���9]����������������6Ij��,��!�~r×����-��ȷ�\"yT@�\Z��b��hٝ-��!Ho�D���U,�&l������5%�C:l?|��}y%̹�z\\�F�H�=�bl݂�fkj�;Mð�;/ӮF��>Ц���i���\n.tL�օ\":l5�\Zd���y�G������{\"\'ׇư	-�C�����a\ZM}w4�xw9޻S,�����{�}0T���J���\\�]G�Pw�G����{��TP/��-�L/v�`%[\nx3�[삥u�&�`�Y�� )�,�3��59�ࣸ����	ya>4]��r�\0�fX���rE $�!.��HE^�3���3e\rX��|��q���\n����3S��W.R�r��+q��b��\\Ϗ!�+å#*��I�/�L�	&��gzOM�}$_�U��H�j�����G�Rs�w&�a�	�U�^���l8�\0܌�a��/��mW��>����P�Ӂ�*ɠ�8�otI��]8�T��#��?{�t(.�i��$0��9��+�\r1�G�q�4H���Qf���tO�9ť��8���\Z=�5�)�1,����N�R�3�O�`S�e�j���fAڱ����_�ǍB�EYt؈Z��X|{�&��g#��P���a����jB�6s+\Z�������\r� swVS1w0i�P��@zȲK�.�S��m�SoA�Ħ(T.\\,*,/�~ˣ���V���J��X(l�cѻ�ć��ԢŎ�K<��������W?�	��ګ�g�\r�&a6zmm��D�wl�X�,o�\nr!�j@V�3H�XQ�m}#�g��������+Y���/V`�$@�al��s)�Xv+�-x[ �]���NRȦS���2�`��4������mBy��x�#\ZXwF��X��hp�n?&�G�G��[-8��a��w��05|�B���\n.�^�?�&\'���̹��Z�)�����Լ��d��*���|O#y����?p!�ׇ�gi�rC*g�{����p���M{�2ӻy��%�C�G��um{�O��������G9������yy��ެh�t��	j���.������WWCƕ⊸��m��.��A���&�q�W��u��n�jP��ccA��r��Er�ȝ(\n�A��4�3�Rp)�+\'��Y�g���z8D��l�Y��w1�ƪ��?,�we��m1S,�f��י_���:Ed�i֚fZq\\bvD�9�%կ�gE�w�Bt+{��e�-�,ռU=Y�����Y��D�����ii�� ��0 �42�����\0��2g\Z��_;q$V�\"US,!�㧴��h����P�J���R��00Uf3G��C�w������ٻ�=>}�cd�}>{s����bſ??�\\{vqi��O~X�9Pdͦ�߱G�ޓ����ͣ����7�e�x�����6�߄�o�^(?A3���0���h2�y����k�x��\'��o{��ڏ��?�N�[+zR` �z����W��W��[7~�^Z,~9����>��?�p��g�����*xz�}����1|3��{��G��ޫ�񏓙�/�����������ٟP���������Af4���W��\"��$f���h�-� A����N	�N�N�A}�H���~�CȠ�6K�H+!o\nX�y�L+s/ѕٗ�J��_���X��VtA�\'fEWIޑEԔ��������k5m����2�*�B����JV28�+��\n>�P�ɂC��o|����f��N�#ku���N���1�45�e�[�i��4�V�c�&����t�1:�t����fWokӦ���Ӵ��7:Ơ�3zS�ӛ�t$������@�'),
(2,'6_4e2027354efdea05',1827067569,'x��<ks�F����+&ؤj�b���)^ɲd˒lE��l�)��c�����?܏���S�\\�@<J�#%ٽ��&�3���ӯy`h�0�?��N_��]s[{����b	/b^�����;6��廃����i�:Ý��z�=-\\�\'�\Z���;�.�(��4Y����X�B���W�Nv��j�C�`��G���/,`6-	�x� :�^��{�3�;�D����}�ehG�8`��y$q`1r�X\'gԃn��xP�-D0�<��q��\n��\Z�, �3J���D�g�[��<�l({��}����n��%�e�\'ӈ�^W7�f��q�.9�vB.<�6`�fP9�2��A+�s���cAd���\\\ZA;�H�G�D0��k�h�Ʈ&�]G�:ܛFgO��F#Ӏ����5\ra �Z��ٶ��M�h���^������5��v��#&b7�O�\r���h�]��c�kԠ����Q�x�ተ9YR�=僚�(=�@�{ڄA�h$�$���)q�]jźs���\\������04�|y���Z�a{jX^a�tX8e,Z	B\n,b�_K$b�a�S7ZV�jR�5w�֨�i5�#�4����j�B%�D�0z��҈�lN�4�$��N�[K�\0q)�Rb�V�0�N���ˑ��\'<�O)��a3W�� �]��Z�\0�>�_w��}Q����K��ӊ�C���B�̜y���{�lμ��>]��\"���0�,,J���r$�����m6������j��\rF�^J���`C7f�ב��q\\��E<�dJ�N\\\Z��̄����F���\n�%����4����B���T��k�y,_[�}�\r�b��S\\���O΄����_G\'�~��F~���7��l5I���ߠ&Q�zt�ϩ����ul�.-�ƿ5����A����-��OAɵ��Hn)Y~	�\r��!N�<i��;��mWS��_��]�E�,.z��S��VԿ�֠ÙS�\ZhY���qM13�S��+��P�d@W��H�����c.�{�FT�Zm �0��\n�(�y}�!I�ArI�|��q2����A��V�T�Z��2\ZXS�B���QC��RD�qTeOip)�9c�q�)o9\0�*�^ILd�`�3�9$���R��{~n�U���Ӽ ���T8��!e�����O�π#7��$8���/�V��ˣ��AM��F��b�`��+Q���\"��_3��\\��dⰔjʃ�k���f �1uB�@en&��\n�d����<�]%\nt�\"e,�=�I����zW�d��x9,9F�A�[���o�k[�蝊0��EA��&��hU�A|l K�K0�}��1����&<��D?q�8yWL�Ad�)�x���p��\" {2q8��֌���b�~�@��\0�1�ll��0����d�Ri�LY��#T�\nmr�����h�o?q���x4,��x��U��XY����բ�V��2#�p�5�*�V�f�g�`eP]Z%<��Vs-t�+g��ɏC�N�]�� ��G|��z\r��-��z�̩)��R�p�=Z����W�Y�gj��^��>�SsC��\0���B�{bBiF��\Zlv����nM��:e�Aq�������jNDd�S��}[͇���A(fu|yz�nH]\nC\0q*\0ك�*\0�)|1Š�A3����(����p���nj�� ��SN�\'�N-��JǸ�I���bF�I�����VJQ}�y��Y�6��|�]/(�ʌCxT����=��\'�s��܋p,5b����܉]\n�&W.%����3�Xl��Q�@������]UO�1�ĸ��PȾ�Qu?VSn�<7�u�ژ;��܃$�ױ�j�|5�^-G�|Z[cTJ5E����:���_-�\n ���q0gKfìQDB�$`�#S�82ރԢ��!�A$�:�22�N���az���7�Gt�R��	=S�rDs��؛�;+��s�Ԟv�1@f��&1��w��@�W�<0�1�|1�p�e����̠��Y�1��tU.��uGg��:L��d���#�,�<@��%�F�������m8.q9�̸V��VX�)�r�\"�%D@Jf�h�Q��������h@hd�B��\0K��2��ō�\\b�f>���P�֫���h�	(5,>d��\n|������\r��љopo��s6\Z�qI\'ujo�\\Q߄�\n�^��x�i�gˑK���c�n�d�Ϗˑrs������ƞʦ�P���G�F���t��t��&<���.\rv�h0��֪�mM�)K:�P)%�}ծ���h\ri�\Z<����IV��&1F�� Rdm�3ϖ~g�X�ՙ�ĸ1;���Ì���%1�0�0��C@�d�����X(7]\r�M�)�y�C�.�#��	�RtaN7]���Ş�E�^���I�l0���s���Z�s֕�)Tʒ���ɧԒ_5��n�*��\\ɅTkT\'<�ۻ��z4PC��������{V�[�q��$y�u���/�A�M+�k+�):(�Nex���Փ���������O��LKWO�<4�Н/Sjd�^�D�(��(<�	>��ll3�6�n�e8���Ͻ���t�ho��N���V��n+�R���6j�\'g����Z��S3�6��ւ�����4 c��À�`��f@������np&Mq��hx�?o+f3���0G�����x�6~ ��>�$�jT���<!��j�����5.M���t�c��� dV~-;]��#�jSlH��.������MY檉؞f�y����5��c��l��l���F#�v�0���{�6��|�ROnk��H�.�7P�e�:����!V�	y4[���5���R_<S͖�A\n���Pn�D��gt����O{��S?j��p�c{�Mح�t�%�=���Y,\\h�7�sD֎kdà��k�6ғ\Z��N�L�D$�<�0+�/��\nN3T���Ι��|�)���5�1g����<kZ�4����m��M�MC��Vt%�N%·���P�:��5\0�����s!�3z��ܦ̗Rh�)@R���{\Z��^��w�)jJ��Ͳ�%�GP	ɽ6��`����m�#WaM� R/���#N�H#a�|�z�%:Wت��LK�k�ꪎ4Y���r����:x��=��_������	w��K���ӹ�ݭmH<��)���m2p����Ӈ[�2���z� ���І�o��_8^$u�8���#�ED6Mv� ��;B���M՜Æ�$�^Ra�ϡ�pxT���j��Âz1��/O��3Tضr.�ɀ���r2��+&u>\0჻\0�Z��p]�#]U-��|G�*�E\"��6|�j�R�MHllQ$�`Y����3E�#]���ޤ�6�jR8��ds��|\Z?�������D�C�nח���8L7�q�|�a��-�!��O����U~R�g��!x\0օ\'t���$��L�G�)V����.9a�W��b܏��G����)B�qY\"��N9�߭!���1Ҵ�@~$��CN/��w�\nT��h�7��\\�����d�d��ۂJ�Η?��:<>��\r�;�}�N�`๯�%��&F:�}�K^�b��g��,I����)�mҡ��\\Ry�Y�*;������(�𔰓�r6�1B�������B���69[Ep�t�9�����tn?R��~<�3>�����*�S��!Ɏa*5�Rmx	\0��\0��f�ӈϨG?�o���k��g�Q:���-��1���~�}��m:3(��J��W��m\\f0`�n�O๯�} ������LrCu}�?����4�d:� 1�FP2����C�$~C��R��\0�DV��>)���o�?��)R��B�/� =��O.�xJ��#�����f��\'�\n������0��cu���u2�}\r�;Y���ju361����+�Y��9���?��]uE�ûXXp�G�.�א`��n6���t��h4�ݞ��V�ժ\r�ݵ;�6�.<{(�z_��F/�Af]1goB<E�Z�GW�H���~Z���#�����~\ZHM�xpv��@��)�[�=�i�b���?����@��1Or�R%xp�<�Im��S(O������K�R��	�f�,��U05g0es��یu��yg!|��}\n� ���i#씏r �m��z	,VBj\r�6�Zaꨩ{��t~��ؠ�����`n\\�<Pa߳_\n+US��#-/��q�k�E����U\n������ݤ�Wt\"Q��;t�#�7\'�>����ݹ�\'��Z@;�%+�A�Ԣ��3�aV��Zm8�܊�afÝB�\Z��ʷ$�EM8��zړ�^�\"��%S ��c���Y��.���O^���=5���տ`꾧�v�9ԯ]%\r�3�]���y=���|Nq�*7�f��FI�3M\0{�`�{tx�$�)��g�cS�e=j���Â�ci���c�k��,2���<���CO���F<���Sy�:��#F��C>�J\Zm�;��� ��{US\r1wq�vF}=�![�{u%N!�ϵAg}�#��P�����<G���Ǫ/XA�;��C��%G�E�:�R����,���׸��8v��\nL��M8�^�z�S�Ph�F�i��<S�?��<�ɂLH�\Z0-���X^�Ms#������̄���-U���z��sr%n9�G��\\*7�����\r��6�w�MRʦ���%+Ѽ���*������lBy��x��HF���X_�hp�a?\'�Gƿ��F\r�ge����~�&���WYBf|9��Z�v�O���\ZX�sJ\r�ҭo��}j�0���r���$&4R�ک���*�}�Vf���2�1/�`\n��n#��o�s����z.Q�?�v�+;�ia7$οVo?� ��ӛ�(\'��^�\0�~Kjȫ�.�*���I����RKyeݪ�M��!_	B���&�q�߀�|2U�e5(M��6�Am�X��EM��<��dd;Iӎ����v#Ⱥ�E�y����C�9M?�����t�m��(c5�a�K���T���0S,��F1S�2�m�u���Ӭ4ʹ��Y���,�T�2�ʚ/������9���TLmQۓuI��Ϙ}�Ar��)w���j�,���L2q��5��u�&����n�u���(�	�)�\'.�d�j��g-Hg �����a`��a���;L��j듋�W�zg6yyz�cd}x3y�����|��8�3�������[��Ӟ����g/��������/����f�yÚ����رno�7�/:��i?A35��`�hvp���y\\��=�X��&�G��o;͓͗�rnO߈�[{I�s�F���v���ni�}��/�[��o{����Nۧ��{y�}8˵\n^]~�<|�����QϻXt�ά���ǳ��/���O3sy�j:��R2��ὢj�h&���s9�6�@�!--����S2�,�\Zj@��F�$�w����!���d��yO�����Ȍ\"�\n]�}������:`*�u\nme�nb&Qt�L=���)��^Ғ�L���\Z3])Y��腒�0�\"�\n���[�i�\\��m%w��f]	��PΡ�s�7>X�3t�N��A���u\Z�.����1G�xl�F�x�6ؘ��Q�t�ޥP��u��f�=j�zָ�kF�g4\Z�Q�=b]hKm�du��R�cٴ;����]r');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'6_3f7368fe3a6e05a9','pages_1'),
(2,'6_3f7368fe3a6e05a9','pages_5'),
(3,'6_3f7368fe3a6e05a9','pages_11'),
(4,'6_3f7368fe3a6e05a9','pages_12'),
(5,'6_3f7368fe3a6e05a9','pages_13'),
(6,'6_3f7368fe3a6e05a9','pages_14'),
(7,'6_3f7368fe3a6e05a9','pages_15'),
(8,'6_3f7368fe3a6e05a9','pages_6'),
(9,'6_3f7368fe3a6e05a9','pages_7'),
(10,'6_3f7368fe3a6e05a9','pages_8'),
(11,'6_3f7368fe3a6e05a9','pages_9'),
(12,'6_3f7368fe3a6e05a9','pages_10'),
(13,'6_3f7368fe3a6e05a9','pages_17'),
(14,'6_3f7368fe3a6e05a9','pages_18'),
(15,'6_3f7368fe3a6e05a9','pages_19'),
(16,'6_3f7368fe3a6e05a9','pages_20'),
(17,'6_3f7368fe3a6e05a9','pages_21'),
(18,'6_3f7368fe3a6e05a9','pages_16'),
(19,'6_3f7368fe3a6e05a9','tt_content_13'),
(20,'6_3f7368fe3a6e05a9','tt_content_14'),
(21,'6_3f7368fe3a6e05a9','tt_content_56'),
(22,'6_3f7368fe3a6e05a9','tt_content_15'),
(23,'6_3f7368fe3a6e05a9','sys_file_12'),
(24,'6_3f7368fe3a6e05a9','sys_file_metadata_12'),
(25,'6_3f7368fe3a6e05a9','pageId_6'),
(26,'6_4e2027354efdea05','pages_1'),
(27,'6_4e2027354efdea05','pages_5'),
(28,'6_4e2027354efdea05','pages_11'),
(29,'6_4e2027354efdea05','pages_12'),
(30,'6_4e2027354efdea05','pages_13'),
(31,'6_4e2027354efdea05','pages_14'),
(32,'6_4e2027354efdea05','pages_15'),
(33,'6_4e2027354efdea05','pages_6'),
(34,'6_4e2027354efdea05','pages_7'),
(35,'6_4e2027354efdea05','pages_8'),
(36,'6_4e2027354efdea05','pages_9'),
(37,'6_4e2027354efdea05','pages_10'),
(38,'6_4e2027354efdea05','pages_17'),
(39,'6_4e2027354efdea05','pages_18'),
(40,'6_4e2027354efdea05','pages_19'),
(41,'6_4e2027354efdea05','pages_20'),
(42,'6_4e2027354efdea05','pages_21'),
(43,'6_4e2027354efdea05','pages_16'),
(44,'6_4e2027354efdea05','tt_content_13'),
(45,'6_4e2027354efdea05','tt_content_14'),
(46,'6_4e2027354efdea05','tt_content_56'),
(47,'6_4e2027354efdea05','tt_content_15'),
(48,'6_4e2027354efdea05','sys_file_12'),
(49,'6_4e2027354efdea05','sys_file_metadata_12'),
(50,'6_4e2027354efdea05','pageId_6'),
(51,'6_4e2027354efdea05','pageId_53');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'6__0_0_0_0',1798123569,'x��WKo�6��W:��͊zX���`w�-��Pg=4IɄ%Q%�u� ��C�L��E���f}3��}2���I��\rɓ,���u�y7\"_��O����2��6�n-��,�(Ȣ�B#��Y��c���Q��w#��d�Q�1���x�\\$ͽ��R���9�=��TF4�ub�5�rO��G�����Bp&L%�v�� �׸\"Mّ����wT�opKo��e���\'��}��xĘ(��]���\ru��+WX:w���Ǚ���<�L��Z�Ns5DA\'��c��\r���?��s�{��l?_\r���+|w�z������OgF,S?�702�w\nT6��%k�j�.ղ��!��yĢn�c���;6;RaxMZ�*V��.����&�f����b�ӱݸ#\r[(h���IW]i��{u7ג}\r)����nv���S�r��m���Fq���;m\n�JHr8;RJ��^w�?B�؃\\u�ƭ�5�+�c�����֧�v��*�q0(���Az�m��vϙ��/�՜kh������E�����x\Z�5\'�n�(Op-�����N*���\"��9�u��Fj\0�$���nM�b���`6#jxY���-����]���X�mXZ�u�3�P�`Z��qh���-�O3����Ԉ����n��B�sX4��?i���E�H�g��%�ą�*��SLE7�����Gv��l%>!������/�\r`Q�ﳃ7��섁ΟG���p������F�b�iٿ`�|���W0��-�$�c�⺫������s.��ܢ��^���!���o��.~\\L�z\"�6�3ٽh�Ek�	��b�l4�+����;^�����9{��W������4��[�!�~�kr��W��1���taW�Y70?�A!�L�����W ���ϲ�~��\r�}&Ԑ���ç_o���=ZG�����O��7�`�N�,�����W��WêM/�˧�[�@�ڧ@p��̗��oP��,���OÈ$qd�diH�A�\\g��AL��gi��\Z�(	e����0��~��\"f����,$I�^��0�m�b�'),
(2,'11__0_0_0_0',1798123569,'x��UKo�6��W:�(��FF�Z_�9�Dpɑ�XITI*�����s���!��Iߐ����<�_dN�X�d��������#w�o;��_�{�XV��dQ��l5Z��%�=X���٭��r�jke\r3�נ.��^�Ԫ��&\'��{�A���M��H��V����3�ek��P���V��f��1C+֔+�N�6�Q��-���بN�%?�ϰ��$ф	Y�q��Io�ۆ�AS���gpoN3����<���6�3����pƇ.:߽У!��;�x4〱%Kh4����_��O��|��(\"N�`\"�l�2�Y��\Z�]��V5m��c�jա���n���[xn�Ҳti�)�j��VK�ڃ7jٿ�&�����`��1����Uv����LՕӭ��ŀU<�1�B��}w�-�\Z\0�P�K)G�J���?��A�����I��M��\Z�\r\r�N�,\'��@��b����~v�.�:W�f� ����_�~��㲁����j�5��[����E�����T��[��,Z��\"vp�+-��^�?$��6�j��`����Э)�A���+XLH{�/;�4��Vʺ3�Ȑ��\rq���\r�E�\\�Vo�!�t�|9D�Fڠh���f;�ތ����U\'���U�(</������*�_RL�c÷�B��7��\'�Q�䬢g��˪��_A�\Zo�zx���Qv/-v��Sv�]�s/^8\r�6δpM����`����a��ZNE��V\r���i�׾�W���N���N]�~�S���y~9�1d��?FͯopϦ-�$���XĨ�Uϟ�\Z�^|�X�����ӗ���|��{\"�A��۩�~�@~���؉�M��������8j������\'?k�O\0�l\r�����������qƳ�3�$Q�pB|��� |Pd+�r\'~ś(�6�B�*�WY\n�$\"��O$Y��I�a����\"݄����'),
(3,'12__0_0_0_0',1798123569,'x��VMo�6��W:��������`7�h���\'�G2aITI*��w�/�v�@-�`o�{����Y/� ��H��Ea�\r�{����g?�WRxF��#��qFAML�83p���ǡ���\nΡ[���Ы2F��`x:�\"Y�U@k%�Rx�7j���jk�&���Sr�t�Do��P�\'��id�[���>hڰ�X\rt�~�0FC���LAg.`-U��#���6 �g���Z�u��ޔ�	�@Q���p�Oo2���7���5P���ul	|��C����dv���x�c6���H=��@�{x�������WE$�̍�[lY9���V�VJ��?�Uj倄��y���ṧR��m�m�0в��J kޤe�&�5���zX*��6(��;#�wOBɮ�]}�ǚ+K��t3ԣ��#�~X��x|�l*Q�*�u���(\0���f�x��;�v��4� O�X�(�M���N�:�D���>�	�QsGH�sC;�L�`mD�s�Q�L�/�s��`��3�Y�\Zڬ�-P;�n�J�Z�B\'��ʭ�e�	m�I;8��z./�O�娳�6��f0K6t��, E��V\n��[��* 4��RR\Zw�V�R��!�0�{Ґ��eU�Ǳ�Vt��j��$�P���so;΃�4GEW6��k�oJD�=�gWL�V�i�~�bv�r�%T\n�p�G����D�\Zz&<,����o�\raю���\Z�`��`�/=�G�{��ip�J��K%����I��^���?eNE���=4�4�-���d��k�F�䁟���6�#�׷m�}~9�1���_�ү�pE/��Vt\Z�I�?XѨ�O�]~�+7����a�?��v���[�5jT�����|�UY����*yN�}�[�z\Z�������\'�Ԋ�\0l�є.b������(� LX�V2R�I�G	T@�d���a�I�d>#Y\ZI��☱���(�!O�M��<�� N	�<*�$�#�I�?���@'),
(4,'13__0_0_0_0',1798123569,'x��U�n�6��+-�r]Ro���H��@��L]�Hi��D��2��^�5��@)#;�\\�ι�4��g��{�\'Y��� ���{�����/�=�\rm�H�(B?\'K�5�ʒ��\r7|􂦳;�� �=�-_0��;�\"i�U��J^�8��7�R��ch�۠8�=%�.�荐�q���0�,��[��&\r��֜��6�`ԑ�*ޙ+X�A�k�-�a�hƘ�����7n�/\\��Dx��L����>�>��U�ɠ�:����{����;�Ox��bɎkh0m�ڐ?6�����a�D�\"fRr0.��t�TJ��?�]j�\0�@�y\"���SO��K��T�Ҟ�J���I��.�E���{�t\0�6 ��[�VQ�o���L�� )��7��c���������̾���\'Fq��%�kȍkG�yC��1�	�¶r3=����t�Y�}�3�Ύ�˃v����q0(���AF�Sm>�v����ϝ͚k`�*w�عu�@����|\0:I4��ܹ^y�V���ǃTL����m�qZh�4\0U���C�&	��V�����z������ҸS�\n�ȵ\r���p�I�ӎ�U�^�V���d�|=�G�FҁH�f;΁�4GDW6�\r�\\�*	�r�$I%�F��� �;x y���n����N��!˲�\nm�\0�\Zo\0�v|�N�A� t��Sv�]�s/^9�O��*���]��I��^�C�[�E��V��И��/����ٳ5��Ӛ\r1�|���k6��w�e#���rƀ��-0���ռ����?���`5��>�v�\\�1l��A���?�������\Z4�����z����ЉíU�\\��}[�v\Z���������jŏO\0�l4!����7��_X�I�#\\T�Ƹh��JC%I�W~�4N+?	C��iX$q�q�Ӫ�1�pV~Ĕ�0�����$C�D��\0��U'),
(5,'14__0_0_0_0',1798123569,'x��UMo�6��W:��HI�##	��Q�Ρ\'�\")-����T����C}-w�)�C��Mz3��yá.�e�ni��ų)�\"$n�o��~���MXciۏ@�\'Q�<�,LsjŅ%-.\Za�%�|��s�-@^U[+[�`pLt�G�\"���\Z �)P���h������8s�(.���aZ�V*�u?�\\�F���u����v�@kA��G$iPؑ�j��بA���(\\`;��dƸ�����L����Dy9�ܛӛL���>��&tk�`�>�E>��B��C#4����x��rJ�kj0=��@~�{x|����׏VIl�ϝ4[����:,�J����ځ�V\r`�0m�OD��x�Ҳ���Z*�hiOz-�j�$��&�E���z�0\0׶ ��;��s(ɮ��V2��IC�\0a�f�G7`�~����j||��*Y�Jp�o{b��-��\rg��\Z�)�����uJ�x���z�:n<�:���5�1�	�y���幣m�ka=jmd��Q���Ͻ�u����sge��5rU�� n��\"��@ks:�\"FPͶ~�E*�U\'E��a�473�Ƚ3��NKc5ev�J:X�ׄ��b\\�	D��{A���8yi��?q�H�Zi�8��=iP�V��q���l�%K�W��I2 \r��q&̤9\";�\\�l�zU\"\n��x�ŤH��F��+fǡb[x,E���~��5�S�d�!gê�H�\0�Z�\0�����Av/-0)?�.��/�⣍Q�}�f|cvb�������-�\"�ѩU34�4�#���{�r���rc�r��|�&7�>?��t��_F�/opM/����\'��;XӠ�O�]>�������׏�?�q�����D\Z\Z573�W��O_����_;%���װ���Q[�+�-�x����	�&[C�\"���\r���%9/+\Z�1JY\Z��4Mc�Qe8�������\n�0��*��(��v~L�\r��1�Иo�i�gyY�q�i\"��'),
(6,'15__0_0_0_0',1798123569,'x��W�n�8��WZ�޲t�Ŵ@�E�.�\"(�J&,�\Z��c���������\r���!��\\^�f~��3�fI�=�,Ȝ�3���n��O��3G+M�n\0�4\n�����)$�\Z&�4D&�5h����-g�H3�J�y3�נe6�ʜH%E��U�e�������t2�)��A�w���m\0��n6�a8�HM۪��)��C\'�綤�Z}+��b	�sgX�0�h�/����|�����a��� z�d�������DX��3�W�����\n\\a�	�Q�W �]���k�}���7����h�}r��k�6�7�����������/$��Q[�d�k�7�h5֞�R4�;�UjD���y(�Dx��SG���L�h����$GV�Q��m4I���>t0W\0��(�����|��T�W���������K^M\Z0��vDK\0���ط\nce�\"��2i���Ql��î*�-�A�8\'��I�\'H���A3�TV�-��y���A�T�o��rf�la��ռ^b\rLV���^;	w!he�k2D��ֶ2ˁ4�$��B25��3/���\\i9�d=fI{���$�\n��Ba�|)�Y�\"FBRmO�\"D\"�2�f�yOjoՒ����X�w��f��Z���T~��v���Em�\Z��Na5\n��{gUW ��F�yO��)E]����8M��N(%�c�M�[����LMxYT����5a�o��4*D��v\\ZJ�܅9��Q��T2����e�P\'��n�̩�������Z�:~1E���O6�{u�{�|����n��7p���������?F�����~N�(N�����(��缜�o/�2F��~|�������Ԅ+�\ZU�S�߼{���SY����(yJ�}���f������_������?<�ޟ��g߿�}��ܐ�q��X��i��K�C�R/f%�����<O�$�YAi��i	�\\��&�ϊ<ĿQ�,�=?Y��F�'),
(7,'7__0_0_0_0',1798123569,'x��Wˎ�6��+/��ID=,K�.I�HgQO]IɄ%Q%�x���{.�2mM�h���;�\\��>��H\Z��\"�oH\Z\'飆�e+��F��M���o��ҥцT�P�DA�I�[�b��%N�����΋ׯ�\n�x=I���Q��m�f.�N�9ǅ�-�S�.�e�PKeD]tQ\"���t���=�T��	G��.8��t7zE�>h\\��hI��|g�3J�ո!��fk�*:Ň�6]�(\Z0&�|\\�SX���6���t��Fp�O#����3pq�}�\ZW�ƭ���,�xWE��,\Z������G#���C&�a:\ZL�?7�������ۻ_?��1����2�\Z�T���s%+�s�*U���!�y��j�C����6�RaxE\Z�(VsX�\\��Dg�ܙC��\n@���uǇ�m�O%_d�5�za��Z�Z�l����VA\r�_7�PA����^�[��[!��\r���b��mȶ�Fq-���\n�. x��@j%9����(���6k�ک\\M��)��Ǻ�a���mv�Ў;Q7闢�9H7D�ύ�測��smD9�\Zج�c;�n�d �>��Zb͉�[���\\ɓ$v����顼��=�;�d�(BM@��5����A4�L&`J�9����rNIi�1����T���Y{ޓ�kL�b����Ak���i��q\r4�%�э��s���-�g�\\>K	�p�$q.�R���I�[�Ay��_��ml-kAI�ψ�e1;�n���,��;�2��0P����h��s7Μ�G%���Uw��x�Ɂ�֡�ZNI��V�u[�Ӄ��U4���D�ы�a?Z]d�������;�G�a{��ы����(�gl#�I�Ek/Z�oh��d�1�@3�>���-���ދ&�(M���dt���?�������]�_Ưq}~<�E���w�\r�O�P�Gӷ�<����90��I�A�gB\r�A���}�����7ݟ���Q�f�����v�B%�W��C�����U?j�u�x���?���r>����\n��)�E#�*&˒8\ns�|���h&$�y��(���_ӵ�����˼ȣ$���fy@�G���DI(f�f��W�_n�'),
(8,'8__0_0_0_0',1798123569,'x��Wˎ�6��+-��LD��A�$h\n����,�\"h��	K�JR����^�eښ-���w���}��#���y�ݐ,N�GK��Թ�Yrӯ�a�*��4�[�8\r}?��`����8s(��f�wػ唲f���Rk^�	�c��6�dN�p)E׫e�����7��G&jd���L咷���np�(ו�w�WѨ��iʎ����6��Bn�[\"Y�������;������#FyQL�U;�!o�a�Nw��4��?�G؃�1Y+�)&/�����U��}��>\Z�[��x8��>l=�W�i��\Z�]߿�x{���F@�Z�w��B.\Z\rUƅ5n��C�jс��t]?`^���B��n�i)׬&-n%�>8���p�;}h�T[1����F�(�*SB��+{7P��2o:��%�\Z�Vo�����\0$y���\n^�T0�߶XKƠ]��;�CSKt8;�Ҩ�A�V�=@��Xw�Z��*5���}$�fϑ�6��hY2ma�tś����\'JnͬS�e���ͫ9V�d�o63l\'��R��ihV��|k{���kq�Ď�BR5��wf9�d��$�\0Ȓt\Z�9y��2&������ g�\n~I!�=r3K����v�=�P��(��P�\r�w�Z<�|���F�\0\rp���B\r�üɫ���+&������=�d�U%�s��q��-�����O���4�\r�I�ψ�E���������M;�2�=�P����h[��.�zG[N$�MQ�����ɑ�ơ�ZNI���V�TW�Ӌ�̳����Drы�\\/�.���Jn�����ג�>H����$�g�k\"X�Ek/Z�oh��d�0^C7D~b��[����M~Q��>���D����B�����&��{�B��g:q��q��+���5!��++}B��(���� �������>�z��ݵ�	W\n8���\n�~Z��j+Tbe�<����u�\ZFmz�.���S\0�g��Q�\'2_���B���(fy��i\'A�!�{�秞��7	#��;��9!	h+r�eA⧱�4\'�\'4h\'�&4b���^�Atc�'),
(9,'9__0_0_0_0',1798123569,'x��W�n�8��WZ�*MI�l)�E���,��bV%R2aIԐT#ȿ�R/�vZ�`@�s��<WG�i�>�Կ��2I5<z�`ލH�����\"x�S�hC��x�DA�I8XrŨ�g�e�1^q�{/h8���f����Q�	�k�a.�J���R�����Z*#���|�����=׹�b�\r>8���vr�!�פ�M�ђ����A*�\Z�R�sk٩|N�	6}#l@�E1�)���M�+\"��hw�8��?�؇�qUk�i�/�����mtȽ`�\0���<�p���d�94���ɧ������w�~x?S\"^!������θS�ec�ˤP�&��v�R-;08���\"�?�D*Q�c�#�״%�`5{o 3��F�0�5��O��\r���-�3U[n��B�\']u���C>o�t�MK�5�����7�y(�~\r��`[�i�Q�ðd��;�����pw$Qѽ<���{����5�+�K}���]#�e��fSUr�`Ps%����ħ�|i��3�e�w_\Z#�9��V�o8�+��f-��.4�hNU�q�LL!�<*b��;��ۋ�k�|�i����\0��v�5�H�0������uAO: 4��RR\Zw�f�9�!�0�NgR�UC򢜯C�3�oa�d��|ޏN��\Z�\n(�fۯ�8GD�W�\'\r�\\>K	�p�$I!�J��W���7�����C;�F6\"�9!\\��Yh{������7��4��섁Ο{J�3w��3����S�\\Sܿb�|���W��Gǖc����Uq�U�8�}�+nt���E(�����?\\H��AQ?/&M=�]����^�������Z�C6��5L0��/�_��ܽh��d�&�#MFK�C�-�wM���49�9?��\"L����W(��{B�����90���r�p�	5d������ow׶\'Bkਾ;��e����Љݕe�X~��\n��jX��u�x���?��r>���������~�U���et��Ba`�s�PHc���\nƒ�<3��~��,Y�q��c�,Ø�+��@���eC'),
(10,'10__0_0_0_0',1798123569,'x��Wˎ�6��+-��ID=,Y�.I�HgQOPtE�$%�D���1���˴5	Z�-2��s��<��&Y�=�,�!Y��5|�Z���!�����_c���<�\r��Ξ��0��U�[�b��%�<�Knx����nc��U�We�����5^3I3/�P���:C��{�A-�uхR{E����=�T��	��z�	SJ��\"HG4.I]���x(��A��5n�ⵙ�Z��N	\"�M���D���u\'��p~�\nK\'�?�{}�I�Ο��#�ظ�4n5W�8-�x�F��,\Z���s���#�!�a#�a\n\r��k��v}��������(S�[�m�;*k]ƹ�n��C�*ق����<`Q5���R����0�\"\rn�\0�9x=��7�@\Z&w�����bt�A���D@i�/d��6���e[t� �[��-�nȡ����}w�Z���5�w���rQ����6�(�at�q�Oa�$͵C�V��<����{�n7\r�_;��<4�H{��]*�n��=\'������R�;�րh󹱋��5���(�\\C[�rl�-�Ч�QK�9Qt�zy�+yRĎ�R1=��Gg��d��\"��\0TIZݚ��@[�d�T�x���-ה��]���XNmXZ���3)QZc��uh�����3����@\\�l��=簨i�2~�`���p���L�,�~J1=n����s��t�Gv���%%>#\\��,���ssXT��v<\rd0{a��sO��m�ν8s\Zm�(暖݃��=\'�Z��j9%Y�Z�IhKs\Z��>As�O���\r��E~�S�]�~0��߻�������(�g�k3���Ek/Z�oh�;d�1^�7D}��[����M~Q��?���D����B��O�wM�Q�49�9?��\"L����W(��kB�����r`�GY�\'��	5d������_��؞��������O��W�`�N�,����W��W������k�)�����Q�G2_���B�ڬ�<���ђ&aJJ�8���aΖ� ��Ə�y�\"�D4��$J�%���d�D	J|%�\rb�&^,H�~H��R�k3'),
(11,'17__0_0_0_0',1798123569,'x��UKo�6��W:;.���a�`$FS��e�CO����J�JR^/���Z�S�@�\"An��\r����C��x���E�/�����<�,�~���VE`��M7�yEq��#�4�V\\0ipQ+/h��J�E;y�Wm�lČ�1�rɊ��Ҫ��M��\0��Q�ʶr�!�3G�E����0L��Jw=�>��Vl7���9RӶ�i%Ȕ���%5F-������5[�h��Pw!N&�˲��M�������&ʻ��ޜF2���7����6�Cz#��8�������޳?�Ɍ���Q��\\\r���5��n�����ï�.$]0[����ZU&�V\r鎹C�\Z��a�n��l:���e�͵TZ�ЎtZk�(ft�L��jg��+\0a[������I2a�:�֎\0U���H�g��;\Z�\\JYM\ZpU�v�j!�O��[͠�D(�����uZ���j�o:�����\'�D?��F&m��սߜ������ �Z�;4O��Թ)��P�b����^b�\\Vl+��^?	��2�c�*b�l�{�EB\Z��g`\'{���ʋ�s9�tc��̎\0dI{���$�Y{ȡ����U@\Z℥����-�$j)����?�I�����Z�C�7����d����&[C���94L�mI� 5L��0f� �-�{.��m�zS1\n�x���H���E0E���m�����Ǯϭj%�59�V�����o�`�o��\Z�a��B#.=�G���ix��ܧV�c��D\'�:�!:eN5F������ů��o,ߓ݋���1�C�~�ݛ��X�	���|���0Z@�~��z�>���0Y�����}T���lhX����Z?����Wih��L���\n��YX����)yJ���%x=���@���������_l�Ǎ?��Ǿ����&��M�,ʓ$��(i�r\\�Q�6ỵl�c��$F%���l�!\Z#$�>8+��8��U�nX,V!KW�om���'),
(12,'18__0_0_0_0',1798123569,'x��UMo�6��W:����]IFF4Z_�z\"��HK�$�$�����P_��u\nhR$�Mz3���{�aET<˂ܲb�Ϧ����\"�E,�~���VE`�eM7\0�<��$ʓ�µ`.,�\"P��!J8�n���@^U[+�1<��J��V=�7)�0��V��s���%%Ih��k�Y�0������9,�똃�5k��U@��&�I�Ҏih�lT��rAΰ\Z��t,��������h�������MFt\n�\n\\�i���G�H<�C=C�phL���Og0�a��aI���?��w�o?�����݅$��E�xo}�j-v��Z5�;֎]jT�#H�}���੣J�ʧ�Q*-4����h��`sx�N�jg��k[��N��w��1r#k<|54�$`\nԖ��j���7�w���+}|��JYMzpl;j5\0r�:�v�\'+�-O#XK��U������tȻ�ZղOt�d���0N�R��ߜ;�g��aXb-۝��g�~���o@[�l����Ʈ*��&�/\"\\�2�#�*j�i���̂�������^ia����\\=���#�U��b@��h)��U��P\Z\r�\Z��P\'2����n�*UKV�9\'5�Z��j9���0�Cj������Fڢh�#��v�3j�ʖ׽��P�JD���\'_L�����~�bv-��\'J\r��Gl�Z�YMτ��Uu��A�5�����Qv/-v�2R~�]��^��6δ�M������I�.`�ZNE�ߪ���=M�����=Y��Z�	!y����MI�\r��y~>�1d��F�/�ᲞM�[��(]����F�}P��9/f�ś����^?�}���o�7�\'��j����_��O���;��vJ����q�]��6?P������~œ/��\'\0I���Y�?��w��_d<_�\\$�,�8�I���,ďt��,cD��x�֛r��<�!%Y�W<L���<�F�Q�I��<O�<�`��\r��\0�'),
(13,'19__0_0_0_0',1798123569,'x��VKo�6��W:��HI~(�!�]t�A�d=49�	K�JRq� ��C�L����.�f}3���\r�<�����-ϗ����IuJF���o��v�įE9�x���r�%IJ��`Fr�eI��A%|�JJh&`�G�8�j�0<��U�J�;���$��hp��8Քޑf�K�<2z��0�uJ�]�C��UZ즰ӱ�*ޔ/����6��\"q�Zn�q�՝s�$�`�7�_H���(&w��g4�\'0Lw�������\r�<�iS[�Y0G�H2�}C�hB�����&���F��|5�~`��=<��xw�Ӈ��@�9�Y�q�eV]��X;v��\Z� ����i�ʐ6O�rP�F���A��M6�F�;�0u\0�v(����ߌz��p��J��4����h,�v����u=>`�*G�}��-s\0�mH�@K�\rl�̼�}�xƾ�G��mZd��i���c�gl��w�ۜ;�q�`Xe��]��j��}j�|�`�j���\\_���s�^��h4���؆Q&y�Z����a���c{�[.G�o�3\\��*y�0`X�@�*��&���7��u@Y�%e�v���dzn��ò;�\"������c�7\\�Z6q>�����\Z��p��l�9���jD�I8k���D4�KxŤY��J��W�A[| �0�Gx}�mt��ؙp�./��G~�7�U�?cGo��+�����>�./�ңMp#CӢWv0hrԫH�S˩�hrj5`�ʝ^���ƞ=Y���Z�)!k\Z/��5��l�y~9�1d��/Fͯ_�j�L�[�K���V3*���>�u|��1;������|�{��E�ڛ��W?^��>kG+vb�<����ƭw=���@��+>�����O���?H���Mb����}�JO��B���e,�H� �\"�%�)\0�٦H\n�.R*��!�c���e����\"�J�X�O�eBV��O���'),
(14,'20__0_0_0_0',1798123569,'x��UKo�6��W:;�H�V2z0��)��b��%)-����T����C���r\n�	r���p���C\\<���\"ˋgSDE�K�����o7�\"�K��\ZK�n\0�<����ha�S+V�����C�p��I�E;y@Tm�lČ�1�r�A)H�U�M�� FG���m5\\z�Rg��@��{a����\nrݏ1��Vl?�Eps4��m��J����Ij���Z�v�k�\\�3l\"\\B�L�e9��<��p}�(/g8�s~����W\'Cۄn�Ч��h�\Z=C�ph����	Of\\@��V��\ZL��ow��>������J�������]`���2)�jHw�XjTC�v�DdӉ��(-+�m��Ҋ�v�����bo�I4\\���3pm�����;Ƅ1WV]ɶT����L�2u_\r~@�[:8���ͅ#T��\05�������u�j!�_��[Π��TOPGM��&�,�G��o;��hj��T1�،0L�R���^:�ᦺ�à�Z�{�O��Թi��p��𩵲^�\Z���N7�~�b��9�V#�f;?�,�(�?{q<(��D/r/�z���XM�����5�$�W�bY4�b��!N`Z)���\"S�\ZR���\'5ڴ���r��R��֒��?N.���\Z�Ͽ�0f��-�{..6B�*�\\<�bR�Tu��7��b;x.E��~��5�U�d�&êZ�vG\0~�o\0�fx�N� {��_G�O�U8��*(>���7��+��&\'���8<���G�V-L_���/����EgK7�[K7F(�a��/��o`�&�����N\\��h���;\\Գ�k�:�I��\Z�Q5�编�������}�����ǉ44jn&��~�B?}�V`�p�<�?|_�ֻGm~����X����G�֊�\0h�5��b����}��)�Q�0�yq��q�SoS�łF9�lY��²�,���$��Y�h&x#J�q#�E)��4e8E8O؟���\''),
(15,'21__0_0_0_0',1798123569,'x��UK��6��W:/6���E�$h\n�{��A�#��$�$����ޡ^��M�} An�7�<���Ê�x��cE�Ϧ����\"��ED�c7�iU�X�t��i\'Q����peɊ@@\r/�xw\'��v�\"@��Z����o�\nYA	�Ҫ�� E�E���m�.�a9cRZރ�ZvV*��0�\0!m��~vK0s4�fmճ\n�T�`� 5	[�1\r�����5_$�ہ��&dY��M�7��pM�3���9�dD\'���	��m�C{��?��@�g�\"��޻���}�*q\\B�i�yC��<��x��ˇ�W��.������W�E�i�UC�S��R�z4x���\'*��:�������J\r�h�%Z�1�ަ�h���c3��Ea�d}D�6�R2u_c�o�ɂ��\rf]�j��w�Q��#��ʱo��S\0fZ��:\'�\\�G��v�xD��]�|�Ggj��1�o//��e��aX]-۽��f�~��<o�Z8|j���\\cW�us�.V�s���\Z`��|/�h��?�{8�f�����z���X͸����5E3HQ��ń�o�M`HC���R֟�E�T-4�,�˞�d�R^V��H���=���=_�G饑�(Z����7��ly�� ؀zU\"\n�x�Ťh��Z�ק��;|����>q�mU+9��p�gU]�v� �Z����l�n��AZd��S~�]���r\Z�l�i�V�;��Q��^��(<���,�ϭ\ZL_���/���z�Vÿ�VB�(��󵚒oa�������N���h���;\\ų�k�8��U�\r�bT�G�̟�F.�^-`��~|����_n\'�Ԩ��~����W�hE&7N�S���\rn��q���_���ϯx�o���	�&[C�,���;��/�l���d$]�D%Q��8de�3,�D�R�%��,aۜ�+<�q��Y��%�Ŋ�\"M��%�2��I�m�U^��Y�'),
(16,'16__0_0_0_0',1798123569,'x��U�n�6��+�\r��FO�#	��g�A���ITI*���^Ùq���Awҹ�}�syiϲ�w�H���Q�w�%w�o?��_R�X��#��q���\'ӜZ�Z�M�o����b􂦳;ɹ� /𪭕�X0�&:�#YT��Z\r��P04J[��s��7E���0L��J�&�K�(�_�bH�\rihW�d.�A����T��^�F\r��	b��vl���㲪��S��S���.(��%�:a��B�%��`�S��9�+p}�C�Q�֐�}\"G>��3 ��C#<��Ο�x��>����`���%��o?|�����+�\0-f$����0�Yh;��jI��Ԫ�A��ȶO=QZ�>��ciEK{�k	V{&u��xVW{{���HۂRF���v\"\n~@Z����{�\Z���-�\\�z&�uw���\0>T�Sʀ�\Z2��`�У:o�x�.�G��85^:���Y�>�	�[kq��˃n�����0(����CF�Sc��n��7��8|�l�\\#W�	���/�Z��\n��$�������ǃ������i��pZ\Z�)�\0U���C��p	h�U�����z�i��V��3�ʐ��\r���p�I�����^�C�K��@-Y87E��H���-0XR���w�-��A:�i`���Q0���X3pq�u#ԫ�Qp��\'_a�T�i�a�;;����)*-���o۝�$�\r�P\\V�Uhw���X��Kv:\r\n�i��kO��v�οx�4<���7%�Ӳ�Pg?�l��s�ѹU34�<��k�+��l��WW�`/W��<D�?�zc�6o��{1x���_��w��ӷ�s\Z��[�Π�Ϫ]>���x��!;���O����p�z\"���۹��~|����ЉÍS�\\��}��f\Z�����>zC{���������0��E�����p߿�\"��2�+�Ib��|r��i�T�✊�b��4,c�B�a�y�fyɳ�4���L��*A3�Ty�x�	W�\0'),
(17,'6__1_0_0_0',1798123569,'x��\\[o�:>��+?�âiu�l�`�A\Z�cgmg�.�D;BdQG�����;�H�������!G��p�N[��}�\Z����}�n�������0�]�Q�NAw��[�`Pr�4@�p��S\\H�ʹ7a�Xn����k,h�ǁL��%�V)��󙫻]�[N�HJ�x�&\Z6۵n�ݔl>��OÄ�>5.E� ��o�Tv�m3/B�*G+�q�uƃoD�{	JqL�M*rF���YdZ�����1��¸�,}�Fa|���^%̀�L���*�aԠ/�(�odbv6�s���I��>�)��)Y{�x%�),ۥxx���X�)Q�{�JDq����p\r��itR��6�8i�6�Kas8x�Ǭ;��:�p����n(��ష���͋��\"�\r�%>�o�G�*k�A�R�V�(^�4ę �\Z��rK�	SOg��X2kC�;��,_$`!�ߛrf^����~��˕6���l�ms���Q�Y�s:�A�Z�j쑈�$�֚����$QD6�8�|W+W֚����M��c�Q$�4�����FY��K��n���Q�Ls�)��s|���\Z�)���?8J�RYˑ�@�0w\n���#X�hV� (�Gy�����Q\Z4)����C\0��7�����,���M&QuA�QfyU�\r�I8]g^��T\nl���Tbh�F5E ���t[����vA�m�i`;μ�p6?�2��~�yu�R޹4uv��Ṗ�O���	�K<8�U.1YHo�@�˘���\"Wv[�,�οHv��\'w2\"d��}�\n|ሒ�5�|���G[tTM�)U`*ROa�?K�,�\0�[�I~]%�v�Bm$v+���[_P����=�e���k\Z�\\���Rd>)��\"�{/�j��P�P����l�A$)�^�o7$\r2n^����t�M�OKh�����63E��(#c�rܕ.Z#8�P���ƙTqZ,S�rS=߰�L9II[cwb\'5�a��EDT���\n�b���R�7\0��2ſ˟����$}y-ǁ��۟fK���ܪL �g�sGҠ�툓�5�f��X�\"����\'��2����4��0��gyDw>�{���pt������ym�	�������:�́5���t4�\n�t|v5<;�b5��ͧ��l4��O��lr5=��5`�����bv}BR|���s�חEޱ�g�����R��b�0�\'�[8��A��//�f�yG���cRis&�X\"&����xR�Q�B�/OR�q����Ӵ����>�8��>Y�U�4�u}\"\"�\\����u�x\'��y�m�v�U��?���6�������(d�B�I}�,yNXR����$��=\' a_}�9e:��:���\\J�w�ZΣ����@�Yw��� �p����EA�x��\n�?$�1����g rk��F<����0\r���1��x�\Z3u8:Y�Q$�����G� \na(���B\na(��Ƴ �L�i��2�3�~�\"�ݎѺ��}֢�T�*t�}I1�zH1�ЋK�r8^0��i����H��LKjtP|b�e2��\\���x8Yg�b\'��o5�i�����?<<0=w۳v����ɻk����������/n�Z��gY������x(�%����������6n����;�B��}S\r\\XQ�g;1�-�V�RP���ce��ھ����ҵePo_:��yb�-r�Uw��V����}�������^(o�۫z{=�����5�U���^�ڂ/Ξ7X�������?�*��hUX�CQ0D�CQ}���\'�������!��\'�u�� �G��\rr�`P}�g�;N�O<?9���?2tf�j�>r���gG���\0l����n���8�����&���o����|p����2��LnTD��HETe��^����촒�کy`ƟF���P ���J��_`a�T{Z�e����h�Uo�/ھ��sX��z��q���˟~�=�tz�������9��t������@�w�<���a�^>�8\0~}�H�9�4h�蛳�E�aY��b[Aq�QGAq�y�G���r��a�M�H��o��_�E�4t�2z�G}�����=��0�A�Zj}Է\rd:���o8�����F���a\r-��X�E���0���'),
(18,'11__1_0_0_0',1798123569,'x��ZYo�8�������aٖ�}0� 	��Yt��%�\"��D�q��J�H�N�l4���ox�p����gy�gc��2��Zy��3��f\"���x-�1�J\n��:m�m�n)��\03�\'�z��D��b�����p�̚2���`��y�9A���|�^�h�3��0^���iqY�k�t}J2?\rRXjPNA��EԿ�����l��ǋ/ʕ�&��F����UF����OnH��\0��C+Ɵ�LZ`�r��V�w�6��4�&t8&�i�¨�Q���K̖`?g�0����}\Z3���)]!~�����#��p}+0&��W���c� �@�\n��cl2F�]��8kG6�sitp����;�:�p����o���`Cp�Z�jC1�g(\"���cIË�����cdAӐd�70�z�6	W�䖑�X\n����=LL�8�%`9����f(�h�ʍDf/F�|!�5�*��ڶ�A�(9\nΒGD�4-�U�H@�su�5J_��(�k��ܫf��F�3x3Y&���@D�D`���M��FY�%i��6~�pA�s�ܾ_�����\\�����3�JO�(���>N�:�t)��?N�*�Q��LCM��\\r\0^(؂x!�*CyFR-��/Ҧ&0��eb��+ܑ8�E���`S-\r��1��\'\'���٩����Ҳ�^h�*��M�������	�O��\"ׄ<u�tY��i��#\"N(�-O~C���7X�,\\���4��KQ@\n��|R;E-	\0@�,v\"�]�Ŷ2��j�b����L�m>����s�\nՊ0WHQ��Ġ��bW���v�]M�*/���UHk�ԣT�xG6k��0����~�Ƴ���g%\0Z�$��dy�l�Dp�ev�[@ϝZ��\",\"\'�Τʵr8�z������+���5��{i�f��Ѓ.\"3��LU�[쩐�@y�<%����`c\Z�>�Ў��`�ϻK�!\0:�*�k��dvܛ�U����{�Z^=	k�N�A�H��_���Q�ԝ̲�Ҕdy������u���)�^���ׂ�D����g�	������� OΧ��*��h2��W���p������Cς�O>��ۓ���	M��)�oo���p��U���Għ\\�!�����n��@��\\6)�d.\"\'�6�Cd���2*@�_J$�����+#������ݶ���{F%y��Y�w�5X]3d��o��	����v��%��N�,�FI~�M������\"DES�>~&�Pn𽨇:���;��[�SVm�����F+�C��}��e��a�eN�i!�f�:	�<���(g8\n?k���cN2�rc���D�����\r���s��E�\Zpu	��Q$9FW��w�4�\r�hxD�#\Z����G4<�;��,�PN��:��paB�GB��UY}{��PPU���|��tO�*b�I�o�MԿ�X[`��幬x���\\ۑK�/����tRH/�+���L�{��/ۊ��u�����-����i�����{1=�@��ҟ�^��vw�K\'\'g����;Ύ����Zo�zk�Əv\01Xk}ĽCX��}pT���c9�`BtE~��Y�y�}���S�dKidk7\Z)z�FSU�p��^��3ݹр5���e`�W3�ߔȞs[j^~�ӗ^~�ug*��^њ��z�>���;=�j�W��~�����۶i���}�W���ֱ8��_!?����y	��-��cGͷ�_�\Z=�-��E͇���{>P7��8\r�i(NCq\Z��P��Mq�����v�5-���m�6}�&3pfNۚ��1:��g�s�3\'�ܶ�5�ృ�=k[��tM��1\\��n`��-23}��k�=�'),
(19,'12__1_0_0_0',1798123569,'x��ZKo�8�yE��m��m�\n�`$F\Z ��~,�E\0��(GYT%*����P\"E�r�d�I�K`~C9���G1�6���֏�݃_�mڭ,�ZG�Gy3�Mhu�M)Z�9`�;m�m����M<DqMb�-���\\�V��<G��-КP\Z���`�<��-;˄d0}j�vKkS�� Z��V��dm����	N�$�i@`�Q�{\r�{#�갚t�:!��Zb\'���0G�k��G�tJ��$K\\,qM�4��O�)�[�u�d�o�޶� ���QJ�1s���^�#\Z��8)F�{���5x���>�Y���.�(�r������e���Pu+p&��W��mT �t�8[��:�\'��m���X/�}�t�z�ͼ;��9~��A���d��Xl��侪aN���[̇�Ƚ�E˴��\n\rZ�Q�$I�S��`���M��әgD,B騼u\n��f�<\"�S4��Ip\Z!b!�ދ�_�f%�\nd#��cP�J�B�d!�8��\ni@�vH�!%��j�jE��$�Z����w�Y��V�֌�c�&É\"1ǔ@W�\"�s��B�\'l\n�0���a�\\s�G�AB��ѻ5�\'ى^��K�c��N1|(��~ FҴ�@0�\r3�H!��ī\"��<�!R�p�Y�%�\\�\n���=�R��#��R\'Kq�$6S�y:U�:���H�J�w�%�,��)�����9Lg���ቒ��=T�p���� �P�O���1����e�YJߍ����(�5��Dn8���b��}��$� B+�o��m�\0��_�N�D0��Fy��=]	be{��\0��:�3��SK�7���K�:z�<��ӳ�nGVЋ(�X�����N�$Rey��ZM{\'?V�-���,(s���z��7x�&��r��]ԫ<Z�4A.-\0��W�&î�)��-�a�j�U�W%#J�ÓheO��,���w\n��otv�jeR�ƎB-�T�b�7DD*V����b�=y��k�H�O�\'u�6�؈D��Bg\'p`0$�ݩ����[����\"m�4����NXSj��쬈�yj��EL�xe\n\r�*��aV�	N���&۝�������3?˳b��ڀ�t&ÿ���D㿇���GH�����tX�h�ٙM���`v69��|r�m��g/�������$��@pGW�y��0��L�Ǜ�\'�%��1$�N�n�4\0��l������T��)χ�:c;ũ\0�z�(��Z��(+4O�ȶ�O���f���]LJ�+���r�s1���^\"r�z-=̨e��E�Hݞf�\nb��O@w�	����~;)�GCM^5���%��Kd|/R\"��9	�u}�z�U����T\n��n[҂��Tg��ȶ��p\n�coΒ��; �B���\"0��9|�p\n*�0��W�3OZ���(\r���3��?C�>,NO��l��0��a4�a\r�hƳ0�(�Ph��*�\n�0�n�B.݌Ъ��=�6�7�,Se���)�U�G|I1�ҋK�r0\\�_a86����Z�Q1���b���dv<��ҳ��t��J��/|�ٖT�j;\'$�}��n��{�e+�D��M^ܳl�x�qϲ���(�ͣ�3>�Z�Σ��xx182���B�rv��~=����[�;�ﷰo��}��/�4u�d���_�y�}���#{y�4�����=p�)+�K�����5�>���\r\\njwX���L��7%��ܖ���xa��k����LyP+Zs�����M�q�����h��X�ÿ�]��W�?�u�oh��:��Ϻ���\'�w�/ȏL��t_?js���Q�-��Q��%7�����<]ϧ��4��8\r�i(NCq\Z��)N�v���η�f�����µtw�{X7��5�����a�\"�o �긇P��h\Z2����皦����Cm��}w�v�~��Z��T�fG'),
(20,'13__1_0_0_0',1798123569,'x��Z�n�8��|E��y��6[��y�$F\Z �3^� �@K�#DU�������H���&�I�7�\\�����F��>��~��.��\\�m�a�:�<)�	/B��hF�2)\0�i[�e:Ni��\0Q�c��V�#LqыVֽ\r�\0�p���R\Z.����麭9�)�a���ݖ�*+f$�a�(���-������4LhH`�A�B\Z�Nt��t�u�E(^�h��\\�W�A\"]���8��W*<#y�c�k��+�:�Њ�G֌[�β�׭(��je��i�|�p�WӘ�Q\r#^�Q�ߪ`vn�s��>�Ob\n��yJ��aņr\n�v/Q}Kp&��Wm��}T ���%8[��*��ۆM��m�� �υ�!����d˙�h�Nw�̐��^��W;��{�E�#�M|��b��EV+Ò���xA�g�u0�rG�	[��<#b�4JG�{� ��q>K�#�c~t�B�yYN#DL$һ����X�Y�i�T���,y�9NrX�\\@U�H�!%��z�je��I��,�q��e�\ne����&M1�E�)��E�8e�/IC��f�q������-MQ��P�0[nE.�����.1|���~$[Ѭ�<X���\"B�GiPG�ڊ���G�IX�##�\\e\n��s�x!a�N���g8U�x���AS0��ԗx[�pL����jh0�ߏ���xr��78�)^�¾;GE�}�>�=�7&�>�`o�bdT���ec�ϓ?�|�0�r{Y{��_!�nQ��bt�S�!�@:)\"��v�k��U�m�CE�)|]_e��\0�V���T�C�;��U��}t]y���,��1.1Xf�)2��!��ꘋ���3֖[Q�웭�:�J/�-G���I���Wg�b7��Ygۧ%\0���@Y����4A4�DX��J��	�q�7�>k{RѲh��JE����6�9I�\Z;;Tsp���$�S��b�]y��[PGx�����ؘġ�\"o+p�1P��Ь	����\"~�6� Ν�i��Nm�ө���Y1u\nr��eL�xe\ZZ�R2ì[S�����]O{���ϼ�E��#!6������0\r��.{�B���y�\"iX�7�����b8������C׀�O�_͛ӫ��)I�����o����fڞ-���R�\Za�����5UՀ6ʃ\0��mRhq\\8\'�>g�MD���T�M�X�HROMI	$Z#rm��wӴ��w\'�,/�N\"2�֝��+� _�F28,�%i�\"���NW3^�6i���-a��d�Wɒ�`4��hy�\ZA�#��o�F��H)�F�@�2��d��p~���;t-��(2;@;���>���f�tL��|HppW���K�9Π�!����Y�\"�+�j��8���\'�[�%�<��찹.9�i�E#-\Zi�H�FZ4Ң��WZ�eF��T����(���\0-˄�e�|���T1�ޏ\'�ɣ����ӫk�7�]�]86]���V1ξ1���p49�N\n�Šw	}���L��|��T\Z��v�D4�a�ٰ��y���m�(yvo�m��6����~M\"{�\0��`m��z�����z�c����c����<�o���Z�f���S�~\r�ߧ��2\rA3�{G��\'z�՛��G��>�q�GH�[��Ӂ;N�a���_�P��l�l�b�s���_d�߾�Ȟr[jއ���s�����3$�f���K=���.<?�c���[�&��N��Z����r�N��sn�`��������i��K�G�/O5ߒ��4:�-��E͇����[�Y7��8��i$N#q\Z��H��-q�����v���f\Z�f�pǞ�]�;3C������� �#-�ϰ5׭��ͺ��ֱ�w�.2���@vg�m�Ǝ�z�ǲ:\Z\n|#а���\\'),
(21,'14__1_0_0_0',1798123569,'x��Z�n�8��|E��A�j��`��H$v��\0h�r�Ȣ*Qu���>�)Q^�d�I�7�p�����F��<��~��.���i��:�:��D��vZ4�h�p�ӳ-�2{���K}D�NM�i�8��Q���m��8�@�i��)��K���W���\n��HI�g�V�0#)\r���貶��R�z�3/\r\Z�kX����FĻ��개l���9Z`7���a�H�b7A)�i��H�z��5�S�\n�S>�b���q�Yu܊���VF�%̇�\n�x5�i�0�f�ޭ\nf��/��0wI�{$���\rR�t�+u(��mq��ױg��|�6*��G\"7\\��U��BJq�]��m��aH���kܻ�	���.w�̑w��^�̍�=u#��.�n�K�\"����b�c/H\Z�L�f�O��:a���32���Q�t�S2��	xD,�NQ37�i�ȅDz7v�`!���*�u�l��V2�%���IVT�e�DR�[��V�j@����r���*����#���ĥ)�p�H\"0%�բ�q��S�(q�4�M�k�ج\"ʙkn�%�<\n��d4��q��0�,�f1��w=��J�\"\n�</�},�E���R��Tv���g�IXR%#�\\e\n�KT��xQ��%�.37�p���)qΩJ��v`�)�Pi_���Ȥ�9����P5�8q/���ه��|�^a�r&�96U��\"Q������\'.��\"W*�oGA��X$��$N�0V[��?�n�4��V�(_.�!����E��+�V��JJ�i������*�\0�\"G���س��s�,�.��:��T��Ϸ��^�y����*�\'=�N�!�/�j:[$Y3�d�jlfAI�(��]�x��+���p��4�n�G�ȣ\0V�Ԡ�d8�QUA0�X��ʸ���b�s����dh�\\�������]��\'ei�,�P��&{CD�L%e�%v���݂P�A�?��[lcc��ܭ������S�.\0�۷2(�!$o�ԫ�v�S;�j8uzV�ڜ[�p�\"^ـ�V���a�kS��ݙlw/Gg�ˋ����E�`�F���߳�d\nU����G`����>(9\Zlv���prٟ^���d4�A��1`�ӏ�#���jrsFR|�@p�7�<��L�3����&E�1�3}l~��l��P��ꦜ?�q�T��\rλ�:�<ũ�:��Q I=31$%�W(\'F�tzO����e��}ד��^Od�ߺ����v\"�W����4~E�C��Ռ� M�ՠuyb�w����(�!i���\'�Yk��s��*~�2���9e	�uS�d]�,��ϵ�}G��9�\rx�h��ч�qaX �L�����=P�E����	��)�9��^�\"^���������D$�!3Gh� �\")A:B����42����hdF#3\Z��Ȍ�z��!ـ/U�!`�	�B���-���eo�b��TU��ޏ*���b�A������ſ�l4�8���V1��m9���h<=�My�Ű	c��J:�_�l�)�L�v�J4�a��0�������O���gZ[7~�>9�J�_��$߼�>�m���F;=\\�/�\'L;��d\'B��u���@5xku̢Cx��>�\r8.����LC��u?�%�����1�я��|��<���;���}��0/��ݯV(�B�.8�~�s����d�?��Ȟr[jލ_���k���Ϻ3qP3Zs�������.<��#����Vu����o_�~۵t�gh��{u���vm���\'���7�GfǰۯAYB\0�>u�|K~i����F5�����~�H�F�4��8��i$N#q^��i�������h{��\nt��c\ra��}�g~`��a[��u�i\Z��k=M�A�C#}nF��l�{s˶ms��}������=/�����\0Y�lB'),
(22,'15__1_0_0_0',1798123569,'x��Y[o�8����<��.!$T��Q�R�ts�լ*!��`�I3U���\r&��ν��\rǷs�9�1r�>p��t�:��J�u�u�5cфV�i1��:�\0�g������/��5���|b��Y���M��8�@�i��	c�\ZK���W���Zbw�����Vޑ���*ߴ��¶�J��S/	bXk�ρ���Ļ�����n��U�V�MK}uX$ԵȍQ�#VX��)I��&q���Ò���wAg�s�S�� ���e���W�o��\nF\\�Q�ݨ �3x);��kR]�#�/w����=��P�`Xq�\ZU��c��z�P�Q���\r�`lc��1��v��-aX?X.�������;��:�`����7�y��!p��[�0��;�,P2	V7��ύ�sC��i<��`����A�|V-�^�$�Tu�s�\'�ls�un-���4^ֺ�	����o9�8Ny#�.\r���ȍ�z7r��J6+��#�r�\".�r(\r��I\nZ�\nm��R^����!ٔ� ��]�,�[�Fo�7���ᔑX`J�M�FY�؍�\0�¶>�� L�i�_s� o?��XhB���3��EoF��%�0���	�J�*Rj�E7�?f��E��$7TAu��s\0^�0��\'k�\'JZ3%�eSE��8j�4��/qK�p0����biM�N݋�t6x��\rOk�2c�6%�NIY%����!��;�g��bܺJ!���N�k\Zw��M��	��s��\"�/�A������\0f#�|��=��=@�\"#eU\'�w%h\'+Y\0Zy�gRѥv�K���V�[��u�SX�P�.�;��w���Y(���)����8�r����+�����kP�ye��1.W���\rI|*̫s�Q��hAY�Oh���2(:N�D�\"pm���P��r�*��9\"iV|R$c9L�W�\05�*�Y�#����Zj�X�br0nd>V\"�H�r���ty7@��2����������^4�`���K�!\0rfQ��!2��fꕲ�t��ڤ�SM܊��%�[����*�F�aV�	�i�j����xп8�ox��ϳ��6��Hw2�{>��@4�g8�迅�::��φE���٤?�^�g��;�\'��>{{56����I��)������Jdq��U�����`�p�ǐ�\Z8)�A\Z��O��Y�P�3$Uns>y6Dv�9�ɏ\n��{G��՚ő�@�aY�D����+���i�}��b�m��~�WI��,���Ȍ�^XFsmC�T�F�ES��sg0v�R��6^��/b,��h��3�+�yj���*el|-�R��{���.�P�=��S8TWJ1;m�A��}�j�������LAu��y��P�P|PFO��w)�0��Bx]��x�\ZC7�2�!�v��z6��ʲL�P2[P�c�%��u4��a\r�hXG�:\Z���X��{�=`K�s�	�0�^�B!ݎ�:��]��)TT�\"m��b�<鏋)&��r����e��F`����,����ܑKLߌ\'��|�I�G���l(wb�|�ή�7U�Iќ��n�u?�[�+�!���v-��:t�w��tEV��U�;����ޫ�l0�쟏�9i\n(�$�cA�^��J���\0b���G��N�}8����ߐ5��������O�O|#�<W.:R���a��E��=��v����f�߿(�}��yj~����=5���\"�%��5�_�ٴ�v�����O�^��r�#�z�:?t��Nm]���r�N��O�e�������iV�%� �/�5?��5z�sË���s��|�n(NCq\Z��P���4��8/��4o��v���w�mlB9�ښfwl��ha[����f ��/���zx�0\r�:K�44�cy��6L���;�fh~ǳ�%2�V�k�ۆ�us�?��{C'),
(23,'7__1_0_0_0',1798123569,'x��\\�o۶���\n�{�V?�C��4H�%v���:h�v�Ȣ&Qu� ���)Q���k�9	��;�;�>�K��y�9=�yHa���}8��|#F�MS��1#�ݾm���/��\rN�i�8��hŷ����H�NfM(\r�X�@G�L�9�9v	�`��ѝ��.>LIB�h��R7�r�	Y}ĩ�1\r,5,��~@C�݉Yu�M�N�E�-�˕��u-rc���\n���d��K�&�4�O����¸\r�,&z���6F)���}���uD��F#n�Q�����l�et�]����(�r�	Y��x%�(�5).^��>�`JT[�<C�(Q\"��,��2��Jq��x�O�����\\��Ԙu�Pg,@H�~s�@�!�6��&��\Z47���\r��E<��b��EZ�J�ZN�xA�\0���40#�䎮c���,#<�`V��G�0�?%�l�E����� u�\0�F��H��\"כ/İ�Te]m���t��\nΒ���IZT\n�c���$9�VwX���9	C���A���jX��V�6�oc�&Í\"1�I�.���40��n�p(t���m�3f��	�o����pN�͇�G��f��iz�dl:5���]��2�$n	�V)L��7Ai/�|�}H8���N���=#5�\0�e�da� �R��*�>[ȋ�l�\r�M�n��D\nx���aVbh�\0��\"@J�Wt[����zF�u�4�&�\'��`2=�4��~�|y�Rtn\\�*kT�)��l@���1��]8�E&1Y���\"�1�๊�Q�8�8e&+��P��[Ԛ(�E	b,�7�s����XQr��oc��.:�#Y�-�W��r��|^:s)�\0�\"��+-�؈���m-��s���K\'��6?dٿ�����a����Q\n<Քel{5��pZS�����L�2dH�ԣ@��^�H�ܼ:�\"MH�f)M�Ghɓ����ԳI�)�g�rl�.]-�Vp���ڙ��\\���7�W��ao2�D&m�ݏFP�8�d����-9S��{�g�x��?��-v�����0��ͥ����[�-���D,m�ԯx��d�Ƥ�S���Ǜ;\\�$�W6���9u\'3�:7�i�� �{1:\\��q�ѽ>�C�m�	� �����O\'S`��:�|��:<����qtv���pr1�����dt=>��1`���W#���rrsB|�sG7Wy�Y1�T��ן�\Zc�0�G�w	��� �>�o������T؜M���t��[<�)R1���@��y\\DN���5�iZF��VÔ�Z��Q���U\r#\"�\\�w��*b��R�C�*�����fk��]p��@Kyqb9�R]@W~$\\��๰Jud?��U�\"�{dgp���<r��N���} 5���>a��蜂�ؿf�Q$$`@���/�a�9��3�)L9Yp����Jc����1�NxV2u8j�ga(@I����\0M�P�C!�<�P�C!��y�E��q���1c�(���-�|�cmO~@e�*C�֗��xx1���W��`<�d4��F��3�$m���sG,1�4\ZOO��9�|8����N�N��O��<���;*�������l�|�\Zhѷ���k�\Zv�y@ˎ�����[@�j�~疯��-_��i�8�J.��Cx��j����\r�q!���%	���j���e��mE�U4v7\n\Z������Euy�r�O���m�B�4OȾ�\"�Mu���~E�+����`��Mv�����d���Qo���&��iƋ\0/��u�t��Ǫ���_~�ë�.o��V��Q0D�CQ0D��\'~y}bmK�X�!m�9�>�����5r�`P}��\'�v7��ӓ�����}��d)�\Z����~k�7���\r�Z�c�����~�p�߄�D���d]���n5��Z���ɵ�H�vTDe�9�5�W(���J�\Z�Q�����d?S ���J����z�=������h�U��m�V��_��z���FZ�ğ~�ݣt���k�z�к/�t������@�W�?o�]��|dq\0��Бzs>4h���Y�\"��������VGAq�QGAq^8�Q���;� ���pw�1����6��=�8~Ƿ���Ța���i�;]!��z�7�\rsn �߷����^������,��ZǛ��߲�h'),
(24,'8__1_0_0_0',1798123569,'x��\\_O�8�����pZv�iڠ{�X�\"A˵�=!En█4�%Ζ.��8��i��-����؞�x�7\09�s8�r��s�°�~�(p�G�(.F�:N��-bF�����f�Wp��G78���q�)�gъoo�Ǒ ��̚P\Z,����|��uZ3�����;-�U|���ќ}hwخ���J��#N�$�i@`�A1�\Z�V̪�n�U�(�gh�]���x�F�k��GTؤ$�$K<\\�5A���x:,xߊ��-�e1ѻVD��1J�U����/�\"\Z�5\ZqS��F&�7`/��h���HD�\'w���ˎW⡌�X�����c�D���3���%���L-��2�\'댇��-nX?�̈́������[�1�3� $o��q�L�w��^��V\r��;���\"�n�K�<��A�b-�Q<\'I�SAh\Z��}rKW1SOg��X0+C�;����q6��\"bb~o�A��i\0F#Dl$Ի����bXs������}P:JFg�B��$-*ʱKBN��[�;�V�ꌄ!YV� ��]5,]Y�{�7�K��F���$G����s\Ze�b7N8�b��c�3����7��a�V8�����-���[�]�M	�9�C����9�\"4-������_�c{(��J���!R��IPFJ��q�JT]Py��@�WdnN���8���)�yH��,�������t0j��U.\r���{�O�?��\'�`^������/��!��;0c��bNz�IL�����g�x^���+�-Ζo���`�0\\��ȐWr\'b3��>���\n��|@>:��eгPy\n��^�k鬥@ ��tɯ��[#>T�b7�ԃ��u��*�@6]��e���+\Z(�����g@)�TS��_��t�BfM�2�Vs3\rʰ �R��Պ�x�$��r��n4�>��4A-�%O�N�S�|���u��W�l� YAWkgR�k!�^�Q����Δ���5v/\Z��f���.\"���Le\0[�V˻Єg	�G^��6\"Q��]s���4�s+3��58�����z�1�,ؘ�p�Zbu�8s�����&4�:��d�Y�&8�B�Xtwχ���O>�Wgy���6� ��ɟW\'�	�������!�N���\'e���ɨ?��\'gÁ;^���=t�����м>�_�_$����e�{,�����K��#���\"�6�Q�D���\"�4�M�X�_�\n���s��\0Pq+�\'UA*8�x�H14��ȱ{�]��f��7�)%��)\"��)5rU���+�)����o��<b�1��B7\0�u�[�?P�K��ɞ���)h�Фr���%Ց=\'(a�>�7EJ��\"���\\J�w���� ��@j���/B.L�8ձ�\"�H>��le�W�a�8x�\'�)L9Yp�s���Jc����1��y0u8B�ea(\0���{�!\ne(��P�B\ne(��PƳ��H�m��2�0f��\0���\Z�E����e���Ue����b���b�I/.�����hmN��NEB�d\Z�����p49���ܳA��:=;��y�y(�L]wJ4������l�Z5��o({׮5���\0�-�Zk3@�6\0ծ�������kY�����x�(9�3���f	��}M�۸�B��IP5s_U3�/�N�A����Y�VưT���X٢��{X��/�[�6e�]\n�Gd_i�󦺼fw���uy���.�^�?���Cy�w�OVި��\'�t5�E���F��_�\r�����u���xU��\r?Ъ6��!\n�(�`��!\n�(���/�O�m��5�mB0{�\'�t�i̖>q�\\!T���Ķ��\'��\\����\nRV5��9V;��@���~\0l����n���wp\0�\n���M�Od�_���ռs�y��2��L�UD���\"*3̾WD���D��F+j�F��3��~��@�=U�jO�aa�X{Z�i�����v)�^�/ھ���[��z���ZZ���ݡt���������/�t������@�w��7��L۰:/�9\0~y�H�9�4���p�zXV��\'�o+�� ��8\n�(�� ��8/����? o����M5��M�^���g�-�c�H�}����aO�Y���n۰}_�5��;\ZBBX�;V��vL4�|[��`��|4���`Fk'),
(25,'9__1_0_0_0',1798123569,'x��\\Mo�8���\nÇ=,�V�e+؃�i���k;/�E\0��(G�,j%����P\"%�r����7sFr�Ùg8i�c:w�c\"g`8w�y�wCgxX��rd���tiF�*a�Z=�g�%�K}Dq�c;]G��B�V~{�>�a�tAjJi��p�˔��\r��LI�g��t�n�aFR\Z��bi��1f��d�g^\Z&4$�ָ����FĻbu�N�����-�˵��t-v��\n�T�䩇+�&ȴ0XO��1��Ƹ�,��Fa|���^&̂�L���2�aԠ7�(��ebv\rF�r���Hsq��~�AJV.;_��r\n���Ps+0%j�W�D�(���\rW`j�F�!�8�f�Gmq��a���k�u�3P\'�0I�~{�@Y �6��!��Z47Ʒԍ�̧xȻ�.Eˬ1�J	ZA�xI�g��60#��n���,#<�dֆ*F� ���Y�H�\"B0�8� ��,�\"6�����6���l�ms���Q�Y�s:�A�Z�j쒈�$�֚���\Z�(\"�z�>����+kM�`��:qi�1�(�p����P�xA��P�&i�B7���b�(g�������9>H�f�]}X��Ӄ\0�����$�p���P85F?/ft���^�yQ�c�-­=��MJ�g�����$�%(%q�IT]Py��A^�d�NW��g8�B�)�ED��<�QM\n��k�%�`�t� ��Z\ZX��3�l4�}\Z�O�?J��:G)��M� jO�C৷`��&.��2��,�o{A�Θ\'��o#Wv[-�v��W���\ra$�(���O���$����|@>:���Ǡ_���S�����K�(@�Y�_VI�VT�\r��a�.c���S�|����%���k\Z(\\��R�=)��\"�[/�j:[���nQk�L�*HR���^�o�$�3n^���v�G���ȣ%���A��p�y�f�C�q�i9�J��\Zk�ãi�L�(-����2S��am3�%m�݇Vj8�d����,9S�����*� �������$=�[��!�o/ͦ\0y׹Uy@�\Z�A�Ζ�a�k��\'��\ZN3DK�~_np��_�@Ckr�Nf�Mn��<���Aw�lr4:;����{yZ�F���A����]������xz6�Qt|r9:9��4��Χ���l4?�����rz�I��/&�����ꈤ��#环.��c1��T���_R��b�0�\'��8�>��yW^��x�\"�ׅǤ��Lx1E|�3�S�\n�IEFI��>=I	�Z�E���o.OL�g{�ʓ��R���ʓ�.OD�˓��Ⱥo�.�h�K\'2��\'���m����\'�Q�䙀���)d�Ȥv�K�#{JL�V��oʌ�U�����r�����\"��5\r��]pA,��T��%��\"�\0rTP_%`v�+����\\p�3�\0O�Zc����1��x�\Z3u8@	�(���\0�=��{2�P C�2�P �@�^�v�5`Kb��`/D�n�hU���S��2U�w���{=��\\���{1�����i���H��Lへz��}�L�G��{:����c�����\n�4u�Ds�������\'�.|��z�F����Z��nxb�\'�E��[�=��[�,���ugp<����C�v���}��={��rZ緎4Q�p_U��\n֣�ĨS�i�����}��+[T��V.�I�A�]Yh��摹���yS=^s�_Q�z���V�W��?���Gy��_Xy�^_����`\'F݂/��GX�������?�*��hUX�CQ0D�CQ}��\'�v����v!�g�\'�t�� ���\rr�`P}�\'���V�x~t|>:�g�*�XՐ��X��GG���\0�`��;��:��wp\0�J���M�Od�_ѿ�U�y�V�e�!��ܨ�끊��0Ͻ\"bM�5���Z�P�j؟����\nd�RU���3,�kO�?��2�2�>E���C۷Ճ��+x^QZ?��Ak����(�|�������[:���_�`����O�7��L۰�/�8\0~y�H�9?7h�����E�aY��`[Aq�QGAq�y�G���u��-z~/���g-k��X����L�g\n��׌�`��A`����~߶��1Xx��Y���9�oas��:����\r���'),
(26,'10__1_0_0_0',1798123569,'x��\\_o�8������д�cْ�{0� \r��Y۹CZ�!����:� ���%Q�ܦ۴�$|g4$g8��\r�.�u�!��cd����°�^�8�U�8��Ѐ���Ӕ�u��G�1P�e7��-���{8��(ŷ����$XvfM(\rָ���<�b�};��d�|j�v_��$�A�ʗ�L��:��	�|ĩ�1\r�5)��^@C�ޕӪ��t�:!�VZa�T��`�PU\"\'F	�he����,qqMWJ:�M�Saɇ~��8�3�9����� �k�QJ�cfCO$Gxs� lЈ�b���\"1�3���9k�\\�%��?!k����C�6��k���\Z��\Z�U�(�sHd�k0�H���R��2��6�a���K���k\Z��b���\n����7�%r�`Cp�[�۪Es\"|O��\\�E�-v(Z��1�T̠�4�W$	pZ�fd���m��S�eJ_,�����=L�-�<[�`�rb~u�A�:i\0F#��H������r�p������}P8JFg�B��$-j��CBN�[i:�R��Ol�qy��V��4=�\r��ء	�p�H�i������s\Ze�b\'N8�e��c�3�͇�7��Q��k8����_prD��\0�.��C��a���m(��7��\'Ҵ�IP�\r3s�)��E�פ�Z�1��0�C�*p��R7�@UK*�:�UM��d�:Y�!��%=��CU/C��}M7J:8�.�������ܹ�\'�Ɠ�ӏBl�NU�˭KT\'��/��!�{0c��cN}�	L�w}�Ho�/x��w�+�-N�o�2Ekt�z�K�%bd�2�C���L`zD��\Z�AL>���\r:*@�*X�	)7{�ǅ��\nP��/�\'�n�XQ���J>�iחV8�l��!K����4P:5%O�B����bA�W��	�\ru�8[��4�B�0K���+���$^�ͫ2��h���� ��<i:iv3{�,��\"Z6- �b�5f��x�m�I�Kq0�N���׌]������{�\nF\r��t�H�g��y�E��X�-@(�\'�q�;؈D��Bg�q@����L�]�Ve�kp�2��f�j^k:Q�5�f7C��\Z�q�>���M�)MN��4�Ʌ<����0��\\LO���;��\\��!��	� ����ק����9�]�?C4��]��N�x\r:;��x2�/Χg>���\0{jk���竩~sr9�9!	��H�����<��\0`�������a�0է��	Ϊ� �>�o������T؜M�����xb�QP����	�C���������4k�U�T��Z�4\n��p�S�t�-����\Zo�4\\��a�ىFw�\n,҂�]����Juc$X9�R_<�T~%R���`J}d���U�\"ûdgp��T<���@!O�@j��}(�/L1(ձw͢b������?�fq,�G�\n{S������ܫ5��@�(\r��g�	S�?���8`y��Qb�9$搘Cb�9$���0�Z�z�<`Kq�0f��\0�����u��M���T�*�w>�h�Ozm����W��x6�d��Mg�ger4D\Z��r����lqr�ȹ���uvZ�dt����\n�4u�E����ޮ�@+jZ9�֮f�����\Z�`��\0+���������,���q�p<K�\\`�~���-!��o����N����\'�N����e���E�Wtrw������+[dk�\0+����ˠ^WzJA��WZ伩�n>�(yE-`�x����_�}Bysp���V�ȷ�g����\"��ىQw�˨�-V>��.���^%vy���),a��!�H\"a��!��>���+]�n ��\\��P��A0�~܍`J �Ŀ�O<\Z��\'�����{����U\r�{��z��7���\r�ڼc�������]��	����+���*[�On5?���=D6�Q��SU��+\"�Tޠ��V+j�V��Ӿ���C��{�*ٞ>���k�i���V�NF{JQ�������A���!����Z���v���w�����^n��S\r������|� >�G�1|	�h���CG���Р��7g���ò�o?珞%đGB	q$đGB��\rqd��/��M4����������ˡ6�|�K_�LC�<Fh��1}<��rd�>�O�,����k&��P�FClZ�n�9�����@��'),
(27,'17__1_0_0_0',1798123569,'x��Y[O�8�����+`riH�T�-��J�B���)i�MJA��{�؉Ӵ�\\`f�Ƿs||�wbdi֓o�����Wb�V+���1`�q֌xZGV�&-�\\�5�j[�vs����ĴZ.0��,J���w]\n�k�`֘R��p��H�jy؞�$��K�ZJ+���uԔv�	�V+&�S�8�Q��Z�|��4 Ν�V��$��P8O��i��\n����qH�xB���%��f�\0����S+D�6�[`�|��V��w�6J�4b6te8��iH���;�(vne0�38)݆�R]�!!�/ۋ��f\',�PJaX��U��\0c��z�1J�8G	\"s�_��e�.}Jq�)Xg�mpú��	��ٳ�{jMƠ���a������!�6ǽ\"�VsL��<�����|��rn�M�<��A�|>%�(���ǉ\0��f�K��*bʪ�N�3sai���\0�2Ngl�bb~��؉&$Dl$P;��xsѬ�X���ms�����:i�9NRТT�h�$����j�}��s=`��.~(��c+U?a��6�i�1�/qLr{�)<>��(�Q�á��\r&Rf���� ����� ��(��e64�Sr;P8)���q{�8����9A�b�\'½�U��0�u��T���E�d�%������f</a\r�ǋ�Na�R����VI�����(�/qC�pY�Ռ��bi�?����xrr���O��^���k�L������1��\r\'<O%!��\'6�<A�{������Ê穛.��#�[P���>A��>50��۬��#:�t\r�\0�%���O�NY\n�\0��3&���V��P����B>G�*�&ד�>�mvdI>w�U��P\"Y\n��Iy�ō{խ� YQ�����L�\"H�T�v��^-I�&ܼ*c�ďf	��Cs\0��B�I����K�1�j9�J׬K��#i�L�-���7rG7�:c�������R�J{\'�l��%�*\"��q��a�-�(���?y�6;����{Ï`0�ͥ���c����\"��fꖲ�t��ڤ�U�ْ�(8w8wQ�dI��4�*�q���0�n_Oz���O��E+��\0������\r��.{� �Φ��~�Ag{2�\rƗ���p`����	���[�|��7\'W��S��\\gI�`5\0S�ßb�a�0Շ�w\r� �>��F3�$����!*�9�<\":��,�dr�#Q5]1$&�lh\'�ev��v����mo�]\n�{�]ب]*pY��X,W.�ݤ�\Z�	M��ě�+�6VZe+,bo����U����7BT�[ְ���RJ�x)�R����\'l�5�ɳ�CQ\n��ZJ�C�m�$	Y��6��SzaZ��	���)��\"	�\0�\n�GI�u9��/�	L9���^�<^����\r��\01��y&0u8Y�� \\��d�ɺ�\r�h�F�7\Z�����o����i��Rfb&��㣀KW�ȳt�=m�*rVƷ�fю��/��\'����{��U���c��řH����|$��G���$�^z�0�Y_��<�̏�uAl��sz�XO�����Y��T�mL�ͽ�\Z��2Deף�v�\"�}���tMs�Iwrҿ�]��V$�������ބ;;����g����}����������d���b���+������4����G�v>E�y��Z��l;P��J؟�l$����O���,����+��=,��VBi�)�~�ge�����WzV>�xUV�����}�t������]M1�o����x\r���\Z�~�_���H75��=�6\'���گ�\Z����5?����|�n(NCq\Z��P���4��8��4o���v�6=�p�v�k*��c��t�n[� O��vg�u�E^�ț)��<d̐btT����=�t�u5Ϝ.�`���x�8��#}�?�s~�'),
(28,'18__1_0_0_0',1798123569,'x��Z�n�8��~E��E��j�\n��H�4@b��,�E\0��hG�,��\r��;�H����&٤՛u��8��C�����V��݁_��ۭ��Zǀu��ǈ?�S�nф�e�V�4TC�vs�{��Ų[0��(J����<\n�k�`ԘR��p��H�nͱ��I\n�Ol�n)��aBb��P��\r���)N�؏�O�]�|��4 �V��$��	P�H�;i�\n/	T%t\"�Q)�����K\\8�B�S���9�3nA8�[��V�QB���\'�!^MC��8	F�{#��\r��M�.�Y���]R���c�t�\nK6�R�VG�D�y,!���b%P�����/!�2FW>�8�6l��6y`=>A��g��К������N���d��[�,��d��aN���;̻�Ƚ�E���.�#(F��>NP0�=rK�sOe����@eO�0�7!�tAD��|��~�$>�1�@턎;_��JR�Ⱥ�6�Ai)\nɒ��$/J�g���[�&����Y��~����He���1��\Zc;�D�]~9�a�%��(�aQ��G&3)���8I����}�_��fc���L��^�ɽ��4�s�t���<gDr�(��H�m����T���a2Z��U\"��@9��%�����2q����ϘU2(r����%n\n6N��o]�\ZL��c�7��|�\r�����)�qm󔅢�G�\n\0��0F�>r`��dd依yYc���ߓ�q�m�̬?Lp�P����\Z�s�ֿK��\'�%�����ޯ�{��.�)+@Y�+9-��D\"�\0�ʫ%߲�O5n(�vc1>F�.7)��E>�m7d>O�O3�(���I�R.f���\\u{�.+��Z��<((A\Z����7�����^�ë2�Q/�h���4�K^$$�4�Z-J$DΎ���+m�\nA���sjeM\n��!�[��l���F�PISc��FB�\0\'��L��R2�-��)7�{�	�c�E~��6$����J����j��]�VT�5$����H��VN�XT��-�����<\'y��5�j�&��W�1NҀ�^�;Ó���?�Sgz�Q��f�B:���i<������Xtp6�����ɨ7_�&�Á3NG\'`�\ZL}��j�_�\\��OH��O	$wx}���	~���?��h5�.a����u̀9�\0��m�qh�]8\'�1g�g]D��|W�M>m�HT�N�	��#����*�nh]c�A���Ճ�(�[�\n\\�S��ǔ�~�]��o�J*)���	�}R��Q4��W���P)�J�R^�J)w\\#Q^R��i�T��\\��\'�h��v�,��ϕT���a�UY���\r��Cλ0,�q�co��PT 0@�C��U2h].\"��8�!������s�����a �1/c�W*�4���R99�i�F#6\Z�ш�Fl4b�/-6Լ�CɁX�RC��v}p�z��y��L�@E�*8|�������|��+�7�]f�f86����h�������p49�N2���wc���L��o|�����;�&����l��;no+2E�%S^�孩jO�R����V)��77�/xskY[7����e�|p�����Ar����_�u���!Z�C�<:��CX��<}-�4M�#Y�_�X�߯��7sE��w�<C���ʩG���z�\n��O=��r�¯d���P;�����2�?Ed�9-=����oL�<0}�Y}�3SFrEkP�Յ�n�؁�W�P>޺OV����������/���v5�z�G�g��kjL�?�/���>�-�l�}dp���ѳ}Kn��SKntQ�a���~�[�F�4��8��i$N#q\Z��%Nsw����7��[KU��516=lvf��]S3���5:����k \r[�j�RM�<�4-\rwPw�vP[W=E5fJg�6�=�-��M���tz'),
(29,'19__1_0_0_0',1798123569,'x��Z�n�8��~E��E��bY��}0R#\r��Y_�\"�@K�#DU�����J�DIN�l�n�ћy��g5F�f���z��>�Jl��9�:ΚoB�gwhB�:�\0�2�jW��\\����!1펇Lq6�����=����\ZS꯱�`=�۝%vV1Ia��V���;&$�~�b5����]���G���Q��Z�|��4 V��$��	P�J�\n;i��\n��:�qH�xB���%��f�\0����}\'D��;`�|��N��7�6J�<b6�d8ěyH���\'�(v�e0�3�)݇9kR]�%!�_�2&k���$C)�aM��kT��\Z��*��(��%��\rƖ1��)�q]��������R<��1�Φ���_� y�͍�@�\rl�{K2[50\'�w�	�-�C\\�^c��URi�J�J�Q�\"��4\r�`���m��S�e�/���PY�&�fd�.\"����_���\'N��	�~�˕hV�*G�嶹JG�Pp�4�\')hQ*P�pHrn��J�KdS����we�pe���]G�1�E\"�I�.7��ge�\"\'�}8�e��A�Ls�$��ݾ�H�ۚ�)����A(�/�A� ��*�A�a�!]{U��-�k�|T���ExdA$7����e�*a\r��׉�&8��.�,�JE�P]@���ko��K�h�y����O���������o㪔i��>��=�3F�.r�lW�$d��~�yc�ϓ��\\q�m~�b�8F[t�D1Z]#C.�܆����o�{�hV�,�d����t�R�\0�N��Ք�iĀ�4��;�s���2r����E�#K�������Ҝ@�c,�ثn��bE�\"~�s3\r��/�R���7x�!��p�U4�;Z$4F.�В\'I\'ͮf�R��G���+]�J ,�\r���3)b���塲�fԅrB���nB#�T�`��ED����b���*��@��2�_���`C�.\n����`��������[����\"j6f�JYc:y`cRͮgI��\"�\r�}��+�PS����izU\Z�$\rhca��9����~t�gYP�l8Hg2�s>��@4�k89|��9:�N�E����d0��fg�3�\'\' �\Zl}��r�_�\\L�NH��>p���2�6#�L�w����f�]�TC,h��1�>�0��fY�̮�I������Ae| � �_9U�CbY�f�٦����w5���ARH^�D��ڃ���|����a&]�7�G*.��I��=k�z�)�Oђ�b���p��~���W��\r����G�+�[u}�D�u�����2��ȃ| ��\05����L�7ձ7g�O�@�C��Uh�_R���c�uγޙWj�@�0	��\'�S��e\Z�v����صԢ�-�h�EK-Zj�R��j��!��-eb!&`��>\n�t;B�<!�Y�P�������v�C�Nt>�ťs9�.��.O�NE4d�GߞXb�i<���g��l48��N�b\'��7>��\nS՝3ž��vL�=�\n)Q���W�5T�i8�C����D$����몯�i֪������lt������@r�����U�`��6��;�u�߇p\0���>���8M�Y��Q�W��˼ʫ)��`a�{H[έ�q��7N�a^��_lP��ԟ6�i�e`�w#�o?��Zz����ɷ�G>��UV��͔9���7U,��`���V+V��������Ӄ�s��ji��z�N��9�����(� ?�M��~������g���R��������r[�~ʚuKqZ��R�����8-�y��������N_�5�g��&�=M���L�Bf_����b[��i]C�{����*f�R,M�vMCs5˲��㙦�X`��)��0��\0RY�'),
(30,'20__1_0_0_0',1798123569,'x��ZmO�8���+P?���K۴A����E����I{B���-9�8�8[����Ɖ;M����n����c�x<�8.�\r����dw�Wb�v#��Ɖo�I֌���ݠ	E�(�n��7�n7����(�H,���\0S�i�򾷾��P\0]�ZcJ�%á�\"�1��\"&)L�غ��\ZyǄ��٢;z�	�v#&�3���Q��\\�\\�|\Z�N��a9�:q.R��N*��a�@�B\'B1i�OH\Z�X��i�\n�S>4B���qܙ�:l~xWj��N#�CO�C����Jq�b�V�[p���]��$��]R���c�t�+2�RVE�D�u,���4_��\n(�Q�����l�+�Ro6�f��c=>N��ghL�`��_� u�Յ2C�,�{M2_U0\'���	�̇�Ƚ�E����r\rZ�Q� ��T�`���u��әgD,�B騬u\n�	��<\"�7��I|p\Z!b!��	w��RP��Z.�Ǡ���`I�q��Ҁ�퐀CJp����X��  +��C��f�Z92X3��\Zc\'�DS]m��0p�EN��)t���)s��G�8I�(9��9��(K�f����<N(��{��J�ci��!���y���vQ�ii���p�ɒEx���3�x!aN����&8Vқ)�,�*M�PS�C���[�C�g�[S�h�y�\\�Ɠ�O��y�L���N*��rpd���(�C�����G��\"U�,�o�A^�X,����#7V�o2�6�k�����/�`�(B�?GL\n&�%�4~Leϣ:Rz��E�ʊP��R\\+{�$@\0h��[ŶJ~��b\'�������rk���펬��A/1�6K�J��\\��_�մ�Rf��\"�J�̂\"-(Z�\']�x��+{	w��G��YBc��\0+y�Pl2�rŐ\"�<C�=��_尕��d=<������b8�z�F��Fk[�+ei�\\T�Q��	&;CDdg%��.�ؑ˽ڄ�1�[���66$����\n9~{j6�]�VT�7�ȡM])��SV�\Zv9U+�v�g�p�<^�BC+K�A�2�*�q��21��\\O{��Ϝ�E�\"��\06�����\r��.{�!�Χ��~���fg2�\rƗ���p�����)���K�|��7�W�S�3��\\g���H?3�ïb�\Za�0Ӈ���\r� �>�F3�$˥�q�9)�9S�\rt��S2�Ƒ#Q�J1$&Pch��mu�~Y1ͦ�m��zY)]J�ee�]e�Ue��eˤ񓰓RH�y���#�[,ܼ��~I)�I�P�C����\'�IOd<7�[��Ąͺ��]�,��ϵR�v����:Pe�ч<�ZH�	���)K����\0�\n�����r�w�P9��^��^x�b�V�I�%�1/afg)�4	�8K9*���FM4j�Q��h�D�&\Z�I4���C�_�4C(`��>\n�t=@˼<w��%ߠ�X�{���Q�UL���ڹ�zW�7�\rG�\"�T��⶘b�i8��N\'��bл]�}����n6�)��y�f?l6f{��V/QmEys�-�x���ݶK�\"�|�j�������j;9�_�.ǌ=�	�$ǜ��v�߄{;���:d�����>�\r8����OC��q>�%�������yX{7�Ï|	�R?��n<B���ST��~��W+~%[7����]�g�k&���SnK/�v,^���/L�z;�_�Δ%������!ٴw�������wdM����G\\��~�m�z�Ь�{uzя�-���\'���\'�G�e���59~��ž%��蹿%׼���\\�`?�vMqj�SS������85�y��~;��o�4��g-MGMӄ_�ҽ�ٙ7g�\'[͙�-m�<O7L�2��1p�����n\Z�����V��2�&nwg�v���`ך͐����=p�'),
(31,'21__1_0_0_0',1798123569,'x��Z�n�8��~�� �͖�`��H$v֗Zh�v�Ȣ*Qu����C�)��&ۤ��z3��6��̡��1����O�Ӆ_�c:�,�[\'�c�\'y3.���qZ4�h��k[�e�z��K|DqMb;-���|��{�>��sZ0kBi���a8�U���]&$��SGwZZ�蘒�ђu45�`B�i%d}�S/	b\ZXkX́���Ļ�객t��!��Zb7���H�k��G��J��$K<,qM�47�O�%Z��θ�,�:j�AtWi���bfC_�#��E4+qS��V�[0���}��\"��=Q��.�r�	+2�QVG\\�B�}�����^y�\n(�Q���\rV`l��R��\n��a��a�`�FO��N\'��\"X� u���2G�l�{Cr[�07���\r�̇xȻ�.E˴�����xI�\0����>������3�_,��Py�&�d��c����_���n\Z��	�n�z��hV��@6r����d(8Kb����\n�m��R�[�:�V�ꂄ!Y�v��^6KW֪����m��c�Q$���jS�x��QV(v�$�C��� ̘in�3��$��Y6�K�=���0|Z��i�k��f>�>!��C�_E�6�\'C����IPD6\np�*�.PM��K	�M�q�J�,ŉ�L��Sh�<v�Ц��x[�p1�͜��riM>N���dz��?<�)1�<-%��.�L��D�����؅�\\f���ݳ.�;o�~����n�c-R�\'4Ϣ�5 g��Q�z���e���HnԊg*\'��@\0���vå؝*w���:�q]�}��nG��\'�(�_v��IL	���,�j:;A��n��L��b+�T�\\�o�$�Sn^�q�z�F�&ȣ\0Z�P��d8՘/Ep�E��Z@���U��9�[xd��Iq�p0�N������PM7�֘��BM��)&{]D�Wř�,�ؕ�ƻ�	��.o���Hx(twC��]�\rx߹�1]�\r� \"dm���զS�&5�j VD�<����\'���	\r�*�:�aV�	N�������i�����̝]��b�׀�tǃ�f��D�����G����Y�|PFc�ٝ����ez1\Z���l|\n�c�֧�G������$�挀sG7�yfi3��T�ǻ���#L���C�e7�t�E��L6�#e~]xL*l�&χ�:��ŭ\0��f(������ 4�ȱ{On��e��}ύR�V�\"��<7*�|m��>6��y�\Z�����k\'!��U/y�wѐ�\"4�py�\Z�#	�t��b��~$�`�n�O��=��3�?�J�9�}0����0��ET�i!ئ�:�g,؉�Hh(�*��)���0�Ƃ{]�,w�K��h�!bv��$5d�p���P���c ۆJ4T��\r�h�DC%\Z*�TB/28$��J$�Lc/@!�n�hU$�.�!�*�Q��~a���FL>�յ{�����*�/�E�k�������h<=�Ms�Ű	s��N�o|~ٖ���;g���n����i��h�Hȫ+���g� ����M����Nm�ީ�NOW���1�GAʘz�������D;���>b�����>�8*���Y�!h��\n�DEZ�/�jo�H���,���4[y�с7M�a^���_�Q���<i�\Z�ko؟���\ndOy-�d�W�כ�Lߪ��/�fʃ��њ�/U6��=x~�bp������������﷖���~�O��|���0��?A���ȴ�v�-�#��ǎ^�[rC���[rË��M��k�\r�i(NCq\Z��P���4�S��v��k�ێic�:���m�ӳ;��-=wL�3�罞�w-�k�����{���h���#�^�]�y���\r�o�e.���!Hmл���\0q7E'),
(32,'16__1_0_0_0',1798123569,'x��YYo�8�����A�òl�`8F\Z ��>�\"\0AK�#DU�����;�H����G�6���ox����\"v��w��t�+qL���^���I֌DZ����Q�=����^/�����Il�呀0�͢�}o|�#�zNf���Db0����t�֒�ULSX>qt����	�������VL7�$qc?b>��F���Y@�[9��I�	\np�J񊠴�W�E]Q�c��*��4vI�kg�)�~:,y�\n�G:��3����m��6��\r=�f2?�`%��\n&7`7e�0����]\Z2�B˘���\"�)�au�5��c\r�ĕ�\n7*������`lc�1�v��-aX�_.�����ƭ;��:K����7����!p��\n[�K��{8���V�Br�P@>1����^%�6��Ϫe#+\Z�$�@����-�F\\e�[K�g.,����`oF���[N,�S����`HJ�F�\"w���J��ȶܶ�KŽ�\0J\"p���E�@@J��� ���]� �����+�Ex��h���&B,&N���ڔq�a`�5�P������A�Ms�V,Z\rc>�$������̒<�@7H=\"\"B���c����d�\rُ��~�\"y\"��M���DE~9\0�J؀�&�:AiBb%���r�\"��5eT���%q8�vA�m�4����?�\r��Gg��Z]��X8MIŵ3Rֈ2�d�������SW�\"�y}��yE�n�I=a�v�޼J��2e�7��dQ��z�\nhQd���d֭��R%#\0�XH�?e絃^���b�b��S�8��o����+x�%�eg�D���d��Y��t�r_E�\"I�ss\r��d�Ȗ+ޒ��^\"̫s:Q��x���,@KQ��ZJ�=OuU��T9S�lWR\Z� +>)���+@�\Z�U�ˬ�j)R�ˏB-U��z0nd�U\"�H�r���,�7@��2&�����!\r}h/�`0d�����9���Jo��?k3�JYm:u`mRé�iE��R�-�U�HxK�T#�0�Ҙ$i�j���b<�_��7<E��,=��|p$����3��N.��!������aqb@g4��GӋ��|<B��|2\0��1x�z56�������)������cq��U�כo&ĥ\\�1d��N�n�������l�����D�ۜO�\r�t^��2���#Q�Bq$�P_X�-�c���zb���v�zb�m��~��Y���\'���Ȍ�^NF�j��}����T���W@U�S��|;U)�E�S~�R�����p�RF�S1�ҏ/IO��;�w���ՕR��N�~�#d���08��y��i!�&�:��<��\Z(z8�?)�\'hć�$0��Bx]�Jx�\ZC7�2L��:�l��\\e���\"��*�@Hv\r�h�FC7\Z��Ѝ�n4t��醞Wy(:`K�l�	�0\"��!ݎ�:/�]�v)T����������c1Ť�W�?�_f�g6���ɺh��H�����x2�g��|Կ��Άr\'��g~��\n^S�]�͹��v\\����\"*?ݳ��?Oy���0O���y�}�7[��{��\r�����1�L~�oɱ `���~>��`���a���p���?��k�=�?�!X���`����	XDH�\0\\��H�/�\0|���\'�w�k��]p`ƣ���Jd_s�z��e�ݢ�,?�-�s���s]��$�V���[=*���]x~�G哽7e���O�ǯNş���S[�{�f�ޫӳ��N�k\\�1~��#�6��k�GmA�_;z��\r5z��\r/j~,7��O���P���4��8\r�i(NCq^7�i�ο��|� =�Y�Ʋg�^�cw��,��y�e,,[�vmM_�d�چA�m����ݎ��dA,W��4�3�gYD��]bôm����? wo');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'6__0_0_0_0','pageId_1'),
(2,'6__0_0_0_0','pageId_5'),
(3,'6__0_0_0_0','pageId_6'),
(4,'11__0_0_0_0','pageId_1'),
(5,'11__0_0_0_0','pageId_11'),
(6,'12__0_0_0_0','pageId_1'),
(7,'12__0_0_0_0','pageId_12'),
(8,'13__0_0_0_0','pageId_1'),
(9,'13__0_0_0_0','pageId_13'),
(10,'14__0_0_0_0','pageId_1'),
(11,'14__0_0_0_0','pageId_14'),
(12,'15__0_0_0_0','pageId_1'),
(13,'15__0_0_0_0','pageId_15'),
(14,'7__0_0_0_0','pageId_1'),
(15,'7__0_0_0_0','pageId_5'),
(16,'7__0_0_0_0','pageId_7'),
(17,'8__0_0_0_0','pageId_1'),
(18,'8__0_0_0_0','pageId_5'),
(19,'8__0_0_0_0','pageId_8'),
(20,'9__0_0_0_0','pageId_1'),
(21,'9__0_0_0_0','pageId_5'),
(22,'9__0_0_0_0','pageId_9'),
(23,'10__0_0_0_0','pageId_1'),
(24,'10__0_0_0_0','pageId_5'),
(25,'10__0_0_0_0','pageId_10'),
(26,'17__0_0_0_0','pageId_1'),
(27,'17__0_0_0_0','pageId_17'),
(28,'18__0_0_0_0','pageId_1'),
(29,'18__0_0_0_0','pageId_18'),
(30,'19__0_0_0_0','pageId_1'),
(31,'19__0_0_0_0','pageId_19'),
(32,'20__0_0_0_0','pageId_1'),
(33,'20__0_0_0_0','pageId_20'),
(34,'21__0_0_0_0','pageId_1'),
(35,'21__0_0_0_0','pageId_21'),
(36,'16__0_0_0_0','pageId_1'),
(37,'16__0_0_0_0','pageId_16'),
(38,'6__1_0_0_0','pageId_1'),
(39,'6__1_0_0_0','pageId_5'),
(40,'6__1_0_0_0','pageId_6'),
(41,'11__1_0_0_0','pageId_1'),
(42,'11__1_0_0_0','pageId_11'),
(43,'12__1_0_0_0','pageId_1'),
(44,'12__1_0_0_0','pageId_12'),
(45,'13__1_0_0_0','pageId_1'),
(46,'13__1_0_0_0','pageId_13'),
(47,'14__1_0_0_0','pageId_1'),
(48,'14__1_0_0_0','pageId_14'),
(49,'15__1_0_0_0','pageId_1'),
(50,'15__1_0_0_0','pageId_15'),
(51,'7__1_0_0_0','pageId_1'),
(52,'7__1_0_0_0','pageId_5'),
(53,'7__1_0_0_0','pageId_7'),
(54,'8__1_0_0_0','pageId_1'),
(55,'8__1_0_0_0','pageId_5'),
(56,'8__1_0_0_0','pageId_8'),
(57,'9__1_0_0_0','pageId_1'),
(58,'9__1_0_0_0','pageId_5'),
(59,'9__1_0_0_0','pageId_9'),
(60,'10__1_0_0_0','pageId_1'),
(61,'10__1_0_0_0','pageId_5'),
(62,'10__1_0_0_0','pageId_10'),
(63,'17__1_0_0_0','pageId_1'),
(64,'17__1_0_0_0','pageId_17'),
(65,'18__1_0_0_0','pageId_1'),
(66,'18__1_0_0_0','pageId_18'),
(67,'19__1_0_0_0','pageId_1'),
(68,'19__1_0_0_0','pageId_19'),
(69,'20__1_0_0_0','pageId_1'),
(70,'20__1_0_0_0','pageId_20'),
(71,'21__1_0_0_0','pageId_1'),
(72,'21__1_0_0_0','pageId_21'),
(73,'16__1_0_0_0','pageId_1'),
(74,'16__1_0_0_0','pageId_16');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_kesearch_tags` text DEFAULT NULL,
  `tx_kesearch_abstract` text DEFAULT NULL,
  `tx_kesearch_resultimage` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1795334294,1794119207,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"}',0,0,0,0,1,1,31,31,1,1795372569,0,0,0,0,0.5,1,'Home','/','TCEMAIN.permissions.groupid = 1\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete',0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__Home','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(2,1,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(3,2,1795333042,1795333022,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,1795333022,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(4,2,1795333042,1795333022,1,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(5,1,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Revenue & payments','/revenue-payments',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','pagets__SidebarLeft','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(6,5,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795531560,0,0,0,0,0.5,1,'Land rates','/revenue-payments/land-rates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(7,5,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Single business permit','/revenue-payments/single-business-permit',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(8,5,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Parking fees','/revenue-payments/parking-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(9,5,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Market fees','/revenue-payments/market-fees',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(10,5,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Waiver of interest','/revenue-payments/waiver-of-interest',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(11,1,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Health','/health',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(12,1,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Environment & water','/environment-water',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(13,1,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Trade & tourism','/trade-tourism',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(14,1,1795334294,1795334294,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795368020,0,0,0,0,0.5,1,'Public participation','/public-participation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(15,1,1795369027,1795334294,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"backend_layout\":\"\"}',0,0,0,0,1,1,31,31,0,1795369027,0,0,0,0,0.5,1,'Contact','/contact',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(16,1,1795348009,1795334294,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795348009,0,0,0,0,0.5,1,'Search','/search',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(17,1,1795334294,1795334294,0,0,0,0,'0',2048,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'E-services portal','/e-services-portal',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(18,1,1795334294,1795334294,0,0,0,0,'0',2304,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Accessibility statement','/accessibility-statement',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(19,1,1795334294,1795334294,0,0,0,0,'0',2560,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Privacy policy','/privacy-policy',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(20,1,1795334294,1795334294,0,0,0,0,'0',2816,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Access to information','/access-to-information',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(21,1,1795334294,1795334294,0,0,0,0,'0',3072,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795334294,0,0,0,0,0.5,1,'Tenders','/tenders',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(22,1,1795334294,1795334294,0,0,0,0,'0',3328,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Service navigation','/service-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(23,1,1795334294,1795334294,0,0,0,0,'0',3584,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Footer navigation','/footer-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(24,22,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,17,0,0,0,0.5,4,'E-services portal','/e-services-portal-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(25,22,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,15,0,0,0,0.5,4,'Contact','/contact-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(26,23,1795334294,1795334294,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,18,0,0,0,0.5,4,'Accessibility statement','/accessibility-statement-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(27,23,1795334294,1795334294,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,19,0,0,0,0.5,4,'Privacy policy','/privacy-policy-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(28,23,1795334294,1795334294,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,20,0,0,0,0.5,4,'Access to information','/access-to-information-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(29,23,1795334294,1795334294,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,21,0,0,0,0.5,4,'Tenders','/tenders-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(30,1,1795336956,1795336956,0,0,0,0,'0',3200,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795336956,0,0,0,0,0.5,1,'News','/news',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(31,30,1795348009,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795348009,0,0,0,0,0.5,1,'Article','/news/article',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(32,1,1795336956,1795336956,0,0,0,0,'0',3840,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'News records','/news-records',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(33,1,1795348009,1795345582,0,0,0,0,'0',3136,NULL,0,0,0,0,NULL,'{\"no_search\":\"\"}',0,0,0,0,1,1,31,31,0,1795348009,0,0,0,0,0.5,1,'Page not found','/page-not-found',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','',NULL,'',1,1,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(34,1,1795348009,1795348009,0,0,0,0,'0',4096,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,254,'Search index','/search-index',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(35,1,1795372569,1795372569,0,0,0,0,'0',3264,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795372569,0,0,0,0,0.5,1,'Events','/events',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(36,35,1795372569,1795372569,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,31,0,1795372569,0,0,0,0,0.5,1,'Event','/events/event',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(37,0,1795414399,1795414399,0,0,0,0,'0',512,NULL,0,1,1,1,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"TCEMAIN.permissions.groupid = 1\\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__Home\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"1\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Home\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,1,1795414399,0,0,0,0,0.5,1,'Mwanzo','/','TCEMAIN.permissions.groupid = 1\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete',0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__Home','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(38,1,1795414399,1795414399,0,0,0,0,'0',256,NULL,0,1,5,5,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__SidebarLeft\",\"backend_layout_next_level\":\"pagets__SidebarLeft\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/revenue-payments\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Revenue & payments\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Mapato na malipo','/mapato-malipo',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarLeft','pagets__SidebarLeft','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(39,1,1795414399,1795414399,0,0,0,0,'0',512,NULL,0,1,11,11,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/health\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Health\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Afya','/afya',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(40,1,1795414399,1795414399,0,0,0,0,'0',768,NULL,0,1,12,12,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/environment-water\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Environment & water\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Mazingira na maji','/mazingira-maji',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(41,1,1795414399,1795414399,0,0,0,0,'0',1024,NULL,0,1,13,13,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/trade-tourism\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Trade & tourism\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Biashara na utalii','/biashara-utalii',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(42,1,1795414399,1795414399,0,0,0,0,'0',1280,NULL,0,1,14,14,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/public-participation\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Public participation\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Ushiriki wa umma','/ushiriki-wa-umma',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(43,1,1795414399,1795414399,0,0,0,0,'0',1536,NULL,0,1,15,15,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__SidebarRight\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/contact\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Contact\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,1795414399,0,0,0,0,0.5,1,'Wasiliana nasi','/wasiliana-nasi',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(44,1,1795414399,1795414399,0,0,0,0,'0',1792,NULL,0,1,16,16,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__SidebarRight\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"1\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/search\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Search\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,1795414399,0,0,0,0,0.5,1,'Tafuta','/tafuta',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__SidebarRight','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(45,1,1795414399,1795414399,0,0,0,0,'0',2048,NULL,0,1,17,17,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__Narrow\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/e-services-portal\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"E-services portal\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Huduma za mtandaoni','/huduma-za-mtandaoni',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(46,1,1795414399,1795414399,0,0,0,0,'0',2304,NULL,0,1,18,18,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/accessibility-statement\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Accessibility statement\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Taarifa ya ufikivu','/taarifa-ya-ufikivu',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(47,1,1795414399,1795414399,0,0,0,0,'0',2560,NULL,0,1,19,19,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/privacy-policy\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Privacy policy\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Sera ya faragha','/sera-ya-faragha',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(48,1,1795414399,1795414399,0,0,0,0,'0',2816,NULL,0,1,20,20,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/access-to-information\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Access to information\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Upatikanaji wa taarifa','/upatikanaji-wa-taarifa',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(49,1,1795414399,1795414399,0,0,0,0,'0',3072,NULL,0,1,21,21,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/tenders\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Tenders\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Zabuni','/zabuni',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(50,1,1795414399,1795414399,0,0,0,0,'0',3136,NULL,0,1,33,33,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__Narrow\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"1\",\"no_index\":\"1\",\"no_search\":\"1\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/page-not-found\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Page not found\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Ukurasa haupatikani','/ukurasa-haupatikani',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Narrow','','','',1,1,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(51,1,1795414399,1795414399,0,0,0,0,'0',3200,NULL,0,1,30,30,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/news\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"News\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Habari','/habari',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(52,1,1795414399,1795414399,0,0,0,0,'0',3264,NULL,0,1,35,35,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/events\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Events\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Matukio','/matukio',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(53,5,1795414399,1795414399,0,0,0,0,'0',256,NULL,0,1,6,6,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Land rates\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,1795531560,0,0,0,0,0.5,1,'Kodi ya ardhi','/mapato-malipo/kodi-ya-ardhi',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(54,5,1795414399,1795414399,0,0,0,0,'0',512,NULL,0,1,7,7,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Single business permit\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Kibali cha biashara','/mapato-malipo/kibali-cha-biashara',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(55,5,1795414399,1795414399,0,0,0,0,'0',768,NULL,0,1,8,8,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/revenue-payments\\/parking-fees\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Parking fees\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Ada za maegesho','/mapato-malipo/ada-za-maegesho',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(56,5,1795414399,1795414399,0,0,0,0,'0',1024,NULL,0,1,9,9,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/revenue-payments\\/market-fees\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Market fees\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Ada za soko','/mapato-malipo/ada-za-soko',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(57,5,1795414399,1795414399,0,0,0,0,'0',1280,NULL,0,1,10,10,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/revenue-payments\\/waiver-of-interest\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Waiver of interest\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Msamaha wa riba','/mapato-malipo/msamaha-wa-riba',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(58,30,1795414399,1795414399,0,0,0,0,'0',256,NULL,0,1,31,31,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__Article\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"1\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/news\\/article\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Article\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Makala','/habari/makala',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(59,35,1795414399,1795414399,0,0,0,0,'0',256,NULL,0,1,36,36,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"pagets__Article\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"1\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"1\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/events\\/event\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Event\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,0,0,0,0,0.5,1,'Tukio','/matukio/tukio',NULL,0,0,0,0,'',1,'','','',0,0,0,'',1,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Article','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(60,22,1795414399,1795414399,0,0,0,0,'0',256,NULL,0,1,24,24,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"4\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"17\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/e-services-portal-1\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"E-services portal\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,17,0,0,0,0.5,4,'Huduma za mtandaoni','/huduma-za-mtandaoni-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(61,22,1795414399,1795414399,0,0,0,0,'0',512,NULL,0,1,25,25,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"4\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"15\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/contact-1\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Contact\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,15,0,0,0,0.5,4,'Wasiliana nasi','/wasiliana-nasi-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(62,23,1795414399,1795414399,0,0,0,0,'0',256,NULL,0,1,26,26,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"4\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"18\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/accessibility-statement-1\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Accessibility statement\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,18,0,0,0,0.5,4,'Taarifa ya ufikivu','/taarifa-ya-ufikivu-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(63,23,1795414399,1795414399,0,0,0,0,'0',512,NULL,0,1,27,27,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"4\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"19\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/privacy-policy-1\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Privacy policy\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,19,0,0,0,0.5,4,'Sera ya faragha','/sera-ya-faragha-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(64,23,1795414399,1795414399,0,0,0,0,'0',768,NULL,0,1,28,28,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"4\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"20\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/access-to-information-1\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Access to information\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,20,0,0,0,0.5,4,'Upatikanaji wa taarifa','/upatikanaji-wa-taarifa-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0),
(65,23,1795414399,1795414399,0,0,0,0,'0',1024,NULL,0,1,29,29,'{\"nav_hide\":\"parent\",\"link\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"doktype\":\"4\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"link\":\"\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"21\",\"shortcut_mode\":\"0\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/tenders-1\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Tenders\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_image\":\"0\"}',0,0,0,0,1,1,31,31,0,0,21,0,0,0,0.5,4,'Zabuni','/zabuni-1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',NULL,NULL,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `tx_kesearch_filter` text DEFAULT NULL,
  `tx_kesearch_filtersubcat` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,32,1795336956,1795336956,0,0,0,0,256,NULL,0,0,NULL,'',0,0,0,0,0,'Trade & markets',0,0,0,0,'','','',NULL,'',NULL,'trade-markets',NULL,NULL),
(2,32,1795336956,1795336956,0,0,0,0,512,NULL,0,0,NULL,'',0,0,0,0,0,'Roads & transport',0,0,0,0,'','','',NULL,'',NULL,'roads-transport',NULL,NULL),
(3,32,1795336956,1795336956,0,0,0,0,768,NULL,0,0,NULL,'',0,0,0,0,0,'Health',0,0,0,0,'','','',NULL,'',NULL,'health',NULL,NULL),
(4,32,1795336956,1795336956,0,0,0,0,1024,NULL,0,0,NULL,'',0,0,0,0,0,'Revenue & payments',0,0,0,0,'','','',NULL,'',NULL,'revenue-payments',NULL,NULL),
(5,32,1795336956,1795336956,0,0,0,0,1280,NULL,0,0,NULL,'',0,0,0,0,0,'Public participation',0,0,0,0,'','','',NULL,'',NULL,'public-participation',NULL,NULL),
(6,32,1795336956,1795336956,0,0,0,0,1536,NULL,0,0,NULL,'',0,0,0,0,0,'Environment',0,0,0,0,'','','',NULL,'',NULL,'environment',NULL,NULL),
(7,32,1795336956,1795336956,0,0,0,0,1792,NULL,0,0,NULL,'',0,0,0,0,0,'Water',0,0,0,0,'','','',NULL,'',NULL,'water',NULL,NULL),
(8,32,1795336956,1795336956,0,0,0,0,2048,NULL,0,0,NULL,'',0,0,0,0,0,'Education',0,0,0,0,'','','',NULL,'',NULL,'education',NULL,NULL);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,1,0,1,'tx_news_domain_model_news','categories'),
(1,12,0,1,'tx_news_domain_model_news','categories'),
(2,2,0,1,'tx_news_domain_model_news','categories'),
(3,3,0,1,'tx_news_domain_model_news','categories'),
(4,4,0,1,'tx_news_domain_model_news','categories'),
(4,13,0,1,'tx_news_domain_model_news','categories'),
(5,5,0,1,'tx_news_domain_model_news','categories'),
(5,9,0,1,'tx_news_domain_model_news','categories'),
(6,6,0,1,'tx_news_domain_model_news','categories'),
(6,8,0,1,'tx_news_domain_model_news','categories'),
(7,7,0,1,'tx_news_domain_model_news','categories'),
(8,10,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml','165cd81b05433cbd58fd78992daf226ea111f5bf','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','data.xml','fda721e59781b4bbe3cb83fb71f14e5b09e7928c',1795531649,1795531649,550039,1,1,'text/xml',0,0),
(2,0,1795344511,1795344511,'/user_upload/slides/slide-coast.svg','ff045dfdd71e6acbcb55576edfcd297e7b28ce67','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-coast.svg','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795344511,1795344511,1233,1,2,'image/svg+xml',0,0),
(3,0,1795344511,1795344511,'/user_upload/slides/slide-rates.svg','1e61ced89c016178e02a3c5bf79eb2de9fc6ddef','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-rates.svg','930ad2b62005be8ab906802601193f671beda593',1795344511,1795344511,1214,1,2,'image/svg+xml',0,0),
(4,0,1795344511,1795344511,'/user_upload/slides/slide-community.svg','fa4ea1a512790f3c4a1936302b29a1a691654ebb','4860957efe25f35a351a0d662bf525e85e7f4062','svg','slide-community.svg','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795344511,1795344511,900,1,2,'image/svg+xml',0,0),
(11,0,1795368020,1795368020,'/user_upload/pages/revenue.svg','1cd73fe883ea2a924471d5fd501fa4302aefed05','41e6d150c75718d77d7de5232176c747d5e946ab','svg','revenue.svg','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd',1795366717,1795366717,1527,1,2,'image/svg+xml',0,0),
(12,0,1795368020,1795368020,'/user_upload/pages/land-rates.svg','d5f7763ccb54d96ca705ae00a952c4e667420ed2','41e6d150c75718d77d7de5232176c747d5e946ab','svg','land-rates.svg','443957829800f283dbb2ffd610ad644b542355be',1795366717,1795366717,1341,1,2,'image/svg+xml',0,0),
(13,0,1795368020,1795368020,'/user_upload/pages/business-permit.svg','9de9cf466345826e6e0004eaff218214e0ed670c','41e6d150c75718d77d7de5232176c747d5e946ab','svg','business-permit.svg','3cdd6e20a13e650cec99679b5eb52e67c529921a',1795366717,1795366717,1796,1,2,'image/svg+xml',0,0),
(14,0,1795368020,1795368020,'/user_upload/pages/parking.svg','d5d63aa11f9836ff8a5574041dd005fc33d3063e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','parking.svg','21e3ea6329d902fadb8e700a33b813364ae0f517',1795366717,1795366717,1635,1,2,'image/svg+xml',0,0),
(15,0,1795368020,1795368020,'/user_upload/pages/market.svg','9b5ab031812f7b3000919f31d93eb6834eef44f1','41e6d150c75718d77d7de5232176c747d5e946ab','svg','market.svg','f4699dfad158612a22995a697549a4f0b4e34d51',1795366717,1795366717,1219,1,2,'image/svg+xml',0,0),
(16,0,1795368020,1795368020,'/user_upload/pages/waiver.svg','c29d9ffd11670a33b99b6be69ccd5d853c4477e3','41e6d150c75718d77d7de5232176c747d5e946ab','svg','waiver.svg','fe4ef5de488313ec55bf32751c903663094ef756',1795366717,1795366717,2156,1,2,'image/svg+xml',0,0),
(17,0,1795368020,1795368020,'/user_upload/pages/health.svg','a1bb0acb15caed893f46871a75b18a2a72fbed07','41e6d150c75718d77d7de5232176c747d5e946ab','svg','health.svg','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a',1795366717,1795366717,1263,1,2,'image/svg+xml',0,0),
(18,0,1795368020,1795368020,'/user_upload/pages/water.svg','6b1802ac603aa6da515cf8c4311e08b581f6e965','41e6d150c75718d77d7de5232176c747d5e946ab','svg','water.svg','4555d9ca1525f63e42e91e3b6f492963d65bc496',1795366717,1795366717,1246,1,2,'image/svg+xml',0,0),
(19,0,1795368020,1795368020,'/user_upload/pages/tourism.svg','8c1f6765ae9538e3fd436189d04637f5e020d708','41e6d150c75718d77d7de5232176c747d5e946ab','svg','tourism.svg','b2596f9cc022b1e81e206e3533d1e5944587bb51',1795366717,1795366717,1109,1,2,'image/svg+xml',0,0),
(20,0,1795368020,1795368020,'/user_upload/pages/office.svg','ce61dc3f063e40c13764b7cd0cdc993f1a605920','41e6d150c75718d77d7de5232176c747d5e946ab','svg','office.svg','2a62d5fb10462c90782877bc4254dec0a59e82a0',1795366717,1795366717,1396,1,2,'image/svg+xml',0,0),
(21,0,1795368020,1795368020,'/user_upload/pages/participation.svg','a4da72511bdbadb3e3b61b67f2225a182ed42e62','41e6d150c75718d77d7de5232176c747d5e946ab','svg','participation.svg','36f0d096874cc84265f1180798b35e74ccb363dc',1795366717,1795366717,1413,1,2,'image/svg+xml',0,0),
(22,0,1795368020,1795368020,'/user_upload/pages/portal.svg','2d8f4684e52b0f63833ec132ac661878cbbd3f8e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','portal.svg','83926aff612828d0f180cb5c7549588e6e10c537',1795366717,1795366717,1459,1,2,'image/svg+xml',0,0),
(23,0,1795368020,1795368020,'/user_upload/pages/accessibility.svg','6f0b06a790eb2db4ac6f06627a44c9b86354e777','41e6d150c75718d77d7de5232176c747d5e946ab','svg','accessibility.svg','ac912b916c948f19149c48cc52ef27f3e3a9a2eb',1795366717,1795366717,1311,1,2,'image/svg+xml',0,0),
(24,0,1795368020,1795368020,'/user_upload/pages/privacy.svg','37eb3d14802d29b87df0e485e47493b1d99c8c21','41e6d150c75718d77d7de5232176c747d5e946ab','svg','privacy.svg','9b8e53905ab5b20c15fdeb594911c71feb55252c',1795366717,1795366717,658,1,2,'image/svg+xml',0,0),
(25,0,1795368020,1795368020,'/user_upload/pages/documents.svg','aabcfbfda5ee6ee108add7c25755e60125aac964','41e6d150c75718d77d7de5232176c747d5e946ab','svg','documents.svg','55578155722872d3dbe552da247abdf9eab0f079',1795366717,1795366717,1109,1,2,'image/svg+xml',0,0),
(26,0,1795368020,1795368020,'/user_upload/pages/tenders.svg','6d7a69908a1ccb7e07fe72d25353ab2cd97bcd6e','41e6d150c75718d77d7de5232176c747d5e946ab','svg','tenders.svg','4466965824279af3d0752afc1c381bc67bf02cb3',1795366717,1795366717,1327,1,2,'image/svg+xml',0,0),
(43,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','241e84244ec067649ea2d0ea239961dfa9a911b0','a20b30e6345e127e49790026ced895ee898ede1b','','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd',1795531649,1795531649,1527,1,2,'image/svg+xml',0,0),
(44,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/20ea8f7cede2a53c268a4bab9647c06acfed9ff3','3a0d8dd4dab01965f63cc1874ec27659e68ab2d4','a20b30e6345e127e49790026ced895ee898ede1b','','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','20ea8f7cede2a53c268a4bab9647c06acfed9ff3',1795531649,1795531649,900,1,2,'image/svg+xml',0,0),
(45,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/21e3ea6329d902fadb8e700a33b813364ae0f517','6a072c5f3058ce87c7e331226dca617a46514da7','a20b30e6345e127e49790026ced895ee898ede1b','','21e3ea6329d902fadb8e700a33b813364ae0f517','21e3ea6329d902fadb8e700a33b813364ae0f517',1795531649,1795531649,1635,1,2,'image/svg+xml',0,0),
(46,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/2a62d5fb10462c90782877bc4254dec0a59e82a0','f87fdf05d0c5c61478c0495b9bdfbbc7ef865a85','a20b30e6345e127e49790026ced895ee898ede1b','','2a62d5fb10462c90782877bc4254dec0a59e82a0','2a62d5fb10462c90782877bc4254dec0a59e82a0',1795531649,1795531649,1396,1,2,'image/svg+xml',0,0),
(47,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','ed73bf77934c98f376223a1eba8ff16bdb0e4491','a20b30e6345e127e49790026ced895ee898ede1b','','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a',1795531649,1795531649,1263,1,2,'image/svg+xml',0,0),
(48,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/36f0d096874cc84265f1180798b35e74ccb363dc','a54eec23cb10896de868963d7d569a38d725ac3e','a20b30e6345e127e49790026ced895ee898ede1b','','36f0d096874cc84265f1180798b35e74ccb363dc','36f0d096874cc84265f1180798b35e74ccb363dc',1795531649,1795531649,1413,1,2,'image/svg+xml',0,0),
(49,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/3cdd6e20a13e650cec99679b5eb52e67c529921a','25689a616091f047048ed8215f8d79c80c92bc66','a20b30e6345e127e49790026ced895ee898ede1b','','3cdd6e20a13e650cec99679b5eb52e67c529921a','3cdd6e20a13e650cec99679b5eb52e67c529921a',1795531649,1795531649,1796,1,2,'image/svg+xml',0,0),
(50,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/443957829800f283dbb2ffd610ad644b542355be','437c9cf197a4e167c48cce35f9538beacf1f475c','a20b30e6345e127e49790026ced895ee898ede1b','','443957829800f283dbb2ffd610ad644b542355be','443957829800f283dbb2ffd610ad644b542355be',1795531649,1795531649,1341,1,2,'image/svg+xml',0,0),
(51,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/4466965824279af3d0752afc1c381bc67bf02cb3','876fedf79b3161dac6bb747b570e6881d0fd47dd','a20b30e6345e127e49790026ced895ee898ede1b','','4466965824279af3d0752afc1c381bc67bf02cb3','4466965824279af3d0752afc1c381bc67bf02cb3',1795531649,1795531649,1327,1,2,'image/svg+xml',0,0),
(52,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/4555d9ca1525f63e42e91e3b6f492963d65bc496','b56ad440266757db55d031cf5fadd6751129372d','a20b30e6345e127e49790026ced895ee898ede1b','','4555d9ca1525f63e42e91e3b6f492963d65bc496','4555d9ca1525f63e42e91e3b6f492963d65bc496',1795531649,1795531649,1246,1,2,'image/svg+xml',0,0),
(53,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','bf9643ba7780e40c2cad570672027d3debcd9d69','a20b30e6345e127e49790026ced895ee898ede1b','','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb',1795531649,1795531649,1233,1,2,'image/svg+xml',0,0),
(54,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/55578155722872d3dbe552da247abdf9eab0f079','332bc17e608fc5c104c37f7288f517e6cedc1a7f','a20b30e6345e127e49790026ced895ee898ede1b','','55578155722872d3dbe552da247abdf9eab0f079','55578155722872d3dbe552da247abdf9eab0f079',1795531649,1795531649,1109,1,2,'image/svg+xml',0,0),
(55,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/83926aff612828d0f180cb5c7549588e6e10c537','f1ccf1dbc49175f378508d2526bfe6ef0b0e8b77','a20b30e6345e127e49790026ced895ee898ede1b','','83926aff612828d0f180cb5c7549588e6e10c537','83926aff612828d0f180cb5c7549588e6e10c537',1795531649,1795531649,1459,1,2,'image/svg+xml',0,0),
(56,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/930ad2b62005be8ab906802601193f671beda593','aa2ff46d1695ecafd15b9d47e0b7f1c24c270008','a20b30e6345e127e49790026ced895ee898ede1b','','930ad2b62005be8ab906802601193f671beda593','930ad2b62005be8ab906802601193f671beda593',1795531649,1795531649,1214,1,2,'image/svg+xml',0,0),
(57,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/9b8e53905ab5b20c15fdeb594911c71feb55252c','7a588fa8f56093604f80ae9ca00ea4a846772935','a20b30e6345e127e49790026ced895ee898ede1b','','9b8e53905ab5b20c15fdeb594911c71feb55252c','9b8e53905ab5b20c15fdeb594911c71feb55252c',1795531649,1795531649,658,1,2,'image/svg+xml',0,0),
(58,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/ac912b916c948f19149c48cc52ef27f3e3a9a2eb','9c987bfeb026319721c2e53237d64ad0598d506d','a20b30e6345e127e49790026ced895ee898ede1b','','ac912b916c948f19149c48cc52ef27f3e3a9a2eb','ac912b916c948f19149c48cc52ef27f3e3a9a2eb',1795531649,1795531649,1311,1,2,'image/svg+xml',0,0),
(59,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/b2596f9cc022b1e81e206e3533d1e5944587bb51','574411d8e13602a441cd710d24e3dd2a6f2e4ffb','a20b30e6345e127e49790026ced895ee898ede1b','','b2596f9cc022b1e81e206e3533d1e5944587bb51','b2596f9cc022b1e81e206e3533d1e5944587bb51',1795531649,1795531649,1109,1,2,'image/svg+xml',0,0),
(60,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/f4699dfad158612a22995a697549a4f0b4e34d51','4ed4ed3f9e93d9dd9aedeec17c0b25716c4cb631','a20b30e6345e127e49790026ced895ee898ede1b','','f4699dfad158612a22995a697549a4f0b4e34d51','f4699dfad158612a22995a697549a4f0b4e34d51',1795531649,1795531649,1219,1,2,'image/svg+xml',0,0),
(61,0,1795531649,1795531649,'/user_upload/_temp_/importexport/data.xml.files/fe4ef5de488313ec55bf32751c903663094ef756','4aab823a35c5d45231c0f2be8f8973d294206e96','a20b30e6345e127e49790026ced895ee898ede1b','','fe4ef5de488313ec55bf32751c903663094ef756','fe4ef5de488313ec55bf32751c903663094ef756',1795531649,1795531649,2156,1,2,'image/svg+xml',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `tx_kesearch_no_search` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1795334315,1795334315,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0,0),
(2,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1600,600,0),
(3,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,1600,600,0),
(4,0,1795344511,1795344511,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,1600,600,0),
(11,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,11,NULL,1200,800,0),
(12,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,12,NULL,1200,800,0),
(13,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,13,NULL,1200,800,0),
(14,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,14,NULL,1200,800,0),
(15,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,15,NULL,1200,800,0),
(16,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,16,NULL,1200,800,0),
(17,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,17,NULL,1200,800,0),
(18,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,18,NULL,1200,800,0),
(19,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,19,NULL,1200,800,0),
(20,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,20,NULL,1200,800,0),
(21,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,21,NULL,1200,800,0),
(22,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,22,NULL,1200,800,0),
(23,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,23,NULL,1200,800,0),
(24,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,24,NULL,1200,800,0),
(25,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,25,NULL,1200,800,0),
(26,0,1795368020,1795368020,0,0,NULL,'',0,0,0,0,NULL,NULL,0,26,NULL,1200,800,0),
(43,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,43,NULL,0,0,0),
(44,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,44,NULL,0,0,0),
(45,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,45,NULL,0,0,0),
(46,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,46,NULL,0,0,0),
(47,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,47,NULL,0,0,0),
(48,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,48,NULL,0,0,0),
(49,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,49,NULL,0,0,0),
(50,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,50,NULL,0,0,0),
(51,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,51,NULL,0,0,0),
(52,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,52,NULL,0,0,0),
(53,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,53,NULL,0,0,0),
(54,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,54,NULL,0,0,0),
(55,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,55,NULL,0,0,0),
(56,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,56,NULL,0,0,0),
(57,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,57,NULL,0,0,0),
(58,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,58,NULL,0,0,0),
(59,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,59,NULL,0,0,0),
(60,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,60,NULL,0,0,0),
(61,0,1795531648,1795531648,0,0,NULL,'',0,0,0,0,NULL,NULL,0,61,NULL,0,0,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1795344523,1795344523,1,2,'/_processed_/8/b/csm_slide-coast_a539169108.svg','csm_slide-coast_a539169108.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','54cacd4d18a32d9798c9fcf9cd25f130e38a19fb','Image.CropScaleMask','a539169108',1600,560),
(2,1795344523,1795344523,1,3,'/_processed_/f/f/csm_slide-rates_202cf46cda.svg','csm_slide-rates_202cf46cda.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','930ad2b62005be8ab906802601193f671beda593','Image.CropScaleMask','202cf46cda',1600,560),
(3,1795344523,1795344523,1,4,'/_processed_/e/b/csm_slide-community_e5b6b5187d.svg','csm_slide-community_e5b6b5187d.svg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:4:\"560c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','838b7499ed5fc0f0fc9017911429abf7add02f50','20ea8f7cede2a53c268a4bab9647c06acfed9ff3','Image.CropScaleMask','e5b6b5187d',1600,560),
(4,1795368035,1795368035,1,19,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','7733916107',1200,800),
(5,1795368035,1795368035,1,19,'',NULL,'','a:3:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"crop\";N;}','8e17f053c0ee386607a1a7dd4c1234c3571c7b95','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','d525cc5c74',600,400),
(6,1795368035,1795368035,1,19,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','b2596f9cc022b1e81e206e3533d1e5944587bb51','Image.CropScaleMask','4c457691d0',295,196),
(7,1795368035,1795368035,1,15,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','355bf597e6',1200,800),
(8,1795368035,1795368035,1,15,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','c5cd09fac1',295,196),
(9,1795368035,1795368035,1,18,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','0492c25a1a',1200,800),
(10,1795368035,1795368035,1,18,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','a1ad152454',295,196),
(11,1795368035,1795368035,1,20,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','ac2f4c151d',1200,800),
(12,1795368035,1795368035,1,20,'',NULL,'','a:3:{s:5:\"width\";i:295;s:6:\"height\";i:196;s:4:\"crop\";N;}','9676b32e4310320692144359b092cc2be5791f6d','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','5d58cc317b',295,196),
(13,1795368194,1795368194,1,15,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','f4699dfad158612a22995a697549a4f0b4e34d51','Image.CropScaleMask','f357b6f0a8',300,200),
(14,1795368277,1795368277,1,12,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','443957829800f283dbb2ffd610ad644b542355be','Image.CropScaleMask','4bc69b387a',1200,800),
(15,1795368277,1795368277,1,12,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','443957829800f283dbb2ffd610ad644b542355be','Image.CropScaleMask','0d8c01c268',300,200),
(16,1795368277,1795368277,1,17,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','Image.CropScaleMask','3e1c804694',1200,800),
(17,1795368277,1795368277,1,17,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','2e8cfed7c67ca68040d6d7f7b968e1a9063c184a','Image.CropScaleMask','f8fef5c0ea',300,200),
(18,1795369031,1795369031,1,20,'',NULL,'','a:3:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"crop\";N;}','8e17f053c0ee386607a1a7dd4c1234c3571c7b95','2a62d5fb10462c90782877bc4254dec0a59e82a0','Image.CropScaleMask','3f32331746',600,400),
(19,1795370248,1795370248,1,11,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','Image.CropScaleMask','fc806927c3',1200,800),
(20,1795370248,1795370248,1,11,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','039761d3da5f2ae222ccf36fc2a0b075c4fe1bbd','Image.CropScaleMask','fe6db4f4b0',300,200),
(21,1795370253,1795370253,1,18,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','4555d9ca1525f63e42e91e3b6f492963d65bc496','Image.CropScaleMask','499a6e3fa6',300,200),
(22,1795370257,1795370257,1,21,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1920;s:9:\"maxHeight\";i:1920;s:4:\"crop\";N;}','b4ad301ef9ebf3977b3797a6a960e1b06885c0f8','36f0d096874cc84265f1180798b35e74ccb363dc','Image.CropScaleMask','09b0a67918',1200,800),
(23,1795370257,1795370257,1,21,'',NULL,'','a:3:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"crop\";N;}','60473dcbb40e956b51b233ed911d60077665c731','36f0d096874cc84265f1180798b35e74ccb363dc','Image.CropScaleMask','a3b8c8f19e',300,200);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,1,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(2,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,3,NULL,NULL,2,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(3,1,1795344511,1795344511,0,0,0,0,NULL,'',0,0,0,0,4,NULL,NULL,3,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(4,5,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,11,NULL,'A mobile phone confirming a payment, beside a stack of coins',11,'tt_content','image',1,'','Pay by mobile money: the receipt arrives on your phone.',NULL,0,0),
(5,6,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,12,NULL,'Two houses on surveyed plots on a green hillside',13,'tt_content','image',1,'','Every plot in the valuation roll has a rateable value.',NULL,0,0),
(6,7,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,13,NULL,'A shop with a striped awning and a framed business permit',16,'tt_content','image',1,'','One permit a year covers trade, health and fire safety.',NULL,0,0),
(7,8,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,14,NULL,'Two cars parked beside a parking sign',18,'tt_content','image',1,'','Parking on Beach Road is paid Monday to Saturday, 7:00 to 18:00.',NULL,0,0),
(8,9,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,15,NULL,'Two market stalls with fruit and vegetables',20,'tt_content','image',1,'','Stalls at the central market on Market Street.',NULL,0,0),
(9,10,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,16,NULL,'A calendar with a ticked check mark beside it',22,'tt_content','image',1,'','Clear your arrears before 30 June to have the interest waived.',NULL,0,0),
(10,11,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,17,NULL,'A health centre with a red cross sign',24,'tt_content','image',1,'','Mto Safi Town health centre, open Monday to Saturday.',NULL,0,0),
(11,12,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,18,NULL,'A river running through green land, with a water tower and a tap',26,'tt_content','image',1,'','The river gives the town its name: Mto Safi means \"clean river\".',NULL,0,0),
(12,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,19,NULL,'A dhow sailing at sunset with a palm tree on the beach',29,'tt_content','image',1,'','A dhow leaves the old harbour at sunset.',NULL,0,0),
(13,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,19,NULL,'A dhow sailing at sunset with a palm tree on the beach',31,'tt_content','image',1,'','Sunset over the old dhow harbour.',NULL,0,0),
(14,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,15,NULL,'Two market stalls with fruit and vegetables',31,'tt_content','image',2,'','Mangoes, tomatoes and sukuma wiki at the central market.',NULL,0,0),
(15,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,18,NULL,'A river running through green land, with a water tower and a tap',31,'tt_content','image',3,'','The river mouth, where the mangrove boardwalk starts.',NULL,0,0),
(16,13,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,20,NULL,'The municipal office with a flag on the roof',31,'tt_content','image',4,'','The municipal office, built in 1962, on Beach Road.',NULL,0,0),
(17,14,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,21,NULL,'Residents gathered in front of a board at a public forum',32,'tt_content','image',1,'','Budget forum in the municipal hall, Central ward.',NULL,0,0),
(18,15,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,20,NULL,'The municipal office with a flag on the roof',34,'tt_content','image',1,'','The municipal office on Beach Road.',NULL,0,0),
(19,17,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,22,NULL,'A laptop showing a login form, beside a padlock',37,'tt_content','image',1,'','Log in with your eCitizen account.',NULL,0,0),
(20,18,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,23,NULL,'A web page with clear headings and a focused button, beside the accessibility symbol',38,'tt_content','image',1,'','Example image: replace it together with the text.',NULL,0,0),
(21,19,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,24,NULL,'A shield with a padlock',39,'tt_content','image',1,'','Example image: replace it together with the text.',NULL,0,0),
(22,20,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,25,NULL,'A folder of documents and a magnifying glass',40,'tt_content','image',1,'','Requests are answered within 21 days.',NULL,0,0),
(23,21,1795368020,1795368020,0,0,0,0,NULL,'',0,0,0,0,26,NULL,'A building under construction with a crane, and a sealed envelope',42,'tt_content','image',1,'','Bids go in a sealed envelope to the procurement office.',NULL,0,0),
(24,1,1795414399,1795414399,0,0,1,1,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"showinpreview\":\"0\",\"sorting_foreign\":\"1\",\"tablenames\":\"tx_mtosafisitepackage_slide\",\"title\":\"\",\"uid_foreign\":\"1\",\"uid_local\":\"2\"}',0,0,0,0,2,NULL,NULL,4,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(25,1,1795414399,1795414399,0,0,1,2,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"showinpreview\":\"0\",\"sorting_foreign\":\"1\",\"tablenames\":\"tx_mtosafisitepackage_slide\",\"title\":\"\",\"uid_foreign\":\"2\",\"uid_local\":\"3\"}',0,0,0,0,3,NULL,NULL,5,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(26,1,1795414399,1795414399,0,0,1,3,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"\",\"description\":\"\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"showinpreview\":\"0\",\"sorting_foreign\":\"1\",\"tablenames\":\"tx_mtosafisitepackage_slide\",\"title\":\"\",\"uid_foreign\":\"3\",\"uid_local\":\"4\"}',0,0,0,0,4,NULL,NULL,6,'tx_mtosafisitepackage_slide','image',1,'',NULL,NULL,0,0),
(27,15,1795414399,1795414399,0,0,1,18,NULL,'{\"alternative\":\"The municipal office with a flag on the roof\",\"autoplay\":\"0\",\"crop\":\"\",\"description\":\"The municipal office on Beach Road.\",\"fieldname\":\"image\",\"hidden\":\"0\",\"link\":\"\",\"showinpreview\":\"0\",\"sorting_foreign\":\"1\",\"tablenames\":\"tt_content\",\"title\":\"\",\"uid_foreign\":\"34\",\"uid_local\":\"20\"}',0,0,0,0,20,NULL,'Ofisi ya manispaa yenye bendera juu ya paa',53,'tt_content','image',1,'','Ofisi ya manispaa kwenye Beach Road.',NULL,0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1795334315,1795334315,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1795336957,0,0,0,NULL,'News images','1:/user_upload/news/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1795332992,1,'BE',1,0,2,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"Sidebar probe\",\"bodytext\":\"<p>Rendered from the area sidebar.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795332992,\"t3ver_stage\":0,\"tstamp\":1795332992,\"uid\":2}',0,'0400$Ab_ebDixmlobc09ZW_wpQOm13MVZdCpf:01dbc21fdb1263685b9147b3b1596ea8'),
(2,1795332999,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":null},\"newRecord\":{\"backend_layout\":\"pagets__Default\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$xqYtF2Yzjz8vs6EvJQvzLj3QUpVEEGdA:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1795333001,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Default\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\"}}',0,'0400$dxU1W8i-7n0ls8Dxve2BCaS2_U6etDoY:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1795333004,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Home\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"}}',0,'0400$12o7r9be8NdlTq7M72UstYxByrD_Sh_g:e175f7045d7ccbfb26ffcf279422c2e5'),
(5,1795333006,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarLeft\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\"}}',0,'0400$s0fUPA88SDA-I6r3a2F12T6-HMxysVUK:e175f7045d7ccbfb26ffcf279422c2e5'),
(6,1795333009,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__SidebarRight\"},\"newRecord\":{\"backend_layout\":\"pagets__Narrow\"}}',0,'0400$rWk3qQFI-05fLi5WkRdZtrLMsXXEvAU3:e175f7045d7ccbfb26ffcf279422c2e5'),
(7,1795333011,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__Narrow\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$Xfdponrx3mLaIVs0SAIfgknY-Uy1U1cn:e175f7045d7ccbfb26ffcf279422c2e5'),
(8,1795333022,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":2}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:f11830df10b4b0bca2db34810c2241b3'),
(9,1795333022,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"backend_layout\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":3}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(10,1795333022,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795333022,\"t3ver_stage\":0,\"tstamp\":1795333022,\"uid\":4}',0,'0400$6O9k9gWNqODicLlfZdAZvOE2unEEcbHF:412add0b3eb6ec8f1cb6710aea92e21e'),
(11,1795333042,4,'BE',1,0,2,'tt_content',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:01dbc21fdb1263685b9147b3b1596ea8'),
(12,1795333042,4,'BE',1,0,4,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:412add0b3eb6ec8f1cb6710aea92e21e'),
(13,1795333042,4,'BE',1,0,3,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(14,1795333042,4,'BE',1,0,2,'pages',NULL,0,'0400$Et27_6xJa9HaTno_RP-mTGjP1NNYDWXK:f11830df10b4b0bca2db34810c2241b3'),
(15,1795334294,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Revenue & payments\",\"backend_layout\":\"pagets__SidebarLeft\",\"backend_layout_next_level\":\"pagets__SidebarLeft\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":5}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7ef5a4e3e11db8ac3fea4d7a75468161'),
(16,1795334294,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Land rates\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":6}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c75354c439a48dbde16b03ac553a080d'),
(17,1795334294,1,'BE',1,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Single business permit\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":7}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:df50bb24cbce671cf0d61f42fbbef601'),
(18,1795334294,1,'BE',1,0,8,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/parking-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Parking fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":8}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:595375f2fb9f014e091eb08fbc51ec88'),
(19,1795334294,1,'BE',1,0,9,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/market-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Market fees\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":9}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(20,1795334294,1,'BE',1,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/revenue-payments\\/waiver-of-interest\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Waiver of interest\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":10}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e904af5a60392ab3165f5849f5877e45'),
(21,1795334294,1,'BE',1,0,11,'pages','{\"doktype\":\"1\",\"slug\":\"\\/health\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":11}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:51bca2bcf14079cc366c99de31802400'),
(22,1795334294,1,'BE',1,0,12,'pages','{\"doktype\":\"1\",\"slug\":\"\\/environment-water\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Environment & water\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":12}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:d6f57183d4ec29f4a568a174f36b861b'),
(23,1795334294,1,'BE',1,0,13,'pages','{\"doktype\":\"1\",\"slug\":\"\\/trade-tourism\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Trade & tourism\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":13}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:8a89606121863fe3a2ec2ea63ba83d69'),
(24,1795334294,1,'BE',1,0,14,'pages','{\"doktype\":\"1\",\"slug\":\"\\/public-participation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":14}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aaa274fb7a5f76c9749f1b2c8fba84a4'),
(25,1795334294,1,'BE',1,0,15,'pages','{\"doktype\":\"1\",\"slug\":\"\\/contact\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1536,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":15}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:c97934f122918253f51c81fbe45fd105'),
(26,1795334294,1,'BE',1,0,16,'pages','{\"doktype\":\"1\",\"slug\":\"\\/search\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1792,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Search\",\"nav_hide\":1,\"backend_layout\":\"pagets__SidebarRight\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":16}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:878fab4218e507eb25dda6ac21dd7ff1'),
(27,1795334294,1,'BE',1,0,17,'pages','{\"doktype\":\"1\",\"slug\":\"\\/e-services-portal\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2048,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":17}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:dd30e16e220c1cff5911b320aa60dbce'),
(28,1795334294,1,'BE',1,0,18,'pages','{\"doktype\":\"1\",\"slug\":\"\\/accessibility-statement\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2304,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":18}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:9e9e8c5ba4be654320a3cd25d73d01a4'),
(29,1795334294,1,'BE',1,0,19,'pages','{\"doktype\":\"1\",\"slug\":\"\\/privacy-policy\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2560,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":19}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:25dbd94d40a6ff54757b6e36bf898997'),
(30,1795334294,1,'BE',1,0,20,'pages','{\"doktype\":\"1\",\"slug\":\"\\/access-to-information\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2816,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":20}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:1d0206225cc3f30f7ba150ff3aae8ab7'),
(31,1795334294,1,'BE',1,0,21,'pages','{\"doktype\":\"1\",\"slug\":\"\\/tenders\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3072,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":21}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:bb4ab293ec9d3ccfe43678d078f6cea0'),
(32,1795334294,1,'BE',1,0,22,'pages','{\"doktype\":\"254\",\"slug\":\"\\/service-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3328,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Service navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":22}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e5087395befe41329009e7b123017494'),
(33,1795334294,1,'BE',1,0,23,'pages','{\"doktype\":\"254\",\"slug\":\"\\/footer-navigation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3584,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Footer navigation\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":23}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7e88f7aa7664c6f494370160b60358a1'),
(34,1795334294,1,'BE',1,0,24,'pages','{\"doktype\":\"4\",\"slug\":\"\\/e-services-portal-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"E-services portal\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":24}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:219ad4d34a3e23c6ccf2ca87da6bc52b'),
(35,1795334294,1,'BE',1,0,25,'pages','{\"doktype\":\"4\",\"slug\":\"\\/contact-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":25}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:464961a1483e7dda27d23c882ff696bb'),
(36,1795334294,1,'BE',1,0,26,'pages','{\"doktype\":\"4\",\"slug\":\"\\/accessibility-statement-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Accessibility statement\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":26}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:544939248209022b223d317bc97b7099'),
(37,1795334294,1,'BE',1,0,27,'pages','{\"doktype\":\"4\",\"slug\":\"\\/privacy-policy-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Privacy policy\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":27}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:97019c60b3ac7f8b98007c072afa2f0f'),
(38,1795334294,1,'BE',1,0,28,'pages','{\"doktype\":\"4\",\"slug\":\"\\/access-to-information-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access to information\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":28}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:aa68f552fa168869c47f8dbefb43cba0'),
(39,1795334294,1,'BE',1,0,29,'pages','{\"doktype\":\"4\",\"slug\":\"\\/tenders-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Tenders\",\"sys_language_uid\":0,\"crdate\":1795334294,\"t3ver_stage\":0,\"tstamp\":1795334294,\"uid\":29}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:2d7ab27da714dae3c89a6e0cb79b80cd'),
(40,1795334294,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Home\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\"}\"}}',0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:e175f7045d7ccbfb26ffcf279422c2e5'),
(41,1795334294,4,'BE',1,0,1,'tt_content',NULL,0,'0400$K4OZd8oLsdIO8nwWCQ2x82pmrqhB7f-1:7fa2c035f26826fe83eeecaaeddc4d40'),
(42,1795336956,1,'BE',1,0,30,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3200,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":30}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:e3e225390eee037c1380949b378763b1'),
(43,1795336956,1,'BE',1,0,31,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news\\/article\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":30,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Article\",\"nav_hide\":1,\"backend_layout\":\"pagets__Article\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":31}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:9cb7b2b3fac90492135e3538aed4605a'),
(44,1795336956,1,'BE',1,0,32,'pages','{\"doktype\":\"254\",\"slug\":\"\\/news-records\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3840,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News records\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":32}',0,'0400$rTH4IENpY5kloyqsp71emQStmkWGL7Ko:302984e7412d7a45766e1d6304831138'),
(45,1795336956,1,'BE',1,0,1,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"trade-markets\",\"pid\":32,\"sorting\":256,\"title\":\"Trade & markets\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c6c8e24453121a7d668fe4b1031ebf88'),
(46,1795336956,1,'BE',1,0,2,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"roads-transport\",\"pid\":32,\"sorting\":512,\"title\":\"Roads & transport\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:497028e4af2a2cda8419e90cde34f71b'),
(47,1795336956,1,'BE',1,0,3,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"health\",\"pid\":32,\"sorting\":768,\"title\":\"Health\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:265912e2a2dda6b4b6be4e7069754d09'),
(48,1795336956,1,'BE',1,0,4,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"revenue-payments\",\"pid\":32,\"sorting\":1024,\"title\":\"Revenue & payments\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:a832991055f9726888b6b83414d05630'),
(49,1795336956,1,'BE',1,0,5,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"public-participation\",\"pid\":32,\"sorting\":1280,\"title\":\"Public participation\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:55bc761d39a2d7a8b56679774f51dfe6'),
(50,1795336956,1,'BE',1,0,6,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"environment\",\"pid\":32,\"sorting\":1536,\"title\":\"Environment\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:0580043665451ed803b9e5d021b149fe'),
(51,1795336956,1,'BE',1,0,7,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"water\",\"pid\":32,\"sorting\":1792,\"title\":\"Water\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:e6068a768abec7500a6d253c29088f52'),
(52,1795336956,1,'BE',1,0,8,'sys_category','{\"parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"education\",\"pid\":32,\"sorting\":2048,\"title\":\"Education\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":8}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f564fff7cae82b30644518a57bd7a8a6'),
(53,1795336956,1,'BE',1,0,1,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-fish-market-opens-at-the-jetty\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New fish market opens at the jetty\",\"datetime\":1793595600,\"teaser\":\"Sixty stalls, cold storage and clean water for traders and buyers.\",\"bodytext\":\"<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night\\u2019s catch and running water at every stall.<\\/p>\\r\\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Trade &amp; Markets Office, +254 700 000 010<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":1}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:fccd16ea3664ec003726b2a72ea38f4b'),
(54,1795336956,1,'BE',1,0,2,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"beach-road-resurfacing-starts\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Beach Road resurfacing starts\",\"datetime\":1793077200,\"teaser\":\"Works run for six weeks. Matatus take the diversion via Market Street.\",\"bodytext\":\"<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.<\\/p>\\r\\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Roads Department, +254 700 000 020<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":2}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:640f28e5c1a5ec2efb19c26699b464a5'),
(55,1795336956,1,'BE',1,0,3,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"free-health-camp-in-ward-3\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Free health camp in Ward 3\",\"datetime\":1792472400,\"teaser\":\"Eye tests, vaccinations and screening, open to every resident.\",\"bodytext\":\"<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.<\\/p>\\r\\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Health Department, +254 700 000 030<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:1152fda277b2623b0152b5765fcb6b28'),
(56,1795336956,1,'BE',1,0,4,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"pay-land-rates-by-mobile-money-from-january\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Pay land rates by mobile money from January\",\"datetime\":1791781200,\"teaser\":\"Residents can now pay land rates and business permits with their phone.\",\"bodytext\":\"<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.<\\/p>\\r\\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Revenue Department, +254 700 000 040<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:f3f39c24ca39d00c02ecd29ec2ad4225'),
(57,1795336956,1,'BE',1,0,5,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"have-your-say-on-the-budget-2027-28\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Have your say on the budget 2027\\/28\",\"datetime\":1790830800,\"teaser\":\"Public participation forums in every ward in November.\",\"bodytext\":\"<p>The municipality prepares its budget for 2027\\/28 and asks residents what matters most to them: roads, water, markets, health or schools.<\\/p>\\r\\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Planning Office, +254 700 000 050<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:bc83755a03cca2ca5c8daa03e9d6e32e'),
(58,1795336956,1,'BE',1,0,6,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"mto-safi-named-cleanest-town-on-the-coast\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"Mto Safi named cleanest town on the coast\",\"datetime\":1789707600,\"teaser\":\"The monthly beach clean-ups and the new waste collection paid off.\",\"bodytext\":\"<p>Mto Safi has won this year\\u2019s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.<\\/p>\\r\\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Environment Department, +254 700 000 060<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":6}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:7e4fc5d3ec5edd1f76b0a3820eb3fb47'),
(59,1795336956,1,'BE',1,0,7,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"new-boreholes-bring-clean-water-to-ward-5\",\"sitemap_priority\":\"0.5\",\"pid\":32,\"title\":\"New boreholes bring clean water to Ward 5\",\"datetime\":1788584400,\"teaser\":\"Three boreholes and twelve water kiosks serve 4,000 residents.\",\"bodytext\":\"<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.<\\/p>\\r\\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.<\\/p>\\r\\n<p><strong>Contact:<\\/strong> Water &amp; Sanitation Department, +254 700 000 070<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":7}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:31860b4bf14b13d2dc895987af663784'),
(60,1795336956,1,'BE',1,0,3,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"News\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">home<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":3}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:b92300cfb5d1d3645c9cb212a7f56c1f'),
(61,1795336956,1,'BE',1,0,4,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":30,\"sorting\":256,\"header\":\"All news\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":4}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:4d391f5ef79b8d5d10dffa8a07ca167d'),
(62,1795336956,1,'BE',1,0,5,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":31,\"sorting\":256,\"header\":\"News article\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795336956,\"t3ver_stage\":0,\"tstamp\":1795336956,\"uid\":5}',0,'0400$86xJqIDAVxA5RjdJECjk8kqBoPK-_GTy:c7626fc9bcba6f70beb6ebc085a400db'),
(63,1795343750,1,'BE',1,0,6,'tt_content','{\"CType\":\"mtosafi_tiles\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":128,\"header\":\"Popular services\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c0db6803ab1ec5f70c36e2a72187867b'),
(64,1795343750,1,'BE',1,0,1,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"icon\":\"\\ud83c\\udfea\",\"label\":\"Single business permit\",\"link\":\"t3:\\/\\/page?uid=7\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":1}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:55820ddffac9b29987f66a48c05c3e01'),
(65,1795343750,1,'BE',1,0,2,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"icon\":\"\\ud83c\\udfe1\",\"label\":\"Land rates\",\"link\":\"t3:\\/\\/page?uid=6\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":2}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:b6549a503cf1dd498f3571f7d5d85d54'),
(66,1795343750,1,'BE',1,0,3,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"icon\":\"\\ud83c\\udd7f\\ufe0f\",\"label\":\"Parking fees\",\"link\":\"t3:\\/\\/page?uid=8\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":3}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:518760b21a46e7982878ebf568972b86'),
(67,1795343750,1,'BE',1,0,4,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":32,\"icon\":\"\\ud83d\\udca7\",\"label\":\"Water connection\",\"link\":\"t3:\\/\\/page?uid=12\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":4}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:ba2135e3eae99237605541429e1c8913'),
(68,1795343750,1,'BE',1,0,5,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":16,\"icon\":\"\\ud83e\\uddfa\",\"label\":\"Market stalls\",\"link\":\"t3:\\/\\/page?uid=9\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":5}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:c65d007d6e8748b9615f1c9e01a28b86'),
(69,1795343750,1,'BE',1,0,6,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":8,\"icon\":\"\\ud83d\\udce3\",\"label\":\"Report a problem\",\"link\":\"t3:\\/\\/page?uid=15\",\"sys_language_uid\":0,\"crdate\":1795343750,\"t3ver_stage\":0,\"tstamp\":1795343750,\"uid\":6}',0,'0400$2DpUg7RvpcWV8vWSHNx1PXw7D4baKoW-:632dfe70d9c02f2a21151ad96efaec1c'),
(70,1795344511,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"2\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:4cf496f597e7b095ce8b755e6cec3c0c'),
(71,1795344511,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"3\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:814fc0f720dfab882655a795e23a5b66'),
(72,1795344511,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":1,\"uid_local\":\"4\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:d2c609347a4764200256b39b9425159a'),
(73,1795344511,1,'BE',1,0,7,'tt_content','{\"CType\":\"mtosafi_slider\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":64,\"header\":\"Highlights\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":7}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:ea41b626baac59a1fe0716bc344af5d9'),
(74,1795344511,1,'BE',1,0,1,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"title\":\"Karibu Mto Safi\",\"text\":\"White beaches, a clean river and a municipality that serves you online, day and night.\",\"link\":\"t3:\\/\\/page?uid=13\",\"link_label\":\"Discover Mto Safi\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":1}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:1ffe01378bcddf3cd4b7ccc25f2930f6'),
(75,1795344511,1,'BE',1,0,2,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"title\":\"Pay your land rates by mobile money\",\"text\":\"Calculate what you owe and pay before 31 March to avoid interest.\",\"link\":\"t3:\\/\\/page?uid=6\",\"link_label\":\"Calculate land rates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":2}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:de55124b95b3be65ab1a5218e23dea0d'),
(76,1795344511,1,'BE',1,0,3,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"title\":\"Have your say on the budget\",\"text\":\"Join the public participation forums in every ward this month.\",\"link\":\"t3:\\/\\/page?uid=14\",\"link_label\":\"See the forum dates\",\"sys_language_uid\":0,\"crdate\":1795344511,\"t3ver_stage\":0,\"tstamp\":1795344511,\"uid\":3}',0,'0400$y85rNvtcwfvOeqi3PMgPKFH-hgYFMbrj:e8603ac799ba0c457941e1d26db41cb8'),
(77,1795345582,1,'BE',1,0,33,'pages','{\"doktype\":\"1\",\"slug\":\"\\/page-not-found\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3136,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Page not found\",\"nav_hide\":1,\"backend_layout\":\"pagets__Narrow\",\"no_index\":1,\"no_follow\":1,\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":33}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:0c3ed5b51e5eff03577c1c2f671f9fbe'),
(78,1795345582,1,'BE',1,0,8,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":33,\"sorting\":256,\"header\":\"This page does not exist\",\"bodytext\":\"<p>The page you are looking for may have moved, or the address may be mistyped.<\\/p>\\r\\n<ul><li><a href=\\\"t3:\\/\\/page?uid=1\\\">Go to the home page<\\/a><\\/li><li><a href=\\\"t3:\\/\\/page?uid=16\\\">Search the site<\\/a><\\/li><\\/ul>\",\"sys_language_uid\":0,\"crdate\":1795345582,\"t3ver_stage\":0,\"tstamp\":1795345582,\"uid\":8}',0,'0400$VZwahj5W6NTvCNh8UdQE_6eNbPlLnTPr:2097d84972a039cb6bfe093b17089287'),
(79,1795348009,1,'BE',1,0,34,'pages','{\"doktype\":\"254\",\"slug\":\"\\/search-index\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":4096,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Search index\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":34}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:152f249a1550628c00eb2837d4cfde70'),
(80,1795348009,2,'BE',1,0,16,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:878fab4218e507eb25dda6ac21dd7ff1'),
(81,1795348009,2,'BE',1,0,33,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:0c3ed5b51e5eff03577c1c2f671f9fbe'),
(82,1795348009,2,'BE',1,0,31,'pages','{\"oldRecord\":{\"no_search\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"no_search\":1,\"l10n_diffsource\":\"{\\\"no_search\\\":\\\"\\\"}\"}}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:9cb7b2b3fac90492135e3538aed4605a'),
(83,1795348009,1,'BE',1,0,1,'tx_kesearch_filteroptions','{\"l10n_parent\":0,\"slug\":\"services\",\"hidden\":0,\"pid\":34,\"sorting\":256,\"title\":\"Services\",\"tag\":\"service\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"tag\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:5959a4f398aeb048aebac4b34bca8539'),
(84,1795348009,1,'BE',1,0,2,'tx_kesearch_filteroptions','{\"l10n_parent\":0,\"slug\":\"news\",\"hidden\":0,\"pid\":34,\"sorting\":512,\"title\":\"News\",\"tag\":\"news\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"tag\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":2}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:90ae5ff47c0a84f43bdf13d71c840463'),
(85,1795348009,1,'BE',1,0,1,'tx_kesearch_filters','{\"rendertype\":\"checkbox\",\"markAllCheckboxes\":\"0\",\"target_pid\":0,\"amount\":10,\"shownumberofresults\":\"1\",\"alphabeticalsorting\":0,\"hidden\":0,\"pid\":34,\"title\":\"Show only\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"alphabeticalsorting\\\":\\\"\\\",\\\"amount\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"markAllCheckboxes\\\":\\\"\\\",\\\"options\\\":\\\"\\\",\\\"rendertype\\\":\\\"\\\",\\\"shownumberofresults\\\":\\\"\\\",\\\"target_pid\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$VzMREKTezVmlbNKu8bH6VI9bV7cZwUg4:37c8f0a5f51b180b553539a4ba22f33e'),
(86,1795348009,1,'BE',1,0,1,'tx_kesearch_indexerconfig','{\"type\":\"page\",\"index_content_with_restrictions\":\"no\",\"index_news_category_mode\":\"1\",\"index_use_page_tags\":\"0\",\"fileext\":\"pdf,ppt,doc,xls,docx,xlsx,pptx\",\"file_reference_fields\":\"media\",\"index_use_page_tags_for_files\":\"0\",\"index_page_doctypes\":\"1\",\"content_fields\":\"bodytext,subheader,header_link\",\"page_fields\":\"\",\"page_fields_hidden\":\"\",\"fal_storage\":\"0\",\"contenttypes\":\"text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline\",\"additional_tables\":\"[accordion]\\ntable = tx_bootstrappackage_accordion_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[tab]\\ntable = tx_bootstrappackage_tab_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[carousel]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_fullscreen]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_small]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[icon_group]\\ntable = tx_bootstrappackage_icon_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\n\\n[card_group]\\ntable = tx_bootstrappackage_card_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\nfields[] = link_title\\n\\n[timeline]\\ntable = tx_bootstrappackage_timeline_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\",\"hidden\":0,\"pid\":34,\"title\":\"Pages\",\"storagepid\":\"34\",\"startingpoints_recursive\":\"1\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":1}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:11382f33999b3ba5cfa81546397116be'),
(87,1795348009,1,'BE',1,0,2,'tx_kesearch_indexerconfig','{\"type\":\"news\",\"index_content_with_restrictions\":\"no\",\"index_news_category_mode\":\"1\",\"index_use_page_tags\":\"0\",\"fileext\":\"pdf,ppt,doc,xls,docx,xlsx,pptx\",\"file_reference_fields\":\"media\",\"index_use_page_tags_for_files\":\"0\",\"index_page_doctypes\":\"1\",\"content_fields\":\"bodytext,subheader,header_link\",\"page_fields\":\"\",\"page_fields_hidden\":\"\",\"fal_storage\":\"0\",\"contenttypes\":\"text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline\",\"additional_tables\":\"[accordion]\\ntable = tx_bootstrappackage_accordion_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[tab]\\ntable = tx_bootstrappackage_tab_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\\n\\n[carousel]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_fullscreen]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[carousel_small]\\ntable = tx_bootstrappackage_carousel_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = nav_title\\nfields[] = link\\n\\n[icon_group]\\ntable = tx_bootstrappackage_icon_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\n\\n[card_group]\\ntable = tx_bootstrappackage_card_group_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = subheader\\nfields[] = bodytext\\nfields[] = link\\nfields[] = link_title\\n\\n[timeline]\\ntable = tx_bootstrappackage_timeline_item\\nreferenceFieldName = tt_content\\nfields[] = header\\nfields[] = bodytext\",\"hidden\":0,\"pid\":34,\"title\":\"News\",\"storagepid\":\"34\",\"targetpid\":\"31\",\"startingpoints_recursive\":\"32\",\"crdate\":1795348009,\"tstamp\":1795348009,\"uid\":2}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:e9c59d805adb65b75c5f9ae69a7ee95b'),
(88,1795348009,1,'BE',1,0,9,'tt_content','{\"CType\":\"ke_search_pi1\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":16,\"sorting\":256,\"header\":\"Filter results\",\"pages\":\"34\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"MAIN\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"resultPage\\\">\\n                    <value index=\\\"vDEF\\\">16<\\/value>\\n                <\\/field>\\n                <field index=\\\"showTextInsteadOfResults\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"textForResults\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Type what you are looking for into the search field at the top of the page.&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"showNoResultsText\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"view\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"highlightSword\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultChars\\\">\\n                    <value index=\\\"vDEF\\\">200<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultsNumeration\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showResultUrl\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showDate\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"images\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"showTypeIcon\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showPageImages\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showNewsImages\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"showFilePreview\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"pagebrowser\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"pagebrowserOnTop\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"pagebrowserAtBottom\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"resultsPerPage\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"maxPagesInPagebrowser\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"filter\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"filters\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":9}',0,'0400$4b5AueGv_xlybqmnvAlz0AWct0QU0mLf:367f4f227870d8e2a11496a182574aa3'),
(89,1795348009,1,'BE',1,0,10,'tt_content','{\"CType\":\"ke_search_pi2\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":16,\"sorting\":128,\"header\":\"Search results\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"MAIN\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"loadFlexformsFromOtherCE\\\">\\n                    <value index=\\\"vDEF\\\">9<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795348009,\"t3ver_stage\":0,\"tstamp\":1795348009,\"uid\":10}',0,'0400$vpXrqLCAGuB2w85UkB4ezd96Nu_zS1x9:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(90,1795368020,1,'BE',1,0,4,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Pay by mobile money: the receipt arrives on your phone.\",\"alternative\":\"A mobile phone confirming a payment, beside a stack of coins\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":5,\"uid_local\":\"11\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":4}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:cea5fcd7b97871880cfe3717d6b52ef4'),
(91,1795368020,1,'BE',1,0,5,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Every plot in the valuation roll has a rateable value.\",\"alternative\":\"Two houses on surveyed plots on a green hillside\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":6,\"uid_local\":\"12\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":5}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5f15a1453f67b933ed3314381f5d67e4'),
(92,1795368020,1,'BE',1,0,6,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"One permit a year covers trade, health and fire safety.\",\"alternative\":\"A shop with a striped awning and a framed business permit\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":7,\"uid_local\":\"13\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":6}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:768f9cd4e98812f969df7ebe17f11b50'),
(93,1795368020,1,'BE',1,0,7,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Parking on Beach Road is paid Monday to Saturday, 7:00 to 18:00.\",\"alternative\":\"Two cars parked beside a parking sign\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":8,\"uid_local\":\"14\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":7}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:117c97010b9af15cb554d115dba4e316'),
(94,1795368020,1,'BE',1,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Stalls at the central market on Market Street.\",\"alternative\":\"Two market stalls with fruit and vegetables\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":9,\"uid_local\":\"15\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":8}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(95,1795368020,1,'BE',1,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Clear your arrears before 30 June to have the interest waived.\",\"alternative\":\"A calendar with a ticked check mark beside it\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":10,\"uid_local\":\"16\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":9}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:729356755eb8ee035abf6b9b02e20c8f'),
(96,1795368020,1,'BE',1,0,10,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Mto Safi Town health centre, open Monday to Saturday.\",\"alternative\":\"A health centre with a red cross sign\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":11,\"uid_local\":\"17\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":10}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b34a074e38840d41041eaee66c42bb0d'),
(97,1795368020,1,'BE',1,0,11,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The river gives the town its name: Mto Safi means \\\"clean river\\\".\",\"alternative\":\"A river running through green land, with a water tower and a tap\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":12,\"uid_local\":\"18\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":11}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b70904b959c6d327947fc437df028f6f'),
(98,1795368020,1,'BE',1,0,12,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"A dhow leaves the old harbour at sunset.\",\"alternative\":\"A dhow sailing at sunset with a palm tree on the beach\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":12}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:fef2cecc4ff45c64d73fc27195ee5748'),
(99,1795368020,1,'BE',1,0,13,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Sunset over the old dhow harbour.\",\"alternative\":\"A dhow sailing at sunset with a palm tree on the beach\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":13}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5e1f4fea56ad8d21a419f2b59b059abf'),
(100,1795368020,1,'BE',1,0,14,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Mangoes, tomatoes and sukuma wiki at the central market.\",\"alternative\":\"Two market stalls with fruit and vegetables\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"15\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":14}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:2207c2b650522ebf0efd90eaad3962af'),
(101,1795368020,1,'BE',1,0,15,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The river mouth, where the mangrove boardwalk starts.\",\"alternative\":\"A river running through green land, with a water tower and a tap\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"18\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":15}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:53cbb769126fb106e07a09de5e196b60'),
(102,1795368020,1,'BE',1,0,16,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The municipal office, built in 1962, on Beach Road.\",\"alternative\":\"The municipal office with a flag on the roof\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":13,\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":16}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5a9ade48273ee95d803333aed1c78820'),
(103,1795368020,1,'BE',1,0,17,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Budget forum in the municipal hall, Central ward.\",\"alternative\":\"Residents gathered in front of a board at a public forum\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":14,\"uid_local\":\"21\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":17}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:78ba90db28917b77e8d54ca398316d0e'),
(104,1795368020,1,'BE',1,0,18,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"The municipal office on Beach Road.\",\"alternative\":\"The municipal office with a flag on the roof\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":15,\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":18}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:c9d27ac33ea45c5163a9ef7a25d8e7c7'),
(105,1795368020,1,'BE',1,0,19,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Log in with your eCitizen account.\",\"alternative\":\"A laptop showing a login form, beside a padlock\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":17,\"uid_local\":\"22\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":19}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7008e0248119dc3a255a0170bf6e9370'),
(106,1795368020,1,'BE',1,0,20,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Example image: replace it together with the text.\",\"alternative\":\"A web page with clear headings and a focused button, beside the accessibility symbol\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":18,\"uid_local\":\"23\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":20}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:97d0d1c7a42cd9603b2010379c1e4e4d'),
(107,1795368020,1,'BE',1,0,21,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Example image: replace it together with the text.\",\"alternative\":\"A shield with a padlock\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":19,\"uid_local\":\"24\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":21}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:bd8e6a36b477d61e04d92cfd10d00f96'),
(108,1795368020,1,'BE',1,0,22,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Requests are answered within 21 days.\",\"alternative\":\"A folder of documents and a magnifying glass\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":20,\"uid_local\":\"25\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":22}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:d6a5725e5b31cdd97b9c53c992e81850'),
(109,1795368020,1,'BE',1,0,23,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":\"Bids go in a sealed envelope to the procurement office.\",\"alternative\":\"A building under construction with a crane, and a sealed envelope\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":21,\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":23}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a4b81cbb471961a3c12b21861b94f4e1'),
(110,1795368020,1,'BE',1,0,11,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":256,\"header\":\"Pay the municipality from wherever you are\",\"bodytext\":\"<p>Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.<\\/p>\\r\\n<p>Most of them can be paid by mobile money or by card in the <a href=\\\"t3:\\/\\/page?uid=17\\\">e-services portal<\\/a>, at any time of day. The cash office in the municipal office is open on working days.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":11}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7a14c618500ae24604910dfdd2f8ff12'),
(111,1795368020,1,'BE',1,0,12,'tt_content','{\"CType\":\"menu_subpages\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":512,\"header\":\"Payments and fees\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":12}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b13bbccfb8e2fc277be02db62485ced6'),
(112,1795368020,1,'BE',1,0,13,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":256,\"header\":\"How your land rates are calculated\",\"bodytext\":\"<p>Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.<\\/p>\\r\\n<p>Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":13}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:aa58d78b4f5fe95c0d2d1cb36d041737'),
(113,1795368020,1,'BE',1,0,14,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":512,\"header\":\"Rates for 2026\",\"bodytext\":\"Land use|Rate|Minimum per plot and year\\nResidential|0.5 % of the rateable value|KES 1,500\\nCommercial|1.2 % of the rateable value|KES 1,500\\nAgricultural|0.2 % of the rateable value|KES 1,500\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":14}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:338e104baa774eacaec42da729015b5f'),
(114,1795368020,1,'BE',1,0,15,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":768,\"header\":\"How to pay\",\"bodytext\":\"<p>Pay by mobile money, by card in the <a href=\\\"t3:\\/\\/page?uid=17\\\">e-services portal<\\/a>, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":15}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:cb118fde3da18e67b21a92b60bb8cbda'),
(115,1795368020,1,'BE',1,0,16,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":256,\"header\":\"One permit for your business\",\"bodytext\":\"<p>Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.<\\/p>\\r\\n<p>Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":16}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:43f02d513e41a72738b96558f7ee9015'),
(116,1795368020,1,'BE',1,0,17,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":512,\"header\":\"What you need to apply\",\"bodytext\":\"Your national ID or passport\\nThe KRA PIN of the business\\nThe plot number of the premises\\nA description of the activity and the number of employees\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":17}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:017157395cc6da9e5d2911de6dfd4b9e'),
(117,1795368020,1,'BE',1,0,18,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"26\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":8,\"sorting\":256,\"header\":\"Parking in the town centre\",\"bodytext\":\"<p>Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.<\\/p>\\r\\n<p>Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":18}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0a64be1ae1f9096cc345beb76e5e2095'),
(118,1795368020,1,'BE',1,0,19,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":8,\"sorting\":512,\"header\":\"Fees\",\"bodytext\":\"Vehicle|Per day|Per month\\nCar|KES 100|KES 2,000\\nPick-up and van|KES 150|KES 3,000\\nLorry|KES 300|KES 6,000\\nMotorcycle (boda boda)|KES 30|KES 500\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":19}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(119,1795368020,1,'BE',1,0,20,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":9,\"sorting\":256,\"header\":\"Selling at the municipal markets\",\"bodytext\":\"<p>Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.<\\/p>\\r\\n<p>Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":20}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(120,1795368020,1,'BE',1,0,21,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":9,\"sorting\":512,\"header\":\"Fees\",\"bodytext\":\"|Fee\\nStall, per month|KES 1,200\\nOpen space, per day|KES 50\\nFish market, per day|KES 80\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":21}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:7fd72e21409e45562c51e7581fc2cb0d'),
(121,1795368020,1,'BE',1,0,22,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"26\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":256,\"header\":\"Interest waived when you clear your arrears\",\"bodytext\":\"<p>Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.<\\/p>\\r\\n<p>Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":22}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:1a929832156241f61c37ce68bcae4a3c'),
(122,1795368020,1,'BE',1,0,23,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":512,\"header\":\"How it works\",\"bodytext\":\"Ask for a statement of your arrears\\nApply for the waiver with the statement\\nPay the arrears without the interest within 30 days of the approval\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":23}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0cf00ee1adffc41f8b3231c0de35256e'),
(123,1795368020,1,'BE',1,0,24,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":11,\"sorting\":256,\"header\":\"Health services close to home\",\"bodytext\":\"<p>The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.<\\/p>\\r\\n<p>For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":24}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:94bb7a1dbcc4ac71f45ee11546313fe2'),
(124,1795368020,1,'BE',1,0,25,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":11,\"sorting\":512,\"header\":\"Health centres\",\"bodytext\":\"Health centre|Ward|Opening hours\\nMto Safi Town|Central|Mon\\u2013Sat 7:00\\u201319:00\\nPwani|Beach|Mon\\u2013Fri 8:00\\u201317:00\\nKijiji|Upper River|Mon\\u2013Fri 8:00\\u201317:00\\nMnarani|Mnarani|Mon\\u2013Fri 8:00\\u201317:00\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":25}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:581bf77acde559fe457e0d401d2ada7b'),
(125,1795368020,1,'BE',1,0,26,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":256,\"header\":\"A clean river for everyone\",\"bodytext\":\"<p>Mto Safi means \\\"clean river\\\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":26}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f6bb218c440a87df0e0eb5986e28af41'),
(126,1795368020,1,'BE',1,0,27,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":512,\"header\":\"Water connection\",\"bodytext\":\"<p>To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.<\\/p>\\r\\n<p>To report a leak or a burst pipe, call +254 700 000 001 at any time.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":27}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:9c3671c42eb2c0522de6952ddc52c9a7'),
(127,1795368020,1,'BE',1,0,28,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":768,\"header\":\"Waste collection\",\"bodytext\":\"Town centre: Monday and Thursday\\nBeach and Mnarani: Tuesday and Friday\\nUpper River: Wednesday and Saturday\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":28}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:b5d015227f2b36f7786e2ff963ca9d51'),
(128,1795368020,1,'BE',1,0,29,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":256,\"header\":\"Karibu Mto Safi\",\"bodytext\":\"<p>White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.<\\/p>\\r\\n<p>The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under <a href=\\\"t3:\\/\\/page?uid=7\\\">Single business permit<\\/a>.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":29}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:12090f8e2b698e14ec860eca10ce232c'),
(129,1795368020,1,'BE',1,0,30,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":512,\"header\":\"Places to visit\",\"bodytext\":\"The dhow harbour and the fish market at sunrise\\nThe mangrove boardwalk at the river mouth\\nMto Safi beach and the coral garden\\nThe old town with its carved doors\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":30}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f6d670f6f6a9a0aecc0bb542c370acdf'),
(130,1795368020,1,'BE',1,0,31,'tt_content','{\"CType\":\"image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":13,\"sorting\":768,\"header\":\"Impressions of Mto Safi\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":31}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:a338b89fc8d0d789df4b1fd4d37a174b'),
(131,1795368020,1,'BE',1,0,32,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":14,\"sorting\":256,\"header\":\"Have your say on the budget\",\"bodytext\":\"<p>Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.<\\/p>\\r\\n<p>You can also send your views in writing to the clerk until 15 May.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":32}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:eeb3ef2adec88a8b5b3e3c510b74be1d'),
(132,1795368020,1,'BE',1,0,33,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":14,\"sorting\":512,\"header\":\"Forum dates\",\"bodytext\":\"Ward|Date|Place\\nCentral|4 May, 10:00|Municipal hall\\nBeach|6 May, 10:00|Pwani primary school\\nUpper River|8 May, 14:00|Kijiji social hall\\nMnarani|11 May, 10:00|Mnarani chief\'s camp\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":33}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:c1c3d2254ecfaef40b15a18e94a89b96'),
(133,1795368020,1,'BE',1,0,34,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":256,\"header\":\"Visit us\",\"bodytext\":\"<p>Mto Safi Municipality<br \\/>Municipal Office<br \\/>Beach Road 1<br \\/>P.O. Box 123, Mto Safi<\\/p>\\r\\n<p>Phone: <a href=\\\"tel:+254700000000\\\">+254 700 000 000<\\/a><br \\/>Email: <a href=\\\"mailto:info@mtosafi.example\\\">info@mtosafi.example<\\/a><\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":34}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5d9f35f4f50ff546dc3085666d071b48'),
(134,1795368020,1,'BE',1,0,35,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":512,\"header\":\"Opening hours\",\"bodytext\":\"Days|Hours\\nMon\\u2013Thu|8:00\\u201317:00\\nFriday|8:00\\u201313:00, 14:00\\u201317:00\\nSat, Sun|Closed\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":35}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:d31fbabb978b029b9ff62ab107e0a25e'),
(135,1795368020,1,'BE',1,0,36,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":768,\"header\":\"Report a problem\",\"bodytext\":\"<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\\\"mailto:report@mtosafi.example\\\">report@mtosafi.example<\\/a>, and say where it is.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":36}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:6fdd460ee24b22c6f60683a1eee4989a'),
(136,1795368020,1,'BE',1,0,37,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":17,\"sorting\":256,\"header\":\"Your municipal services online\",\"bodytext\":\"<p>In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.<\\/p>\\r\\n<p>Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":37}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:63988be2047e9f9c26151c5b9b4770d7'),
(137,1795368020,1,'BE',1,0,38,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":18,\"sorting\":256,\"header\":\"Example text\",\"bodytext\":\"<p>This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.<\\/p>\\r\\n<p>The design of this site targets WCAG 2.1 level AA.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":38}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:4bdce2eccaa2dfa57eb92d16572012a4'),
(138,1795368020,1,'BE',1,0,39,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":19,\"sorting\":256,\"header\":\"Example text\",\"bodytext\":\"<p>This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":39}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:eb04e3ff75360f80fc27ed5d3e94f482'),
(139,1795368020,1,'BE',1,0,40,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":20,\"sorting\":256,\"header\":\"Ask for the information we hold\",\"bodytext\":\"<p>Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.<\\/p>\\r\\n<p>We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":40}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:f63ce2811b6be061690bfdf008a41f07'),
(140,1795368020,1,'BE',1,0,41,'tt_content','{\"CType\":\"bullets\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":20,\"sorting\":512,\"header\":\"Published without a request\",\"bodytext\":\"The budget and the annual accounts\\nThe valuation roll\\nThe minutes of the municipal board\\nTenders and the contracts awarded\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":41}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:0d86f780a4565c319d6988991b035f3a'),
(141,1795368020,1,'BE',1,0,42,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":21,\"sorting\":256,\"header\":\"Doing business with the municipality\",\"bodytext\":\"<p>The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":42}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:5e996be55a352bc1f4f3f871c802dcec'),
(142,1795368020,1,'BE',1,0,43,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":21,\"sorting\":512,\"header\":\"Open tenders\",\"bodytext\":\"Number|Subject|Closes\\nMSM\\/T\\/01\\/2026|Resurfacing of Market Street|12 June\\nMSM\\/T\\/02\\/2026|Solar street lights, Beach ward|19 June\\nMSM\\/T\\/03\\/2026|Waste collection vehicles (2)|26 June\",\"sys_language_uid\":0,\"crdate\":1795368020,\"t3ver_stage\":0,\"tstamp\":1795368020,\"uid\":43}',0,'0400$xMLjJCXME4Y-J67HKbitobfUuM1jZtbq:9390101edeadec5344c252f3b3b98ec9'),
(143,1795369027,2,'BE',1,0,15,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__SidebarRight\",\"l10n_diffsource\":\"{\\\"backend_layout\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:c97934f122918253f51c81fbe45fd105'),
(144,1795369027,1,'BE',1,0,44,'tt_content','{\"CType\":\"form_formframework\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":128,\"header\":\"Write to us\",\"subheader\":\"The right department answers within five working days.\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">EXT:mtosafi_sitepackage\\/Resources\\/Private\\/Forms\\/contact.form.yaml<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795369027,\"t3ver_stage\":0,\"tstamp\":1795369027,\"uid\":44}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:3b272544b7c1a9f5690a42a5b760dca9'),
(145,1795369027,2,'BE',1,0,34,'tt_content','{\"oldRecord\":{\"colPos\":0,\"imageorient\":25,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"imageorient\":\"0\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:5d9f35f4f50ff546dc3085666d071b48'),
(146,1795369027,2,'BE',1,0,35,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:d31fbabb978b029b9ff62ab107e0a25e'),
(147,1795369027,2,'BE',1,0,36,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$4VqQG-xaO_urr_eYLrryuyRCTsGykTXl:6fdd460ee24b22c6f60683a1eee4989a'),
(148,1795372569,1,'BE',1,0,35,'pages','{\"doktype\":\"1\",\"slug\":\"\\/events\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3264,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Events\",\"nav_hide\":1,\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":35}',0,'0400$Q3782IGoGjQ0KNvZnsH7Kn0yTjRNYEg-:d58411788d5a726dba77a4228008d89f'),
(149,1795372569,1,'BE',1,0,36,'pages','{\"doktype\":\"1\",\"slug\":\"\\/events\\/event\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":35,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Event\",\"nav_hide\":1,\"backend_layout\":\"pagets__Article\",\"no_search\":1,\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":36}',0,'0400$Q3782IGoGjQ0KNvZnsH7Kn0yTjRNYEg-:baa7a09b75230872aacb0cfcf5051237'),
(150,1795372569,1,'BE',1,0,8,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"beach-clean-up-day\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Beach clean-up day\",\"datetime\":1794715200,\"event_end\":1794729600,\"location_simple\":\"Public beach, meeting point at the lifeguard tower\",\"categories\":\"1\",\"teaser\":\"Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.\",\"bodytext\":\"<p>Residents, schools and businesses clean the beach together. Gloves, bags and water are provided. The cleanest group wins a tree for its school.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 7:00\\u201311:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":8}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:ff635a07b31923a6d7cd863a31313787'),
(151,1795372569,1,'BE',1,0,9,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"public-participation-forum-budget-2027-28\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Public participation forum: budget 2027\\/28\",\"datetime\":1795330800,\"event_end\":1795341600,\"location_simple\":\"Municipal hall, Beach Road 1\",\"categories\":\"1\",\"teaser\":\"Municipal hall, 10:00. Every resident may speak.\",\"bodytext\":\"<p>Every resident may speak. The forum is held in Kiswahili and English. Sign language interpretation is available on request until 15 November.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 10:00\\u201313:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":9}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:ea59bb16023727fc0c0128366bbe4ed3'),
(152,1795372569,1,'BE',1,0,10,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"youth-job-and-skills-fair\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Youth job and skills fair\",\"datetime\":1796450400,\"event_end\":1796472000,\"location_simple\":\"Mto Safi Polytechnic\",\"categories\":\"1\",\"teaser\":\"Mto Safi Polytechnic, 9:00\\u201315:00. Bring copies of your CV and certificates.\",\"bodytext\":\"<p>Employers from tourism, fishing, construction and IT present jobs and apprenticeships. Bring copies of your CV and certificates.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 9:00\\u201315:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Recommended, at the Education Office<\\/p>\",\"tx_mtosafisitepackage_registration_link\":\"t3:\\/\\/page?uid=15\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":10}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:74d687ec564a59b0360c2264c05d7a29'),
(153,1795372569,1,'BE',1,0,11,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"jamhuri-day-celebrations\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Jamhuri Day celebrations\",\"datetime\":1797055200,\"event_end\":1797073200,\"location_simple\":\"Municipal grounds\",\"teaser\":\"Municipal grounds, 9:00\\u201314:00. Flag raising, speeches, school choirs and traditional dances.\",\"bodytext\":\"<p>The municipality celebrates Jamhuri Day with the flag raising, speeches, school choirs and traditional dances.<\\/p>\\r\\n<p><strong>Time:<\\/strong> 9:00\\u201314:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":11}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:a7708bdfd76f24b1743f6d30ac679090'),
(154,1795372569,1,'BE',1,0,12,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"festive-market-at-the-jetty\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Festive market at the jetty\",\"datetime\":1797685200,\"event_end\":1798138800,\"location_simple\":\"Jetty and fish market\",\"categories\":\"1\",\"teaser\":\"Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.\",\"bodytext\":\"<p>Food, crafts and music every evening before Christmas.<\\/p>\\r\\n<p><strong>Time:<\\/strong> Every evening, 16:00\\u201322:00<br \\/><strong>Cost:<\\/strong> Free entry<br \\/><strong>Registration:<\\/strong> Traders apply for a stall at the Trade &amp; Markets Office until 1 December<\\/p>\",\"tx_mtosafisitepackage_registration_link\":\"t3:\\/\\/page?uid=9\",\"tx_mtosafisitepackage_registration_label\":\"Apply for a stall\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":12}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:6c6005b66e9191f57d7fa62294c401ca'),
(155,1795372569,1,'BE',1,0,13,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":0,\"istopnews\":0,\"editlock\":0,\"path_segment\":\"land-rates-help-desk\",\"sitemap_priority\":\"0.5\",\"is_event\":1,\"full_day\":0,\"organizer\":0,\"location\":0,\"pid\":32,\"title\":\"Land rates help desk\",\"datetime\":1800252000,\"event_end\":1806494400,\"location_simple\":\"Municipal office, cash office\",\"categories\":\"1\",\"teaser\":\"Monday to Friday, 9:00\\u201315:00, at the cash office: help with your valuation notice and land rates.\",\"bodytext\":\"<p>Staff of the Revenue Department help you read your valuation notice, calculate your land rates and set up payment by mobile money.<\\/p>\\r\\n<p><strong>Time:<\\/strong> Monday to Friday, 9:00\\u201315:00<br \\/><strong>Cost:<\\/strong> Free<br \\/><strong>Registration:<\\/strong> Not needed<\\/p>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":13}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:b01640b8cfd71f6a58c6ac688cc2a238'),
(156,1795372569,1,'BE',1,0,45,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":512,\"header\":\"Events\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">asc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\">today<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">36<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">events<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"extraEntryEventNews\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.eventRestriction\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":45}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:ef25e3b02a873bda1a67249f52737086'),
(157,1795372569,1,'BE',1,0,46,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":35,\"sorting\":256,\"header\":\"Upcoming events\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">asc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\">today<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">36<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">eventsPage<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"extraEntryEventNews\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.eventRestriction\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":46}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:e98a5e9f23ca3235102a132a15092d64'),
(158,1795372569,1,'BE',1,0,47,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":36,\"sorting\":256,\"header\":\"Event\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"sys_language_uid\":0,\"crdate\":1795372569,\"t3ver_stage\":0,\"tstamp\":1795372569,\"uid\":47}',0,'0400$t5eSR96s95-XYfd2RYS86z7oTA7pOGng:4252955adc057961e279f23960919217'),
(159,1795414399,1,'BE',1,0,37,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"1\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"TCEMAIN.permissions.groupid = 1\\\\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__Home\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"1\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Home\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":0,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":1,\"sys_language_uid\":1,\"l10n_source\":1,\"title\":\"[Translate to Kiswahili:] Home\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":\"TCEMAIN.permissions.groupid = 1\\nTCEMAIN.permissions.group = show,editcontent,edit,new,delete\",\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":1,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__Home\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":37}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:711f7fd735d383d3e32b503dd056ca77'),
(160,1795414399,1,'BE',1,0,38,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"5\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__SidebarLeft\\\",\\\"backend_layout_next_level\\\":\\\"pagets__SidebarLeft\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/revenue-payments\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Revenue & payments\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":5,\"title\":\"[Translate to Kiswahili:] Revenue & payments\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__SidebarLeft\",\"backend_layout_next_level\":\"pagets__SidebarLeft\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":38}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:25fb0f8c54125efeb15a71bcd7ab0dae'),
(161,1795414399,1,'BE',1,0,39,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-health\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"11\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/health\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Health\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":11,\"title\":\"[Translate to Kiswahili:] Health\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":39}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:f8a7770703417fcd54288c2180819c52'),
(162,1795414399,1,'BE',1,0,40,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-environment-water\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"12\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/environment-water\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Environment & water\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":12,\"title\":\"[Translate to Kiswahili:] Environment & water\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":40}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:7cda874357e9b43e55f32e92e735b3f8'),
(163,1795414399,1,'BE',1,0,41,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-trade-tourism\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"13\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/trade-tourism\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Trade & tourism\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":13,\"title\":\"[Translate to Kiswahili:] Trade & tourism\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":41}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:72c156ab8075d295e6bed13d44a3899f'),
(164,1795414399,1,'BE',1,0,42,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-public-participation\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"14\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/public-participation\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Public participation\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":14,\"title\":\"[Translate to Kiswahili:] Public participation\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":42}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:44dacbb46da3eeda7bf3a298d3f8dcdf'),
(165,1795414399,1,'BE',1,0,43,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-contact\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"15\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__SidebarRight\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/contact\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Contact\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1536,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":15,\"title\":\"[Translate to Kiswahili:] Contact\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__SidebarRight\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":43}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:d00c6994241112f65826f8dda1afa4db'),
(166,1795414399,1,'BE',1,0,44,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-search\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"16\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__SidebarRight\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"1\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/search\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Search\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1792,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":16,\"title\":\"[Translate to Kiswahili:] Search\",\"nav_hide\":1,\"no_search\":1,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__SidebarRight\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":44}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:99cee0b66191b5b1b299f6957b8d046f'),
(167,1795414399,1,'BE',1,0,45,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-e-services-portal\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"17\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__Narrow\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/e-services-portal\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"E-services portal\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2048,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":17,\"title\":\"[Translate to Kiswahili:] E-services portal\",\"nav_hide\":1,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__Narrow\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":45}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:d5c8a0c399b70b593af4e702ea1ff918'),
(168,1795414399,1,'BE',1,0,46,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-accessibility-statement\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"18\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/accessibility-statement\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Accessibility statement\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2304,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":18,\"title\":\"[Translate to Kiswahili:] Accessibility statement\",\"nav_hide\":1,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":46}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:e8adec7f7fc01007a1fc847e41d3f0c8'),
(169,1795414399,1,'BE',1,0,47,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-privacy-policy\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"19\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/privacy-policy\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Privacy policy\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2560,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":19,\"title\":\"[Translate to Kiswahili:] Privacy policy\",\"nav_hide\":1,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":47}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:c2d3f3895ebb62a7f0918358495feb90'),
(170,1795414399,1,'BE',1,0,48,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-access-to-information\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"20\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/access-to-information\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Access to information\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":2816,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":20,\"title\":\"[Translate to Kiswahili:] Access to information\",\"nav_hide\":1,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":48}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:7281e4156dc7c00da5e8e8f12d1ad645'),
(171,1795414399,1,'BE',1,0,49,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-tenders\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"21\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/tenders\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Tenders\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3072,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":21,\"title\":\"[Translate to Kiswahili:] Tenders\",\"nav_hide\":1,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":49}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:81e6b08ac1d0937f00907cc283f89f88'),
(172,1795414399,1,'BE',1,0,50,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-page-not-found\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"33\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__Narrow\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"1\\\",\\\"no_index\\\":\\\"1\\\",\\\"no_search\\\":\\\"1\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/page-not-found\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Page not found\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3136,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":33,\"title\":\"[Translate to Kiswahili:] Page not found\",\"nav_hide\":1,\"no_search\":1,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__Narrow\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":1,\"no_follow\":1,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":50}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:671da757bfb02238463b8b779450e7f1'),
(173,1795414399,1,'BE',1,0,51,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-news\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"30\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/news\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"News\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3200,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":30,\"title\":\"[Translate to Kiswahili:] News\",\"nav_hide\":1,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":51}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:5c5552cdbd37b0d7a00d7bee803a84b9'),
(174,1795414399,1,'BE',1,0,52,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-events\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"35\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/events\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Events\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":3264,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":35,\"title\":\"[Translate to Kiswahili:] Events\",\"nav_hide\":1,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":52}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:eac43127adf688163af4c91393ae5b52'),
(175,1795414399,1,'BE',1,0,53,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-land-rates\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"6\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/revenue-payments\\\\\\/land-rates\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Land rates\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":6,\"title\":\"[Translate to Kiswahili:] Land rates\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":53}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:60b47c38b54ea9484946816deb210a0e'),
(176,1795414399,1,'BE',1,0,54,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-single-business-permit\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"7\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/revenue-payments\\\\\\/single-business-permit\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Single business permit\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":7,\"title\":\"[Translate to Kiswahili:] Single business permit\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":54}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:7b311257b3050241474e7db89cab4819'),
(177,1795414399,1,'BE',1,0,55,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-parking-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"8\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/revenue-payments\\\\\\/parking-fees\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Parking fees\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":8,\"title\":\"[Translate to Kiswahili:] Parking fees\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":55}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:085a4605348cd07ca76bf90f23a64611'),
(178,1795414399,1,'BE',1,0,56,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-market-fees\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"9\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/revenue-payments\\\\\\/market-fees\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Market fees\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":9,\"title\":\"[Translate to Kiswahili:] Market fees\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":56}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:f7d5ae7112f81c9c5489570127872f29'),
(179,1795414399,1,'BE',1,0,57,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-waiver-of-interest\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"10\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/revenue-payments\\\\\\/waiver-of-interest\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Waiver of interest\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":10,\"title\":\"[Translate to Kiswahili:] Waiver of interest\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":57}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:342de781cc87083f78d06a82c68f09f4'),
(180,1795414399,1,'BE',1,0,58,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-news\\/translate-to-kiswahili-article\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"31\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__Article\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"1\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/news\\\\\\/article\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Article\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":30,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":31,\"title\":\"[Translate to Kiswahili:] Article\",\"nav_hide\":1,\"no_search\":1,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__Article\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":58}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:ab21e322e42a7bdfabb904f5462e4c02'),
(181,1795414399,1,'BE',1,0,59,'pages','{\"doktype\":\"1\",\"slug\":\"\\/translate-to-kiswahili-events\\/translate-to-kiswahili-event\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"36\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"pagets__Article\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"1\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"1\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/events\\\\\\/event\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Event\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":35,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":36,\"title\":\"[Translate to Kiswahili:] Event\",\"nav_hide\":1,\"no_search\":1,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__Article\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":59}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:4433f049eb08150ef22f96b06e4856b1'),
(182,1795414399,1,'BE',1,0,60,'pages','{\"doktype\":\"4\",\"slug\":\"\\/translate-to-kiswahili-e-services-portal-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":\"17\",\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"24\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"4\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"17\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/e-services-portal-1\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"E-services portal\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":24,\"title\":\"[Translate to Kiswahili:] E-services portal\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":60}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:5ab4163aa2745e5a0113db40c70dc8f4'),
(183,1795414399,1,'BE',1,0,61,'pages','{\"doktype\":\"4\",\"slug\":\"\\/translate-to-kiswahili-contact-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":\"15\",\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"25\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"4\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"15\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/contact-1\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Contact\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":22,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":25,\"title\":\"[Translate to Kiswahili:] Contact\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":61}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:56660b3f54e5664e7301c75c63113d07'),
(184,1795414399,1,'BE',1,0,62,'pages','{\"doktype\":\"4\",\"slug\":\"\\/translate-to-kiswahili-accessibility-statement-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":\"18\",\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"26\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"4\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"18\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/accessibility-statement-1\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Accessibility statement\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":26,\"title\":\"[Translate to Kiswahili:] Accessibility statement\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":62}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:24aebf1ddb9e283704201212e1ca1eb2'),
(185,1795414399,1,'BE',1,0,63,'pages','{\"doktype\":\"4\",\"slug\":\"\\/translate-to-kiswahili-privacy-policy-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":\"19\",\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"27\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"4\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"19\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/privacy-policy-1\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Privacy policy\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":27,\"title\":\"[Translate to Kiswahili:] Privacy policy\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":63}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:0089143ede545095718c11b0f1a63339'),
(186,1795414399,1,'BE',1,0,64,'pages','{\"doktype\":\"4\",\"slug\":\"\\/translate-to-kiswahili-access-to-information-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":\"20\",\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"28\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"4\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"20\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/access-to-information-1\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Access to information\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":28,\"title\":\"[Translate to Kiswahili:] Access to information\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":64}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:d483efb03977925709dcaec58241fe0c'),
(187,1795414399,1,'BE',1,0,65,'pages','{\"doktype\":\"4\",\"slug\":\"\\/translate-to-kiswahili-tenders-1\",\"categories\":\"0\",\"layout\":\"0\",\"link\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":\"21\",\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"29\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"4\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"21\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/tenders-1\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Tenders\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":23,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":29,\"title\":\"[Translate to Kiswahili:] Tenders\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"link\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":65}',0,'0400$cdNYJBoV6HQKamTu0mizyP-XnBjQNdED:47f778231b3d851f3b07a2ce1fdd8e12'),
(188,1795414399,2,'BE',1,0,37,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Home\",\"hidden\":1},\"newRecord\":{\"title\":\"Mwanzo\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:711f7fd735d383d3e32b503dd056ca77'),
(189,1795414399,2,'BE',1,0,38,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Revenue & payments\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\",\"hidden\":1},\"newRecord\":{\"title\":\"Mapato na malipo\",\"slug\":\"\\/mapato-malipo\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:25fb0f8c54125efeb15a71bcd7ab0dae'),
(190,1795414399,2,'BE',1,0,39,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Health\",\"slug\":\"\\/translate-to-kiswahili-health\",\"hidden\":1},\"newRecord\":{\"title\":\"Afya\",\"slug\":\"\\/afya\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:f8a7770703417fcd54288c2180819c52'),
(191,1795414399,2,'BE',1,0,40,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Environment & water\",\"slug\":\"\\/translate-to-kiswahili-environment-water\",\"hidden\":1},\"newRecord\":{\"title\":\"Mazingira na maji\",\"slug\":\"\\/mazingira-maji\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:7cda874357e9b43e55f32e92e735b3f8'),
(192,1795414399,2,'BE',1,0,41,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Trade & tourism\",\"slug\":\"\\/translate-to-kiswahili-trade-tourism\",\"hidden\":1},\"newRecord\":{\"title\":\"Biashara na utalii\",\"slug\":\"\\/biashara-utalii\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:72c156ab8075d295e6bed13d44a3899f'),
(193,1795414399,2,'BE',1,0,42,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Public participation\",\"slug\":\"\\/translate-to-kiswahili-public-participation\",\"hidden\":1},\"newRecord\":{\"title\":\"Ushiriki wa umma\",\"slug\":\"\\/ushiriki-wa-umma\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:44dacbb46da3eeda7bf3a298d3f8dcdf'),
(194,1795414399,2,'BE',1,0,43,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Contact\",\"slug\":\"\\/translate-to-kiswahili-contact\",\"hidden\":1},\"newRecord\":{\"title\":\"Wasiliana nasi\",\"slug\":\"\\/wasiliana-nasi\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:d00c6994241112f65826f8dda1afa4db'),
(195,1795414399,2,'BE',1,0,44,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Search\",\"slug\":\"\\/translate-to-kiswahili-search\",\"hidden\":1},\"newRecord\":{\"title\":\"Tafuta\",\"slug\":\"\\/tafuta\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:99cee0b66191b5b1b299f6957b8d046f'),
(196,1795414399,2,'BE',1,0,45,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] E-services portal\",\"slug\":\"\\/translate-to-kiswahili-e-services-portal\",\"hidden\":1},\"newRecord\":{\"title\":\"Huduma za mtandaoni\",\"slug\":\"\\/huduma-za-mtandaoni\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:d5c8a0c399b70b593af4e702ea1ff918'),
(197,1795414399,2,'BE',1,0,46,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Accessibility statement\",\"slug\":\"\\/translate-to-kiswahili-accessibility-statement\",\"hidden\":1},\"newRecord\":{\"title\":\"Taarifa ya ufikivu\",\"slug\":\"\\/taarifa-ya-ufikivu\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:e8adec7f7fc01007a1fc847e41d3f0c8'),
(198,1795414399,2,'BE',1,0,47,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Privacy policy\",\"slug\":\"\\/translate-to-kiswahili-privacy-policy\",\"hidden\":1},\"newRecord\":{\"title\":\"Sera ya faragha\",\"slug\":\"\\/sera-ya-faragha\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:c2d3f3895ebb62a7f0918358495feb90'),
(199,1795414399,2,'BE',1,0,48,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Access to information\",\"slug\":\"\\/translate-to-kiswahili-access-to-information\",\"hidden\":1},\"newRecord\":{\"title\":\"Upatikanaji wa taarifa\",\"slug\":\"\\/upatikanaji-wa-taarifa\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:7281e4156dc7c00da5e8e8f12d1ad645'),
(200,1795414399,2,'BE',1,0,49,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Tenders\",\"slug\":\"\\/translate-to-kiswahili-tenders\",\"hidden\":1},\"newRecord\":{\"title\":\"Zabuni\",\"slug\":\"\\/zabuni\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:81e6b08ac1d0937f00907cc283f89f88'),
(201,1795414399,2,'BE',1,0,50,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Page not found\",\"slug\":\"\\/translate-to-kiswahili-page-not-found\",\"hidden\":1},\"newRecord\":{\"title\":\"Ukurasa haupatikani\",\"slug\":\"\\/ukurasa-haupatikani\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:671da757bfb02238463b8b779450e7f1'),
(202,1795414399,2,'BE',1,0,51,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] News\",\"slug\":\"\\/translate-to-kiswahili-news\",\"hidden\":1},\"newRecord\":{\"title\":\"Habari\",\"slug\":\"\\/habari\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:5c5552cdbd37b0d7a00d7bee803a84b9'),
(203,1795414399,2,'BE',1,0,52,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Events\",\"slug\":\"\\/translate-to-kiswahili-events\",\"hidden\":1},\"newRecord\":{\"title\":\"Matukio\",\"slug\":\"\\/matukio\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:eac43127adf688163af4c91393ae5b52'),
(204,1795414399,2,'BE',1,0,53,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Land rates\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-land-rates\",\"hidden\":1},\"newRecord\":{\"title\":\"Kodi ya ardhi\",\"slug\":\"\\/mapato-malipo\\/kodi-ya-ardhi\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:60b47c38b54ea9484946816deb210a0e'),
(205,1795414399,2,'BE',1,0,54,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Single business permit\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-single-business-permit\",\"hidden\":1},\"newRecord\":{\"title\":\"Kibali cha biashara\",\"slug\":\"\\/mapato-malipo\\/kibali-cha-biashara\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:7b311257b3050241474e7db89cab4819'),
(206,1795414399,2,'BE',1,0,55,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Parking fees\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-parking-fees\",\"hidden\":1},\"newRecord\":{\"title\":\"Ada za maegesho\",\"slug\":\"\\/mapato-malipo\\/ada-za-maegesho\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:085a4605348cd07ca76bf90f23a64611'),
(207,1795414399,2,'BE',1,0,56,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Market fees\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-market-fees\",\"hidden\":1},\"newRecord\":{\"title\":\"Ada za soko\",\"slug\":\"\\/mapato-malipo\\/ada-za-soko\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:f7d5ae7112f81c9c5489570127872f29'),
(208,1795414399,2,'BE',1,0,57,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Waiver of interest\",\"slug\":\"\\/translate-to-kiswahili-revenue-payments\\/translate-to-kiswahili-waiver-of-interest\",\"hidden\":1},\"newRecord\":{\"title\":\"Msamaha wa riba\",\"slug\":\"\\/mapato-malipo\\/msamaha-wa-riba\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:342de781cc87083f78d06a82c68f09f4'),
(209,1795414399,2,'BE',1,0,58,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Article\",\"slug\":\"\\/translate-to-kiswahili-news\\/translate-to-kiswahili-article\",\"hidden\":1},\"newRecord\":{\"title\":\"Makala\",\"slug\":\"\\/habari\\/makala\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:ab21e322e42a7bdfabb904f5462e4c02'),
(210,1795414399,2,'BE',1,0,59,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Event\",\"slug\":\"\\/translate-to-kiswahili-events\\/translate-to-kiswahili-event\",\"hidden\":1},\"newRecord\":{\"title\":\"Tukio\",\"slug\":\"\\/matukio\\/tukio\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:4433f049eb08150ef22f96b06e4856b1'),
(211,1795414399,2,'BE',1,0,60,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] E-services portal\",\"slug\":\"\\/translate-to-kiswahili-e-services-portal-1\",\"hidden\":1},\"newRecord\":{\"title\":\"Huduma za mtandaoni\",\"slug\":\"\\/huduma-za-mtandaoni-1\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:5ab4163aa2745e5a0113db40c70dc8f4'),
(212,1795414399,2,'BE',1,0,61,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Contact\",\"slug\":\"\\/translate-to-kiswahili-contact-1\",\"hidden\":1},\"newRecord\":{\"title\":\"Wasiliana nasi\",\"slug\":\"\\/wasiliana-nasi-1\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:56660b3f54e5664e7301c75c63113d07'),
(213,1795414399,2,'BE',1,0,62,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Accessibility statement\",\"slug\":\"\\/translate-to-kiswahili-accessibility-statement-1\",\"hidden\":1},\"newRecord\":{\"title\":\"Taarifa ya ufikivu\",\"slug\":\"\\/taarifa-ya-ufikivu-1\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:24aebf1ddb9e283704201212e1ca1eb2'),
(214,1795414399,2,'BE',1,0,63,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Privacy policy\",\"slug\":\"\\/translate-to-kiswahili-privacy-policy-1\",\"hidden\":1},\"newRecord\":{\"title\":\"Sera ya faragha\",\"slug\":\"\\/sera-ya-faragha-1\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:0089143ede545095718c11b0f1a63339'),
(215,1795414399,2,'BE',1,0,64,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Access to information\",\"slug\":\"\\/translate-to-kiswahili-access-to-information-1\",\"hidden\":1},\"newRecord\":{\"title\":\"Upatikanaji wa taarifa\",\"slug\":\"\\/upatikanaji-wa-taarifa-1\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:d483efb03977925709dcaec58241fe0c'),
(216,1795414399,2,'BE',1,0,65,'pages','{\"oldRecord\":{\"title\":\"[Translate to Kiswahili:] Tenders\",\"slug\":\"\\/translate-to-kiswahili-tenders-1\",\"hidden\":1},\"newRecord\":{\"title\":\"Zabuni\",\"slug\":\"\\/zabuni-1\",\"hidden\":0}}',0,'0400$IHgHklFiJXVreKit2Vf8TmTPzYqP4MUc:47f778231b3d851f3b07a2ce1fdd8e12'),
(217,1795414399,1,'BE',1,0,24,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"1\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"image\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"showinpreview\\\":\\\"0\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tx_mtosafisitepackage_slide\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"1\\\",\\\"uid_local\\\":\\\"2\\\"}\",\"showinpreview\":\"0\",\"pid\":1,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"2\",\"uid_foreign\":1,\"tablenames\":\"tx_mtosafisitepackage_slide\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":null,\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":24}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:ec378d8e96f494986de35c9be84dff5c'),
(218,1795414399,1,'BE',1,0,4,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=13\\\",\\\"link_label\\\":\\\"Discover Mto Safi\\\",\\\"parent\\\":\\\"7\\\",\\\"text\\\":\\\"White beaches, a clean river and a municipality that serves you online, day and night.\\\",\\\"title\\\":\\\"Karibu Mto Safi\\\"}\",\"pid\":1,\"sorting\":257,\"sys_language_uid\":1,\"l10n_source\":1,\"l10n_state\":null,\"parent\":7,\"title\":\"Karibu Mto Safi\",\"text\":\"White beaches, a clean river and a municipality that serves you online, day and night.\",\"link\":\"t3:\\/\\/page?uid=13\",\"link_label\":\"Discover Mto Safi\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":4}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:2e41f10d50e57e8ea18b5fbd61ae9a86'),
(219,1795414399,1,'BE',1,0,25,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"2\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"image\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"showinpreview\\\":\\\"0\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tx_mtosafisitepackage_slide\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"2\\\",\\\"uid_local\\\":\\\"3\\\"}\",\"showinpreview\":\"0\",\"pid\":1,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"3\",\"uid_foreign\":2,\"tablenames\":\"tx_mtosafisitepackage_slide\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":null,\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":25}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:5ce305fb03b44e2e5ced3360656e263a'),
(220,1795414399,1,'BE',1,0,5,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":\"2\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=6\\\",\\\"link_label\\\":\\\"Calculate land rates\\\",\\\"parent\\\":\\\"7\\\",\\\"text\\\":\\\"Calculate what you owe and pay before 31 March to avoid interest.\\\",\\\"title\\\":\\\"Pay your land rates by mobile money\\\"}\",\"pid\":1,\"sorting\":385,\"sys_language_uid\":1,\"l10n_source\":2,\"l10n_state\":null,\"parent\":7,\"title\":\"Pay your land rates by mobile money\",\"text\":\"Calculate what you owe and pay before 31 March to avoid interest.\",\"link\":\"t3:\\/\\/page?uid=6\",\"link_label\":\"Calculate land rates\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":5}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:f3d52a6d5b5585079da95dddc913a458'),
(221,1795414399,1,'BE',1,0,26,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"image\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"showinpreview\\\":\\\"0\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tx_mtosafisitepackage_slide\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"3\\\",\\\"uid_local\\\":\\\"4\\\"}\",\"showinpreview\":\"0\",\"pid\":1,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"4\",\"uid_foreign\":3,\"tablenames\":\"tx_mtosafisitepackage_slide\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":null,\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":26}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:2190384e72cbe31d01b0259338cca742'),
(222,1795414399,1,'BE',1,0,6,'tx_mtosafisitepackage_slide','{\"hidden\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=14\\\",\\\"link_label\\\":\\\"See the forum dates\\\",\\\"parent\\\":\\\"7\\\",\\\"text\\\":\\\"Join the public participation forums in every ward this month.\\\",\\\"title\\\":\\\"Have your say on the budget\\\"}\",\"pid\":1,\"sorting\":449,\"sys_language_uid\":1,\"l10n_source\":3,\"l10n_state\":null,\"parent\":7,\"title\":\"Have your say on the budget\",\"text\":\"Join the public participation forums in every ward this month.\",\"link\":\"t3:\\/\\/page?uid=14\",\"link_label\":\"See the forum dates\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":6}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:e07dd4cca395bf381d64df995b691198'),
(223,1795414399,1,'BE',1,0,48,'tt_content','{\"CType\":\"mtosafi_slider\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":0,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"7\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"mtosafi_slider\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795344511\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Highlights\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795344511\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"3\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":96,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":7,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Highlights\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":48}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:251e07b78ef27bce7293ccf22649b0e7'),
(224,1795414399,1,'BE',1,0,7,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"icon\\\":\\\"\\\\ud83c\\\\udfea\\\",\\\"label\\\":\\\"Single business permit\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=7\\\",\\\"parent\\\":\\\"6\\\"}\",\"pid\":1,\"sorting\":257,\"sys_language_uid\":1,\"l10n_source\":1,\"l10n_state\":null,\"parent\":6,\"icon\":\"\\ud83c\\udfea\",\"label\":\"Single business permit\",\"link\":\"t3:\\/\\/page?uid=7\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":7}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:22c4bbc9d80aadadbf17c197db8ce3e2'),
(225,1795414399,1,'BE',1,0,8,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":\"2\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"icon\\\":\\\"\\\\ud83c\\\\udfe1\\\",\\\"label\\\":\\\"Land rates\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=6\\\",\\\"parent\\\":\\\"6\\\"}\",\"pid\":1,\"sorting\":385,\"sys_language_uid\":1,\"l10n_source\":2,\"l10n_state\":null,\"parent\":6,\"icon\":\"\\ud83c\\udfe1\",\"label\":\"Land rates\",\"link\":\"t3:\\/\\/page?uid=6\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":8}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:2872767fa11b6e3759a3432d2e857349'),
(226,1795414399,1,'BE',1,0,9,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"icon\\\":\\\"\\\\ud83c\\\\udd7f\\\\ufe0f\\\",\\\"label\\\":\\\"Parking fees\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=8\\\",\\\"parent\\\":\\\"6\\\"}\",\"pid\":1,\"sorting\":449,\"sys_language_uid\":1,\"l10n_source\":3,\"l10n_state\":null,\"parent\":6,\"icon\":\"\\ud83c\\udd7f\\ufe0f\",\"label\":\"Parking fees\",\"link\":\"t3:\\/\\/page?uid=8\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":9}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:80ae96733436b8bc6b858da89a423d69'),
(227,1795414399,1,'BE',1,0,10,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":\"4\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"icon\\\":\\\"\\\\ud83d\\\\udca7\\\",\\\"label\\\":\\\"Water connection\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=12\\\",\\\"parent\\\":\\\"6\\\"}\",\"pid\":1,\"sorting\":481,\"sys_language_uid\":1,\"l10n_source\":4,\"l10n_state\":null,\"parent\":6,\"icon\":\"\\ud83d\\udca7\",\"label\":\"Water connection\",\"link\":\"t3:\\/\\/page?uid=12\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":10}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:6a59ece9a70008b3e88d75c2d773d677'),
(228,1795414399,1,'BE',1,0,11,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":\"5\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"icon\\\":\\\"\\\\ud83e\\\\uddfa\\\",\\\"label\\\":\\\"Market stalls\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=9\\\",\\\"parent\\\":\\\"6\\\"}\",\"pid\":1,\"sorting\":497,\"sys_language_uid\":1,\"l10n_source\":5,\"l10n_state\":null,\"parent\":6,\"icon\":\"\\ud83e\\uddfa\",\"label\":\"Market stalls\",\"link\":\"t3:\\/\\/page?uid=9\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":11}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:58d86b42783e6e0e622bd210422a8455'),
(229,1795414399,1,'BE',1,0,12,'tx_mtosafisitepackage_tile','{\"hidden\":0,\"l10n_parent\":\"6\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"icon\\\":\\\"\\\\ud83d\\\\udce3\\\",\\\"label\\\":\\\"Report a problem\\\",\\\"link\\\":\\\"t3:\\\\\\/\\\\\\/page?uid=15\\\",\\\"parent\\\":\\\"6\\\"}\",\"pid\":1,\"sorting\":505,\"sys_language_uid\":1,\"l10n_source\":6,\"l10n_state\":null,\"parent\":6,\"icon\":\"\\ud83d\\udce3\",\"label\":\"Report a problem\",\"link\":\"t3:\\/\\/page?uid=15\",\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":12}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:388eea74bebe0a3054df2d4d1afb1ea7'),
(230,1795414399,1,'BE',1,0,49,'tt_content','{\"CType\":\"mtosafi_tiles\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":0,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"6\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"mtosafi_tiles\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795343750\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Popular services\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795343750\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"6\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":112,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":6,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Popular services\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":49}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:21e00c94bebf8e8e281aee5f17852bc1'),
(231,1795414399,1,'BE',1,0,50,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":0,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"3\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"news_newsliststicky\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795336956\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"News\\\",\\\"header_layout\\\":\\\"100\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"<?xml version=\\\\\\\"1.0\\\\\\\" encoding=\\\\\\\"utf-8\\\\\\\" standalone=\\\\\\\"yes\\\\\\\" ?>\\\\n<T3FlexForms>\\\\n    <data>\\\\n        <sheet index=\\\\\\\"sDEF\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.orderBy\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">datetime<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.orderDirection\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">desc<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.startingpoint\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">32<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.recursive\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">0<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n        <sheet index=\\\\\\\"additional\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.detailPid\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">31<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.listPid\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">30<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.limit\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">3<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.hidePagination\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">1<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n        <sheet index=\\\\\\\"template\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.templateLayout\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">home<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n    <\\\\\\/data>\\\\n<\\\\\\/T3FlexForms>\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795336956\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":120,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":3,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] News\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">home<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":50}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:ad9a6d0c0e3b3a79b7d6de8d41009d62'),
(232,1795414399,1,'BE',1,0,51,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"100\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"45\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"news_newsliststicky\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795372569\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Events\\\",\\\"header_layout\\\":\\\"100\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"1\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"<?xml version=\\\\\\\"1.0\\\\\\\" encoding=\\\\\\\"utf-8\\\\\\\" standalone=\\\\\\\"yes\\\\\\\" ?>\\\\n<T3FlexForms>\\\\n    <data>\\\\n        <sheet index=\\\\\\\"sDEF\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.orderBy\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">datetime<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.orderDirection\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">asc<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.startingpoint\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">32<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.recursive\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">0<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.timeRestriction\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">today<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n        <sheet index=\\\\\\\"additional\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.detailPid\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">36<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.listPid\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">35<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.limit\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">3<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n                <field index=\\\\\\\"settings.hidePagination\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">1<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n        <sheet index=\\\\\\\"template\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.templateLayout\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">events<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n        <sheet index=\\\\\\\"extraEntryEventNews\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.eventRestriction\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">1<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n    <\\\\\\/data>\\\\n<\\\\\\/T3FlexForms>\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795372569\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":124,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":45,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Events\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">asc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\">today<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">36<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">events<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"extraEntryEventNews\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.eventRestriction\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":51}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:a44fb4f5cacae383ecd34ba7f260f0a5'),
(233,1795414399,1,'BE',1,0,52,'tt_content','{\"CType\":\"form_formframework\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"44\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"form_formframework\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795369027\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Write to us\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"1\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"<?xml version=\\\\\\\"1.0\\\\\\\" encoding=\\\\\\\"utf-8\\\\\\\" standalone=\\\\\\\"yes\\\\\\\" ?>\\\\n<T3FlexForms>\\\\n    <data>\\\\n        <sheet index=\\\\\\\"sDEF\\\\\\\">\\\\n            <language index=\\\\\\\"lDEF\\\\\\\">\\\\n                <field index=\\\\\\\"settings.persistenceIdentifier\\\\\\\">\\\\n                    <value index=\\\\\\\"vDEF\\\\\\\">EXT:mtosafi_sitepackage\\\\\\/Resources\\\\\\/Private\\\\\\/Forms\\\\\\/contact.form.yaml<\\\\\\/value>\\\\n                <\\\\\\/field>\\\\n            <\\\\\\/language>\\\\n        <\\\\\\/sheet>\\\\n    <\\\\\\/data>\\\\n<\\\\\\/T3FlexForms>\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"The right department answers within five working days.\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795369027\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":192,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":44,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Write to us\",\"header_link\":\"\",\"subheader\":\"The right department answers within five working days.\",\"bodytext\":null,\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">EXT:mtosafi_sitepackage\\/Resources\\/Private\\/Forms\\/contact.form.yaml<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":52}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:7cc105963fb6bd1bc18c823bc659f69b'),
(234,1795414399,1,'BE',1,0,27,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":\"[Translate to Kiswahili:] The municipal office on Beach Road.\",\"alternative\":\"[Translate to Kiswahili:] The municipal office with a flag on the roof\",\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"18\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"The municipal office with a flag on the roof\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"The municipal office on Beach Road.\\\",\\\"fieldname\\\":\\\"image\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"showinpreview\\\":\\\"0\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tt_content\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"34\\\",\\\"uid_local\\\":\\\"20\\\"}\",\"showinpreview\":\"0\",\"pid\":15,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"20\",\"uid_foreign\":34,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":null,\"crdate\":1795414399,\"t3ver_stage\":0,\"tstamp\":1795414399,\"uid\":27}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:dd318efa0f8b108e87c8725b284b77c4'),
(235,1795414399,1,'BE',1,0,53,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"1\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"34\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"textpic\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"<p>Mto Safi Municipality<br \\\\\\/>Municipal Office<br \\\\\\/>Beach Road 1<br \\\\\\/>P.O. Box 123, Mto Safi<\\\\\\/p>\\\\r\\\\n<p>Phone: <a href=\\\\\\\"tel:+254700000000\\\\\\\">+254 700 000 000<\\\\\\/a><br \\\\\\/>Email: <a href=\\\\\\\"mailto:info@mtosafi.example\\\\\\\">info@mtosafi.example<\\\\\\/a><\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"1\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795368020\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Visit us\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"1\\\",\\\"image_zoom\\\":\\\"1\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"1\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795369027\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":384,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":34,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Visit us\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>[Translate to Kiswahili:] Mto Safi Municipality<br \\/>Municipal Office<br \\/>Beach Road 1<br \\/>P.O. Box 123, Mto Safi<\\/p>\\r\\n<p>Phone: <a href=\\\"tel:+254700000000\\\">+254 700 000 000<\\/a><br \\/>Email: <a href=\\\"mailto:info@mtosafi.example\\\">info@mtosafi.example<\\/a><\\/p>\",\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":53}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:d0c57d2bff54e852a15ac899a01f4960'),
(236,1795414399,1,'BE',1,0,54,'tt_content','{\"CType\":\"table\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"35\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"table\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"Days|Hours\\\\nMon\\\\u2013Thu|8:00\\\\u201317:00\\\\nFriday|8:00\\\\u201313:00, 14:00\\\\u201317:00\\\\nSat, Sun|Closed\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"1\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795368020\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Opening hours\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"1\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"1\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795369027\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":448,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":35,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Opening hours\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"[Translate to Kiswahili:] Days|Hours\\nMon\\u2013Thu|8:00\\u201317:00\\nFriday|8:00\\u201313:00, 14:00\\u201317:00\\nSat, Sun|Closed\",\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":54}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:7182bf157a2e905be72902a3b3b7c25f'),
(237,1795414399,1,'BE',1,0,55,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"1\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"36\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"text\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\\\\\\\"mailto:report@mtosafi.example\\\\\\\">report@mtosafi.example<\\\\\\/a>, and say where it is.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"1\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795368020\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Report a problem\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"1\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795369027\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":15,\"sorting\":480,\"tstamp\":1795414399,\"crdate\":1795414399,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":36,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Report a problem\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>[Translate to Kiswahili:] A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\\\"mailto:report@mtosafi.example\\\">report@mtosafi.example<\\/a>, and say where it is.<\\/p>\",\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"t3ver_stage\":0,\"uid\":55}',0,'0400$E3SeM5PxUSFMoYGRXR3UNGnckbipqe0i:446729e5b5ab26ef6a2707cb143bcbae'),
(238,1795414399,2,'BE',1,0,48,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Highlights\",\"hidden\":1},\"newRecord\":{\"header\":\"Mambo muhimu\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:251e07b78ef27bce7293ccf22649b0e7'),
(239,1795414399,2,'BE',1,0,49,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Popular services\",\"hidden\":1},\"newRecord\":{\"header\":\"Huduma maarufu\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:21e00c94bebf8e8e281aee5f17852bc1'),
(240,1795414399,2,'BE',1,0,50,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] News\",\"hidden\":1},\"newRecord\":{\"header\":\"Habari\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:ad9a6d0c0e3b3a79b7d6de8d41009d62'),
(241,1795414399,2,'BE',1,0,51,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Events\",\"hidden\":1},\"newRecord\":{\"header\":\"Matukio\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:a44fb4f5cacae383ecd34ba7f260f0a5'),
(242,1795414399,2,'BE',1,0,52,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Write to us\",\"subheader\":\"The right department answers within five working days.\",\"hidden\":1},\"newRecord\":{\"header\":\"Tuandikie\",\"subheader\":\"Idara husika itakujibu ndani ya siku tano za kazi.\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:7cc105963fb6bd1bc18c823bc659f69b'),
(243,1795414399,2,'BE',1,0,53,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Visit us\",\"bodytext\":\"<p>[Translate to Kiswahili:] Mto Safi Municipality<br \\/>Municipal Office<br \\/>Beach Road 1<br \\/>P.O. Box 123, Mto Safi<\\/p>\\r\\n<p>Phone: <a href=\\\"tel:+254700000000\\\">+254 700 000 000<\\/a><br \\/>Email: <a href=\\\"mailto:info@mtosafi.example\\\">info@mtosafi.example<\\/a><\\/p>\",\"hidden\":1},\"newRecord\":{\"header\":\"Tutembelee\",\"bodytext\":\"<p>Manispaa ya Mto Safi<br \\/>Ofisi ya Manispaa<br \\/>Beach Road 1<br \\/>S.L.P. 123, Mto Safi<\\/p>\\r\\n<p>Simu: <a href=\\\"tel:+254700000000\\\">+254 700 000 000<\\/a><br \\/>Barua pepe: <a href=\\\"mailto:info@mtosafi.example\\\">info@mtosafi.example<\\/a><\\/p>\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:d0c57d2bff54e852a15ac899a01f4960'),
(244,1795414399,2,'BE',1,0,54,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Opening hours\",\"bodytext\":\"[Translate to Kiswahili:] Days|Hours\\nMon\\u2013Thu|8:00\\u201317:00\\nFriday|8:00\\u201313:00, 14:00\\u201317:00\\nSat, Sun|Closed\",\"hidden\":1},\"newRecord\":{\"header\":\"Saa za kazi\",\"bodytext\":\"Siku|Saa\\nJumatatu\\u2013Alhamisi|8:00\\u201317:00\\nIjumaa|8:00\\u201313:00, 14:00\\u201317:00\\nJumamosi, Jumapili|Imefungwa\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:7182bf157a2e905be72902a3b3b7c25f'),
(245,1795414399,2,'BE',1,0,55,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Report a problem\",\"bodytext\":\"<p>[Translate to Kiswahili:] A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\\\"mailto:report@mtosafi.example\\\">report@mtosafi.example<\\/a>, and say where it is.<\\/p>\",\"hidden\":1},\"newRecord\":{\"header\":\"Ripoti tatizo\",\"bodytext\":\"<p>Shimo barabarani, taa ya barabarani iliyoharibika, mfereji ulioziba au taka ambazo hazijakusanywa: piga simu +254 700 000 002 au andika kwa <a href=\\\"mailto:report@mtosafi.example\\\">report@mtosafi.example<\\/a>, na useme ni wapi.<\\/p>\",\"hidden\":0}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:446729e5b5ab26ef6a2707cb143bcbae'),
(246,1795414399,2,'BE',1,0,27,'sys_file_reference','{\"oldRecord\":{\"alternative\":\"[Translate to Kiswahili:] The municipal office with a flag on the roof\",\"description\":\"[Translate to Kiswahili:] The municipal office on Beach Road.\"},\"newRecord\":{\"alternative\":\"Ofisi ya manispaa yenye bendera juu ya paa\",\"description\":\"Ofisi ya manispaa kwenye Beach Road.\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:dd318efa0f8b108e87c8725b284b77c4'),
(247,1795414399,2,'BE',1,0,7,'tx_mtosafisitepackage_tile','{\"oldRecord\":{\"label\":\"Single business permit\"},\"newRecord\":{\"label\":\"Kibali cha biashara\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:22c4bbc9d80aadadbf17c197db8ce3e2'),
(248,1795414399,2,'BE',1,0,8,'tx_mtosafisitepackage_tile','{\"oldRecord\":{\"label\":\"Land rates\"},\"newRecord\":{\"label\":\"Kodi ya ardhi\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:2872767fa11b6e3759a3432d2e857349'),
(249,1795414399,2,'BE',1,0,9,'tx_mtosafisitepackage_tile','{\"oldRecord\":{\"label\":\"Parking fees\"},\"newRecord\":{\"label\":\"Ada za maegesho\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:80ae96733436b8bc6b858da89a423d69'),
(250,1795414399,2,'BE',1,0,10,'tx_mtosafisitepackage_tile','{\"oldRecord\":{\"label\":\"Water connection\"},\"newRecord\":{\"label\":\"Kuunganishiwa maji\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:6a59ece9a70008b3e88d75c2d773d677'),
(251,1795414399,2,'BE',1,0,11,'tx_mtosafisitepackage_tile','{\"oldRecord\":{\"label\":\"Market stalls\"},\"newRecord\":{\"label\":\"Vibanda vya soko\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:58d86b42783e6e0e622bd210422a8455'),
(252,1795414399,2,'BE',1,0,12,'tx_mtosafisitepackage_tile','{\"oldRecord\":{\"label\":\"Report a problem\"},\"newRecord\":{\"label\":\"Ripoti tatizo\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:388eea74bebe0a3054df2d4d1afb1ea7'),
(253,1795414399,2,'BE',1,0,4,'tx_mtosafisitepackage_slide','{\"oldRecord\":{\"text\":\"White beaches, a clean river and a municipality that serves you online, day and night.\",\"link_label\":\"Discover Mto Safi\"},\"newRecord\":{\"text\":\"Fukwe nyeupe, mto safi na manispaa inayokuhudumia mtandaoni, mchana na usiku.\",\"link_label\":\"Gundua Mto Safi\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:2e41f10d50e57e8ea18b5fbd61ae9a86'),
(254,1795414399,2,'BE',1,0,5,'tx_mtosafisitepackage_slide','{\"oldRecord\":{\"title\":\"Pay your land rates by mobile money\",\"text\":\"Calculate what you owe and pay before 31 March to avoid interest.\",\"link_label\":\"Calculate land rates\"},\"newRecord\":{\"title\":\"Lipa kodi ya ardhi kwa pesa za simu\",\"text\":\"Kokotoa deni lako na ulipe kabla ya tarehe 31 Machi ili kuepuka riba.\",\"link_label\":\"Kokotoa kodi ya ardhi\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:f3d52a6d5b5585079da95dddc913a458'),
(255,1795414399,2,'BE',1,0,6,'tx_mtosafisitepackage_slide','{\"oldRecord\":{\"title\":\"Have your say on the budget\",\"text\":\"Join the public participation forums in every ward this month.\",\"link_label\":\"See the forum dates\"},\"newRecord\":{\"title\":\"Toa maoni yako kuhusu bajeti\",\"text\":\"Shiriki katika mabaraza ya umma katika kila wadi mwezi huu.\",\"link_label\":\"Tazama tarehe za mabaraza\"}}',0,'0400$2Itrg8mNFVaQhvanU0dWcp4AqLjV4ku-:e07dd4cca395bf381d64df995b691198'),
(256,1795531560,1,'BE',1,0,56,'tt_content','{\"CType\":\"mtosafi_landrates\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":\"1\",\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":640,\"header\":\"Land rates calculator\",\"tx_mtosafisitepackage_minimum_rate\":1500,\"tx_mtosafisitepackage_interest\":\"1.00\",\"sys_language_uid\":0,\"crdate\":1795531560,\"t3ver_stage\":0,\"tstamp\":1795531560,\"uid\":56}',0,'0400$wtMsAreXBumpsyXY_WW9-tlh3ULbD-g4:fe60803ecb66c41dd58fcb8faade2185'),
(257,1795531560,1,'BE',1,0,1,'tx_mtosafisitepackage_landuse','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"sorting\":256,\"label\":\"Residential\",\"percent\":\"0.50\",\"sys_language_uid\":0,\"crdate\":1795531560,\"t3ver_stage\":0,\"tstamp\":1795531560,\"uid\":1}',0,'0400$wtMsAreXBumpsyXY_WW9-tlh3ULbD-g4:fa05b020fe6ca43f55b4eb5d399f860f'),
(258,1795531560,1,'BE',1,0,2,'tx_mtosafisitepackage_landuse','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"sorting\":128,\"label\":\"Commercial\",\"percent\":\"1.20\",\"sys_language_uid\":0,\"crdate\":1795531560,\"t3ver_stage\":0,\"tstamp\":1795531560,\"uid\":2}',0,'0400$wtMsAreXBumpsyXY_WW9-tlh3ULbD-g4:452b7298dff5d3cef9149b99e0c5fa98'),
(259,1795531560,1,'BE',1,0,3,'tx_mtosafisitepackage_landuse','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":6,\"sorting\":64,\"label\":\"Agricultural\",\"percent\":\"0.20\",\"sys_language_uid\":0,\"crdate\":1795531560,\"t3ver_stage\":0,\"tstamp\":1795531560,\"uid\":3}',0,'0400$wtMsAreXBumpsyXY_WW9-tlh3ULbD-g4:050b88d8c65c73993047528c4b2f8c9b'),
(260,1795531560,1,'BE',1,0,4,'tx_mtosafisitepackage_landuse','{\"hidden\":0,\"l10n_parent\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"label\\\":\\\"Residential\\\",\\\"parent\\\":\\\"56\\\",\\\"percent\\\":\\\"0.50\\\"}\",\"pid\":6,\"sorting\":257,\"sys_language_uid\":1,\"l10n_source\":1,\"l10n_state\":null,\"parent\":56,\"label\":\"Residential\",\"percent\":\"0.50\",\"crdate\":1795531560,\"t3ver_stage\":0,\"tstamp\":1795531560,\"uid\":4}',0,'0400$VdAKco2_OdPnUe-4G8z3hzUmSccs3Mi2:dd87b4fc44247a46187541b9bba382d2'),
(261,1795531560,1,'BE',1,0,5,'tx_mtosafisitepackage_landuse','{\"hidden\":0,\"l10n_parent\":\"2\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"label\\\":\\\"Commercial\\\",\\\"parent\\\":\\\"56\\\",\\\"percent\\\":\\\"1.20\\\"}\",\"pid\":6,\"sorting\":385,\"sys_language_uid\":1,\"l10n_source\":2,\"l10n_state\":null,\"parent\":56,\"label\":\"Commercial\",\"percent\":\"1.20\",\"crdate\":1795531560,\"t3ver_stage\":0,\"tstamp\":1795531560,\"uid\":5}',0,'0400$VdAKco2_OdPnUe-4G8z3hzUmSccs3Mi2:5e477a561d9dc2d25e054aa46f123b0e'),
(262,1795531560,1,'BE',1,0,6,'tx_mtosafisitepackage_landuse','{\"hidden\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"0\\\",\\\"label\\\":\\\"Agricultural\\\",\\\"parent\\\":\\\"56\\\",\\\"percent\\\":\\\"0.20\\\"}\",\"pid\":6,\"sorting\":449,\"sys_language_uid\":1,\"l10n_source\":3,\"l10n_state\":null,\"parent\":56,\"label\":\"Agricultural\",\"percent\":\"0.20\",\"crdate\":1795531560,\"t3ver_stage\":0,\"tstamp\":1795531560,\"uid\":6}',0,'0400$VdAKco2_OdPnUe-4G8z3hzUmSccs3Mi2:ff8d79efd3cd305a59226fdbad6ddeca'),
(263,1795531560,1,'BE',1,0,57,'tt_content','{\"CType\":\"mtosafi_landrates\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"image_zoom\":1,\"imagecols\":\"2\",\"recursive\":\"0\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"56\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"mtosafi_landrates\\\",\\\"assets\\\":\\\"0\\\",\\\"bodytext\\\":\\\"\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"crdate\\\":\\\"1795531560\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"0\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Land rates calculator\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"1\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"0\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tstamp\\\":\\\"1795531560\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_interest\\\":\\\"1.00\\\",\\\"tx_mtosafisitepackage_landuses\\\":\\\"3\\\",\\\"tx_mtosafisitepackage_minimum_rate\\\":\\\"1500\\\",\\\"tx_mtosafisitepackage_slides\\\":\\\"0\\\",\\\"tx_mtosafisitepackage_tiles\\\":\\\"0\\\",\\\"tx_news_related_news\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":704,\"tstamp\":1795531560,\"crdate\":1795531560,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":56,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to Kiswahili:] Land rates calculator\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_news_related_news\":0,\"tx_mtosafisitepackage_minimum_rate\":1500,\"tx_mtosafisitepackage_interest\":\"1.00\",\"t3ver_stage\":0,\"uid\":57}',0,'0400$VdAKco2_OdPnUe-4G8z3hzUmSccs3Mi2:d0d3611c87008a7e4e85bab32b541b70'),
(264,1795531560,2,'BE',1,0,57,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to Kiswahili:] Land rates calculator\",\"hidden\":1},\"newRecord\":{\"header\":\"Kikokotoo cha kodi ya ardhi\",\"hidden\":0}}',0,'0400$8fW8HwKUveYEf5Vyv33bAri7LebyKGdD:d0d3611c87008a7e4e85bab32b541b70'),
(265,1795531560,2,'BE',1,0,4,'tx_mtosafisitepackage_landuse','{\"oldRecord\":{\"label\":\"Residential\"},\"newRecord\":{\"label\":\"Makazi\"}}',0,'0400$8fW8HwKUveYEf5Vyv33bAri7LebyKGdD:dd87b4fc44247a46187541b9bba382d2'),
(266,1795531560,2,'BE',1,0,5,'tx_mtosafisitepackage_landuse','{\"oldRecord\":{\"label\":\"Commercial\"},\"newRecord\":{\"label\":\"Biashara\"}}',0,'0400$8fW8HwKUveYEf5Vyv33bAri7LebyKGdD:5e477a561d9dc2d25e054aa46f123b0e'),
(267,1795531560,2,'BE',1,0,6,'tx_mtosafisitepackage_landuse','{\"oldRecord\":{\"label\":\"Agricultural\"},\"newRecord\":{\"label\":\"Kilimo\"}}',0,'0400$8fW8HwKUveYEf5Vyv33bAri7LebyKGdD:ff8d79efd3cd305a59226fdbad6ddeca');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1795330974,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lina.wolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1795330980,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"lwolf\"]',-1,-99,'',0,'','info',NULL,NULL),
(3,1795332992,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(4,1795332999,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1795333001,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(6,1795333004,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"4\"}',0,0,'',0,'','info',NULL,NULL),
(7,1795333006,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"5\"}',0,0,'',0,'','info',NULL,NULL),
(8,1795333009,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"6\"}',0,0,'',0,'','info',NULL,NULL),
(9,1795333011,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"7\"}',0,0,'',0,'','info',NULL,NULL),
(10,1795333022,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(11,1795333022,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(12,1795333022,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(13,1795333042,1,3,2,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(14,1795333042,1,3,4,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":4}',2,0,'',0,'','info',NULL,NULL),
(15,1795333042,1,3,3,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":3}',2,0,'',0,'','info',NULL,NULL),
(16,1795333042,1,3,2,'pages',0,0,'Record pages:{uid} was deleted',1,'content','','{\"uid\":2}',1,0,'',0,'','info',NULL,NULL),
(17,1795334294,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1795334294,1,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":6,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(19,1795334294,1,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":7,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(20,1795334294,1,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":8,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(21,1795334294,1,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":9,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(22,1795334294,1,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":10,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(23,1795334294,1,1,11,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(24,1795334294,1,1,12,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(25,1795334294,1,1,13,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":13,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1795334294,1,1,14,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":14,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(27,1795334294,1,1,15,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":15,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(28,1795334294,1,1,16,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":16,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(29,1795334294,1,1,17,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":17,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(30,1795334294,1,1,18,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":18,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(31,1795334294,1,1,19,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":19,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(32,1795334294,1,1,20,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(33,1795334294,1,1,21,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(34,1795334294,1,1,22,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(35,1795334294,1,1,23,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(36,1795334294,1,1,24,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":24,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(37,1795334294,1,1,25,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":25,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(38,1795334294,1,1,26,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":26,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(39,1795334294,1,1,27,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":27,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(40,1795334294,1,1,28,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":28,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(41,1795334294,1,1,29,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":29,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(42,1795334294,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":1,\"history\":\"40\"}',0,0,'',0,'','info',NULL,NULL),
(43,1795334294,1,2,24,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":24,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(44,1795334294,1,2,25,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":25,\"history\":0}',22,0,'',0,'','info',NULL,NULL),
(45,1795334294,1,2,26,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":26,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(46,1795334294,1,2,27,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":27,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(47,1795334294,1,2,28,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":28,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(48,1795334294,1,2,29,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":29,\"history\":0}',23,0,'',0,'','info',NULL,NULL),
(49,1795334294,1,3,1,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(51,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 121',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(52,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"commands\" in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(53,1795336947,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/vendor/typo3/cms-core/Classes/Command/Descriptor/TextDescriptor.php line 106',5,'php','','',-1,-99,'',0,'','warning',NULL,NULL),
(54,1795336956,1,1,30,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":30,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(55,1795336956,1,1,31,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":31,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(56,1795336956,1,1,32,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":32,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(57,1795336956,1,1,1,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(58,1795336956,1,1,2,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(59,1795336956,1,1,3,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(60,1795336956,1,1,4,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(61,1795336956,1,1,5,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(62,1795336956,1,1,6,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(63,1795336956,1,1,7,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(64,1795336956,1,1,8,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_category\",\"uid\":8,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(65,1795336956,1,1,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(66,1795336956,1,1,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(67,1795336956,1,1,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(68,1795336956,1,1,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(69,1795336956,1,1,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(70,1795336956,1,1,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(71,1795336956,1,1,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(72,1795336956,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(73,1795336956,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":4,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(74,1795336956,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":5,\"pid\":31}',31,0,'',0,'','info',NULL,NULL),
(75,1795336956,1,2,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(76,1795336956,1,2,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(77,1795336956,1,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(78,1795336956,1,2,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(79,1795336956,1,2,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(80,1795336956,1,2,6,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":6,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(81,1795336956,1,2,7,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":7,\"history\":0}',32,0,'',0,'','info',NULL,NULL),
(82,1795343750,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1795343750,1,1,1,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(84,1795343750,1,1,2,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(85,1795343750,1,1,3,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(86,1795343750,1,1,4,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(87,1795343750,1,1,5,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(88,1795343750,1,1,6,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(89,1795343750,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(90,1795344511,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(91,1795344511,1,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(92,1795344511,1,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(93,1795344511,1,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(94,1795344511,1,1,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(95,1795344511,1,1,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(96,1795344511,1,1,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(97,1795344511,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(98,1795344511,1,2,1,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":1,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(99,1795344511,1,2,2,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":2,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(100,1795344511,1,2,3,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(101,1795345582,1,1,33,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":33,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(102,1795345582,1,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":8,\"pid\":33}',33,0,'',0,'','info',NULL,NULL),
(103,1795348009,1,1,34,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":34,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(104,1795348009,1,2,16,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":16,\"history\":\"80\"}',1,0,'',0,'','info',NULL,NULL),
(105,1795348009,1,2,33,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":33,\"history\":\"81\"}',1,0,'',0,'','info',NULL,NULL),
(106,1795348009,1,2,31,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":31,\"history\":\"82\"}',30,0,'',0,'','info',NULL,NULL),
(107,1795348009,1,1,1,'tx_kesearch_filteroptions',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filteroptions\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(108,1795348009,1,1,2,'tx_kesearch_filteroptions',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filteroptions\",\"uid\":2,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(109,1795348009,1,1,1,'tx_kesearch_filters',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_filters\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(110,1795348009,1,2,1,'tx_kesearch_filters',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_kesearch_filters\",\"uid\":1,\"history\":0}',34,0,'',0,'','info',NULL,NULL),
(111,1795348009,1,1,1,'tx_kesearch_indexerconfig',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_indexerconfig\",\"uid\":1,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(112,1795348009,1,1,2,'tx_kesearch_indexerconfig',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_kesearch_indexerconfig\",\"uid\":2,\"pid\":34}',34,0,'',0,'','info',NULL,NULL),
(113,1795348009,1,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":9,\"pid\":16}',16,0,'',0,'','info',NULL,NULL),
(114,1795348009,1,1,10,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":10,\"pid\":16}',16,0,'',0,'','info',NULL,NULL),
(115,1795348011,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n31 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n0 pages have been indexed. \n\n30 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 87 ms\nNews\n7 News and 0 related files have been indexed.\n\n\nIndexing process took 20 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 1 ms.\n\nFinished\nIndexing finished at 11/22/26, 12:46:52 (took 1 seconds).\nIndex contains 7 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(116,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(117,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(118,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(119,1795348012,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(120,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(121,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(122,1795348055,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(123,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(124,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(125,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(126,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(127,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(128,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(129,1795348678,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(130,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(131,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(132,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(133,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(134,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(135,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(136,1795348682,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(137,1795348709,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(138,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(139,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(140,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(141,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(142,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(143,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(144,1795349331,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(145,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(146,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(147,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(148,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(149,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(150,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(151,1795349401,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(152,1795365530,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(153,1795365530,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(154,1795365714,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(155,1795368020,1,1,4,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(156,1795368020,1,1,5,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(157,1795368020,1,1,6,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(158,1795368020,1,1,7,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(159,1795368020,1,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(160,1795368020,1,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(161,1795368020,1,1,10,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":10,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(162,1795368020,1,1,11,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":11,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(163,1795368020,1,1,12,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":12,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(164,1795368020,1,1,13,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":13,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(165,1795368020,1,1,14,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":14,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(166,1795368020,1,1,15,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":15,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(167,1795368020,1,1,16,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":16,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(168,1795368020,1,1,17,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":17,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(169,1795368020,1,1,18,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":18,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(170,1795368020,1,1,19,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":19,\"pid\":17}',17,0,'',0,'','info',NULL,NULL),
(171,1795368020,1,1,20,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":18}',18,0,'',0,'','info',NULL,NULL),
(172,1795368020,1,1,21,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":19}',19,0,'',0,'','info',NULL,NULL),
(173,1795368020,1,1,22,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(174,1795368020,1,1,23,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(175,1795368020,1,1,11,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":11,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(176,1795368020,1,1,12,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":12,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(177,1795368020,1,1,13,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":13,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(178,1795368020,1,1,14,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":14,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(179,1795368020,1,1,15,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":15,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(180,1795368020,1,1,16,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":16,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(181,1795368020,1,1,17,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":17,\"pid\":7}',7,0,'',0,'','info',NULL,NULL),
(182,1795368020,1,1,18,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(183,1795368020,1,1,19,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":19,\"pid\":8}',8,0,'',0,'','info',NULL,NULL),
(184,1795368020,1,1,20,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(185,1795368020,1,1,21,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":21,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(186,1795368020,1,1,22,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":22,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(187,1795368020,1,1,23,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":23,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(188,1795368020,1,1,24,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":24,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(189,1795368020,1,1,25,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":25,\"pid\":11}',11,0,'',0,'','info',NULL,NULL),
(190,1795368020,1,1,26,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":26,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(191,1795368020,1,1,27,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":27,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(192,1795368020,1,1,28,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":28,\"pid\":12}',12,0,'',0,'','info',NULL,NULL),
(193,1795368020,1,1,29,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":29,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(194,1795368020,1,1,30,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":30,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(195,1795368020,1,1,31,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":31,\"pid\":13}',13,0,'',0,'','info',NULL,NULL),
(196,1795368020,1,1,32,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":32,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(197,1795368020,1,1,33,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":33,\"pid\":14}',14,0,'',0,'','info',NULL,NULL),
(198,1795368020,1,1,34,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(199,1795368020,1,1,35,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":35,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(200,1795368020,1,1,36,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":36,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(201,1795368020,1,1,37,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":37,\"pid\":17}',17,0,'',0,'','info',NULL,NULL),
(202,1795368020,1,1,38,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":38,\"pid\":18}',18,0,'',0,'','info',NULL,NULL),
(203,1795368020,1,1,39,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":39,\"pid\":19}',19,0,'',0,'','info',NULL,NULL),
(204,1795368020,1,1,40,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":40,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(205,1795368020,1,1,41,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":41,\"pid\":20}',20,0,'',0,'','info',NULL,NULL),
(206,1795368020,1,1,42,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":42,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(207,1795368020,1,1,43,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":43,\"pid\":21}',21,0,'',0,'','info',NULL,NULL),
(208,1795368020,1,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":11,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(209,1795368020,1,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":13,\"history\":0}',6,0,'',0,'','info',NULL,NULL),
(210,1795368020,1,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',7,0,'',0,'','info',NULL,NULL),
(211,1795368020,1,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":18,\"history\":0}',8,0,'',0,'','info',NULL,NULL),
(212,1795368020,1,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":20,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(213,1795368020,1,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":22,\"history\":0}',10,0,'',0,'','info',NULL,NULL),
(214,1795368020,1,2,24,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":24,\"history\":0}',11,0,'',0,'','info',NULL,NULL),
(215,1795368020,1,2,26,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":26,\"history\":0}',12,0,'',0,'','info',NULL,NULL),
(216,1795368020,1,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',13,0,'',0,'','info',NULL,NULL),
(217,1795368020,1,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":31,\"history\":0}',13,0,'',0,'','info',NULL,NULL),
(218,1795368020,1,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',14,0,'',0,'','info',NULL,NULL),
(219,1795368020,1,2,34,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"history\":0}',15,0,'',0,'','info',NULL,NULL),
(220,1795368020,1,2,37,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":37,\"history\":0}',17,0,'',0,'','info',NULL,NULL),
(221,1795368020,1,2,38,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":38,\"history\":0}',18,0,'',0,'','info',NULL,NULL),
(222,1795368020,1,2,39,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":39,\"history\":0}',19,0,'',0,'','info',NULL,NULL),
(223,1795368020,1,2,40,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":40,\"history\":0}',20,0,'',0,'','info',NULL,NULL),
(224,1795368020,1,2,42,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":42,\"history\":0}',21,0,'',0,'','info',NULL,NULL),
(225,1795368024,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n31 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n16 pages have been indexed. \n\n14 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 182 ms\nNews\n7 News and 0 related files have been indexed.\n\n\nIndexing process took 34 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 2 ms.\n\nFinished\nIndexing finished at 11/22/26, 18:20:24 (took 0 seconds).\nIndex contains 23 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(226,1795369027,1,2,15,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":15,\"history\":\"143\"}',1,0,'',0,'','info',NULL,NULL),
(227,1795369027,1,1,44,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":44,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(228,1795369027,1,2,34,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":34,\"history\":\"145\"}',15,0,'',0,'','info',NULL,NULL),
(229,1795369027,1,2,35,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":35,\"history\":\"146\"}',15,0,'',0,'','info',NULL,NULL),
(230,1795369027,1,2,36,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":36,\"history\":\"147\"}',15,0,'',0,'','info',NULL,NULL),
(231,1795369943,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: The \"TYPO3\\CMS\\Form\\Mvc\\Configuration\\YamlSource\" service or alias has been removed or inlined when the container was compiled. You should either make it public, or stop using the container directly and use dependency injection instead. | Symfony\\Component\\DependencyInjection\\Exception\\ServiceNotFoundException thrown in file /var/www/html/vendor/symfony/dependency-injection/Container.php in line 243',5,'php','','',-1,0,'',0,'','error',NULL,NULL),
(232,1795372569,1,1,35,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":35,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(233,1795372569,1,1,36,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":36,\"pid\":35}',35,0,'',0,'','info',NULL,NULL),
(234,1795372569,1,1,8,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":8,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(235,1795372569,1,1,9,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":9,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(236,1795372569,1,1,10,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":10,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(237,1795372569,1,1,11,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":11,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(238,1795372569,1,1,12,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":12,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(239,1795372569,1,1,13,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_news_domain_model_news\",\"uid\":13,\"pid\":32}',32,0,'',0,'','info',NULL,NULL),
(240,1795372569,1,1,45,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":45,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(241,1795372569,1,1,46,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":46,\"pid\":35}',35,0,'',0,'','info',NULL,NULL),
(242,1795372569,1,1,47,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":47,\"pid\":36}',36,0,'',0,'','info',NULL,NULL),
(243,1795372572,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n33 pages have been selected for indexing in the main language.\n\n2 languages (All languages, English) have been found.\n\n16 pages have been indexed. \n\n16 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 142 ms\nNews\n13 News and 0 related files have been indexed.\n\n\nIndexing process took 50 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 1 ms.\n\nFinished\nIndexing finished at 11/22/26, 19:36:12 (took 0 seconds).\nIndex contains 29 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(244,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(245,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(246,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(247,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(248,1795372574,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(249,1795414399,1,1,37,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":37,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(250,1795414399,1,1,38,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":38,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(251,1795414399,1,1,39,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":39,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(252,1795414399,1,1,40,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":40,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(253,1795414399,1,1,41,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":41,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(254,1795414399,1,1,42,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":42,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(255,1795414399,1,1,43,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":43,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(256,1795414399,1,1,44,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":44,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(257,1795414399,1,1,45,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":45,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(258,1795414399,1,1,46,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":46,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(259,1795414399,1,1,47,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":47,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(260,1795414399,1,1,48,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":48,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(261,1795414399,1,1,49,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":49,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(262,1795414399,1,1,50,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":50,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(263,1795414399,1,1,51,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":51,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(264,1795414399,1,1,52,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":52,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(265,1795414399,1,1,53,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":53,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(266,1795414399,1,1,54,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":54,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(267,1795414399,1,1,55,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":55,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(268,1795414399,1,1,56,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":56,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(269,1795414399,1,1,57,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":57,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(270,1795414399,1,1,58,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":58,\"pid\":30}',30,0,'',0,'','info',NULL,NULL),
(271,1795414399,1,1,59,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":59,\"pid\":35}',35,0,'',0,'','info',NULL,NULL),
(272,1795414399,1,1,60,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":60,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(273,1795414399,1,1,61,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":61,\"pid\":22}',22,0,'',0,'','info',NULL,NULL),
(274,1795414399,1,1,62,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":62,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(275,1795414399,1,1,63,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":63,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(276,1795414399,1,1,64,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":64,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(277,1795414399,1,1,65,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"pages\",\"uid\":65,\"pid\":23}',23,0,'',0,'','info',NULL,NULL),
(278,1795414399,1,2,37,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":37,\"history\":\"188\"}',0,0,'',0,'','info',NULL,NULL),
(279,1795414399,1,2,38,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":38,\"history\":\"189\"}',1,0,'',0,'','info',NULL,NULL),
(280,1795414399,1,2,39,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":39,\"history\":\"190\"}',1,0,'',0,'','info',NULL,NULL),
(281,1795414399,1,2,40,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":40,\"history\":\"191\"}',1,0,'',0,'','info',NULL,NULL),
(282,1795414399,1,2,41,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":41,\"history\":\"192\"}',1,0,'',0,'','info',NULL,NULL),
(283,1795414399,1,2,42,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":42,\"history\":\"193\"}',1,0,'',0,'','info',NULL,NULL),
(284,1795414399,1,2,43,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":43,\"history\":\"194\"}',1,0,'',0,'','info',NULL,NULL),
(285,1795414399,1,2,44,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":44,\"history\":\"195\"}',1,0,'',0,'','info',NULL,NULL),
(286,1795414399,1,2,45,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":45,\"history\":\"196\"}',1,0,'',0,'','info',NULL,NULL),
(287,1795414399,1,2,46,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":46,\"history\":\"197\"}',1,0,'',0,'','info',NULL,NULL),
(288,1795414399,1,2,47,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":47,\"history\":\"198\"}',1,0,'',0,'','info',NULL,NULL),
(289,1795414399,1,2,48,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":48,\"history\":\"199\"}',1,0,'',0,'','info',NULL,NULL),
(290,1795414399,1,2,49,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":49,\"history\":\"200\"}',1,0,'',0,'','info',NULL,NULL),
(291,1795414399,1,2,50,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":50,\"history\":\"201\"}',1,0,'',0,'','info',NULL,NULL),
(292,1795414399,1,2,51,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":51,\"history\":\"202\"}',1,0,'',0,'','info',NULL,NULL),
(293,1795414399,1,2,52,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":52,\"history\":\"203\"}',1,0,'',0,'','info',NULL,NULL),
(294,1795414399,1,2,53,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":53,\"history\":\"204\"}',5,0,'',0,'','info',NULL,NULL),
(295,1795414399,1,2,54,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":54,\"history\":\"205\"}',5,0,'',0,'','info',NULL,NULL),
(296,1795414399,1,2,55,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":55,\"history\":\"206\"}',5,0,'',0,'','info',NULL,NULL),
(297,1795414399,1,2,56,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":56,\"history\":\"207\"}',5,0,'',0,'','info',NULL,NULL),
(298,1795414399,1,2,57,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":57,\"history\":\"208\"}',5,0,'',0,'','info',NULL,NULL),
(299,1795414399,1,2,58,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":58,\"history\":\"209\"}',30,0,'',0,'','info',NULL,NULL),
(300,1795414399,1,2,59,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":59,\"history\":\"210\"}',35,0,'',0,'','info',NULL,NULL),
(301,1795414399,1,2,60,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":60,\"history\":\"211\"}',22,0,'',0,'','info',NULL,NULL),
(302,1795414399,1,2,61,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":61,\"history\":\"212\"}',22,0,'',0,'','info',NULL,NULL),
(303,1795414399,1,2,62,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":62,\"history\":\"213\"}',23,0,'',0,'','info',NULL,NULL),
(304,1795414399,1,2,63,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":63,\"history\":\"214\"}',23,0,'',0,'','info',NULL,NULL),
(305,1795414399,1,2,64,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":64,\"history\":\"215\"}',23,0,'',0,'','info',NULL,NULL),
(306,1795414399,1,2,65,'pages',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"pages\",\"uid\":65,\"history\":\"216\"}',23,0,'',0,'','info',NULL,NULL),
(307,1795414399,1,1,24,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(308,1795414399,1,1,4,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(309,1795414399,1,2,4,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":4,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(310,1795414399,1,1,25,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(311,1795414399,1,1,5,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(312,1795414399,1,2,5,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(313,1795414399,1,1,26,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":26,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(314,1795414399,1,1,6,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(315,1795414399,1,2,6,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":6,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(316,1795414399,1,1,48,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":48,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(317,1795414399,1,2,48,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":48,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(318,1795414399,1,1,7,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(319,1795414399,1,1,8,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(320,1795414399,1,1,9,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(321,1795414399,1,1,10,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":10,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(322,1795414399,1,1,11,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(323,1795414399,1,1,12,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(324,1795414399,1,1,49,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":49,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(325,1795414399,1,2,49,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":49,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(326,1795414399,1,1,50,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":50,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(327,1795414399,1,1,51,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":51,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(328,1795414399,1,1,52,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":52,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(329,1795414399,1,1,27,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":27,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(330,1795414399,1,1,53,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":53,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(331,1795414399,1,2,53,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":53,\"history\":0}',15,0,'',0,'','info',NULL,NULL),
(332,1795414399,1,1,54,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":54,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(333,1795414399,1,1,55,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":55,\"pid\":15}',15,0,'',0,'','info',NULL,NULL),
(334,1795414399,1,2,50,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":50,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(335,1795414399,1,2,51,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":51,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(336,1795414399,1,2,48,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":48,\"history\":\"238\"}',1,0,'',0,'','info',NULL,NULL),
(337,1795414399,1,2,49,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":49,\"history\":\"239\"}',1,0,'',0,'','info',NULL,NULL),
(338,1795414399,1,2,50,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":50,\"history\":\"240\"}',1,0,'',0,'','info',NULL,NULL),
(339,1795414399,1,2,51,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":51,\"history\":\"241\"}',1,0,'',0,'','info',NULL,NULL),
(340,1795414399,1,2,52,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":52,\"history\":\"242\"}',15,0,'',0,'','info',NULL,NULL),
(341,1795414399,1,2,53,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":53,\"history\":\"243\"}',15,0,'',0,'','info',NULL,NULL),
(342,1795414399,1,2,54,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":54,\"history\":\"244\"}',15,0,'',0,'','info',NULL,NULL),
(343,1795414399,1,2,55,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":55,\"history\":\"245\"}',15,0,'',0,'','info',NULL,NULL),
(344,1795414399,1,2,27,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"sys_file_reference\",\"uid\":27,\"history\":\"246\"}',15,0,'',0,'','info',NULL,NULL),
(345,1795414399,1,2,7,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":7,\"history\":\"247\"}',1,0,'',0,'','info',NULL,NULL),
(346,1795414399,1,2,8,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":8,\"history\":\"248\"}',1,0,'',0,'','info',NULL,NULL),
(347,1795414399,1,2,9,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":9,\"history\":\"249\"}',1,0,'',0,'','info',NULL,NULL),
(348,1795414399,1,2,10,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":10,\"history\":\"250\"}',1,0,'',0,'','info',NULL,NULL),
(349,1795414399,1,2,11,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":11,\"history\":\"251\"}',1,0,'',0,'','info',NULL,NULL),
(350,1795414399,1,2,12,'tx_mtosafisitepackage_tile',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_tile\",\"uid\":12,\"history\":\"252\"}',1,0,'',0,'','info',NULL,NULL),
(351,1795414399,1,2,4,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":4,\"history\":\"253\"}',1,0,'',0,'','info',NULL,NULL),
(352,1795414399,1,2,5,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":5,\"history\":\"254\"}',1,0,'',0,'','info',NULL,NULL),
(353,1795414399,1,2,6,'tx_mtosafisitepackage_slide',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_slide\",\"uid\":6,\"history\":\"255\"}',1,0,'',0,'','info',NULL,NULL),
(354,1795414401,0,0,0,'',0,0,'[ke_search] Running indexing process in full mode.\nPages\n33 pages have been selected for indexing in the main language.\n\n3 languages (All languages, English, Kiswahili) have been found.\n\n32 pages have been indexed. \n\n16 had no content or the content was not indexable.\n\n0 files have been indexed.\nIndexing process took 167 ms\nNews\n13 News and 0 related files have been indexed.\n\n\nIndexing process took 50 ms\n\nCleanup\n0 entries deleted.\nCleanup process took 1 ms.\n\nFinished\nIndexing finished at 11/23/26, 07:13:21 (took 0 seconds).\nIndex contains 45 entries.\n',4,'default','','',-1,-99,'',0,'','info',NULL,NULL),
(355,1795414412,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(356,1795414412,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(357,1795414412,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(358,1795414412,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"previewMode\" in /var/www/html/vendor/tpwd/ke_search/Classes/Lib/Searchresult.php line 168',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(359,1795531560,1,1,56,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":56,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(360,1795531560,1,1,1,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":1,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(361,1795531560,1,1,2,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":2,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(362,1795531560,1,1,3,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":3,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(363,1795531560,1,2,56,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":56,\"history\":0}',6,0,'',0,'','info',NULL,NULL),
(364,1795531560,1,1,4,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":4,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(365,1795531560,1,1,5,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":5,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(366,1795531560,1,1,6,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":6,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(367,1795531560,1,1,57,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','','{\"table\":\"tt_content\",\"uid\":57,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),
(368,1795531560,1,2,57,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":57,\"history\":0}',6,0,'',0,'','info',NULL,NULL),
(369,1795531560,1,2,57,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":57,\"history\":\"264\"}',6,0,'',0,'','info',NULL,NULL),
(370,1795531560,1,2,4,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":4,\"history\":\"265\"}',6,0,'',0,'','info',NULL,NULL),
(371,1795531560,1,2,5,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":5,\"history\":\"266\"}',6,0,'',0,'','info',NULL,NULL),
(372,1795531560,1,2,6,'tx_mtosafisitepackage_landuse',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tx_mtosafisitepackage_landuse\",\"uid\":6,\"history\":\"267\"}',6,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('029d857185cc6f0a9a8ab7e9d2ef95f3','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',3,0,'tx_mtosafisitepackage_tile',4,'',0,0,2147483647,0,0,''),
('03b174c60be6721f149bdb384c9b3685','pages',61,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('060db93adbf8c80a5c341ef5bfea77c8','sys_file_reference',22,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',25,'',0,0,2147483647,0,0,''),
('074360f2b3765e7cd9bd342738851d6a','pages',58,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('07db517ae886f8dc10be0c2ee0997e25','tt_content',47,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('0857a51e2e4feb7c47a38d6aa472fa9f','pages',59,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',36,'',0,0,2147483647,0,0,''),
('08d2716299a7edd920edfd9427d93525','tx_mtosafisitepackage_tile',1,'link',0,0,2147483647,0,'','typolink','7f69a1aa54e9db8a5ae0d952977b4cd9:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('09a11618d843bd2ea4e06687945190c2','tt_content',57,'tx_mtosafisitepackage_landuses',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_landuse',6,'',0,0,2147483647,0,0,''),
('0a2b30b3fd10b9a5d1992a061704732d','pages',50,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',33,'',0,0,2147483647,0,0,''),
('0ae2b7e859fff1559ce5b2bfcdeb365a','pages',39,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',11,'',0,0,2147483647,0,0,''),
('0bb42ee7906264eb370da9ee8c5cc360','tt_content',31,'image',0,0,2147483647,0,'','','',3,0,'sys_file_reference',16,'',0,0,2147483647,0,0,''),
('10024751613cd818698f689393f45860','tt_content',52,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','961510a00113a2f50daa68fc42a1ca17',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml'),
('15176dab87b98925b8f65c60378b9db9','pages',48,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,''),
('1571d3ddda52e40d0eadf34c15443ed4','tt_content',48,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',4,'',0,0,2147483647,0,0,''),
('17d5bf3449012f6032742f906e754655','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',12,'',0,0,2147483647,0,0,''),
('1851bbc1db6881a3fe4870df6256ae6b','tx_mtosafisitepackage_slide',4,'link',0,0,2147483647,0,'','typolink','2db3883e7010ab969a4c6c9ff0b9da31:0',0,0,'pages',13,'',0,0,2147483647,0,0,''),
('19682de1c89f1c9f7f3c1f90896eef4d','tt_content',46,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('1a1b33ad44894354a18d0d45ff698eff','tx_kesearch_filters',1,'options',0,0,2147483647,0,'','','',0,0,'tx_kesearch_filteroptions',1,'',0,0,2147483647,0,0,''),
('1b2ed6872931f6bf2631618fb6288e67','tt_content',36,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('1c18b2c4fcfecf16eaa9eeff06c60c74','tt_content',45,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('1dd0e0354b52fbddbadff8931116243c','tx_kesearch_indexerconfig',2,'targetpid',0,0,2147483647,0,'','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('1fde6c7fd92bd9d8eafb8e741be22840','tt_content',4,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('20f5efef03fe691570c3d2cd2fc393cf','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('220bc45f86eae522c66204eabb90e306','tx_mtosafisitepackage_slide',3,'link',0,0,2147483647,0,'','typolink','bf1e9cf52cce365bffb23721ba63b67b:0',0,0,'pages',14,'',0,0,2147483647,0,0,''),
('222baf9b25427e410e9c39f6ec6f2b7f','sys_category',5,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',5,'categories',0,0,2147483647,0,1,''),
('225e9febc94acfa52497bc219ce6d31b','sys_file_reference',21,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',24,'',0,0,2147483647,0,0,''),
('2386acca52c4f18cefdc6b906df671e9','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',13,'',0,0,2147483647,0,0,''),
('257852b45581f9ba338dbd166ba5b174','pages',63,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',19,'',0,0,2147483647,0,0,''),
('272ed908a089e4479e11d9ea32071618','pages',64,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',28,'',0,0,2147483647,0,0,''),
('2780872b4d83ef806371ff889b7799cc','tx_kesearch_indexerconfig',2,'startingpoints_recursive',0,0,2147483647,0,'','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('29a329d6c2587007f7066bb2fb04e99e','pages',52,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('30ddbb32f1c31a45277a635e878cef2e','tt_content',31,'image',0,0,2147483647,0,'','','',1,0,'sys_file_reference',14,'',0,0,2147483647,0,0,''),
('311af28e5bf97ba04c337bc0924ac7df','pages',40,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('313e461a539f46cf2465487a128c051c','tx_mtosafisitepackage_tile',4,'link',0,0,2147483647,0,'','typolink','e34f7e18c8dc8d47f12cbbc9ec0587df:0',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('31aedcffb204bd0c7d625c74d33e25fc','tt_content',56,'tx_mtosafisitepackage_landuses',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_landuse',3,'',0,0,2147483647,0,0,''),
('33be7c7c27d73f38622f81fcce501fee','tt_content',9,'pages',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('34207e80000f80f5d379c7239ccccf4f','tx_mtosafisitepackage_slide',4,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',24,'',0,0,2147483647,0,0,''),
('37aaef61fe9da71c3d2158c1cc012f0c','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('37f576097de0f748cecc71524ab0533f','tt_content',50,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('39701b713c1e030d4915ca9a6ce65299','tx_mtosafisitepackage_slide',4,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',1,'',0,0,2147483647,0,0,''),
('397497f0d911d5b8550159f504d01194','tt_content',39,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',21,'',0,0,2147483647,0,0,''),
('39f11610b54678a8af0feb57210bb43f','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',5,0,'tx_mtosafisitepackage_tile',6,'',0,0,2147483647,0,0,''),
('3d2896994c41d754a6409b530412c846','tt_content',3,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('3dd61fadc472ee3f5bb4d4e7e08a79a8','sys_file_reference',10,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',17,'',0,0,2147483647,0,0,''),
('3fd1c6442f55b996bd19ede1b4d2a14c','tt_content',57,'tx_mtosafisitepackage_landuses',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_landuse',5,'',0,0,2147483647,0,0,''),
('415de9b0331ee3670c2a9526f1affae8','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',15,'',0,0,2147483647,0,0,''),
('4402b32b58c950bb2cb91e2f1ed8bba8','pages',27,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',19,'',0,0,2147483647,0,0,''),
('4502c999e76beaad402d5f8db6b86f25','tx_kesearch_indexerconfig',2,'storagepid',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('4757b12b90def24df1880d8a111e43d5','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_tile',2,'',0,0,2147483647,0,0,''),
('47d351b61ea29efbe541d4778add7530','tx_kesearch_indexerconfig',1,'storagepid',0,0,2147483647,0,'','','',0,0,'pages',34,'',0,0,2147483647,0,0,''),
('480b46ad69572f59b62b9a26b54a746b','sys_file_reference',17,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',21,'',0,0,2147483647,0,0,''),
('48c722574641f7d66187f214aaf902e7','tt_content',55,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('4a40a686f068314552907821c929c0b5','tt_content',51,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',45,'',0,0,2147483647,0,0,''),
('4a57e393c2ef3bfb2abbdd5ffdb128c0','tx_mtosafisitepackage_slide',6,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',3,'',0,0,2147483647,0,0,''),
('4b396e42faacd181c23a02dfa803afc1','pages',46,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('4b8649c4ac802e70df9887d61abb4741','tt_content',47,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('4c50552ba214ce72d9d786f4de43b368','sys_category',7,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',7,'categories',0,0,2147483647,0,1,''),
('505ac3050b1043f117f21c125ce5f915','tx_mtosafisitepackage_tile',6,'link',0,0,2147483647,0,'','typolink','7f897eb5d5b640dce3bedcdb56c2d987:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('5212307d56a434cda710fd02e8113f82','tt_content',34,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'+254700000000'),
('529b5cce1a84064c904a6c430d56ecd1','sys_file_reference',16,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('52a805998bfbffb2b59c817758082483','tx_mtosafisitepackage_tile',10,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',4,'',0,0,2147483647,0,0,''),
('5429966bdbff8fa90d5c254833c7756c','tt_content',15,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('579ed8b6ce96931f2d74a3b106f6129c','tx_mtosafisitepackage_landuse',4,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_landuse',1,'',0,0,2147483647,0,0,''),
('57f3f24035003e076a2841803043128c','tx_mtosafisitepackage_tile',11,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',5,'',0,0,2147483647,0,0,''),
('5925468a9a9c41a9dafd1e52dc6f7153','tx_mtosafisitepackage_tile',10,'link',0,0,2147483647,0,'','typolink','8a0fa9e8673c46fcfd6f5aa77ae0ca81:0',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('59cedf06047f188e18852b5a7ebea995','tt_content',49,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',3,0,'tx_mtosafisitepackage_tile',10,'',0,0,2147483647,0,0,''),
('5b7fffc2df7ac1bb402227ce05d2ce85','tx_mtosafisitepackage_slide',5,'link',0,0,2147483647,0,'','typolink','b3c46bacdb562a7f2092ccf567e5bf7f:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('5c11a5c7bf2da510817bb633b82e7349','pages',57,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',10,'',0,0,2147483647,0,0,''),
('5ff7613f9fb288bf6fbd7ae2cd3272fc','tt_content',49,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_tile',9,'',0,0,2147483647,0,0,''),
('61822530192fdcaa565eb8f0d5a797b2','pages',41,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',13,'',0,0,2147483647,0,0,''),
('642b702d5002f29241f7c501f3d28cf1','tt_content',34,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('64c4f34accd4a8388efdeeb0140f541b','pages',53,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('655053dcf91ff4de04e0e7b0935ac0dc','tx_mtosafisitepackage_tile',5,'link',0,0,2147483647,0,'','typolink','a01eec11a0a46a8e86685cb8ec780ef1:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('6588346adbea50117c2b4ec974921dca','tt_content',53,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('679f66b060ba12c8427fbf2a710b0fd9','pages',29,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',21,'',0,0,2147483647,0,0,''),
('68275e712ee6626930e72c076be4577e','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('6976e8dbb7f47034395b0319c447303c','pages',63,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',27,'',0,0,2147483647,0,0,''),
('6c4281b73fb321f54db2e96de9711b3d','tt_content',49,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',6,'',0,0,2147483647,0,0,''),
('6d5ef69adfce56a9d43b25d56fd362e3','tt_content',52,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',44,'',0,0,2147483647,0,0,''),
('6dd1114501e9319d5dcfe17f5d540a57','tt_content',53,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',34,'',0,0,2147483647,0,0,''),
('6e9153c8043ab894a418dc6522791810','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',1,'',0,0,2147483647,0,0,''),
('6eeee2f91defe051041e8bab34298208','tt_content',56,'tx_mtosafisitepackage_landuses',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_landuse',2,'',0,0,2147483647,0,0,''),
('7106458409a1a556fb1c60516e842efb','tt_content',18,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',7,'',0,0,2147483647,0,0,''),
('7140c40420dd9126c54556b8ad8d9764','tt_content',45,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',36,'',0,0,2147483647,0,0,''),
('71bd7ba8149169134006c9ca870e2006','sys_file_reference',12,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('74a75a9ee551e9c9ffc290f8aeedf3a5','pages',47,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',19,'',0,0,2147483647,0,0,''),
('75556fee2d3ed592163a8b8db36019f9','sys_file_reference',25,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('75c3df5c09e24b3c2c96c640da355e01','tx_mtosafisitepackage_tile',2,'link',0,0,2147483647,0,'','typolink','087881d39e3c58af824e5fb90e661a8e:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('77491718585910205641ef73b044aa19','sys_category',1,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',1,'categories',0,0,2147483647,0,1,''),
('777a432b0e62b25c1b84f398c69e5955','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',1,'',0,0,2147483647,0,0,''),
('77d010084c16ba8308f7be5f1b76c604','tx_mtosafisitepackage_slide',1,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('78ac964f351553e09522625f35df8007','tt_content',51,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('790e94ef030c1874447b64f6c9e63a49','pages',62,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',26,'',0,0,2147483647,0,0,''),
('7948bfb5fb5858eeb7961d595c01ddf5','tt_content',4,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('79562c633d5c093af983840b815f2b9e','sys_category',8,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',10,'categories',0,0,2147483647,0,1,''),
('7ab46b1e874e6100a8c759c1a43fea3f','sys_category',6,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',8,'categories',0,0,2147483647,0,1,''),
('7b21b2228a8fd7ec83265fb900741d46','sys_file_reference',11,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',18,'',0,0,2147483647,0,0,''),
('7c1bbf8ace3af3464650f760cfe80a10','tt_content',50,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',31,'',0,0,2147483647,0,0,''),
('7d2b90b0af50bae4b7f3034bca4059c4','pages',60,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('7e694f9466d958648b1c103f07e2eddd','pages',26,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('835a7a68a9f43205ac7f21f52c844870','tt_content',48,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('83741935e51ba60618233a90d0c9a725','sys_file_reference',27,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',18,'',0,0,2147483647,0,0,''),
('84ad13f6b52a918039bc14cd87042e29','tt_content',9,'pi_flexform',0,0,2147483647,0,'MAIN/lDEF/resultPage/vDEF/','','',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('859051dfd012e76127af431eb4ed7c75','tt_content',51,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',36,'',0,0,2147483647,0,0,''),
('86aa77750d3d62492d28cf72adb0c6ec','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',4,0,'tx_mtosafisitepackage_tile',5,'',0,0,2147483647,0,0,''),
('89b7a1d601707ce5db2046096b795a8c','pages',64,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,''),
('8a09d78bb5d89a345a80acd899445413','tx_mtosafisitepackage_tile',7,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',1,'',0,0,2147483647,0,0,''),
('8a594b57465e8a76202e1a34021ac90f','tt_content',42,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',23,'',0,0,2147483647,0,0,''),
('8bcbfe12fe5781dd8c106a20de0a3518','tt_content',57,'tx_mtosafisitepackage_landuses',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_landuse',4,'',0,0,2147483647,0,0,''),
('8c33249d3a9ac4708bfc8836b16a1c9b','tt_content',16,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('8c76b6040dad29bfd9ec75428ea6c28b','tt_content',48,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_slide',6,'',0,0,2147483647,0,0,''),
('8cf31030e8dcf8ec645c98f5bb9a1bfc','pages',65,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',21,'',0,0,2147483647,0,0,''),
('91055865169ba9d2b0e9094d3dfcffd4','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('92d50c408e8ee6009a404279825f6f70','sys_category',4,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',13,'categories',0,0,2147483647,0,1,''),
('9341a6b66fdb3f9d629df14955f28519','pages',55,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',8,'',0,0,2147483647,0,0,''),
('93ee32f2452fbd011bc1acd7e0e5b088','sys_file_reference',24,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('960e459a1c93d12d716e538716e03756','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_slide',3,'',0,0,2147483647,0,0,''),
('9863c1453317dd78d570a13ebff34eed','tt_content',49,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_tile',8,'',0,0,2147483647,0,0,''),
('9f3a8d10770ff46f06c3be7aa44e54c5','tx_news_domain_model_news',10,'tx_mtosafisitepackage_registration_link',0,0,2147483647,0,'','typolink','55fca047b228a52e981d533d3c4a7abc:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('a1530fc1de36b227f25a66bd93cd142b','tx_mtosafisitepackage_slide',6,'link',0,0,2147483647,0,'','typolink','8a78be47402a30f2deb4b3740a2b2737:0',0,0,'pages',14,'',0,0,2147483647,0,0,''),
('a17ad158348538e8c55cc866a8d440f0','tt_content',50,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('a26cc2e4f1d394f20c27cc3fccd65e97','tt_content',13,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('a3206db63bcb3c130f6b6f3874ded57d','tx_mtosafisitepackage_tile',8,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',2,'',0,0,2147483647,0,0,''),
('a337a79987cb444fbb435427ab45568c','sys_file_reference',18,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('a3cc86a75fef4d79b777c521a359bf5f','tt_content',29,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('a3eb334f7d65686a269621dda0200923','tt_content',53,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('a3ecdf84c21e9b588d9059eae5bd6f57','tt_content',49,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',4,0,'tx_mtosafisitepackage_tile',11,'',0,0,2147483647,0,0,''),
('a69870b2c147f2e9c49924c30bba8eb3','sys_file_reference',15,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',18,'',0,0,2147483647,0,0,''),
('a6e1ea9752dea7b790e7554d42ce890e','pages',42,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',14,'',0,0,2147483647,0,0,''),
('a9bb4d70a473b52d4a259986ad3214b7','tt_content',38,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',20,'',0,0,2147483647,0,0,''),
('ac0835d3bd7450f46d3ba28dcaf8880b','sys_file_reference',7,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',14,'',0,0,2147483647,0,0,''),
('ac3e2ceba954f0d2e5005157cb1c35c9','tt_content',3,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('ad6fb4471e613b89162ab5a6c3bf5107','tx_mtosafisitepackage_tile',8,'link',0,0,2147483647,0,'','typolink','82072b741a41ae8cfc84eca08a54cf21:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('ad7aab61aa9803e4740479abd67b9da0','tt_content',53,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'+254700000000'),
('ada04708dd2d0cf299a2ae336f223b77','sys_file_reference',25,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('ae350ae7d276348c54fa35dafcb6240f','pages',51,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('ae4674271593b4bb3e655ce12c85a1e9','tt_content',50,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',3,'',0,0,2147483647,0,0,''),
('afa5905f35bd9d3722f399de089a5339','tx_mtosafisitepackage_tile',9,'link',0,0,2147483647,0,'','typolink','a1118f7ffe161b828ca00898a92ea19a:0',0,0,'pages',8,'',0,0,2147483647,0,0,''),
('afefa0fa76526c23f9d9113de34379a2','pages',49,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',21,'',0,0,2147483647,0,0,''),
('b1089f60cddf4fa1a393572b789b3a7f','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',16,'',0,0,2147483647,0,0,''),
('b3762b32222c8c42bbaf2d9242765aa5','tt_content',37,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',19,'',0,0,2147483647,0,0,''),
('b38f28ed732223137346f2774cf22443','pages',37,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('b45c03698636f85bdd64f62aeebb4f5d','tt_content',46,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',36,'',0,0,2147483647,0,0,''),
('b6a3542cd92f76ef9be4ac0e10c602ea','tx_mtosafisitepackage_slide',6,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',26,'',0,0,2147483647,0,0,''),
('b702c03699882dc1ebee02a221717bc2','tx_mtosafisitepackage_tile',7,'link',0,0,2147483647,0,'','typolink','4e9cc3c99ff25205eee2109b7af6e33f:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('b776b7ba95937d942e0403f296a4fc56','tt_content',55,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('b78d1ef37162e947b421d75b51fcf1f0','tx_mtosafisitepackage_landuse',5,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_landuse',2,'',0,0,2147483647,0,0,''),
('b79ecad0203c4e91193ee6a838aac0f4','pages',65,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',29,'',0,0,2147483647,0,0,''),
('b8390ee0400ed62108c64b63dfc80330','sys_category',4,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',4,'categories',0,0,2147483647,0,1,''),
('b96dfec8962a424c335a15f010c09c64','tt_content',22,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('b9c912b6184055cadc4b89cb3b52ca24','tt_content',32,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',17,'',0,0,2147483647,0,0,''),
('b9f72a31f9f4dd8fe959bba70da7baba','tx_mtosafisitepackage_landuse',6,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_landuse',3,'',0,0,2147483647,0,0,''),
('bc577547d4c72172ebdc852ea3747576','tx_mtosafisitepackage_tile',3,'link',0,0,2147483647,0,'','typolink','5add86f047c9d524d9e9595219c10eb5:0',0,0,'pages',8,'',0,0,2147483647,0,0,''),
('bd0499781b8651f6a47dbdd267b552eb','tt_content',8,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('bd0f5a9e7f0b3c96b591b270f22d70dc','pages',60,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',24,'',0,0,2147483647,0,0,''),
('bd9363e3c7ceb56b08c8192e9541bfc5','tt_content',45,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('bdab9f5c733a1925a2082d96913bc1f8','tt_content',31,'image',0,0,2147483647,0,'','','',2,0,'sys_file_reference',15,'',0,0,2147483647,0,0,''),
('be76052f114545ca8c67ab42a26a0a2f','tx_mtosafisitepackage_tile',11,'link',0,0,2147483647,0,'','typolink','10ddfe6b32ba498d2226d832fe1608be:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('bf6cc0f81d2f48c8ad397ef2c3eee2b3','tx_mtosafisitepackage_slide',3,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('c038eefe78af750fd106e036d6e7bde9','tx_mtosafisitepackage_slide',2,'link',0,0,2147483647,0,'','typolink','e3c3bf6b59d1e8eefa995a17a3471d72:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('c14fd6ec1c7236724d685c3ae63e0ec4','tt_content',34,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',18,'',0,0,2147483647,0,0,''),
('c221fddc7849caccd29fc8127c5a1ecd','sys_file_reference',26,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('c225a5dc51fe62e7b785fe672031e07b','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('c2914756c599ce17e7cb0585c6f86165','tt_content',36,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'report@mtosafi.example'),
('c2fdbd9e0f046bc11d8c91708731e7b5','tt_content',54,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',35,'',0,0,2147483647,0,0,''),
('c45d81bd65ed780c1f18939526272e2a','sys_file_reference',20,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',23,'',0,0,2147483647,0,0,''),
('c54d6e1dbf8edbce22fb4011cf341c4a','pages',25,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('c56becdc4ea2ae3a8579c4d7b1d4aed1','tt_content',5,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',30,'',0,0,2147483647,0,0,''),
('c56e35759381f002b24def76c7066aa4','tx_mtosafisitepackage_tile',12,'link',0,0,2147483647,0,'','typolink','58d9b5f9d15a3df0ffd8c0dd55a1fb66:0',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('c66364f690722e7855542eee32488b3c','sys_file_reference',23,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('c68c3983c94cf534c1005c71c7652087','sys_file_reference',26,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('c95f34b89b8c54b41333d17af7d2d4fe','tx_mtosafisitepackage_slide',5,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',25,'',0,0,2147483647,0,0,''),
('ca34608fee503babde3755c56abc293f','tt_content',5,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('ca44fa1a4b459340d86774bbb0b4b45c','pages',38,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',5,'',0,0,2147483647,0,0,''),
('cc525b5738d587aa9038005247b67650','sys_category',2,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',2,'categories',0,0,2147483647,0,1,''),
('cc547b9336a89588b41b9aac515676d6','tt_content',24,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('ccf27ed75cce3fdca300151061714b0a','tt_content',26,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',11,'',0,0,2147483647,0,0,''),
('cd03540122f752ba28f3b2f778daed32','pages',24,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('d0c87340bc327a8355a748af77c43662','tt_content',6,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',2,0,'tx_mtosafisitepackage_tile',3,'',0,0,2147483647,0,0,''),
('d1ada2ce04cd7359419edb1b9d820c2e','tt_content',49,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',7,'',0,0,2147483647,0,0,''),
('d2ada98790a86b08a8930d6f5c005bb7','tx_kesearch_filters',1,'options',0,0,2147483647,0,'','','',1,0,'tx_kesearch_filteroptions',2,'',0,0,2147483647,0,0,''),
('d3114ff3fff65827b38d9b18145da0db','tt_content',57,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',56,'',0,0,2147483647,0,0,''),
('d3722f9232f47d2b03aef4cb5dcf809b','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('d55a1800d95931fd7a591f388a8f53ce','tt_content',44,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','1ea3783b1efa0d9299000582e728ea8a',0,0,'_STRING',0,'',0,0,2147483647,0,0,'EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml'),
('d7f7b5b9e364676846c011f4fa081ad1','tx_mtosafisitepackage_tile',9,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',3,'',0,0,2147483647,0,0,''),
('d942ec34be501dca1628a90417cc1965','tt_content',48,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_slide',5,'',0,0,2147483647,0,0,''),
('db8867c607e858ec4f20a4020f0ad862','pages',45,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('dc2945a033f8c6a0349084cc656d1881','pages',61,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',25,'',0,0,2147483647,0,0,''),
('de2495b6d52987671af4b4751b3cae67','pages',43,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',15,'',0,0,2147483647,0,0,''),
('de3954d092ea613d54be22888c93616f','tt_content',40,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',22,'',0,0,2147483647,0,0,''),
('dee089dabcf4ebd689b72971842c5a43','tt_content',47,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',35,'',0,0,2147483647,0,0,''),
('e034cc1227f32c5041fb3be2638c8deb','sys_file_reference',24,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('e05441bea25287ab7ef9a4d72341a937','tt_content',34,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@mtosafi.example'),
('e1a7ae2c7f50177ae5858b412bdff44c','tt_content',49,'tx_mtosafisitepackage_tiles',0,0,2147483647,0,'','','',5,0,'tx_mtosafisitepackage_tile',12,'',0,0,2147483647,0,0,''),
('e3188deab7686e755c6f63b406715d99','sys_category',1,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',12,'categories',0,0,2147483647,0,1,''),
('e347371ae65979f6857a13b1bbdc3e8a','sys_category',6,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',6,'categories',0,0,2147483647,0,1,''),
('e3595e870a8b402d8071edf4009d6ee9','tt_content',11,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('e43bdfa4a83a3c017d36d4cfa3a76444','tt_content',51,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',32,'',0,0,2147483647,0,0,''),
('e547b917eef4839386b80829d8da098a','tt_content',53,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',27,'',0,0,2147483647,0,0,''),
('e54c4b2d95c034daecb3f81498aa0289','tt_content',10,'pi_flexform',0,0,2147483647,0,'MAIN/lDEF/loadFlexformsFromOtherCE/vDEF/','','',0,0,'tt_content',9,'',0,0,2147483647,0,0,''),
('e5d5bafd27ede6e4bfb9f22c7119046d','sys_file_reference',13,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('e5db4317e6458f59a44dd32ed60180c6','tt_content',29,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('e6ae20ecdc91993983801ec95da4893d','sys_file_reference',27,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('e76f2a09e00d48f8ea87a15611c4ea38','pages',54,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('e7d3cbccbe2f5bc711724d68f6c28fc0','pages',56,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('e911be4b97f51ea843bcb77ec5e2fe82','sys_category',5,'items',0,0,2147483647,0,'','','',1,0,'tx_news_domain_model_news',9,'categories',0,0,2147483647,0,1,''),
('eb437033808db107b592ca03207f3bde','tx_news_domain_model_news',12,'tx_mtosafisitepackage_registration_link',0,0,2147483647,0,'','typolink','b89f1eea3897b9064c20c16343252f30:0',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('ec31780550bc19da7bf363c897d827f2','tt_content',56,'tx_mtosafisitepackage_landuses',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_landuse',1,'',0,0,2147483647,0,0,''),
('ec71812977d00695e80192e0bb397d9f','tx_mtosafisitepackage_slide',5,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_slide',2,'',0,0,2147483647,0,0,''),
('ef9e0e86be45638085e9662d9146b7af','sys_file_reference',19,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',22,'',0,0,2147483647,0,0,''),
('f0fada814d52cd634a394296574b2fdb','pages',62,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',18,'',0,0,2147483647,0,0,''),
('f28edf7f129f3dcd6cfeb403ba7a0e39','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('f352f231282e4969b3ea85c3f9b4608f','sys_category',3,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',3,'categories',0,0,2147483647,0,1,''),
('f51f305d611e34c56672a3994834aa11','tx_mtosafisitepackage_tile',12,'l10n_parent',0,0,2147483647,0,'','','',0,0,'tx_mtosafisitepackage_tile',6,'',0,0,2147483647,0,0,''),
('f5ed8c79cd8612b55a515f9f520c7ba6','tt_content',7,'tx_mtosafisitepackage_slides',0,0,2147483647,0,'','','',1,0,'tx_mtosafisitepackage_slide',2,'',0,0,2147483647,0,0,''),
('f6143939c533cf455cf78face1748d83','sys_file_reference',14,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',15,'',0,0,2147483647,0,0,''),
('f640e46359138786bad533a1dc6c9adb','tx_mtosafisitepackage_slide',2,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('f6a0bea04b5b567e9d6942672112d49c','tt_content',31,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',13,'',0,0,2147483647,0,0,''),
('f8fed83d71b0c8590aee92cac919b923','pages',44,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',16,'',0,0,2147483647,0,0,''),
('f9feddf408fc7808849da2413f760752','tt_content',20,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('fb534e0348cb0df4b46f46afc05eb5c6','tt_content',11,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',17,'',0,0,2147483647,0,0,''),
('fc193642beeafd12f02297477a258ef6','tx_mtosafisitepackage_slide',1,'link',0,0,2147483647,0,'','typolink','af39f1ff3aa52a5bc109a0ba6e0c4e9d:0',0,0,'pages',13,'',0,0,2147483647,0,0,''),
('fce6d6e68799136a3291b364b914834b','tx_kesearch_indexerconfig',1,'startingpoints_recursive',0,0,2147483647,0,'','','',0,0,'pages',1,'',0,0,2147483647,0,0,''),
('fd63ef5aba69ecdfe176ca3368250ab4','tt_content',55,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',36,'',0,0,2147483647,0,0,''),
('fed36fd2032652e9a28f9e21e509e64e','pages',28,'shortcut',0,0,2147483647,0,'','','',0,0,'pages',20,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\LanguagePackUpdateTimestampMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','mtosafi_sitepackage:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','mtosafi_sitepackage:Initialisation/dataImported','i:1;'),
(40,'extensionDataImport','news:ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','ke_search:ext_tables_static+adt.sql','s:0:\"\";'),
(48,'extensionDataImport','altcha:ext_tables_static+adt.sql','s:0:\"\";'),
(49,'extensionDataImport','eventnews:ext_tables_static+adt.sql','s:0:\"\";'),
(55,'tx_kesearch','lastRun','a:3:{s:9:\"startTime\";i:1795414401;s:7:\"endTime\";i:1795414401;s:12:\"indexingTime\";i:0;}');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_slides` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_landuses` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_minimum_rate` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mtosafisitepackage_interest` decimal(10,2) unsigned NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l18n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1795334294,1794119207,1,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\">TYPO3</a>.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(2,1,1795333042,1795332992,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Sidebar probe',0,'','','','<p>Rendered from the area sidebar.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(3,1,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'News',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(4,30,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'All news',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(5,31,1795336956,1795336956,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'News article',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(6,1,1795343750,1795343750,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_tiles',0,0,'','',0,'Popular services',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,6,0,0,0,0.00),
(7,1,1795344511,1795344511,0,0,0,0,'0',64,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_slider',0,0,'','',0,'Highlights',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,3,0,0,0.00),
(8,33,1795345582,1795345582,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'This page does not exist',100,'','','','<p>The page you are looking for may have moved, or the address may be mistyped.</p>\r\n<ul><li><a href=\"t3://page?uid=1\">Go to the home page</a></li><li><a href=\"t3://page?uid=16\">Search the site</a></li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(9,16,1795348009,1795348009,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',1,NULL,0,'ke_search_pi1',0,0,'','',0,'Filter results',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'34',0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"MAIN\">\n            <language index=\"lDEF\">\n                <field index=\"resultPage\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n                <field index=\"showTextInsteadOfResults\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"textForResults\">\n                    <value index=\"vDEF\">&lt;p&gt;Type what you are looking for into the search field at the top of the page.&lt;/p&gt;</value>\n                </field>\n                <field index=\"showNoResultsText\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"view\">\n            <language index=\"lDEF\">\n                <field index=\"highlightSword\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"resultChars\">\n                    <value index=\"vDEF\">200</value>\n                </field>\n                <field index=\"resultsNumeration\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showResultUrl\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showDate\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"images\">\n            <language index=\"lDEF\">\n                <field index=\"showTypeIcon\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showPageImages\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showNewsImages\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showFilePreview\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"pagebrowser\">\n            <language index=\"lDEF\">\n                <field index=\"pagebrowserOnTop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"pagebrowserAtBottom\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"resultsPerPage\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"maxPagesInPagebrowser\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"filter\">\n            <language index=\"lDEF\">\n                <field index=\"filters\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(10,16,1795348009,1795348009,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'ke_search_pi2',0,0,'','',0,'Search results',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"MAIN\">\n            <language index=\"lDEF\">\n                <field index=\"loadFlexformsFromOtherCE\">\n                    <value index=\"vDEF\">9</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(11,5,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Pay the municipality from wherever you are',0,'','','','<p>Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.</p>\r\n<p>Most of them can be paid by mobile money or by card in the <a href=\"t3://page?uid=17\">e-services portal</a>, at any time of day. The cash office in the municipal office is open on working days.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(12,5,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'menu_subpages',0,0,'','',0,'Payments and fees',0,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(13,6,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'How your land rates are calculated',0,'','','','<p>Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.</p>\r\n<p>Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(14,6,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Rates for 2026',0,'','','','Land use|Rate|Minimum per plot and year\nResidential|0.5 % of the rateable value|KES 1,500\nCommercial|1.2 % of the rateable value|KES 1,500\nAgricultural|0.2 % of the rateable value|KES 1,500',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(15,6,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'How to pay',0,'','','','<p>Pay by mobile money, by card in the <a href=\"t3://page?uid=17\">e-services portal</a>, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(16,7,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'One permit for your business',0,'','','','<p>Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.</p>\r\n<p>Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(17,7,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'What you need to apply',0,'','','','Your national ID or passport\nThe KRA PIN of the business\nThe plot number of the premises\nA description of the activity and the number of employees',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(18,8,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Parking in the town centre',0,'','','','<p>Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.</p>\r\n<p>Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.</p>',1,0,NULL,NULL,26,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(19,8,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Fees',0,'','','','Vehicle|Per day|Per month\nCar|KES 100|KES 2,000\nPick-up and van|KES 150|KES 3,000\nLorry|KES 300|KES 6,000\nMotorcycle (boda boda)|KES 30|KES 500',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(20,9,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Selling at the municipal markets',0,'','','','<p>Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.</p>\r\n<p>Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(21,9,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Fees',0,'','','','|Fee\nStall, per month|KES 1,200\nOpen space, per day|KES 50\nFish market, per day|KES 80',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(22,10,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Interest waived when you clear your arrears',0,'','','','<p>Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.</p>\r\n<p>Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.</p>',1,0,NULL,NULL,26,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(23,10,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'How it works',0,'','','','Ask for a statement of your arrears\nApply for the waiver with the statement\nPay the arrears without the interest within 30 days of the approval',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(24,11,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Health services close to home',0,'','','','<p>The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.</p>\r\n<p>For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(25,11,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Health centres',0,'','','','Health centre|Ward|Opening hours\nMto Safi Town|Central|Mon–Sat 7:00–19:00\nPwani|Beach|Mon–Fri 8:00–17:00\nKijiji|Upper River|Mon–Fri 8:00–17:00\nMnarani|Mnarani|Mon–Fri 8:00–17:00',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(26,12,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'A clean river for everyone',0,'','','','<p>Mto Safi means \"clean river\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(27,12,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Water connection',0,'','','','<p>To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.</p>\r\n<p>To report a leak or a burst pipe, call +254 700 000 001 at any time.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(28,12,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Waste collection',0,'','','','Town centre: Monday and Thursday\nBeach and Mnarani: Tuesday and Friday\nUpper River: Wednesday and Saturday',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(29,13,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Karibu Mto Safi',0,'','','','<p>White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.</p>\r\n<p>The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under <a href=\"t3://page?uid=7\">Single business permit</a>.</p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(30,13,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Places to visit',0,'','','','The dhow harbour and the fish market at sunrise\nThe mangrove boardwalk at the river mouth\nMto Safi beach and the coral garden\nThe old town with its carved doors',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(31,13,1795368020,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'image',0,0,'','',0,'Impressions of Mto Safi',0,'','','',NULL,4,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(32,14,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Have your say on the budget',0,'','','','<p>Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.</p>\r\n<p>You can also send your views in writing to the clerk until 15 May.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(33,14,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Forum dates',0,'','','','Ward|Date|Place\nCentral|4 May, 10:00|Municipal hall\nBeach|6 May, 10:00|Pwani primary school\nUpper River|8 May, 14:00|Kijiji social hall\nMnarani|11 May, 10:00|Mnarani chief\'s camp',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(34,15,1795369027,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"colPos\":\"\",\"imageorient\":\"\"}',0,0,0,0,'default',1,NULL,0,'textpic',0,0,'','',0,'Visit us',0,'','','','<p>Mto Safi Municipality<br />Municipal Office<br />Beach Road 1<br />P.O. Box 123, Mto Safi</p>\r\n<p>Phone: <a href=\"tel:+254700000000\">+254 700 000 000</a><br />Email: <a href=\"mailto:info@mtosafi.example\">info@mtosafi.example</a></p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(35,15,1795369027,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'table',0,0,'','',0,'Opening hours',0,'','','','Days|Hours\nMon–Thu|8:00–17:00\nFriday|8:00–13:00, 14:00–17:00\nSat, Sun|Closed',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(36,15,1795369027,1795368020,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Report a problem',0,'','','','<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\"mailto:report@mtosafi.example\">report@mtosafi.example</a>, and say where it is.</p>',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(37,17,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Your municipal services online',0,'','','','<p>In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.</p>\r\n<p>Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.</p>',1,0,NULL,NULL,0,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(38,18,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Example text',0,'','','','<p>This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.</p>\r\n<p>The design of this site targets WCAG 2.1 level AA.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(39,19,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Example text',0,'','','','<p>This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(40,20,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Ask for the information we hold',0,'','','','<p>Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.</p>\r\n<p>We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(41,20,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'bullets',0,0,'','',0,'Published without a request',0,'','','','The budget and the annual accounts\nThe valuation roll\nThe minutes of the municipal board\nTenders and the contracts awarded',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(42,21,1795368020,1795368020,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Doing business with the municipality',0,'','','','<p>The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.</p>',1,0,NULL,NULL,25,0,1,1,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(43,21,1795368020,1795368020,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'table',0,0,'','',0,'Open tenders',0,'','','','Number|Subject|Closes\nMSM/T/01/2026|Resurfacing of Market Street|12 June\nMSM/T/02/2026|Solar street lights, Beach ward|19 June\nMSM/T/03/2026|Waste collection vehicles (2)|26 June',0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,1,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(44,15,1795369027,1795369027,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Write to us',0,'','','The right department answers within five working days.',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(45,1,1795372569,1795372569,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'Events',100,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">asc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\">today</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">36</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">35</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">events</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"extraEntryEventNews\">\n            <language index=\"lDEF\">\n                <field index=\"settings.eventRestriction\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(46,35,1795372569,1795372569,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'Upcoming events',100,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">asc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\">today</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">36</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">eventsPage</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"extraEntryEventNews\">\n            <language index=\"lDEF\">\n                <field index=\"settings.eventRestriction\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(47,36,1795372569,1795372569,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'Event',100,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">35</value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">35</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,0,0.00),
(48,1,1795414399,1795414399,0,0,0,0,'',96,NULL,0,1,7,7,NULL,'{\"CType\":\"mtosafi_slider\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"crdate\":\"1795344511\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Highlights\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795344511\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"3\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'mtosafi_slider',0,0,'','',0,'Mambo muhimu',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,0,3,0,0,0.00),
(49,1,1795414399,1795414399,0,0,0,0,'',112,NULL,0,1,6,6,NULL,'{\"CType\":\"mtosafi_tiles\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"crdate\":\"1795343750\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Popular services\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795343750\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"6\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'mtosafi_tiles',0,0,'','',0,'Huduma maarufu',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,6,0,0,0,0.00),
(50,1,1795414399,1795414399,0,0,0,0,'',120,NULL,0,1,3,3,NULL,'{\"CType\":\"news_newsliststicky\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"crdate\":\"1795336956\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"News\",\"header_layout\":\"100\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">31<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">30<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">home<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795336956\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'Habari',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,'',0,0,'',1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">31</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,0,0,0,0,0.00),
(51,1,1795414399,1795414399,0,0,0,0,'',124,NULL,0,1,45,45,NULL,'{\"CType\":\"news_newsliststicky\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"crdate\":\"1795372569\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Events\",\"header_layout\":\"100\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"1\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">asc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">32<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\">today<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">36<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">35<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\">events<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"extraEntryEventNews\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.eventRestriction\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795372569\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'news_newsliststicky',0,0,'','',0,'Matukio',100,'','','',NULL,0,0,NULL,NULL,0,0,1,2,'',0,0,'',1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">asc</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">32</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\">today</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">36</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">35</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\">events</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"extraEntryEventNews\">\n            <language index=\"lDEF\">\n                <field index=\"settings.eventRestriction\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,0,0,0,0,0.00),
(52,15,1795414399,1795414399,0,0,0,0,'',192,NULL,0,1,44,44,NULL,'{\"CType\":\"form_formframework\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"crdate\":\"1795369027\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Write to us\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"1\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">EXT:mtosafi_sitepackage\\/Resources\\/Private\\/Forms\\/contact.form.yaml<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"The right department answers within five working days.\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795369027\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'Tuandikie',0,'','','Idara husika itakujibu ndani ya siku tano za kazi.',NULL,0,0,NULL,NULL,0,0,1,2,'',0,0,'',1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">EXT:mtosafi_sitepackage/Resources/Private/Forms/contact.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,0,0,0,0,0.00),
(53,15,1795414399,1795414399,0,0,0,0,'',384,NULL,0,1,34,34,NULL,'{\"CType\":\"textpic\",\"assets\":\"0\",\"bodytext\":\"<p>Mto Safi Municipality<br \\/>Municipal Office<br \\/>Beach Road 1<br \\/>P.O. Box 123, Mto Safi<\\/p>\\r\\n<p>Phone: <a href=\\\"tel:+254700000000\\\">+254 700 000 000<\\/a><br \\/>Email: <a href=\\\"mailto:info@mtosafi.example\\\">info@mtosafi.example<\\/a><\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"1\",\"cols\":\"0\",\"crdate\":\"1795368020\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Visit us\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"1\",\"image_zoom\":\"1\",\"imageborder\":\"0\",\"imagecols\":\"1\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795369027\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',1,NULL,0,'textpic',0,0,'','',0,'Tutembelee',0,'','','','<p>Manispaa ya Mto Safi<br />Ofisi ya Manispaa<br />Beach Road 1<br />S.L.P. 123, Mto Safi</p>\r\n<p>Simu: <a href=\"tel:+254700000000\">+254 700 000 000</a><br />Barua pepe: <a href=\"mailto:info@mtosafi.example\">info@mtosafi.example</a></p>',1,0,NULL,NULL,0,0,1,1,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,0,0,0,0,0.00),
(54,15,1795414399,1795414399,0,0,0,0,'',448,NULL,0,1,35,35,NULL,'{\"CType\":\"table\",\"assets\":\"0\",\"bodytext\":\"Days|Hours\\nMon\\u2013Thu|8:00\\u201317:00\\nFriday|8:00\\u201313:00, 14:00\\u201317:00\\nSat, Sun|Closed\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"1\",\"cols\":\"0\",\"crdate\":\"1795368020\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Opening hours\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"1\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"1\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795369027\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',1,NULL,0,'table',0,0,'','',0,'Saa za kazi',0,'','','','Siku|Saa\nJumatatu–Alhamisi|8:00–17:00\nIjumaa|8:00–13:00, 14:00–17:00\nJumamosi, Jumapili|Imefungwa',0,0,NULL,NULL,0,0,1,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,1,0,'',0,'','','',0,0,0,0,0,0,0,0.00),
(55,15,1795414399,1795414399,0,0,0,0,'',480,NULL,0,1,36,36,NULL,'{\"CType\":\"text\",\"assets\":\"0\",\"bodytext\":\"<p>A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to <a href=\\\"mailto:report@mtosafi.example\\\">report@mtosafi.example<\\/a>, and say where it is.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"1\",\"cols\":\"0\",\"crdate\":\"1795368020\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Report a problem\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"1\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795369027\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',1,NULL,0,'text',0,0,'','',0,'Ripoti tatizo',0,'','','','<p>Shimo barabarani, taa ya barabarani iliyoharibika, mfereji ulioziba au taka ambazo hazijakusanywa: piga simu +254 700 000 002 au andika kwa <a href=\"mailto:report@mtosafi.example\">report@mtosafi.example</a>, na useme ni wapi.</p>',0,0,NULL,NULL,0,0,1,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,0,0,0,0,0.00),
(56,6,1795531560,1795531560,0,0,0,0,'0',640,NULL,0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mtosafi_landrates',0,0,'','',0,'Land rates calculator',0,'','','',NULL,0,0,NULL,NULL,0,0,1,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,3,1500,1.00),
(57,6,1795531560,1795531560,0,0,0,0,'',704,NULL,0,1,56,56,NULL,'{\"CType\":\"mtosafi_landrates\",\"assets\":\"0\",\"bodytext\":\"\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"crdate\":\"1795531560\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"0\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Land rates calculator\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"1\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"\",\"imageorient\":\"0\",\"imagewidth\":\"\",\"layout\":\"0\",\"linkToTop\":\"0\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tstamp\":\"1795531560\",\"tx_impexp_origuid\":\"0\",\"tx_mtosafisitepackage_interest\":\"1.00\",\"tx_mtosafisitepackage_landuses\":\"3\",\"tx_mtosafisitepackage_minimum_rate\":\"1500\",\"tx_mtosafisitepackage_slides\":\"0\",\"tx_mtosafisitepackage_tiles\":\"0\",\"tx_news_related_news\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'mtosafi_landrates',0,0,'','',0,'Kikokotoo cha kodi ya ardhi',0,'','','',NULL,0,0,NULL,NULL,0,0,1,2,'',0,0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,0,0,3,1500,1.00);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_eventnews_domain_model_location`
--

DROP TABLE IF EXISTS `tx_eventnews_domain_model_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_eventnews_domain_model_location` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `address` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `municipality` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(16) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `lat` double DEFAULT 0,
  `lng` double DEFAULT 0,
  `link` varchar(255) NOT NULL DEFAULT '',
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_eventnews_domain_model_location`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_eventnews_domain_model_location` WRITE;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_location` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_eventnews_domain_model_organizer`
--

DROP TABLE IF EXISTS `tx_eventnews_domain_model_organizer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_eventnews_domain_model_organizer` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_eventnews_domain_model_organizer`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_eventnews_domain_model_organizer` WRITE;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_organizer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_eventnews_domain_model_organizer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_filteroptions`
--

DROP TABLE IF EXISTS `tx_kesearch_filteroptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_filteroptions` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `tag` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `automated_tagging` text DEFAULT NULL,
  `automated_tagging_exclude` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_filteroptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_filteroptions` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_filteroptions` DISABLE KEYS */;
INSERT INTO `tx_kesearch_filteroptions` VALUES
(1,34,1795348009,1795348009,0,0,'{\"hidden\":\"\",\"slug\":\"\",\"tag\":\"\",\"title\":\"\"}',0,0,256,NULL,0,'Services','service','services',NULL,NULL),
(2,34,1795348009,1795348009,0,0,'{\"hidden\":\"\",\"slug\":\"\",\"tag\":\"\",\"title\":\"\"}',0,0,512,NULL,0,'News','news','news',NULL,NULL);
/*!40000 ALTER TABLE `tx_kesearch_filteroptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_filters`
--

DROP TABLE IF EXISTS `tx_kesearch_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_filters` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `options` text DEFAULT NULL,
  `rendertype` varchar(90) NOT NULL DEFAULT '',
  `markAllCheckboxes` smallint(6) NOT NULL DEFAULT 0,
  `target_pid` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL DEFAULT 0,
  `shownumberofresults` smallint(6) NOT NULL DEFAULT 0,
  `alphabeticalsorting` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_filters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_filters` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_filters` DISABLE KEYS */;
INSERT INTO `tx_kesearch_filters` VALUES
(1,34,1795348009,1795348009,0,0,'{\"alphabeticalsorting\":\"\",\"amount\":\"\",\"hidden\":\"\",\"markAllCheckboxes\":\"\",\"options\":\"\",\"rendertype\":\"\",\"shownumberofresults\":\"\",\"target_pid\":\"\",\"title\":\"\"}',0,0,NULL,0,'Show only','1,2','checkbox',0,0,10,1,0);
/*!40000 ALTER TABLE `tx_kesearch_filters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_index`
--

DROP TABLE IF EXISTS `tx_kesearch_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_index` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `starttime` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `fe_group` varchar(100) NOT NULL DEFAULT '0',
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `targetpid` text DEFAULT NULL,
  `content` mediumtext DEFAULT NULL,
  `hidden_content` mediumtext DEFAULT NULL,
  `params` text DEFAULT NULL,
  `type` tinytext DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `sortdate` int(11) NOT NULL DEFAULT 0,
  `orig_uid` varchar(255) NOT NULL DEFAULT '0',
  `orig_pid` int(11) NOT NULL DEFAULT 0,
  `title` text DEFAULT NULL,
  `language` int(11) NOT NULL DEFAULT 0,
  `directory` tinytext DEFAULT NULL,
  `hash` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  FULLTEXT KEY `tags` (`tags`),
  FULLTEXT KEY `title` (`title`),
  FULLTEXT KEY `titlecontent` (`title`,`content`),
  FULLTEXT KEY `titlecontenthiddencontent` (`title`,`content`,`hidden_content`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_index`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_index` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_index` DISABLE KEYS */;
INSERT INTO `tx_kesearch_index` VALUES
(1,34,1795414401,1795348011,0,0,'0',0,'31','Sixty stalls, cold storage and clean water for traders and buyers.\nThe new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.\r\nTraders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.\r\nContact: Trade &amp; Markets Office, +254 700 000 010','','&tx_news_pi1[news]=1&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Trademarkets#,#syscat1#,#news#','Sixty stalls, cold storage and clean water for traders and buyers.',1793595600,'1',32,'New fish market opens at the jetty',0,'',''),
(2,34,1795414401,1795348011,0,0,'0',0,'31','Works run for six weeks. Matatus take the diversion via Market Street.\nBeach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.\r\nDuring the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.\r\nContact: Roads Department, +254 700 000 020','','&tx_news_pi1[news]=2&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Roadstransport#,#syscat2#,#news#','Works run for six weeks. Matatus take the diversion via Market Street.',1793077200,'2',32,'Beach Road resurfacing starts',0,'',''),
(3,34,1795414401,1795348011,0,0,'0',0,'31','Eye tests, vaccinations and screening, open to every resident.\nThe municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.\r\nOn offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.\r\nContact: Health Department, +254 700 000 030','','&tx_news_pi1[news]=3&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Health#,#syscat3#,#news#','Eye tests, vaccinations and screening, open to every resident.',1792472400,'3',32,'Free health camp in Ward 3',0,'',''),
(4,34,1795414401,1795348011,0,0,'0',0,'31','Residents can now pay land rates and business permits with their phone.\nFrom 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.\r\nPayment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.\r\nContact: Revenue Department, +254 700 000 040','','&tx_news_pi1[news]=4&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Revenuepayments#,#syscat4#,#news#','Residents can now pay land rates and business permits with their phone.',1791781200,'4',32,'Pay land rates by mobile money from January',0,'',''),
(5,34,1795414401,1795348011,0,0,'0',0,'31','Public participation forums in every ward in November.\nThe municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.\r\nA forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.\r\nContact: Planning Office, +254 700 000 050','','&tx_news_pi1[news]=5&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Publicparticipation#,#syscat5#,#news#','Public participation forums in every ward in November.',1790830800,'5',32,'Have your say on the budget 2027/28',0,'',''),
(6,34,1795414401,1795348011,0,0,'0',0,'31','The monthly beach clean-ups and the new waste collection paid off.\nMto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.\r\nThe mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.\r\nContact: Environment Department, +254 700 000 060','','&tx_news_pi1[news]=6&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Environment#,#syscat6#,#news#','The monthly beach clean-ups and the new waste collection paid off.',1789707600,'6',32,'Mto Safi named cleanest town on the coast',0,'',''),
(7,34,1795414401,1795348012,0,0,'0',0,'31','Three boreholes and twelve water kiosks serve 4,000 residents.\nThree new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.\r\nA water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.\r\nContact: Water &amp; Sanitation Department, +254 700 000 070','','&tx_news_pi1[news]=7&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Water#,#syscat7#,#news#','Three boreholes and twelve water kiosks serve 4,000 residents.',1788584400,'7',32,'New boreholes bring clean water to Ward 5',0,'',''),
(8,34,1795414401,1795368024,0,0,'',0,'5','Pay the municipality from wherever you are\n Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.\r\n Most of them can be paid by mobile money or by card in the e-services portal, at any time of day. The cash office in the municipal office is open on working days.\n\n\n\n','','','page','#service#','',1795368020,'5',1,'Revenue & payments',0,'',''),
(9,34,1795414401,1795368024,0,0,'',0,'6','How your land rates are calculated\n Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.\r\n Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.\n\n\n\nRates for 2026\nLand use Rate Minimum per plot and year\nResidential 0.5 % of the rateable value KES 1,500\nCommercial 1.2 % of the rateable value KES 1,500\nAgricultural 0.2 % of the rateable value KES 1,500\n\n\n\nHow to pay\n Pay by mobile money, by card in the e-services portal, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.\n\n\n\n','','','page','#service#','',1795368020,'6',5,'Land rates',0,'',''),
(10,34,1795414401,1795368024,0,0,'',0,'7','One permit for your business\n Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.\r\n Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.\n\n\n\nWhat you need to apply\nYour national ID or passport\nThe KRA PIN of the business\nThe plot number of the premises\nA description of the activity and the number of employees\n\n\n\n','','','page','#service#','',1795334294,'7',5,'Single business permit',0,'',''),
(11,34,1795414401,1795368024,0,0,'',0,'8','Parking in the town centre\n Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.\r\n Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.\n\n\n\nFees\nVehicle Per day Per month\nCar KES 100 KES 2,000\nPick-up and van KES 150 KES 3,000\nLorry KES 300 KES 6,000\nMotorcycle (boda boda) KES 30 KES 500\n\n\n\n','','','page','#service#','',1795334294,'8',5,'Parking fees',0,'',''),
(12,34,1795414401,1795368024,0,0,'',0,'9','Selling at the municipal markets\n Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.\r\n Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.\n\n\n\nFees\n Fee\nStall, per month KES 1,200\nOpen space, per day KES 50\nFish market, per day KES 80\n\n\n\n','','','page','#service#','',1795368020,'9',5,'Market fees',0,'',''),
(13,34,1795414401,1795368024,0,0,'',0,'10','Interest waived when you clear your arrears\n Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.\r\n Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.\n\n\n\nHow it works\nAsk for a statement of your arrears\nApply for the waiver with the statement\nPay the arrears without the interest within 30 days of the approval\n\n\n\n','','','page','#service#','',1795334294,'10',5,'Waiver of interest',0,'',''),
(14,34,1795414401,1795368024,0,0,'',0,'11','Health services close to home\n The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.\r\n For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.\n\n\n\nHealth centres\nHealth centre Ward Opening hours\nMto Safi Town Central Mon–Sat 7:00–19:00\nPwani Beach Mon–Fri 8:00–17:00\nKijiji Upper River Mon–Fri 8:00–17:00\nMnarani Mnarani Mon–Fri 8:00–17:00\n\n\n\n','','','page','#service#','',1795368020,'11',1,'Health',0,'',''),
(15,34,1795414401,1795368024,0,0,'',0,'12','A clean river for everyone\n Mto Safi means \"clean river\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.\n\n\n\nWater connection\n To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.\r\n To report a leak or a burst pipe, call +254 700 000 001 at any time.\n\n\n\nWaste collection\nTown centre: Monday and Thursday\nBeach and Mnarani: Tuesday and Friday\nUpper River: Wednesday and Saturday\n\n\n\n','','','page','#service#','',1795368020,'12',1,'Environment & water',0,'',''),
(16,34,1795414401,1795368024,0,0,'',0,'13','Karibu Mto Safi\n White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.\r\n The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under Single business permit.\n\n\n\nPlaces to visit\nThe dhow harbour and the fish market at sunrise\nThe mangrove boardwalk at the river mouth\nMto Safi beach and the coral garden\nThe old town with its carved doors\n\n\n\n','','','page','#service#','',1795368020,'13',1,'Trade & tourism',0,'',''),
(17,34,1795414401,1795368024,0,0,'',0,'14','Have your say on the budget\n Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.\r\n You can also send your views in writing to the clerk until 15 May.\n\n\n\nForum dates\nWard Date Place\nCentral 4 May, 10:00 Municipal hall\nBeach 6 May, 10:00 Pwani primary school\nUpper River 8 May, 14:00 Kijiji social hall\nMnarani 11 May, 10:00 Mnarani chief\'s camp\n\n\n\n','','','page','#service#','',1795368020,'14',1,'Public participation',0,'',''),
(18,34,1795414401,1795368024,0,0,'',0,'15','Visit us\n Mto Safi Municipality Municipal Office Beach Road 1 P.O. Box 123, Mto Safi\r\n Phone: +254 700 000 000 Email: info@mtosafi.example\n\n\n\nOpening hours\nDays Hours\nMon–Thu 8:00–17:00\nFriday 8:00–13:00, 14:00–17:00\nSat, Sun Closed\n\n\n\nReport a problem\n A pothole, a broken street light, a blocked drain or waste that was not collected: call +254 700 000 002 or write to report@mtosafi.example, and say where it is.\n\n\n\n','','','page','#service#','',1795369027,'15',1,'Contact',0,'',''),
(19,34,1795414401,1795368024,0,0,'',0,'17','Your municipal services online\n In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.\r\n Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.\n\n\n\n','','','page','#service#','',1795334294,'17',1,'E-services portal',0,'',''),
(20,34,1795414401,1795368024,0,0,'',0,'18','Example text\n This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.\r\n The design of this site targets WCAG 2.1 level AA.\n\n\n\n','','','page','#service#','',1795334294,'18',1,'Accessibility statement',0,'',''),
(21,34,1795414401,1795368024,0,0,'',0,'19','Example text\n This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.\n\n\n\n','','','page','#service#','',1795334294,'19',1,'Privacy policy',0,'',''),
(22,34,1795414401,1795368024,0,0,'',0,'20','Ask for the information we hold\n Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.\r\n We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.\n\n\n\nPublished without a request\nThe budget and the annual accounts\nThe valuation roll\nThe minutes of the municipal board\nTenders and the contracts awarded\n\n\n\n','','','page','#service#','',1795334294,'20',1,'Access to information',0,'',''),
(23,34,1795414401,1795368024,0,0,'',0,'21','Doing business with the municipality\n The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.\n\n\n\nOpen tenders\nNumber Subject Closes\nMSM/T/01/2026 Resurfacing of Market Street 12 June\nMSM/T/02/2026 Solar street lights, Beach ward 19 June\nMSM/T/03/2026 Waste collection vehicles (2) 26 June\n\n\n\n','','','page','#service#','',1795334294,'21',1,'Tenders',0,'',''),
(24,34,1795414401,1795372572,0,0,'0',0,'36','Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.\nResidents, schools and businesses clean the beach together. Gloves, bags and water are provided. The cleanest group wins a tree for its school.\r\nTime: 7:00–11:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=8&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Environment#,#syscat6#,#news#','Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.',1794715200,'8',32,'Beach clean-up day',0,'',''),
(25,34,1795414401,1795372572,0,0,'0',0,'36','Municipal hall, 10:00. Every resident may speak.\nEvery resident may speak. The forum is held in Kiswahili and English. Sign language interpretation is available on request until 15 November.\r\nTime: 10:00–13:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=9&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Publicparticipation#,#syscat5#,#news#','Municipal hall, 10:00. Every resident may speak.',1795330800,'9',32,'Public participation forum: budget 2027/28',0,'',''),
(26,34,1795414401,1795372572,0,0,'0',0,'36','Mto Safi Polytechnic, 9:00–15:00. Bring copies of your CV and certificates.\nEmployers from tourism, fishing, construction and IT present jobs and apprenticeships. Bring copies of your CV and certificates.\r\nTime: 9:00–15:00Cost: FreeRegistration: Recommended, at the Education Office','','&tx_news_pi1[news]=10&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Education#,#syscat8#,#news#','Mto Safi Polytechnic, 9:00–15:00. Bring copies of your CV and certificates.',1796450400,'10',32,'Youth job and skills fair',0,'',''),
(27,34,1795414401,1795372572,0,0,'0',0,'36','Municipal grounds, 9:00–14:00. Flag raising, speeches, school choirs and traditional dances.\nThe municipality celebrates Jamhuri Day with the flag raising, speeches, school choirs and traditional dances.\r\nTime: 9:00–14:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=11&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#news#','Municipal grounds, 9:00–14:00. Flag raising, speeches, school choirs and traditional dances.',1797055200,'11',32,'Jamhuri Day celebrations',0,'',''),
(28,34,1795414401,1795372572,0,0,'0',0,'36','Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.\nFood, crafts and music every evening before Christmas.\r\nTime: Every evening, 16:00–22:00Cost: Free entryRegistration: Traders apply for a stall at the Trade &amp; Markets Office until 1 December','','&tx_news_pi1[news]=12&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Trademarkets#,#syscat1#,#news#','Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.',1797685200,'12',32,'Festive market at the jetty',0,'',''),
(29,34,1795414401,1795372572,0,0,'0',0,'36','Monday to Friday, 9:00–15:00, at the cash office: help with your valuation notice and land rates.\nStaff of the Revenue Department help you read your valuation notice, calculate your land rates and set up payment by mobile money.\r\nTime: Monday to Friday, 9:00–15:00Cost: FreeRegistration: Not needed','','&tx_news_pi1[news]=13&tx_news_pi1[controller]=News&tx_news_pi1[action]=detail','news','#Revenuepayments#,#syscat4#,#news#','Monday to Friday, 9:00–15:00, at the cash office: help with your valuation notice and land rates.',1800252000,'13',32,'Land rates help desk',0,'',''),
(30,34,1795414401,1795414401,0,0,'',0,'5','Pay the municipality from wherever you are\n Land rates, permits, parking and market fees pay for the roads, the street lights, the markets and the waste collection of Mto Safi.\r\n Most of them can be paid by mobile money or by card in the e-services portal, at any time of day. The cash office in the municipal office is open on working days.\n\n\n\n','','','page','#service#','',1795368020,'5',1,'Mapato na malipo',1,'',''),
(31,34,1795414401,1795414401,0,0,'',0,'6','How your land rates are calculated\n Every owner of land in Mto Safi pays land rates once a year. The rate is a share of the rateable value of your plot. The valuation roll sets that value, and your valuation notice states it. The share depends on what the land is used for.\r\n Pay before 31 March. From April, interest of 1 % of the annual rate is added for every month the rate stays unpaid.\n\n\n\nRates for 2026\nLand use Rate Minimum per plot and year\nResidential 0.5 % of the rateable value KES 1,500\nCommercial 1.2 % of the rateable value KES 1,500\nAgricultural 0.2 % of the rateable value KES 1,500\n\n\n\nHow to pay\n Pay by mobile money, by card in the e-services portal, or at the cash office in the municipal office. Keep the receipt: it is your proof of payment.\n\n\n\n','','','page','#service#','',1795368020,'6',5,'Kodi ya ardhi',1,'',''),
(32,34,1795414401,1795414401,0,0,'',0,'7','One permit for your business\n Every business in Mto Safi, from a kiosk to a hotel, needs a single business permit. It replaces the separate trade, health and fire licences, and it is valid for the calendar year.\r\n Apply for a new permit or renew yours in the e-services portal. A renewal is due by 31 January.\n\n\n\nWhat you need to apply\nYour national ID or passport\nThe KRA PIN of the business\nThe plot number of the premises\nA description of the activity and the number of employees\n\n\n\n','','','page','#service#','',1795334294,'7',5,'Kibali cha biashara',1,'',''),
(33,34,1795414401,1795414401,0,0,'',0,'8','Parking in the town centre\n Parking in the town centre and on Beach Road is paid from Monday to Saturday, 7:00 to 18:00. Sundays and public holidays are free.\r\n Pay by mobile money with your number plate, or buy a monthly sticker in the e-services portal.\n\n\n\nFees\nVehicle Per day Per month\nCar KES 100 KES 2,000\nPick-up and van KES 150 KES 3,000\nLorry KES 300 KES 6,000\nMotorcycle (boda boda) KES 30 KES 500\n\n\n\n','','','page','#service#','',1795334294,'8',5,'Ada za maegesho',1,'',''),
(34,34,1795414401,1795414401,0,0,'',0,'9','Selling at the municipal markets\n Mto Safi runs three markets: the central market on Market Street, the fish market at the jetty and the Saturday market at the bus park.\r\n Traders with a stall pay a monthly fee, traders without one a daily fee at the gate. A free stall is allocated by the market office; ask there for the waiting list.\n\n\n\nFees\n Fee\nStall, per month KES 1,200\nOpen space, per day KES 50\nFish market, per day KES 80\n\n\n\n','','','page','#service#','',1795368020,'9',5,'Ada za soko',1,'',''),
(35,34,1795414401,1795414401,0,0,'',0,'10','Interest waived when you clear your arrears\n Owners who pay all their land rate arrears in one sum before 30 June can apply for a waiver of the interest on them.\r\n Apply at the cash office or in the e-services portal before you pay. The waiver is granted once per plot.\n\n\n\nHow it works\nAsk for a statement of your arrears\nApply for the waiver with the statement\nPay the arrears without the interest within 30 days of the approval\n\n\n\n','','','page','#service#','',1795334294,'10',5,'Msamaha wa riba',1,'',''),
(36,34,1795414401,1795414401,0,0,'',0,'11','Health services close to home\n The municipality runs four health centres and eleven dispensaries. Maternal care, vaccinations and the treatment of common illnesses are free in all of them.\r\n For an emergency, call 1199 or go to Mto Safi Sub-County Hospital, which is open day and night.\n\n\n\nHealth centres\nHealth centre Ward Opening hours\nMto Safi Town Central Mon–Sat 7:00–19:00\nPwani Beach Mon–Fri 8:00–17:00\nKijiji Upper River Mon–Fri 8:00–17:00\nMnarani Mnarani Mon–Fri 8:00–17:00\n\n\n\n','','','page','#service#','',1795368020,'11',1,'Afya',1,'',''),
(37,34,1795414401,1795414401,0,0,'',0,'12','A clean river for everyone\n Mto Safi means \"clean river\", and we work to keep it that way: with a sewage plant that serves the town centre, waste collection twice a week and clean-up days in every ward.\n\n\n\nWater connection\n To connect a plot to the water supply, apply in the e-services portal with the plot number. A connection to a house on a plot along a main pipe costs KES 6,500 and takes about three weeks.\r\n To report a leak or a burst pipe, call +254 700 000 001 at any time.\n\n\n\nWaste collection\nTown centre: Monday and Thursday\nBeach and Mnarani: Tuesday and Friday\nUpper River: Wednesday and Saturday\n\n\n\n','','','page','#service#','',1795368020,'12',1,'Mazingira na maji',1,'',''),
(38,34,1795414401,1795414401,0,0,'',0,'13','Karibu Mto Safi\n White beaches, a quiet river mouth and the old dhow harbour bring visitors to Mto Safi all year round. Tourism and the fish trade are what the town lives from.\r\n The tourist information at the jetty helps with accommodation, boat trips and guides. Businesses that want to start here find the permits they need under Single business permit.\n\n\n\nPlaces to visit\nThe dhow harbour and the fish market at sunrise\nThe mangrove boardwalk at the river mouth\nMto Safi beach and the coral garden\nThe old town with its carved doors\n\n\n\n','','','page','#service#','',1795368020,'13',1,'Biashara na utalii',1,'',''),
(39,34,1795414401,1795414401,0,0,'',0,'14','Have your say on the budget\n Before the county assembly decides on the budget, the municipality presents it in every ward. Come to a forum, ask questions and tell us what your ward needs most.\r\n You can also send your views in writing to the clerk until 15 May.\n\n\n\nForum dates\nWard Date Place\nCentral 4 May, 10:00 Municipal hall\nBeach 6 May, 10:00 Pwani primary school\nUpper River 8 May, 14:00 Kijiji social hall\nMnarani 11 May, 10:00 Mnarani chief\'s camp\n\n\n\n','','','page','#service#','',1795368020,'14',1,'Ushiriki wa umma',1,'',''),
(40,34,1795414401,1795414401,0,0,'',0,'15','Tutembelee\n Manispaa ya Mto Safi Ofisi ya Manispaa Beach Road 1 S.L.P. 123, Mto Safi\r\n Simu: +254 700 000 000 Barua pepe: info@mtosafi.example\n\n\n\nSaa za kazi\nSiku Saa\nJumatatu–Alhamisi 8:00–17:00\nIjumaa 8:00–13:00, 14:00–17:00\nJumamosi, Jumapili Imefungwa\n\n\n\nRipoti tatizo\n Shimo barabarani, taa ya barabarani iliyoharibika, mfereji ulioziba au taka ambazo hazijakusanywa: piga simu +254 700 000 002 au andika kwa report@mtosafi.example, na useme ni wapi.\n\n\n\n','','','page','#service#','',1795369027,'15',1,'Wasiliana nasi',1,'',''),
(41,34,1795414401,1795414401,0,0,'',0,'17','Your municipal services online\n In the e-services portal you pay land rates, permits and fees, apply for a water connection and download your receipts, at any time of day.\r\n Log in with your eCitizen account. You do not have one yet? Register at eCitizen first; it takes five minutes.\n\n\n\n','','','page','#service#','',1795334294,'17',1,'Huduma za mtandaoni',1,'',''),
(42,34,1795414401,1795414401,0,0,'',0,'18','Example text\n This is placeholder text for the demo site. The municipality writes its own accessibility statement here: the standard the site aims at, what is not accessible yet and how visitors report a barrier.\r\n The design of this site targets WCAG 2.1 level AA.\n\n\n\n','','','page','#service#','',1795334294,'18',1,'Taarifa ya ufikivu',1,'',''),
(43,34,1795414401,1795414401,0,0,'',0,'19','Example text\n This is placeholder text for the demo site. The municipality writes its own privacy policy here: which personal data the site and its forms collect, what for, how long it is kept and whom visitors contact about it.\n\n\n\n','','','page','#service#','',1795334294,'19',1,'Sera ya faragha',1,'',''),
(44,34,1795414401,1795414401,0,0,'',0,'20','Ask for the information we hold\n Every citizen has the right to the information the municipality holds. Ask for a document in writing, by email or at the front desk of the municipal office, and say as precisely as you can what you are looking for.\r\n We answer within 21 days. Copies cost KES 10 per page; electronic copies are free.\n\n\n\nPublished without a request\nThe budget and the annual accounts\nThe valuation roll\nThe minutes of the municipal board\nTenders and the contracts awarded\n\n\n\n','','','page','#service#','',1795334294,'20',1,'Upatikanaji wa taarifa',1,'',''),
(45,34,1795414401,1795414401,0,0,'',0,'21','Doing business with the municipality\n The municipality publishes every tender above KES 500,000 here and on the national procurement portal. Bids are submitted in a sealed envelope at the procurement office before the closing date.\n\n\n\nOpen tenders\nNumber Subject Closes\nMSM/T/01/2026 Resurfacing of Market Street 12 June\nMSM/T/02/2026 Solar street lights, Beach ward 19 June\nMSM/T/03/2026 Waste collection vehicles (2) 26 June\n\n\n\n','','','page','#service#','',1795334294,'21',1,'Zabuni',1,'','');
/*!40000 ALTER TABLE `tx_kesearch_index` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_indexerconfig`
--

DROP TABLE IF EXISTS `tx_kesearch_indexerconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_indexerconfig` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `storagepid` text DEFAULT NULL,
  `targetpid` text DEFAULT NULL,
  `startingpoints_recursive` text DEFAULT NULL,
  `single_pages` text DEFAULT NULL,
  `sysfolder` text DEFAULT NULL,
  `index_content_with_restrictions` text DEFAULT NULL,
  `type` varchar(90) NOT NULL DEFAULT '',
  `index_news_category_mode` smallint(6) NOT NULL DEFAULT 0,
  `index_news_category_selection` text DEFAULT NULL,
  `index_extnews_category_selection` text DEFAULT NULL,
  `index_news_archived` smallint(6) NOT NULL DEFAULT 0,
  `index_news_useHRDatesSingle` smallint(6) NOT NULL DEFAULT 0,
  `index_news_useHRDatesSingleWithoutDay` smallint(6) NOT NULL DEFAULT 0,
  `index_news_files_mode` smallint(6) NOT NULL DEFAULT 0,
  `index_use_page_tags` smallint(6) NOT NULL DEFAULT 0,
  `index_use_page_tags_for_files` smallint(6) NOT NULL DEFAULT 0,
  `index_page_doctypes` varchar(255) NOT NULL DEFAULT '',
  `directories` text DEFAULT NULL,
  `fileext` tinytext DEFAULT NULL,
  `content_fields` text DEFAULT NULL,
  `page_fields` text DEFAULT NULL,
  `page_fields_hidden` text DEFAULT NULL,
  `file_reference_fields` text DEFAULT NULL,
  `file_collections` text DEFAULT NULL,
  `filteroption` int(11) NOT NULL DEFAULT 0,
  `fal_storage` int(11) NOT NULL DEFAULT 0,
  `contenttypes` text DEFAULT NULL,
  `additional_tables` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_indexerconfig`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_indexerconfig` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_indexerconfig` DISABLE KEYS */;
INSERT INTO `tx_kesearch_indexerconfig` VALUES
(1,34,1795348009,1795348009,0,0,0,'Pages','34',NULL,'1',NULL,NULL,'no','page',1,NULL,NULL,0,0,0,0,0,0,'1',NULL,'pdf,ppt,doc,xls,docx,xlsx,pptx','bodytext,subheader,header_link','','','media',NULL,0,0,'text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline','[accordion]\ntable = tx_bootstrappackage_accordion_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[tab]\ntable = tx_bootstrappackage_tab_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[carousel]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_fullscreen]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_small]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[icon_group]\ntable = tx_bootstrappackage_icon_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\n\n[card_group]\ntable = tx_bootstrappackage_card_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\nfields[] = link_title\n\n[timeline]\ntable = tx_bootstrappackage_timeline_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext'),
(2,34,1795348009,1795348009,0,0,0,'News','34','31','32',NULL,NULL,'no','news',1,NULL,NULL,0,0,0,0,0,0,'1',NULL,'pdf,ppt,doc,xls,docx,xlsx,pptx','bodytext,subheader,header_link','','','media',NULL,0,0,'text,textmedia,textpic,bullets,table,html,header,uploads,shortcut,accordion,tab,carousel,carousel_fullscreen,carousel_small,icon_group,card_group,timeline','[accordion]\ntable = tx_bootstrappackage_accordion_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[tab]\ntable = tx_bootstrappackage_tab_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext\n\n[carousel]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_fullscreen]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[carousel_small]\ntable = tx_bootstrappackage_carousel_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = nav_title\nfields[] = link\n\n[icon_group]\ntable = tx_bootstrappackage_icon_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\n\n[card_group]\ntable = tx_bootstrappackage_card_group_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = subheader\nfields[] = bodytext\nfields[] = link\nfields[] = link_title\n\n[timeline]\ntable = tx_bootstrappackage_timeline_item\nreferenceFieldName = tt_content\nfields[] = header\nfields[] = bodytext');
/*!40000 ALTER TABLE `tx_kesearch_indexerconfig` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_stat_search`
--

DROP TABLE IF EXISTS `tx_kesearch_stat_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_stat_search` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `searchphrase` text DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `hits` int(11) NOT NULL DEFAULT 0,
  `tagsagainst` text DEFAULT NULL,
  `language` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_stat_search`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_stat_search` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_stat_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_kesearch_stat_search` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_kesearch_stat_word`
--

DROP TABLE IF EXISTS `tx_kesearch_stat_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_kesearch_stat_word` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `word` text DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `pageid` int(11) NOT NULL DEFAULT 0,
  `resultsfound` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_kesearch_stat_word`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_kesearch_stat_word` WRITE;
/*!40000 ALTER TABLE `tx_kesearch_stat_word` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_kesearch_stat_word` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_landuse`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_landuse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_landuse` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(100) NOT NULL DEFAULT '',
  `percent` decimal(10,2) unsigned NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_landuse`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_landuse` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_landuse` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_landuse` VALUES
(1,6,1795531560,1795531560,0,0,1,0,0,0,NULL,'',0,0,0,0,56,'Residential',0.50),
(2,6,1795531560,1795531560,0,0,514,0,0,0,NULL,'',0,0,0,0,56,'Commercial',1.20),
(3,6,1795531560,1795531560,0,0,515,0,0,0,NULL,'',0,0,0,0,56,'Agricultural',0.20),
(4,6,1795531560,1795531560,0,0,1,1,1,1,NULL,'{\"hidden\":\"0\",\"label\":\"Residential\",\"parent\":\"56\",\"percent\":\"0.50\"}',0,0,0,0,57,'Makazi',0.50),
(5,6,1795531560,1795531560,0,0,2,1,2,2,NULL,'{\"hidden\":\"0\",\"label\":\"Commercial\",\"parent\":\"56\",\"percent\":\"1.20\"}',0,0,0,0,57,'Biashara',1.20),
(6,6,1795531560,1795531560,0,0,3,1,3,3,NULL,'{\"hidden\":\"0\",\"label\":\"Agricultural\",\"parent\":\"56\",\"percent\":\"0.20\"}',0,0,0,0,57,'Kilimo',0.20);
/*!40000 ALTER TABLE `tx_mtosafisitepackage_landuse` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_slide`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_slide` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(100) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  `link` text NOT NULL DEFAULT '',
  `link_label` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_slide`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_slide` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_slide` VALUES
(1,1,1795344511,1795344511,0,0,1,0,0,0,NULL,'',0,0,0,0,7,1,'Karibu Mto Safi','White beaches, a clean river and a municipality that serves you online, day and night.','t3://page?uid=13','Discover Mto Safi'),
(2,1,1795344511,1795344511,0,0,514,0,0,0,NULL,'',0,0,0,0,7,1,'Pay your land rates by mobile money','Calculate what you owe and pay before 31 March to avoid interest.','t3://page?uid=6','Calculate land rates'),
(3,1,1795344511,1795344511,0,0,515,0,0,0,NULL,'',0,0,0,0,7,1,'Have your say on the budget','Join the public participation forums in every ward this month.','t3://page?uid=14','See the forum dates'),
(4,1,1795414399,1795414399,0,0,1,1,1,1,NULL,'{\"hidden\":\"0\",\"image\":\"1\",\"link\":\"t3:\\/\\/page?uid=13\",\"link_label\":\"Discover Mto Safi\",\"parent\":\"7\",\"text\":\"White beaches, a clean river and a municipality that serves you online, day and night.\",\"title\":\"Karibu Mto Safi\"}',0,0,0,0,48,1,'Karibu Mto Safi','Fukwe nyeupe, mto safi na manispaa inayokuhudumia mtandaoni, mchana na usiku.','t3://page?uid=13','Gundua Mto Safi'),
(5,1,1795414399,1795414399,0,0,2,1,2,2,NULL,'{\"hidden\":\"0\",\"image\":\"1\",\"link\":\"t3:\\/\\/page?uid=6\",\"link_label\":\"Calculate land rates\",\"parent\":\"7\",\"text\":\"Calculate what you owe and pay before 31 March to avoid interest.\",\"title\":\"Pay your land rates by mobile money\"}',0,0,0,0,48,1,'Lipa kodi ya ardhi kwa pesa za simu','Kokotoa deni lako na ulipe kabla ya tarehe 31 Machi ili kuepuka riba.','t3://page?uid=6','Kokotoa kodi ya ardhi'),
(6,1,1795414399,1795414399,0,0,3,1,3,3,NULL,'{\"hidden\":\"0\",\"image\":\"1\",\"link\":\"t3:\\/\\/page?uid=14\",\"link_label\":\"See the forum dates\",\"parent\":\"7\",\"text\":\"Join the public participation forums in every ward this month.\",\"title\":\"Have your say on the budget\"}',0,0,0,0,48,1,'Toa maoni yako kuhusu bajeti','Shiriki katika mabaraza ya umma katika kila wadi mwezi huu.','t3://page?uid=14','Tazama tarehe za mabaraza');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_slide` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_mtosafisitepackage_tile`
--

DROP TABLE IF EXISTS `tx_mtosafisitepackage_tile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mtosafisitepackage_tile` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `icon` varchar(8) NOT NULL DEFAULT '',
  `label` varchar(100) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mtosafisitepackage_tile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_mtosafisitepackage_tile` WRITE;
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` DISABLE KEYS */;
INSERT INTO `tx_mtosafisitepackage_tile` VALUES
(1,1,1795343750,1795343750,0,0,1,0,0,0,NULL,'',0,0,0,0,6,'🏪','Single business permit','t3://page?uid=7'),
(2,1,1795343750,1795343750,0,0,514,0,0,0,NULL,'',0,0,0,0,6,'🏡','Land rates','t3://page?uid=6'),
(3,1,1795343750,1795343750,0,0,515,0,0,0,NULL,'',0,0,0,0,6,'🅿️','Parking fees','t3://page?uid=8'),
(4,1,1795343750,1795343750,0,0,516,0,0,0,NULL,'',0,0,0,0,6,'💧','Water connection','t3://page?uid=12'),
(5,1,1795343750,1795343750,0,0,517,0,0,0,NULL,'',0,0,0,0,6,'🧺','Market stalls','t3://page?uid=9'),
(6,1,1795343750,1795343750,0,0,518,0,0,0,NULL,'',0,0,0,0,6,'📣','Report a problem','t3://page?uid=15'),
(7,1,1795414399,1795414399,0,0,1,1,1,1,NULL,'{\"hidden\":\"0\",\"icon\":\"\\ud83c\\udfea\",\"label\":\"Single business permit\",\"link\":\"t3:\\/\\/page?uid=7\",\"parent\":\"6\"}',0,0,0,0,49,'🏪','Kibali cha biashara','t3://page?uid=7'),
(8,1,1795414399,1795414399,0,0,2,1,2,2,NULL,'{\"hidden\":\"0\",\"icon\":\"\\ud83c\\udfe1\",\"label\":\"Land rates\",\"link\":\"t3:\\/\\/page?uid=6\",\"parent\":\"6\"}',0,0,0,0,49,'🏡','Kodi ya ardhi','t3://page?uid=6'),
(9,1,1795414399,1795414399,0,0,3,1,3,3,NULL,'{\"hidden\":\"0\",\"icon\":\"\\ud83c\\udd7f\\ufe0f\",\"label\":\"Parking fees\",\"link\":\"t3:\\/\\/page?uid=8\",\"parent\":\"6\"}',0,0,0,0,49,'🅿️','Ada za maegesho','t3://page?uid=8'),
(10,1,1795414399,1795414399,0,0,4,1,4,4,NULL,'{\"hidden\":\"0\",\"icon\":\"\\ud83d\\udca7\",\"label\":\"Water connection\",\"link\":\"t3:\\/\\/page?uid=12\",\"parent\":\"6\"}',0,0,0,0,49,'💧','Kuunganishiwa maji','t3://page?uid=12'),
(11,1,1795414399,1795414399,0,0,5,1,5,5,NULL,'{\"hidden\":\"0\",\"icon\":\"\\ud83e\\uddfa\",\"label\":\"Market stalls\",\"link\":\"t3:\\/\\/page?uid=9\",\"parent\":\"6\"}',0,0,0,0,49,'🧺','Vibanda vya soko','t3://page?uid=9'),
(12,1,1795414399,1795414399,0,0,6,1,6,6,NULL,'{\"hidden\":\"0\",\"icon\":\"\\ud83d\\udce3\",\"label\":\"Report a problem\",\"link\":\"t3:\\/\\/page?uid=15\",\"parent\":\"6\"}',0,0,0,0,49,'📣','Ripoti tatizo','t3://page?uid=15');
/*!40000 ALTER TABLE `tx_mtosafisitepackage_tile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `is_event` smallint(5) unsigned NOT NULL DEFAULT 0,
  `full_day` smallint(5) unsigned NOT NULL DEFAULT 0,
  `event_end` int(10) unsigned DEFAULT 0,
  `organizer` int(10) unsigned DEFAULT 0,
  `location` int(10) unsigned DEFAULT 0,
  `organizer_simple` varchar(255) NOT NULL DEFAULT '',
  `location_simple` varchar(255) NOT NULL DEFAULT '',
  `tx_mtosafisitepackage_registration_link` text NOT NULL DEFAULT '',
  `tx_mtosafisitepackage_registration_label` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(NULL,1,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New fish market opens at the jetty','Sixty stalls, cold storage and clean water for traders and buyers.','<p>The new fish market at the jetty opened on Monday. It has sixty stalls, a cold room for the night’s catch and running water at every stall.</p>\r\n<p>Traders who sold at the old market keep their stall number. New traders apply for a stall at the trade office in the municipal office. The market opens daily from 5:00 to 18:00.</p>\r\n<p><strong>Contact:</strong> Trade &amp; Markets Office, +254 700 000 010</p>',1793595600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-fish-market-opens-at-the-jetty',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,2,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Beach Road resurfacing starts','Works run for six weeks. Matatus take the diversion via Market Street.','<p>Beach Road between the roundabout and the public beach gets a new surface and drainage. The works start on 3 November and run for about six weeks.</p>\r\n<p>During the works, matatus and lorries take the diversion via Market Street. Pedestrians and bicycles can pass at all times. Shops along Beach Road stay open.</p>\r\n<p><strong>Contact:</strong> Roads Department, +254 700 000 020</p>',1793077200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'beach-road-resurfacing-starts',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,3,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Free health camp in Ward 3','Eye tests, vaccinations and screening, open to every resident.','<p>The municipality and the Ward 3 health centre hold a free health camp on 25 and 26 October at Ward 3 Primary School, from 8:00 to 16:00.</p>\r\n<p>On offer: eye tests, blood pressure and diabetes screening, and vaccinations for children. Bring your health card if you have one. No appointment is needed.</p>\r\n<p><strong>Contact:</strong> Health Department, +254 700 000 030</p>',1792472400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'free-health-camp-in-ward-3',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,4,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Pay land rates by mobile money from January','Residents can now pay land rates and business permits with their phone.','<p>From 1 January 2027, residents pay land rates, the single business permit and market fees by mobile money. The receipt arrives by SMS and counts as proof of payment.</p>\r\n<p>Payment at the cash office in the municipal office stays possible. The land rates calculator on our website shows what you owe before you pay.</p>\r\n<p><strong>Contact:</strong> Revenue Department, +254 700 000 040</p>',1791781200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pay-land-rates-by-mobile-money-from-january',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,5,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Have your say on the budget 2027/28','Public participation forums in every ward in November.','<p>The municipality prepares its budget for 2027/28 and asks residents what matters most to them: roads, water, markets, health or schools.</p>\r\n<p>A forum takes place in every ward in November. The main forum is on 22 November in the municipal hall. Residents who cannot attend send their views in writing to the municipal office by 30 November.</p>\r\n<p><strong>Contact:</strong> Planning Office, +254 700 000 050</p>',1790830800,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'have-your-say-on-the-budget-2027-28',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,6,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Mto Safi named cleanest town on the coast','The monthly beach clean-ups and the new waste collection paid off.','<p>Mto Safi has won this year’s Clean Coast Town Award. The jury praised the monthly beach clean-ups by residents and schools, and the new waste collection in all wards.</p>\r\n<p>The mayor thanked every volunteer and announced that the clean-ups continue every third Saturday of the month.</p>\r\n<p><strong>Contact:</strong> Environment Department, +254 700 000 060</p>',1789707600,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'mto-safi-named-cleanest-town-on-the-coast',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,7,32,1795336956,1795336956,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'New boreholes bring clean water to Ward 5','Three boreholes and twelve water kiosks serve 4,000 residents.','<p>Three new boreholes in Ward 5 now supply twelve water kiosks. About 4,000 residents no longer have to walk to the river for water.</p>\r\n<p>A water kiosk is open from 6:00 to 19:00. A 20-litre container costs KES 5.</p>\r\n<p><strong>Contact:</strong> Water &amp; Sanitation Department, +254 700 000 070</p>',1788584400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'new-boreholes-bring-clean-water-to-ward-5',NULL,'',0.5,'','',0,0,0,0,0,'','','',''),
(NULL,8,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Beach clean-up day','Meet at the lifeguard tower on the public beach, 7:00. Gloves, bags and water provided.','<p>Residents, schools and businesses clean the beach together. Gloves, bags and water are provided. The cleanest group wins a tree for its school.</p>\r\n<p><strong>Time:</strong> 7:00–11:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1794715200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'beach-clean-up-day',NULL,'',0.5,'','',1,0,1794729600,0,0,'','Public beach, meeting point at the lifeguard tower','',''),
(NULL,9,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Public participation forum: budget 2027/28','Municipal hall, 10:00. Every resident may speak.','<p>Every resident may speak. The forum is held in Kiswahili and English. Sign language interpretation is available on request until 15 November.</p>\r\n<p><strong>Time:</strong> 10:00–13:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1795330800,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'public-participation-forum-budget-2027-28',NULL,'',0.5,'','',1,0,1795341600,0,0,'','Municipal hall, Beach Road 1','',''),
(NULL,10,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Youth job and skills fair','Mto Safi Polytechnic, 9:00–15:00. Bring copies of your CV and certificates.','<p>Employers from tourism, fishing, construction and IT present jobs and apprenticeships. Bring copies of your CV and certificates.</p>\r\n<p><strong>Time:</strong> 9:00–15:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Recommended, at the Education Office</p>',1796450400,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'youth-job-and-skills-fair',NULL,'',0.5,'','',1,0,1796472000,0,0,'','Mto Safi Polytechnic','t3://page?uid=15',''),
(NULL,11,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Jamhuri Day celebrations','Municipal grounds, 9:00–14:00. Flag raising, speeches, school choirs and traditional dances.','<p>The municipality celebrates Jamhuri Day with the flag raising, speeches, school choirs and traditional dances.</p>\r\n<p><strong>Time:</strong> 9:00–14:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1797055200,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'jamhuri-day-celebrations',NULL,'',0.5,'','',1,0,1797073200,0,0,'','Municipal grounds','',''),
(NULL,12,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Festive market at the jetty','Every evening from 16:00 to 22:00 at the jetty: food, crafts and music.','<p>Food, crafts and music every evening before Christmas.</p>\r\n<p><strong>Time:</strong> Every evening, 16:00–22:00<br /><strong>Cost:</strong> Free entry<br /><strong>Registration:</strong> Traders apply for a stall at the Trade &amp; Markets Office until 1 December</p>',1797685200,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'festive-market-at-the-jetty',NULL,'',0.5,'','',1,0,1798138800,0,0,'','Jetty and fish market','t3://page?uid=9','Apply for a stall'),
(NULL,13,32,1795372569,1795372569,0,0,0,0,'0',0,0,0,0,NULL,0,'',0,0,0,0,0,'Land rates help desk','Monday to Friday, 9:00–15:00, at the cash office: help with your valuation notice and land rates.','<p>Staff of the Revenue Department help you read your valuation notice, calculate your land rates and set up payment by mobile money.</p>\r\n<p><strong>Time:</strong> Monday to Friday, 9:00–15:00<br /><strong>Cost:</strong> Free<br /><strong>Registration:</strong> Not needed</p>',1800252000,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'land-rates-help-desk',NULL,'',0.5,'','',1,0,1806494400,0,0,'','Municipal office, cash office','','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_typo3altcha_domain_model_challenge`
--

DROP TABLE IF EXISTS `tx_typo3altcha_domain_model_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_typo3altcha_domain_model_challenge` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `challenge` varchar(1024) NOT NULL DEFAULT '',
  `is_solved` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_typo3altcha_domain_model_challenge`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_typo3altcha_domain_model_challenge` WRITE;
/*!40000 ALTER TABLE `tx_typo3altcha_domain_model_challenge` DISABLE KEYS */;
INSERT INTO `tx_typo3altcha_domain_model_challenge` VALUES
(1,0,1795369783,1795369783,0,'b14ee5adc9e3d8ee18dfd97186b9c47b',0),
(2,0,1795369826,1795369826,0,'3a8d6f989a1b179c9f9df3f63bddd99d',0),
(3,0,1795369830,1795369830,0,'4a35ec6b33d5b8fdb4a3f0b8bea722e2',1),
(4,0,1795369857,1795369856,0,'11e10a2ef2c615e04eabd25394088573',1),
(5,0,1795369996,1795369995,0,'80088554263ad4850116a834b4256890',1),
(6,0,1795370028,1795370028,0,'7bff55dfa221c741a872a7fe8f6d6846',0),
(7,0,1795370029,1795370029,0,'380f64900637163993edf48d4dae7f63',0),
(8,0,1795370029,1795370029,0,'7ea6b9d738dae73d8b9c6d01898e7e03',0),
(9,0,1795370029,1795370029,0,'56679ee611f164e7be08ed67e3a232ab',0),
(10,0,1795370029,1795370029,0,'87a11cfaeff5f8ad6ffe1bd9d16eb897',0),
(11,0,1795370029,1795370029,0,'a0117466d46cb4d1cf0ae91551f5b459',0),
(12,0,1795370029,1795370029,0,'ad0c1e52ab6d90c15a766811b6bf1eaa',0),
(13,0,1795370030,1795370030,0,'447d2a37ef3dda3201a77b29098a6977',0),
(14,0,1795370030,1795370030,0,'452d533e9477514627d604360c8275d1',0),
(15,0,1795370031,1795370031,0,'b043a0f62e4b4f084a1eddedb80731c2',0),
(16,0,1795414596,1795414581,0,'37da35d4696e5e2004aa5a49dd2df81c',1);
/*!40000 ALTER TABLE `tx_typo3altcha_domain_model_challenge` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-24 15:52:25
